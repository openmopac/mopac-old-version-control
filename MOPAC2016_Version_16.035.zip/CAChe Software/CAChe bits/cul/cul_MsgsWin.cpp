/*
** cul_MsgsWin.cpp
*/
#include <windows.h>
#include <stdio.h>
#include <stdarg.h>

#include <ccl.h>
#include <ccl_Msgs.h>
#include <ComputeEngine.h>

#include "cul.h"

#undef DBPRINTF
#include "cul_Include.h"

int cul_shouldDiscardMsg(volatile struct cul_CPMsgChannel *const channel);

/*
** cul_sendCPMessage() -- Send a message; unreliable delivery
**
**	cul_sendCPMessage() attempts to send a message to a
**	coprocess. If for any reason the message cannot be sent
**	immediately, cul_sendCPMesage() returns an error. Any
**	message currently awaiting delivery will be discarded.
*/

cul_messageStatus
cul_sendCPMessage(volatile struct cul_CPMsgChannel *const channel,
	const char *const text)
{

	if (cul_shouldDiscardMsg(channel))
		return(CUL_MSGS_BUSY);

 	ComputeEngine *ce = (ComputeEngine *)(channel->m_ce);

	ce->Send_CEM_Status(channel->channelID, (char *)text, CCL_MSG_FLAGS_NONE);

	return(CUL_MSGS_SENT);

}

/*
** cul_sendCPMessageWait() -- Send a message; reliable delivery
**
**	cul_sendCPMessageWait() attempts to send a message to a
**	coprocess. If the message cannot be sent immediately,
**	cul_sendCPMesageWait() blocks.
*/

cul_messageStatus cul_sendCPMessageWait( volatile struct cul_CPMsgChannel *const channel,
                                         const char *const text,
                                         Boolean (*giveUp)() )
{
	ComputeEngine *ce = (ComputeEngine *)(channel->m_ce);

	ce->Send_CEM_Status(channel->channelID, (char *)text, CCL_MSG_FLAGS_BLOCKING);

	return(CUL_MSGS_SENT);
}

/*
** cul_printCPMessage() -- Send a formatted message; unreliable delivery
**
**	cul_printCPMessage() attempts to send a message to a
**	coprocess. If for any reason the message cannot be sent
**	immediately, cul_printCPMesage() returns an error. Any
**	message currently awaiting delivery will be discarded.
**	The message to be sent is described using a format
**	string and arguments of the printf() function.
**
** Note:
**
**	The caller must take responsibility to ensure that the
**	message will not overrun the buffer previously allocated
**	for the channel.
*/

cul_messageStatus
cul_printCPMessage(volatile struct cul_CPMsgChannel *const channel,
	const char *const format, ...)
{
	va_list nextArg;	/* variable argument list ptr */
	char *msgBufP;
	char msgBuf[CUL_MSG_BUF_SIZE];

	msgBufP = msgBuf;
	/* Set up for the message formatting operation */
	va_start(nextArg, format);
	/* Copy the data into the message buffer */
	(void) vsprintf(msgBufP, format, nextArg);
	/* Clean up after variable argument handling */
	va_end(nextArg);
	if (cul_shouldDiscardMsg(channel))
		return(CUL_MSGS_BUSY);
	
	ComputeEngine *ce = (ComputeEngine *)(channel->m_ce);

	ce->Send_CEM_Status(channel->channelID, msgBuf, CCL_MSG_FLAGS_NONE);

	return(CUL_MSGS_SENT);

}

/*
** cul_vprintCPMessage() -- Send a formatted message; unreliable delivery
**
**	cul_vprintCPMessage() attempts to send a message to a
**	coprocess. If for any reason the message cannot be sent
**	immediately, cul_vprintCPMesage() returns an error. Any
**	message currently awaiting delivery will be discarded.
**	The message to be sent is described using a format
**	string and arguments of the printf() function.
**
** Note:
**
**	The caller must call the va_start() function to set
**	up the 'nextArg' parameter before calling this function
**	and the va_end() function after this function returns.
**
**	The caller must take responsibility to ensure that the
**	message will not overrun the buffer previously allocated
**	for the channel.
*/

cul_messageStatus
cul_vprintCPMessage(volatile struct cul_CPMsgChannel *const channel,
	const char *const format, va_list nextArg)
{
	char *msgBufP;
	char msgBuf[CUL_MSG_BUF_SIZE];

	msgBufP = msgBuf;
	/* Copy the data into the message buffer */
	(void) vsprintf((char *) msgBufP, format, nextArg);

	if (cul_shouldDiscardMsg(channel))
		return(CUL_MSGS_BUSY);
	
	ComputeEngine *ce = (ComputeEngine *)(channel->m_ce);

	ce->Send_CEM_Status(channel->channelID, msgBuf, CCL_MSG_FLAGS_NONE);
	return(CUL_MSGS_SENT);

}

/*
** cul_printCPMessageWait() -- Send a formatted message; reliable delivery
**
**	cul_printCPMessageWait() attempts to send a message to a
**	coprocess. If the message cannot be sent immediately,
**	cul_printCPMessageWait() blocks.
**
**	The message to be sent is described using a format
**	string and arguments of the printf() function.
**
*/

cul_messageStatus cul_printCPMessageWait( volatile struct cul_CPMsgChannel *const channel,
                                          Boolean (*giveUp)(),
                                          const char *const format, ... )
{
	va_list nextArg;	/* variable argument list ptr */
	char *msgBufP;
	char msgBuf[CUL_MSG_BUF_SIZE];

	msgBufP = msgBuf;
	va_start(nextArg, format);
	/* Copy the data into the message buffer */
	(void) vsprintf(msgBufP, format, nextArg);
	/* Clean up after variable argument handling */
	va_end(nextArg);
	
	ComputeEngine *ce = (ComputeEngine *)(channel->m_ce);

	ce->Send_CEM_Status(channel->channelID, msgBuf, CCL_MSG_FLAGS_BLOCKING);

	return(CUL_MSGS_SENT);
}

#ifdef DEADCODE

This function compiles with an error under Mac OS X (BSD) because it references va_start yet it has
a fixed argument list.  Furthermore, this function does not appear to be referenced by any code
under wincache/src/Standalone.  Therefore, I have wrapped this function with a "#ifdef 0" directive.
/*
** cul_vprintCPMessageWait() -- Send a formatted message; reliable delivery
**
**	cul_vprintCPMessageWait() attempts to send a message to a
**	coprocess. If the message cannot be sent immediately,
**	cul_printCPMessageWait() blocks.
**
**	The message to be sent is described using a format
**	string and arguments of the vprintf() function.
**
** Notes:
**
**	The caller must call the va_start() function to set
**	up the 'nextArg' parameter before calling this function
**	and the va_end() function after this function returns.
**
**	The caller must take responsibility to ensure that the
**	message will not overrun the buffer previously allocated
**	for the channel.
*/

cul_messageStatus
cul_vprintCPMessageWait(volatile struct cul_CPMsgChannel
	*const channel, Boolean (*giveUp)(),
	const char *const format, va_list nextArg)
{
	char *msgBufP;
	char msgBuf[CUL_MSG_BUF_SIZE];

	msgBufP = msgBuf;
	/* Set up for the message formatting operation */
	va_start(nextArg, format);
	/* Copy the data into the message buffer */
	(void) vsprintf(msgBufP, format, nextArg);
	/* Clean up after variable argument handling */
	va_end(nextArg);
	
	ComputeEngine *ce = (ComputeEngine *)(channel->m_ce);

	ce->Send_CEM_Status(channel->channelID, msgBuf, CCL_MSG_FLAGS_BLOCKING);

	return(CUL_MSGS_SENT);
}

#endif

/*
** cul_initCPMessageChannel() -- Initialize a channel data structure
**
**	cul_initCPMessageChannel() must be called to initialize
**	an interprocessor channel data structure prior to its use.
**
** Returns 0 on success, -1 on error
**
** Note:
**
*/
int
cul_initCPMessageChannel(struct cul_CPMsgChannel *const channel,
	const unsigned char channelID, void *ce)
{
	channel->channelID = channelID;
	channel->m_ce = ce;
	return(0);
}

/*
** cul_destroyCPMessageChannel() -- Close a message channel
**
**	cul_destroyCPMessageChannel() must be called to close a
**	message channel. It waits for the buffer to empty, then
**	deletes all data structures/semaphores/whatever (implementation
**	dependent). Basically, it cleans up.
*/

void
cul_destroyCPMessageChannel(struct cul_CPMsgChannel *const channel)
{
}

/*
** cul_GetCPMsgChannelID() -- Returns the message channel ID
*/
unsigned long
cul_GetCPMsgChannelID(const struct cul_CPMsgChannel *const channel)
{
	return((unsigned long) (channel->channelID));
}

/*
** cul_shouldDiscardMsg() -- Returns non-zero if msg should be junked
**
**	cul_shouldDiscardMsg() returns true if insufficient time
**	has elapsed between the sending of messages on a discardable
**	channel. It is only used in the Unix environment.
*/
static unsigned int cul_MinMsgInterval = 60;
#define CUL_CA_TIME_IN_TICKS() ((GetTickCount() * 60) / 1000)

#define CUL_MSGS_INITIAL_CA_NUM 8
#define CUL_MSGS_INCR_CA_NUM 8

int
cul_shouldDiscardMsg(volatile struct cul_CPMsgChannel *const channel)
{
	struct ca
	{
		unsigned int numSlots;
		unsigned int numSlotsUsed;
		struct channelInfo
		{
			volatile struct cul_CPMsgChannel *channel;
			unsigned long lastMsgTime;
		} channelInfo[1]; /* number varies */
	};
	static struct ca *channelArray = 0;
	unsigned int i;
	/* Does the channel array exist? */
	if (channelArray == 0)	{
		/* No -- allocate and initialize it */
		channelArray = (struct ca*)calloc(offsetof(struct ca,
			channelInfo[CUL_MSGS_INITIAL_CA_NUM]), 1);
		/*
		** If the channel array could not be allocated,
		** indicate that the message should be printed.
		*/
		if (channelArray == 0)
			return(0);
		channelArray->numSlots = CUL_MSGS_INITIAL_CA_NUM;
	}
	/* Is the caller's channel in the channel array? */
	for (i = 0; i < channelArray->numSlotsUsed; i++)	{
		if (channelArray->channelInfo[i].channel == channel)
			break;
	}
	if (i == channelArray->numSlotsUsed)	{	/* no room -- add it */
		if (channelArray->numSlots == channelArray->numSlotsUsed) {
			channelArray = (struct ca*)realloc(channelArray, offsetof(struct ca,
				channelInfo[CUL_MSGS_INCR_CA_NUM +
				channelArray->numSlots]));
			/*
			** If the channel array could not be allocated,
			** indicate that the message should be printed.
			*/
			if (channelArray == 0)
				return(0);
			channelArray->numSlots = CUL_MSGS_INCR_CA_NUM +
					channelArray->numSlots;
		}
		/* Initialize channel timing info */
		channelArray->channelInfo[channelArray->numSlotsUsed].channel
			= channel;
		channelArray->channelInfo[channelArray->numSlotsUsed].lastMsgTime
			= CUL_CA_TIME_IN_TICKS();
		channelArray->numSlotsUsed++;
		return(0);	/* Always print 1st msg. on a channel */
	}
	/* Found it -- has enough time elapsed to send another msg? */
	if (channelArray->channelInfo[i].lastMsgTime +
		cul_MinMsgInterval > CUL_CA_TIME_IN_TICKS())
		return(1);
	channelArray->channelInfo[i].lastMsgTime
		= CUL_CA_TIME_IN_TICKS();
	return(0);
}
