/*
 * cul_CheckAbort.c -- functions to abort a Mac function
 */
 
#include <OSEvents.h>

#include "cul.h"
#include "cul_include.h"

#pragma segment culCheckAbortSeg


#if 0
/* For reference... */
struct EvQEl {
	QElemPtr qLink;
	short qType;
	short evtQWhat; 	/*this part is identical to the EventRecord as...*/
	long evtQMessage;	/*defined in ToolIntf*/
	long evtQWhen;
	Point evtQWhere;
	short evtQModifiers;
};

typedef struct EvQEl EvQEl;
typedef EvQEl *EvQElPtr;
#endif

/*
 * Scan the event queue for cmd-dots.
 * Returns true if cmd-dots are found, false if none are found.
 * Does not modify the event queue.
 */
Boolean
cul_CheckAbort(void)
{
	QHdrPtr eventQueueP;
	EvQElPtr q;
	Boolean last;
	Boolean found = false;

	eventQueueP = GetEvQHdr(); 
	q = (EvQElPtr) eventQueueP->qHead;
	if (q) {
		do {
			/* is it a cmd-dot ? */
			if ((q->evtQWhat == keyDown || q->evtQWhat == autoKey)
			 && (q->evtQModifiers & (cmdKey | shiftKey)) == cmdKey
			 && (q->evtQMessage & charCodeMask) == '.') {
				found = true;
			}
			last = (q == (EvQElPtr) eventQueueP->qTail); /* last event? */
			q = (EvQElPtr) q->qLink; /* next event */
		} while (!last);
	}
	return found;
}

/*
 * Scan the event queue for cmd-dots.
 * Returns true if cmd-dots are found, false if none are found.
 * Clears cmd-dot events in the queue (to null events) as they are found.
 */
Boolean
cul_CheckAbortClear(void)
{
	QHdrPtr eventQueueP;
	EvQElPtr q;
	Boolean last;
	Boolean found = false;

	eventQueueP = GetEvQHdr(); 
	q = (EvQElPtr) eventQueueP->qHead;
	if (q) {
		do {
			/* is it a cmd-dot ? */
			if ((q->evtQWhat == keyDown || q->evtQWhat == autoKey)
			 && (q->evtQModifiers & (cmdKey | shiftKey)) == cmdKey
			 && (q->evtQMessage & charCodeMask) == '.') {
				found = true;
				/* blast the event but leave in queue */
				q->evtQWhat = nullEvent;
			}
			last = (q == (EvQElPtr) eventQueueP->qTail); /* last event? */
			q = (EvQElPtr) q->qLink; /* next event */
		} while (!last);
	}
	return found;
}

