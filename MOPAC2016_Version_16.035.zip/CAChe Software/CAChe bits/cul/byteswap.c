/*
** byteswap.c -- Code to swap bytes
**
** The routines in this file swap bytes in various size data items
** to allow data to be moved among machines with differing native
** byte orders.
*/

#include "cul.h"

/*
** This cul_convMode token is used to convert incomming network
** data to native format.
*/

const cul_convMode cul_NetworkSrc =
{
	CUL_INTFMT_BIGENDIEN, CUL_FPFMT_IEEE754BIGENDIEN
};

/* read longs */
culErr
cul_rdcnvlong(cul_convMode convmode, long *const where,
	const size_t wanted, size_t *const got, FILE *fp)
{
	if ((*got = fread((void *) where, sizeof(*where), wanted, fp)) == 0)
	{
		if (feof(fp))
			return(CUL_STDIO_EOF);

		return(CUL_STDIO_ERROR);
	}
	return(cul_icnvlong(convmode, (void *) where, *got));
}

/* read shorts */

culErr
cul_rdcnvshort(cul_convMode convmode, short *const where,
	const size_t wanted, size_t *const got, FILE *fp)
{
	if ((*got = fread((void *) where, sizeof(*where), wanted, fp)) == 0)
	{
		if (feof(fp))
			return(CUL_STDIO_EOF);

		return(CUL_STDIO_ERROR);
	}

	return(cul_icnvshort(convmode, (void *) where, *got));
}

/* read the hack of scaled 3-byte ints */

culErr
cul_rdcnv3int(cul_convMode convmode, long *const where,
	const size_t wanted, size_t *const got, FILE *fp)
{
	size_t i, num_read = 0;
	unsigned long value;
	culErr rc;

	*got = 0;

	for (i = 0; i < wanted; i++)
	{
		size_t result;

		value = 0;
		result = fread((void *) &value, 3, 1, fp);

		if (result == 0)
		{
			if (feof(fp))
			{
				/* If nothing have been read, treat as end of file */

				if (num_read == 0)
					return(CUL_STDIO_EOF);

				else
					/* If some values have been read, convert them */
					break;
			}
	
			return(CUL_STDIO_ERROR);
		}

		if (convmode.intCode == CUL_INTFMT_SMALLENDIEN)
		{
#if (CUL_INTFMT == CUL_INTFMT_BIGENDIEN)
			value >>= 8;	/* shift into low order bytes of long (zero fill) */

#elif (CUL_INTFMT == CUL_INTFMT_SMALLENDIEN)
			value <<= 8;	/* shift into high order bytes of long (zero fill) */

#else
#error "CUL_INTFMT not set or set incorrectly"

#endif
		}

		where[num_read++] = value;	/* load value into caller's buffer */
	} /* for... */

	/* swap byte order, if necessary */

	if ((rc = cul_icnvlong(convmode, (void *) where, num_read)) != 0)
		return(rc);

	*got = num_read;

	return(0);
}

/* read floats */
culErr
cul_rdcnvfloat(cul_convMode convmode, float *const where,
	const size_t wanted, size_t *const got, FILE *fp)
{
	if ((*got = fread((void *) where, sizeof(*where), wanted, fp)) == 0)
	{
		if (feof(fp))
			return(CUL_STDIO_EOF);

		return(CUL_STDIO_ERROR);
	}

	return(cul_icnvfloat(convmode, (void *) where, *got));
}

/* read doubles */
culErr
cul_rdcnvdouble(cul_convMode convmode, double *const where,
	const size_t wanted, size_t *const got, FILE *fp)
{
	if ((*got = fread((void *) where, sizeof(*where), wanted, fp)) == 0)
	{
		if (feof(fp))
			return(CUL_STDIO_EOF);

		return(CUL_STDIO_ERROR);
	}

	return(cul_icnvdouble(convmode, (void *) where, *got));
}

/* convert longs to native format */
culErr
cul_icnvlong(cul_convMode convmode, long *const where,
	const unsigned long count)
{
	switch (convmode.intCode)
	{

#if (CUL_INTFMT == CUL_INTFMT_BIGENDIEN)

		case CUL_INTFMT_BIGENDIEN:

			return(0);

		case CUL_INTFMT_SMALLENDIEN:
		{
			unsigned long i;

			for (i = 0; i < count; i++)
				CUL_LONGSWAP(where[i]);

			break;
		}

#elif (CUL_INTFMT == CUL_INTFMT_SMALLENDIEN)

		case CUL_INTFMT_BIGENDIEN:
		{
			unsigned long i;

			for (i = 0; i < count; i++)
				CUL_LONGSWAP(where[i]);

			break;
		}

		case CUL_INTFMT_SMALLENDIEN:

			return(0);

#else
#error "CUL_INTFMT not set or set incorrectly"

#endif

		default:

			return(CUL_BAD_CONVMODE);
	}

	return(0);
}

/* convert shorts to native format */
culErr
cul_icnvshort(cul_convMode convmode, short *const where,
	const unsigned long count)
{
	switch (convmode.intCode)
	{

#if (CUL_INTFMT == CUL_INTFMT_BIGENDIEN)

		case CUL_INTFMT_BIGENDIEN:

			return(0);

		case CUL_INTFMT_SMALLENDIEN:
		{
			unsigned long i;

			for (i = 0; i < count; i++)
				CUL_SHORTSWAP(where[i]);

			break;
		}

#elif (CUL_INTFMT == CUL_INTFMT_SMALLENDIEN)

		case CUL_INTFMT_BIGENDIEN:
		{
			unsigned long i;

			for (i = 0; i < count; i++)
				CUL_SHORTSWAP(where[i]);

			break;
		}

		case CUL_INTFMT_SMALLENDIEN:

			return(0);

#else
#error "CUL_INTFMT not set or set incorrectly"

#endif

		default:

			return(CUL_BAD_CONVMODE);
	}

	return(0);
}

/* convert floats to native format */
culErr
cul_icnvfloat(cul_convMode convmode, float *const where,
	const unsigned long count)
{
	switch (convmode.fpCode)
	{

#if (CUL_FPFMT == CUL_FPFMT_IEEE754BIGENDIEN)

		case CUL_FPFMT_IEEE754BIGENDIEN:

			return(0);

		case CUL_FPFMT_IEEE754SMALLENDIEN:
		{
			unsigned long i;

			for (i = 0; i < count; i++)
				CUL_LONGSWAP(where[i]);

			break;
		}

#elif (CUL_FPFMT == CUL_FPFMT_IEEE754SMALLENDIEN)

		case CUL_INTFMT_BIGENDIEN:
		{
			unsigned long i;

			for (i = 0; i < count; i++)
				CUL_LONGSWAP(where[i]);

			break;
		}

		case CUL_FPFMT_IEEE754SMALLENDIEN:

			return(0);

#else
#error "CUL_FPFMT not set or set incorrectly"

#endif

		default:

			return(CUL_BAD_CONVMODE);
	}

	return(0);
}

/* convert doubles to native format */
culErr
cul_icnvdouble(cul_convMode convmode, double *const where,
	const unsigned long count)
{

	switch (convmode.fpCode)
	{

#if (CUL_FPFMT == CUL_FPFMT_IEEE754BIGENDIEN)

		case CUL_FPFMT_IEEE754BIGENDIEN:

			return(0);

		case CUL_FPFMT_IEEE754SMALLENDIEN:
		{
			unsigned long i;

			for (i = 0; i < count; i++)
				CUL_DOUBLESWAP(where[i]);

			break;
		}

#elif (CUL_FPFMT == CUL_FPFMT_IEEE754SMALLENDIEN)

		case CUL_INTFMT_BIGENDIEN:
		{
			unsigned long i;

			for (i = 0; i < count; i++)
				CUL_DOUBLESWAP(where[i]);

			break;
		}

		case CUL_FPFMT_IEEE754SMALLENDIEN:

			return(0);

#else
#error "CUL_FPFMT not set or set incorrectly"

#endif

		default:

			return(CUL_BAD_CONVMODE);
	}

	return(0);
}

/* convert longs to network format */
culErr cul_ecnvlong(long *const where, const unsigned long count)
{
#if (CUL_INTFMT == CUL_INTFMT_BIGENDIEN)
#pragma unused(where, count, i)
#elif (CUL_INTFMT == CUL_INTFMT_SMALLENDIEN)
	unsigned long i;
	for (i = 0; i < count; i++)
		CUL_LONGSWAP(where[i]);
#else
#error "CUL_INTFMT not set or set incorrectly"
#endif

	return(0);
}

/* convert shorts to network format */
culErr cul_ecnvshort(short *const where, const unsigned long count)
{
#if (CUL_INTFMT == CUL_INTFMT_BIGENDIEN)
#pragma unused(where, count, i)
#elif (CUL_INTFMT == CUL_INTFMT_SMALLENDIEN)
	unsigned long i;
	for (i = 0; i < count; i++)
		CUL_SHORTSWAP(where[i]);
#else
#error "CUL_INTFMT not set or set incorrectly"
#endif

	return(0);
}

/* convert floats to network format */
culErr cul_ecnvfloat(float *const where, const unsigned long count)
{
#if (CUL_FPFMT == CUL_FPFMT_IEEE754BIGENDIEN)
#pragma unused(where, count, i)
#elif (CUL_FPFMT == CUL_FPFMT_IEEE754SMALLENDIEN)
	unsigned long i;
	for (i = 0; i < count; i++)
		CUL_LONGSWAP(where[i]);
#else
#error "CUL_FPFMT not set or set incorrectly"
#endif

	return(0);
}

/* convert doubles to network format */
culErr cul_ecnvdouble(double *const where, const unsigned long count)
{
#if (CUL_FPFMT == CUL_FPFMT_IEEE754BIGENDIEN)
#pragma unused(where, count, i)
#elif (CUL_FPFMT == CUL_FPFMT_IEEE754SMALLENDIEN)
	unsigned long i;
	for (i = 0; i < count; i++)
		CUL_DOUBLESWAP(where[i]);
#else
#error "CUL_FPFMT not set or set incorrectly"
#endif

	return(0);
}

/* initialize a cul_convMode token */
culErr cul_makeConvMode(cul_convMode *const my_convMode, const cul_convCode intCode, const cul_convCode fpCode)
{
	my_convMode->intCode = intCode;
	my_convMode->fpCode = fpCode;
	
	return(0);
}
