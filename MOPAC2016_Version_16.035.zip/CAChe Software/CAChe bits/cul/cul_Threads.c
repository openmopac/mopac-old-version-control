/*
**	cul_Threads.c -- helper routines for the Mac thread manager
*/

#include <Types.h>
#include <Memory.h>
#include <stddef.h>
#include <SegLoad.h>
#include <OSUtils.h>
#include <String.h>
#include <Errors.h>
#include <GestaltEqu.h>
#include <ToolUtils.h>
#include <stdio.h>

#include "cul_Include.h"
#include "cul_Threads.h"

#define CUL_SEMAPHORE_DELETE_PENDING 1

#define CUL_THREAD_FROM_SEMWAITLINK(semPtr) ((cul_ThreadPtr) \
	((char *) semPtr - offsetof(cul_Thread, semWaitList)))

#define CUL_THREAD_FROM_HELDLINK(semPtr) ((cul_ThreadPtr) \
	((char *) (semPtr) - offsetof(cul_Thread, semHeldList)))

#define CUL_THREAD_FROM_CHILDLINK(threadPtr) ((cul_ThreadPtr) \
	((char *) (threadPtr) - offsetof(cul_Thread, siblingList)))

#define CUL_THREAD_FROM_MASTERLINK(threadPtr) ((cul_ThreadPtr) \
	((char *) (threadPtr) - offsetof(cul_Thread, masterList)))

#define CUL_SEMAPHORE_FROM_SEMHELDLINK(semPtr) ((cul_ThreadSemaphorePtr) \
	((char *) (semPtr) - offsetof(cul_ThreadSemaphore, semHeldList)))

/*
** The following structure is used as the head of a linked-list of
** cul_Threads. This allows one to wait on all threads, rather than
** just the child threads.
*/

static volatile cul_Thread cul_ThreadListHead;

static volatile cul_ThreadPtr cul_CurrentThread = 0;

static unsigned long cul_ThreadSeq = 1;

#define CUL_THREAD_MAGIC_NUM '$thd'
#define CUL_THREADSEM_MAGIC_NUM '$tsm'

pascal void cul_ThreadInSwitch(ThreadID threadID, cul_ThreadPtr threadP);
pascal void cul_ThreadOutSwitch(ThreadID threadID, cul_ThreadPtr threadP);
pascal void cul_ThreadEnd(ThreadID threadID, cul_ThreadPtr threadP);

static void cul_DisposeThread(cul_ThreadPtr deadThread);
static OSErr cul_SetThreadState(cul_ThreadPtr threadP,
	const ThreadState newState);
static cul_ThreadPtr *cul_getCurrentThreadPtr(void);

/* Mac segmentation directive */

#pragma segment Seg_CUL_IP

/*
** cul_NewThread()
**
**	cul_NewThread() creates a new thread in a manner similar to
**	the NewThread() system call. I returns a pointer to a
**	thread control structure which is used to identify the thread
**	to other cul thread control routines. Threads created with
**	this call should call the system thread management routines
**	on themselves or other cul threads. Use cul thread management
**	functions.
*/

OSErr
cul_NewThread(ThreadStyle threadStyle, ThreadEntryProcPtr threadEntry,
	void *threadParam, Size stackSize, ThreadOptions options,
	cul_Thread **threadMade)
{
	OSErr err;

	/*
	** Does the thread linked-list control structure need to
	** be initialized?
	*/

	if (cul_CurrentThread == 0)
	{
		err = cul_InitThreads();
		if (err != noErr) return(err);
	}
		
	/* Allocate a cul_Thread control structure */

	if ((*threadMade = (cul_Thread *) NewPtrClear(sizeof(cul_Thread)))
		== 0)
		return(MemError());

	/*
	** Don't allow the new thread to begin execution until
	** its control structure is filled in. Don't allow any
	** other threads to run while the linked lists are being
	** manipulated.
	*/

	ThreadBeginCritical();

	/* Call the "system" to create a thread */

	if ((err = NewThread(threadStyle, threadEntry, threadParam,
		stackSize, options, &(*threadMade)->threadResult,
		&(*threadMade)->threadID)) != noErr)
	{
		DisposePtr((Ptr) *threadMade);
		*threadMade = 0;
		return(err);
	}

	/* Link it into the master thread list */
	
	(*threadMade)->masterList.next
		= cul_ThreadListHead.masterList.next;
	if (cul_ThreadListHead.masterList.next != 0)
		cul_ThreadListHead.masterList.next->prev
			= &(*threadMade)->masterList;
	(*threadMade)->masterList.prev = &cul_ThreadListHead.masterList;
	cul_ThreadListHead.masterList.next = &(*threadMade)->masterList;

	/* Link it into the sibling-thread list */

	(*threadMade)->siblingList.next
		= cul_CurrentThread->childListHead.next;
	if (cul_CurrentThread->childListHead.next != 0)
		cul_CurrentThread->childListHead.next->prev
			= &(*threadMade)->siblingList;
	/* note: (*threadMade)->siblingList.prev must remain zero */
	(*threadMade)->siblingList.prev = &cul_CurrentThread->childListHead;
	cul_CurrentThread->childListHead.next = &(*threadMade)->siblingList;

	/* Get a pointer to the commonly-needed cul_CurrentThread global */

	(*threadMade)->cul_CurrentThread = &cul_CurrentThread;	/* pointer to current-thread global */

	/* Set the parent pointer */

	(*threadMade)->parent = cul_CurrentThread;

#ifndef CACHE_PPC
	(*threadMade)->appA5 = SetCurrentA5();	/* application's A5 register */
#endif

	/* Put in some checking information for defensive programming */

	(*threadMade)->magic = CUL_THREAD_MAGIC_NUM;
	(*threadMade)->seq = cul_ThreadSeq++;

	SetThreadSwitcher((*threadMade)->threadID,
		cul_ThreadInSwitch, *threadMade, true);

	SetThreadSwitcher((*threadMade)->threadID,
		cul_ThreadOutSwitch, *threadMade, false);

	SetThreadTerminator((*threadMade)->threadID,
		cul_ThreadEnd, *threadMade);

	(*threadMade)->state = ((options & kNewSuspend) ? stopped : ready);

	ThreadEndCritical();

	return(noErr);
}

/*
** cul_InitThreads()
**
**	This routine should be called from the main application
**	thread in order to initialize the cul threads library.
**	Failure to do so will result in it automatically being
**	called by the cul_NewThread() routine, but this is not
**	necessarily reliable.
*/

OSErr
cul_InitThreads(void)
{
	static cul_Thread mainThread;
	OSErr	err = noErr;
	long	threadret = 0;

	/* Determine if threads manager is installed */
	err = Gestalt(gestaltThreadMgrAttr, &threadret);
	if (err != noErr) return(err);
	/* Ideally there would be a specific error code. */
	if (!BitTst(&threadret, 31-gestaltThreadMgrPresent)) return(threadProtocolErr);

	memset(&mainThread, 0, sizeof(mainThread));

	ThreadBeginCritical();

	if (cul_CurrentThread == 0)
	{
		cul_CurrentThread = &cul_ThreadListHead;
		(void) GetCurrentThread(&cul_CurrentThread->threadID);
		cul_CurrentThread->magic = CUL_THREAD_MAGIC_NUM;
		cul_CurrentThread->seq = cul_ThreadSeq++;
		cul_CurrentThread->state = ready;
#ifndef CACHE_PPC
		cul_CurrentThread->appA5 = SetCurrentA5();
#endif
		/*
		** Install routines to switch the main thread cul context
		** in an out.
		*/

		SetThreadSwitcher(cul_CurrentThread->threadID,
			cul_ThreadInSwitch, &cul_ThreadListHead, true);
	
		SetThreadSwitcher(cul_CurrentThread->threadID,
			cul_ThreadOutSwitch, &cul_ThreadListHead, false);
	}

	ThreadEndCritical();
	
	return(noErr);
}

/*
** cul_WaitThread() -- Wait for a child / all children to terminate
**
**	cul_WaitThread() cleans up after children which have died. It
**	recovers the useful information to pass back to the caller,
**	then disposes of the control structure. If *thread points to
**	a cul_ThreadPtr which has been set to null, then the routine
**	will attempt to find any child which has died and clean up after
**	it. The pointer to the dead child's control structure (which
**	has been freed!) is returned to indicate which child died.
**	If *thread points to a cul_ThreadPtr of a child thread, only
**	that child will be waited for.
**
**	If the specified child doesn't exist, threadNotFoundErr will be
**	returned. If there are no children, procNotFound will be
**	returned.
*/

OSErr
cul_WaitThread(cul_ThreadPtr *thread, void **threadResult,
	unsigned long options)
{
	OSErr err;

	/* Are there any children on which to wait? */

	if (cul_CurrentThread->childListHead.next == 0)
		return(procNotFound);	/* no */

	/* Check for a common error -- a null pointer for parameter thread */

	if (thread == 0)
	{
		DBPRINTF(("cul_WaitThread(): Prgm error: null thread param\n"));
		return(paramErr);
	}

	/* Make sure we're not waiting on ourself */

	if (*thread == cul_CurrentThread)
		return(threadProtocolErr);

	ThreadBeginCritical();

	do
	{
		cul_ThreadPtr deadThread;

		deadThread = 0;

		if (*thread != 0)
		{
			cul_ThreadPtr childThreadP;
			cul_ThreadLinkPtr child;

			/* Validate the requested thread pointer */

			if ((*thread)->magic != CUL_THREAD_MAGIC_NUM)
			{
				DBPRINTF(("Attempt to wait on invalid thread ptr from"
					" thread seq# %lu\n", cul_CurrentThread->seq));
				ThreadEndCritical();
				return(paramErr);
			}

			/* Find the requested child */

			for (child = cul_CurrentThread->childListHead.next;
				child != 0; child = child->next)
			{
				childThreadP = CUL_THREAD_FROM_CHILDLINK(child);

				if (childThreadP == *thread)
				{
					break;
				}
			}

			/* Was the requested child found? */

			if (child == 0)
			{
				/* no */

				ThreadEndCritical();
				return(threadNotFoundErr);
			}

			/* Is the thread dead? */

			if (childThreadP->state == zombie)
			{
				deadThread = childThreadP;
			}
		}

		else	/* search for any deceased children */
		{
			cul_ThreadPtr childThreadP;
			cul_ThreadLinkPtr child;

			/* Find any dead child */

			for (child = cul_CurrentThread->childListHead.next;
				child != 0; child = child->next)
			{
				childThreadP = CUL_THREAD_FROM_CHILDLINK(child);

				if (childThreadP->state == zombie)
				{
					deadThread = childThreadP;
					break;
				}
			}
		}

		/* Was a deceased child found? */

		if (deadThread != 0)
		{
			/* yes -- return the useful information to the parent */

			DBPRINTF(("Reaping child thread %lu\n; g", deadThread->seq));

			if (threadResult)	/* if caller supplied a location... */
				*threadResult = deadThread->threadResult;
			*thread = deadThread;

			/* unlink and free the thread control structure */

			DBPRINTF(("cul_WaitThread() about to dispose of %lu "
				"from %lu\n; g",
				deadThread->seq, cul_CurrentThread->seq));
			cul_DisposeThread(deadThread);

			ThreadEndCritical();

			return(noErr);
		}

		/* If we should block... */

		if (!(options & CUL_THREAD_NO_BLOCK))
		{
			/* Indicate to children that the parent thread is waiting */

			cul_CurrentThread->state = waiting;

			/*
			** Let other threads run -- one of our children
			** will wake us as he dies
			*/

			if ((err = SetThreadStateEndCritical(kCurrentThreadID,
				kStoppedThreadState, kNoThreadID)) != 0)
			{
				/* Serious programming error -- may not be recoverable */

				/*
				** The next call is dangerous. Did the
				** SetThreadStateEndCritical() routine decrement
				** the critical-section counter? There's no way to
				** know. Since leaving the system in a state where
				** it thinks it's in a critical section seems worse
				** than potentially releasing another critical
				** section, issue a ThreadEndCritical() call and
				** hope for the best.
				*/
		
				cul_CurrentThread->state = ready;

				ThreadEndCritical();	/* allow other threads to run */
				*thread = 0;
				DBPRINTF(("Programming error in cul_WaitThread()\n"));
				return(err);
			}

			ThreadBeginCritical();

			cul_CurrentThread->state = ready;
		}

		/*
		** Continue to loop while children exist if the wait()
		** should block.
		*/

	} while ((cul_CurrentThread->childListHead.next != 0)
		&& !(options & CUL_THREAD_NO_BLOCK));

	ThreadEndCritical();

	/*
	** If there are still children alive or zombied, return
	** a threadNotFoundErr. Otherwise, return a procNotFound error.
	*/

	return(cul_CurrentThread->childListHead.next != 0 ?
		threadNotFoundErr : procNotFound);
}

/*
** cul_FreezeThread() -- Mark a thread as unrunnable
**
**	cul_FreezeThread() puts the specified thread into an unrunnable
**	state. The thread will remain unrunnable until it is operated
**	on by cul_ThawThread().
*/

OSErr
cul_FreezeThread(cul_ThreadPtr threadP)
{
	return(cul_SetThreadState(threadP, kStoppedThreadState));
}

/*
** cul_ThawThread() -- Mark a thread as runnable
**
**	cul_ThawThread() puts the specified thread into a runnable
**	state. It undoes the work of cul_FreezeThread().
*/

OSErr
cul_ThawThread(cul_ThreadPtr threadP)
{
	return(cul_SetThreadState(threadP, kReadyThreadState));
}

static OSErr
cul_SetThreadState(cul_ThreadPtr threadP, const ThreadState newState)
{
	OSErr err;

	ThreadBeginCritical();

	/* Is the thread pointer valid */

	if (threadP->magic != CUL_THREAD_MAGIC_NUM)
	{
		ThreadEndCritical();
		return(paramErr);
	}

	/* Is the thread still alive? */

	if (threadP->state == zombie)
	{
		/* No -- return a thread not found error */

		ThreadEndCritical();
		return(threadNotFoundErr);
	}

	/* Handle the request based on type and current state of thread */

	switch (newState)
	{
		case kReadyThreadState:

			if ((threadP->state != stopped)
				&& (threadP->state != blockedStopped)
				&& (threadP->state != ready)) /* OK to re-ready */
			{
				ThreadEndCritical();
				return(threadProtocolErr);
			}

			/*
			** If the thread was frozen in a blocked state, mark
			** it as blocked. Otherwise, thaw it.
			*/

			if (threadP->state == blockedStopped)
				threadP->state = blocked;

			else
			{
				if ((err = SetThreadState(threadP->threadID,
					kReadyThreadState, kCurrentThreadID)) != noErr)
				{
					ThreadEndCritical();
					return(err);
				}
				
				threadP->state = ready;
			}

			break;

		case kStoppedThreadState:

			if ((threadP->state != ready)
				&& (threadP->state != waiting)
				&& (threadP->state != blocked)
				&& (threadP->state != blockedStopped)
				&& (threadP->state != stopped))	/* OK to re-stop */
			{
				ThreadEndCritical();
				return(threadProtocolErr);
			}

			/*
			** If the thread is already blocked, just mark it as
			** blockedStopped. The thread manager has already been
			** instructed not to schedule it. Otherwise, mark it
			** blocked and instruct the thread manager not to run it.
			*/

			if ((threadP->state == blocked)
				|| (threadP->state == blockedStopped))
			{
				threadP->state = blockedStopped;
			}
	
			else
			{
				enum cul_ThreadState oldstate = threadP->state;
				
				threadP->state = stopped;
				if ((err = SetThreadStateEndCritical(threadP->threadID,
					kStoppedThreadState, kNoThreadID)) != noErr)
				{
					threadP->state = oldstate;
					ThreadEndCritical();
					return(err);
				}
				ThreadBeginCritical(); /* To match the end critical below */
			}

			break;

		default:

			DBPRINTF(("Programmer error: invalid state in "
				"cul_SetThreadState()\n"));
			ThreadEndCritical();
			return(paramErr);
			break;
	}

	ThreadEndCritical();

	return(noErr);
}

/*
** cul_IsThreadFrozen() -- Determines whether thread was stopped by programmer
**
**	cul_IsThreadFrozen() returns true if the specified thread was stopped
**	by a call to cul_FreezeThread(), or was frozen during creation.
**	Otherwise, it returns false.
*/

Boolean
cul_IsThreadFrozen(cul_ThreadPtr threadP)
{
	/* Check validity of thread */

	if (threadP == 0 || threadP->magic != CUL_THREAD_MAGIC_NUM)
	{
		return(false);
	}

	if (threadP->state == blocked || threadP->state == blockedStopped)
		return(true);

	return(false);
}

/*
** cul_DisposeThread() -- Dispose of an unneeded thread
**
**	This routine is disposes of a cul thread. It should only
**	be called by other cul library routines.
*/

static void
cul_DisposeThread(cul_ThreadPtr deadThread)
{
	cul_ThreadLinkPtr tlP;
	cul_SemLinkPtr semLinkP;

#ifdef DEBUG
{
DBPRINTF(("Disposing of seq # %lu\n; g", deadThread->seq));
if (deadThread->parent)
DBPRINTF((
	"parent %lu, "
	" ml.next 0x%08lx, ml.prev 0x%08lx,\n"
	" semHeldList 0x%08lx,\n"
	" semWaitList.next 0x%08lx, semWaitList.prev 0x%08lx,\n"
	" CLHead.next 0x%08lx, CLHead.prev 0x%08lx,\n"
	" SList.next 0x%08lx, SList.prev 0x%08lx\n; g",
	deadThread->parent->seq,
	deadThread->masterList.next, deadThread->masterList.prev,
	deadThread->semHeldList.next,
	deadThread->semWaitList.next, deadThread->semWaitList.prev,
	deadThread->childListHead.next, deadThread->childListHead.prev,
	deadThread->siblingList.next, deadThread->siblingList.prev));
else
DBPRINTF((
	"no parent, "
	" ml.next 0x%08lx, ml.prev 0x%08lx,\n"
	" semHeldList 0x%08lx,\n"
	" semWaitList.next 0x%08lx, semWaitList.prev 0x%08lx,\n"
	" CLHead.next 0x%08lx, CLHead.prev 0x%08lx,\n"
	" SList.next 0x%08lx, SList.prev 0x%08lx\n; g",
	deadThread->masterList.next, deadThread->masterList.prev,
	deadThread->semHeldList.next,
	deadThread->semWaitList.next, deadThread->semWaitList.prev,
	deadThread->childListHead.next, deadThread->childListHead.prev,
	deadThread->siblingList.next, deadThread->siblingList.prev));
}
#endif /* DEBUG */

	/* Check validity of thread */

	if (deadThread->magic != CUL_THREAD_MAGIC_NUM)
	{
		DBPRINTF(("Attempt to dispose of invalid thread pointer\n"));
		return;
	}
DBPRINTF(("Unlinking thread from master list\n; g"));

	/* Unlink the thread from the master thread list */

	if (deadThread->masterList.prev != 0)
		deadThread->masterList.prev->next
			= deadThread->masterList.next;

	if (deadThread->masterList.next != 0)
		deadThread->masterList.next->prev
			= deadThread->masterList.prev;

	/* Unlink the thread from the sibling thread list of parent */
DBPRINTF(("Unlinking thread from parent's sibling list\n; g"));

	if (deadThread->siblingList.prev != 0)
		deadThread->siblingList.prev->next
			= deadThread->siblingList.next;

	if (deadThread->siblingList.next != 0)
		deadThread->siblingList.next->prev
			= deadThread->siblingList.prev;

	/* Orphan any children (traverses the sibling list) */
DBPRINTF(("Orphaning children\n; g"));

	for (tlP = deadThread->childListHead.next; tlP != 0;)
	{
		cul_ThreadLinkPtr tmp;
		cul_ThreadPtr thread;

		thread = CUL_THREAD_FROM_CHILDLINK(tlP);
		thread->parent = 0;
		tmp = tlP->next;	/* do this before wiping out info */
		tlP->next = tlP->prev = 0;
		tlP = tmp;
	}

	/*
	** Remove thread from the semaphore wait queue
	**
	** Note that there is no need to worry about whether the
	** semaphore has a delete operation pending, since, if
	** it's on this list, another thread currently owns it.
	** If no other thread is waiting on it, it will be deleted
	** when the owning thread is done with it.
	*/

DBPRINTF(("About to unlink thread from semaphore wait queues\n; g"));
	if (deadThread->semWaitList.prev != 0)
	{
		deadThread->semWaitList.prev->next =
			deadThread->semWaitList.next;
	}

	if (deadThread->semWaitList.next != 0)
	{
		deadThread->semWaitList.next->prev =
			deadThread->semWaitList.prev;
	}
DBPRINTF(("About to release held semaphores\n; g"));

	/*
	** Release any semaphores held by this thread
	**
	** Because the cul_ThreadSemaphoreV() routine removes the
	** requested entry from the semHeldList list, the
	** next entry which needs to be removed is always at the
	** head of the list.
	*/

	while ((semLinkP = deadThread->semHeldList.next) != 0)
	{
		cul_ThreadSemaphoreV(CUL_SEMAPHORE_FROM_SEMHELDLINK(semLinkP));
	}
DBPRINTF(("About to clear thread control structure\n; g"));

	memset(deadThread, ~0, sizeof(deadThread));	/* defensive programming */

	DisposePtr((Ptr) deadThread);

	ThreadEndCritical();
}

/*
** cul_ThreadSemaphoreP() -- Acquire a cul semaphore
**
**	cul_ThreadSemaphoreP() attempts to acquire a cul semaphore.
**	If the semaphore is in use by another thread, the process
**	can continue or block, depending on the value passed in
**	the options parameter.
*/

OSErr
cul_ThreadSemaphoreP(cul_ThreadSemaphorePtr semaphoreP, long options)
{
	OSErr rc;

	ThreadBeginCritical();
	DBPRINTF(("Entering cul_ThreadSemaphoreP() %lu\n; g",
		cul_CurrentThread->seq));

	/* Is the semaphore valid? */

	if (semaphoreP->magic != CUL_THREADSEM_MAGIC_NUM)
	{
		/* No */

		DBPRINTF(("Invalid semaphore passed to cul_ThreadSemaphoreP() %lu\n",
			cul_CurrentThread->seq));
		ThreadEndCritical();
		return(paramErr);
	}

	/* Is the semaphore awaiting deletion? */

	if (semaphoreP->flags & CUL_SEMAPHORE_DELETE_PENDING)
	{
		/* Yes -- return an error indication */

		DBPRINTF(("Error exit from cul_ThreadSemaphoreP() %lu\n",
			cul_CurrentThread->seq));
		ThreadEndCritical();
		return(paramErr);
	}

	/*
	** If the semaphore is held by another thread and the caller
	** doesn't want to wait for it...
	*/

	if ((semaphoreP->value == 0)
		&& (options & CUL_SEMAPHORES_NOBLOCK))
	{
		ThreadEndCritical();
		return(fBsyErr);
	}

	/* If the semaphore is available... */

	if (semaphoreP->value != 0)
	{
		/* Give it to the requester */

		semaphoreP->value = 0;

		rc = noErr;
	}

	else
	{
		/* Queue the request */

		cul_SemLinkPtr last;

		/* Find the end of the queue */
		
		for (last = &semaphoreP->semWaitList;
			last->next != 0;
			last = last->next)
		{
			/* the for() loop does all the work */ ;
		}

		/* Add the current thread to the end */

		//if (last != &semaphoreP->semWaitList)
			cul_CurrentThread->semWaitList.prev = last;
		//else
		//	cul_CurrentThread->semWaitList.prev = 0;

		last->next = &cul_CurrentThread->semWaitList;
		cul_CurrentThread->semWaitList.next = 0;	/* for safety */

		/* Suspend execution until the semaphore becomes available */

		cul_CurrentThread->state = blocked;

		if ((rc =
			SetThreadStateEndCritical(cul_CurrentThread->threadID,
			kStoppedThreadState, kNoThreadID)) != noErr)
		{
			cul_CurrentThread->state = ready;
			/* Did above call aready do this on failure? */
			ThreadEndCritical();
			DBPRINTF(("Error exit from cul_ThreadSemaphoreP() %lu\n",
				cul_CurrentThread->seq));
			return(rc);
		}

		ThreadBeginCritical();

		/*
		** The cul_ThreadSemaphoreV() routine will eventually
		** wake this thread.
		*/
		
		cul_CurrentThread->state = ready;

		rc = noErr;
	}

	/*
	** Link semaphore into the list of semaphores
	** held by this thread
	*/

	semaphoreP->semHeldList.next
		= cul_CurrentThread->semHeldList.next;
	semaphoreP->semHeldList.prev = &cul_CurrentThread->semHeldList;
	if (cul_CurrentThread->semHeldList.next)
		cul_CurrentThread->semHeldList.next->prev
			= &semaphoreP->semHeldList;
	cul_CurrentThread->semHeldList.next = &semaphoreP->semHeldList;

	ThreadEndCritical();

	/*
	** Note: When execution gets here the effects of all
	** ThreadBeginCritical() calls made by this routine must
	** have been undone!
	*/ 

	DBPRINTF(("Normal exit from cul_ThreadSemaphoreP() %lu\n; g",
		cul_CurrentThread->seq));
	return(rc);
}

/*
** cul_ThreadSemaphoreV() -- Release a semaphore
**
**	cul_ThreadSemaphoreV() releases a previously-acquired semaphore.
**	If any threads are waiting on this semaphore, the first one
**	is allowed to proceed. If no threads are waiting on the semaphore,
**	and it has been scheduled for deletion (see the
**	cul_DisposeThreadSemaphore() routine description), the semaphore
**	will be deleted.
*/

OSErr
cul_ThreadSemaphoreV(cul_ThreadSemaphorePtr semaphoreP)
{
	OSErr err;
	cul_SemLinkPtr semP;

	ThreadBeginCritical();
	DBPRINTF(("Entering cul_ThreadSemaphoreV() %lu\n; g",
		cul_CurrentThread->seq));

	/* Is the semaphore valid? */

	if (semaphoreP->magic != CUL_THREADSEM_MAGIC_NUM)
	{
		/* No */

		DBPRINTF(("Invalid semaphore passed to cul_ThreadSemaphoreV() %lu\n",
			cul_CurrentThread->seq));
		ThreadEndCritical();
		return(paramErr);
	}

	/*
	** Does this thread own the semaphore? It's an error to try
	** to return a semaphore one doesn't own.
	*/

	for (semP = cul_CurrentThread->semHeldList.next;
		semP != 0; semP = semP->next)
	{
		if (CUL_SEMAPHORE_FROM_SEMHELDLINK(semP) == semaphoreP)
			break;
	}

	if (semP == 0)
	{
		/* yes -- programming error */

		ThreadEndCritical();
		DBPRINTF(("cul_ThreadSemaphoreP() %lu: Attempt to return "
			"semaphore thread doesn't own\n", cul_CurrentThread->seq));
		return(paramErr);
	}

	/* Is the semaphore available? */

	if (semaphoreP->value)
	{
		/* yes -- programming error */

		ThreadEndCritical();
		DBPRINTF(("cul_ThreadSemaphoreP() %lu: Attempt to return "
			"unheld semaphore\n", cul_CurrentThread->seq));
		return(paramErr);
	}

	/*
	** Unlink the semaphore from the list of held semaphores
	** for this thread.
	*/

	if (semaphoreP->semHeldList.next != 0)
		semaphoreP->semHeldList.next->prev
		= semaphoreP->semHeldList.prev;

	if (semaphoreP->semHeldList.prev != 0)
		semaphoreP->semHeldList.prev->next
		= semaphoreP->semHeldList.next;

	/* Is there a thread waiting on this semaphore? */

	if (semaphoreP->semWaitList.next != 0)
	{
		cul_ThreadPtr threadToRun;

		/* Yes - pass it the semaphore */

		threadToRun =
			CUL_THREAD_FROM_SEMWAITLINK(semaphoreP->semWaitList.next);

		/* Unlink the semaphore from the waiting list */

		semaphoreP->semWaitList.next
			= semaphoreP->semWaitList.next->next;

		if (semaphoreP->semWaitList.next != 0)
			semaphoreP->semWaitList.next->prev
				= &semaphoreP->semWaitList;

		threadToRun->semWaitList.next = 0;
		threadToRun->semWaitList.prev = 0;
	
		/*
		** The first item in the list must not point back to
		** the queue head.
		*/

		//if (semaphoreP->semWaitList.next != 0)
		//	semaphoreP->semWaitList.next->prev = 0;

		/*
		** If the thread is blocked (waiting on a semaphore),
		** wake the waiting thread. If the thread is blockedStopped
		** (was frozen while blocked waiting on a semaphore), mark
		** it as stopped. It will resume execution when unfrozen.
		*/

		switch (threadToRun->state)
		{
			case blockedStopped:
			{
				threadToRun->state = stopped;
				break;
			}

			case blocked:
			{
				if ((err = SetThreadState(threadToRun->threadID,
					kReadyThreadState, kCurrentThreadID)) != noErr)
				{
					DBPRINTF(("Pgmr error in cul_ThreadSemaphoreV() %lu\n", cul_CurrentThread->seq));
					ThreadEndCritical();
					return(err);
				}
			
				break;
			}

			default:
			{
				DBPRINTF(("Unexpected thread state(%d) in "
					"cul_ThreadSemaphoreV() %lu\n",
					(int) threadToRun->state, cul_CurrentThread->seq));
					ThreadEndCritical();
					return(paramErr);
			}
		}
	}

	else
	{
		/*
		** No threads waiting -- mark semaphore available
		** for other threads. Note that this must be done
		** before attempting to delete the semaphore, since
		** deletion of an active semaphore is not allowed.
		*/

		semaphoreP->value = 1;

		/* Is the semaphore waiting to be deleted? */

		if (semaphoreP->flags & CUL_SEMAPHORE_DELETE_PENDING)
		{
			cul_DisposeThreadSemaphore(semaphoreP);
		}
	}

	ThreadEndCritical();

	/*
	** Note: When execution gets here the effects of all
	** ThreadBeginCritical() calls made by this routine must
	** have been undone!
	*/ 

	DBPRINTF(("Normal exit from cul_ThreadSemaphoreV() %lu\n; g", cul_CurrentThread->seq));
	return(noErr);
}

/*
** cul_NewThreadSemaphore() -- Create a new semaphore.
**
**	cul_NewThreadSemaphore() creates and initializes a new
**	semaphore.
*/

OSErr
cul_NewThreadSemaphore(cul_ThreadSemaphorePtr *semaphorePP)
{
	if ((*semaphorePP = (cul_ThreadSemaphorePtr)
		NewPtrClear(sizeof(cul_ThreadSemaphore))) == 0)
	{
		return(MemError());
	}

	/* Mark it available for acquisition by a thread */

	(*semaphorePP)->magic = CUL_THREADSEM_MAGIC_NUM;
	(*semaphorePP)->value = 1;

	return(noErr);
}

/*
** cul_DisposeThreadSemaphore() -- Dispose of a semaphore
**
**	cul_DisposeThreadSemaphore() frees the control structure
**	used by cul thread semaphores. If the semaphore is in use,
**	it will be marked for later deletion. This will prevent any
**	additional operations from being queued on it.
*/

void
cul_DisposeThreadSemaphore(cul_ThreadSemaphorePtr semaphoreP)
{
	ThreadBeginCritical();

	/* Is the semaphore valid? */

	if (semaphoreP->magic != CUL_THREADSEM_MAGIC_NUM)
	{
		/* No */

		DBPRINTF(("Invalid semaphore passed to cul_DisposeThreadSemaphore() %lu\n",
			cul_CurrentThread->seq));
		ThreadEndCritical();
		return;
	}

	/* If the semaphore is in use, delay deletion until it is free. */

	if (semaphoreP->value == 0)
		semaphoreP->flags |= CUL_SEMAPHORE_DELETE_PENDING;

	else
	{
		memset(semaphoreP, 0, sizeof(*semaphoreP));

		DisposePtr((Ptr) semaphoreP);
	}

	ThreadEndCritical();
}

/*
** cul_InMainThread() -- Returns true if called from main thread
*/

Boolean
cul_InMainThread(void)
{
	return(cul_CurrentThread == &cul_ThreadListHead);
}

/* Routines to get and set the thread refCon field */

OSErr
cul_SetThreadRefConInt(cul_Thread *const thread,
	unsigned long value)
{
	if (thread == 0 || thread->magic != CUL_THREAD_MAGIC_NUM)
		return(paramErr);

	thread->refCon.refConInt = value;

	return(noErr);
}

OSErr
cul_GetThreadRefConInt(const cul_Thread *const thread,
	unsigned long *value)
{
	if (thread == 0 || thread->magic != CUL_THREAD_MAGIC_NUM)
		return(paramErr);

	*value = thread->refCon.refConInt;

	return(noErr);
}

OSErr
cul_SetThreadRefConPtr(cul_Thread *const thread, void *ptr)
{
	if (thread == 0 || thread->magic != CUL_THREAD_MAGIC_NUM)
		return(paramErr);

	thread->refCon.refConPtr = ptr;

	return(noErr);
}

OSErr
cul_GetThreadRefConPtr(const cul_Thread *const thread,
	void * *const ptr)
{
	if (thread == 0 || thread->magic != CUL_THREAD_MAGIC_NUM)
		return(paramErr);

	*ptr = thread->refCon.refConPtr;

	return(noErr);
}

OSErr
cul_SetCurThreadRefConInt(unsigned long value)
{
	return(cul_SetThreadRefConInt(cul_CurrentThread, value));
}

OSErr
cul_GetCurThreadRefConInt(unsigned long *const value)
{
	return(cul_GetThreadRefConInt(cul_CurrentThread, value));
}

OSErr
cul_SetCurThreadRefConPtr(void *ptr)
{
	return(cul_SetThreadRefConPtr(cul_CurrentThread, ptr));
}

OSErr
cul_GetCurThreadRefConPtr(void * *const ptr)
{
	return(cul_GetThreadRefConPtr(cul_CurrentThread, ptr));
}

/*
** cul_ThreadInSwitch() -- Custom thread switcher (inbound)
*/

pascal void
cul_ThreadInSwitch(ThreadID threadID, cul_ThreadPtr threadP)
{
	long oldA5;

#ifndef CACHE_PPC
	oldA5 = SetA5(threadP->appA5); 
#endif
	*cul_getCurrentThreadPtr() = threadP;

#ifndef CACHE_PPC
	(void) SetA5(oldA5);
#endif
}

/*
** cul_ThreadOutSwitch() -- Custom thread switcher (outbound)
*/

pascal void
cul_ThreadOutSwitch(ThreadID threadID, cul_ThreadPtr threadP)
{
	long oldA5;

#ifndef CACHE_PPC
	oldA5 = SetA5(threadP->appA5); 
#endif
	/*
	** Don't set cul_CurrentThread to 0, as that will cause
	** reinitialize of the linked lists. 1 is just as invalid
	** an address and will not cause reinitialization to
	** take place.
	*/

	*cul_getCurrentThreadPtr() = (cul_ThreadPtr) 1;

#ifndef CACHE_PPC
	(void) SetA5(oldA5);
#endif
}

pascal void
cul_ThreadEnd(ThreadID threadID, cul_ThreadPtr threadP)
{
	/* If a termination procedure has been installed, call it */

	if (threadP->termProc != 0)
	{
		(*threadP->termProc)(cul_CurrentThread);
	}

	ThreadBeginCritical();

	/* Mark the thread as being a zombie */

	threadP->state = zombie;

	/* Is the parent alive? */

	if (threadP->parent != 0)
	{
		/* If the parent is waiting on it's children, wake it */

		if (threadP->parent->state == waiting)
		{
			DBPRINTF(("Waking %lu\n; g", threadP->parent->seq));

			if (SetThreadState(threadP->parent->threadID,
				kReadyThreadState, kNoThreadID) != noErr)
			{
				DBPRINTF(("Error waking parent\n"));
			}
		}
	}

	/*
	** The parent is dead or has disowned the child. The dying
	** child must dispose of his own corpse. This can be a little
	** complicated if the process is a preemptive one, since
	** it is not possible to dispose of the control structure
	** memory block in an interrupt context. For the moment, ignore
	** the issue and assume that all threads are cooperative.
	**
	** ##### This will definitely need to be revisited. ####
	*/

	else
	{
		cul_DisposeThread(threadP);
	}

	ThreadEndCritical();
}

/*
** cul_ThreadAtExit1() -- Install cul_Thread exit handler
**
**	cul_ThreadAtExit1() installs a routine which will be called when a
**	thread exits. At this time, only one such routine can be installed
**	at a time. In the future, this may be changed. If an previously
**	installed routine is deinstalled in order to satisfy the installation
**	request, and the oldTermProcPtrPtr argument is non-null, the pointer to
**	the previously installed routine will be returned. Otherwise, null will
**	be returned.
**
** Note:
**
**	The "1" in the name is meant to imply that only one atexit handler
**	may be installed at a time. When the facility is extended, new routines
**	will be provided without the second parameter. These routines will of
**	course need to be kept around for backward compatibility.
*/

OSErr
cul_ThreadAtExit1(cul_ThreadExitProcPtr newTermProcPtr,
	cul_ThreadExitProcPtr *const oldTermProcPtrPtr)
{
	return(cul_ThreadAtExitThread1(cul_CurrentThread, newTermProcPtr,
		oldTermProcPtrPtr));
}

OSErr
cul_ThreadAtExitThread1(cul_ThreadPtr threadP,
	cul_ThreadExitProcPtr newTermProcPtr,
	cul_ThreadExitProcPtr *const oldTermProcPtrPtr)
{
	/*
	** Assume no routine is currently installed. This simplifies
	** error handling.
	*/

	if (oldTermProcPtrPtr != 0)
		*oldTermProcPtrPtr = 0;

	/* Check for valid thread pointer */

	if (!threadP || threadP->magic != CUL_THREAD_MAGIC_NUM)
	{
		return(paramErr);
	}

	/*
	** If a routine has already been installed and the caller wants
	** to know about it...
	*/

	if (threadP->termProc != 0 && oldTermProcPtrPtr != 0)
	{
		*oldTermProcPtrPtr = threadP->termProc;
	}

	/* Install the new termination proc */

	threadP->termProc = newTermProcPtr;

	return(noErr);
}

/*
** cul_getCurrentThreadPtr()
**
**	This routine circumvents some of the problems that compiler
**	optimization can cause in completion routines. See tech note
**	#208 for more information.
**
**	This routine is static to prevent non-library routines from
**	gaining easy access to the cul_Thread control structure. It's
**	always a good idea to minimize programmer temptations.
*/

static cul_ThreadPtr *
cul_getCurrentThreadPtr(void)
{
	return((struct cul_Thread**)&cul_CurrentThread);
}

#ifdef DEBUG
#include <stdarg.h>
void
cul_dbprintf(const char *fmt, ...)
{
	static FILE *debugFP = 0;
	va_list ap;
	static char *buf = 0;

#ifdef DEBUG_FILE_OUTPUT
	if (debugFP == 0)
	{
		if ((debugFP = fopen("cul_logfile", "w")) == 0)
			return;
	}
#else
	if (buf == 0)
	{
		buf = (char *) NewPtr(1024);
		if (buf == 0)
			return;
	}
#endif

	va_start(ap, fmt);
#ifdef DEBUG_FILE_OUTPUT
	vfprintf(debugFP, fmt, ap);
	fflush(debugFP);
#else
	vsprintf(buf, fmt, ap);
	c2pstr(buf);
	DebugStr(buf);
#endif
	va_end(ap);
}
#endif /* DEBUG */
