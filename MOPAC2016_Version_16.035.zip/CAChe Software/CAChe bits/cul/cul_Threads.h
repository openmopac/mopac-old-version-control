/*
** cul_Threads.h
*/

#ifndef	__CUL_THREADS_H__
#define	__CUL_THREADS_H__

#include <Types.h>
#include <Threads.h>

#define CUL_SEMAPHORES_NOBLOCK 1
#define CUL_THREAD_NO_BLOCK 1

struct cul_SemLink
{
	struct cul_SemLink *prev;
	struct cul_SemLink *next;
};

typedef struct cul_SemLink cul_SemLink, *cul_SemLinkPtr;

struct cul_ThreadLink
{
	struct cul_ThreadLink *prev;
	struct cul_ThreadLink *next;
};

struct cul_ThreadSemaphore
{
	unsigned long magic;
	long value;
	long flags;
	cul_SemLink semWaitList;
	cul_SemLink semHeldList;
	union
	{
		unsigned long refConInt;	/* should be longest possible int */
		void *refConPtr;			/* should be longest possible ptr */
	} refCon;
};

typedef struct cul_ThreadSemaphore cul_ThreadSemaphore,
	*cul_ThreadSemaphorePtr;

typedef struct cul_ThreadLink cul_ThreadLink, *cul_ThreadLinkPtr;

enum cul_ThreadState
{
	uninitialized = 0,
	ready,		/* ready to run or running */
	stopped,	/* stopped by programmer directive */
	waiting,	/* in a cul_WaitThread() call waiting on children */
	blocked,	/* waiting on a semaphore */
	blockedStopped,	/* stopped while waiting on a semaphore */
	zombie		/* waiting for parent to issue a cul_WaitThread() call */
};

struct cul_Thread
{
	unsigned long magic;	/* magic number */
	unsigned long seq;	/* thread sequence number */
	void *threadResult;
	ThreadID threadID;
	enum cul_ThreadState state;
	struct cul_Thread *parent;
	struct cul_Thread **cul_CurrentThread;	/* pointer to current-thread global */
	cul_ThreadLink masterList;
	cul_SemLink semHeldList;
	cul_SemLink semWaitList;
	cul_ThreadLink childListHead;
	cul_ThreadLink siblingList;
	void (*termProc)(struct cul_Thread *const);
	union
	{
		unsigned long refConInt;	/* should be longest possible int */
		void *refConPtr;			/* should be longest possible ptr */
	} refCon;
	long appA5;	/* application's A5 register */
};

typedef struct cul_Thread cul_Thread, *cul_ThreadPtr;

#ifdef __cplusplus
extern "C" {
#endif

OSErr cul_InitThreads(void);

OSErr cul_NewThread(ThreadStyle threadStyle,
	ThreadEntryProcPtr threadEntry,
	void *threadParam, Size stackSize, ThreadOptions options,
	cul_Thread **threadMade);

OSErr cul_ThreadSemaphoreP(cul_ThreadSemaphorePtr semaphoreP,
	long options);	/* Grab semaphore */

OSErr cul_ThreadSemaphoreV(cul_ThreadSemaphorePtr semaphoreP); /* Release sempahore */

OSErr cul_NewThreadSemaphore(cul_ThreadSemaphorePtr *semaphorePP);

void cul_DisposeThreadSemaphore(cul_ThreadSemaphorePtr semaphoreP);

OSErr cul_FreezeThread(cul_ThreadPtr threadP);

OSErr cul_ThawThread(cul_ThreadPtr threadP);

Boolean cul_IsThreadFrozen(cul_ThreadPtr threadP);

OSErr cul_WaitThread(cul_ThreadPtr *thread, void **threadResult,
	unsigned long options);

OSErr cul_SetThreadRefConInt(cul_Thread *const thread,
	unsigned long value);

OSErr cul_GetThreadRefConInt(const cul_Thread *const thread,
	unsigned long *const value);

OSErr cul_SetThreadRefConPtr(cul_Thread *const thread, void *ptr);

OSErr cul_GetThreadRefConPtr(const cul_Thread *const thread,
	void * *const ptr);

OSErr cul_SetCurThreadRefConInt(unsigned long value);

OSErr cul_GetCurThreadRefConInt(unsigned long *const value);

OSErr cul_SetCurThreadRefConPtr(void *ptr);

OSErr cul_GetCurThreadRefConPtr(void * *const ptr);

typedef void (*cul_ThreadExitProcPtr)(struct cul_Thread *const);

OSErr cul_ThreadAtExit1(cul_ThreadExitProcPtr newTermProcPtr,
	cul_ThreadExitProcPtr *const prevTermProcPtr);

OSErr cul_ThreadAtExitThread1(cul_ThreadPtr threadP,
	cul_ThreadExitProcPtr newTermProcPtr,
	cul_ThreadExitProcPtr *const oldTermProcPtrPtr);

Boolean cul_InMainThread(void);

#ifdef __cplusplus
}
#endif

#endif	/* __CUL_THREADS_H__ */
