/*
** cul_ResIDs.h -- CAChe Utility Library resource IDs
*/

#ifndef __CUL_RESIDS__
#define __CUL_RESIDS__

#define CUL_MP_ID 1900	/* Modal progress DLOG/DITL/dctb */

#endif
