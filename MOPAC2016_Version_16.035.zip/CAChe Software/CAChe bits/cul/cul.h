/*
** cul.h -- public include file for CAChe Utility Library (CUL)
*/

#ifndef __CUL__
#define __CUL__

#include <compat.h>
#include <stdarg.h>

#ifdef __cplusplus	/* For type-safe linkage */
extern "C" {		/* Specify "C"-style linkage */
#endif

/* Error codes returned by cul */

typedef long culErr;

#define CUL_STDIO_EOF		-1901	/* EOF on read */
#define CUL_STDIO_ERROR		-1902	/* Error on read or write */
#define CUL_BAD_CONVMODE	-1903	/* Bad conversion mode */

/* Command-line argument stuff */

char** get_args(char *cmdLine, int *argc);

/* End of line stuff */

#define CUL_NETEOL '\015'

/* convert from host to network end of line */
void cul_h2neol(char *buf);
void cul_h2nneol(char *buf, const unsigned long count);

/* convert from network to host(native) end of line */
void cul_n2heol(char *buf);
void cul_n2hneol(char *buf, const unsigned long count);

/* Byte swap stuff */

#define CUL_INTFMT_BIGENDIEN			0
#define CUL_INTFMT_SMALLENDIEN			1
#define CUL_FPFMT_IEEE754BIGENDIEN		0
#define CUL_FPFMT_IEEE754SMALLENDIEN	1

/*
** define CUL_INTFMT and CUL_FPFMT to be the native format codes
** for this machine.
*/

#if defined(_WINDOWS) || defined(_WIN32)
#define CUL_INTFMT CUL_INTFMT_SMALLENDIEN
#define CUL_FPFMT CUL_FPFMT_IEEE754SMALLENDIEN
#define CUL_LONG_3BYTE_OFFSET 0
#else
#define CUL_INTFMT CUL_INTFMT_BIGENDIEN
#define CUL_FPFMT CUL_FPFMT_IEEE754BIGENDIEN
#define CUL_LONG_3BYTE_OFFSET 1
#endif

typedef unsigned long cul_convCode, *cul_convCodeP;

typedef struct cul_convMode
{
	cul_convCode intCode;	/* integer conversion code */
	cul_convCode fpCode;		/* floating point conversion code */
} cul_convMode, *cul_convModeP;

/*
** This convMode token is used to convert incomming network
** data to native format.
*/
extern const cul_convMode cul_NetworkSrc;

/* read longs */
culErr cul_rdcnvlong(cul_convMode convmode, long *const where,
	const size_t wanted, size_t *const got, FILE *fp);
/* read the hack of scaled 3-byte ints */
culErr cul_rdcnv3int(cul_convMode convmode, long *const where,
	const size_t wanted, size_t *const got, FILE *fp);
/* read shorts */
culErr cul_rdcnvshort(cul_convMode convmode, short *const where,
	const size_t wanted, size_t *const got, FILE *fp);
/* read floats */
culErr cul_rdcnvfloat(cul_convMode convmode, float *const where,
	const size_t wanted, size_t *const got, FILE *fp);
/* read doubles */
culErr cul_rdcnvdouble(cul_convMode convmode, double *const where,
	const size_t wanted, size_t *const got, FILE *fp); 
/* convert longs to native format */
culErr cul_icnvlong(cul_convMode convmode, long *const where,
	const unsigned long count);
/* convert shorts to native format */
culErr cul_icnvshort(cul_convMode convmode, short *const where,
	const unsigned long count);
/* convert floats to native format */
culErr cul_icnvfloat(cul_convMode convmode, float *const where,
	const unsigned long count);
/* convert doubles to native format */
culErr cul_icnvdouble(cul_convMode convmode, double *const where,
	const unsigned long count);
/* convert longs to network format */
culErr cul_ecnvlong(long *const where, const unsigned long count);
/* convert shorts to network format */
culErr cul_ecnvshort(short *const where, const unsigned long count);
/* convert floats to network format */
culErr cul_ecnvfloat(float *const where, const unsigned long count);
/* convert doubles to network format */
culErr cul_ecnvdouble(double *const where, const unsigned long count);
/* initialize a cul_convMode token */
culErr cul_makeConvMode(cul_convMode *const my_convMode,
	const cul_convCode intCode, const cul_convCode fpCode);

#define CUL_LONGSWAP(i) {register unsigned char *c; register unsigned char t; c = (unsigned char *) &i; t = c[3]; c[3] = c[0]; c[0] = t; t = c[2]; c[2] = c[1]; c[1] = t;}
#define CUL_SHORTSWAP(i) (i) = ((((i) >> 8) & 0x0ff) | ((i) << 8))
#define CUL_DOUBLESWAP(x) {register unsigned char *c; register unsigned char t; c = (unsigned char *) &x; t = c[7]; c[7] = c[0]; c[0] = t; t = c[6]; c[6] = c[1]; c[1] = t; t = c[5]; c[5] = c[2]; c[2] = t; t = c[4]; c[4] = c[3]; c[3] = t;}

/*
 * Standard exit routine (does not return).
 * The interface matches the standard C exit function.
 */
void cul_Exit(int status);

/*
** Yield macro -- Used to provide a processor-independent
** method of yielding cpu time while waiting for something
** to happen. A no-op on non-multitasking machines (e.g. 88K)
*/

#if defined(unix)
#define CUL_YIELD() yield()	/* An aix system call */
#else
#define CUL_YIELD()		/* Nothing to do */
#endif

typedef unsigned int cul_semaphoreState;

#define CUL_SEMAPHORE_ACQUIRED 0
#define CUL_SEMAPHORE_BUSY -1

typedef struct cul_semaphore
{
#ifdef unix
	int semID;
#else
	unsigned char clientFlag;
	unsigned char serverFlag;
#endif
} cul_semaphore;

#if !defined(__cplusplus)
cul_semaphoreState cul_AcquireSemaphoreWait(volatile cul_semaphore *sem);
cul_semaphoreState cul_AcquireSemaphore(volatile cul_semaphore *sem);
#endif
void cul_ReleaseSemaphore(cul_semaphore *sem);
int cul_InitSemaphore(cul_semaphore *sem);
void cul_DestroySemaphore(cul_semaphore *sem);
double cul_seconds(void);
void cul_elapsedtime(double st, double et, char *buf);

typedef int cul_messageStatus;

/*
** Note: the buffer used for passing data must reside
** in the same (uncached!) shared memory segment as
** the control structure which follows.
*/

typedef struct cul_CPMsgChannel
{
#if defined(unix)
	int readFD;		/* message channel file descriptor */
	int writeFD;	/* message channel file descriptor */
#elif (_WIN32)
	void *m_ce; 
#else
#error "cul.h: No machine type defined."
#endif
	unsigned char channelID;	/* pass to the ServerQueue */
} cul_CPMsgChannel;

#define CUL_MSGS_SENT 0
#define CUL_MSGS_BUSY -1
#define CUL_MSGS_FAILED -2
#define CUL_MSGS_EOF -3
#define CUL_MSGS_MSGRCVD 0
#define CUL_MSGS_NOMSG -1

/*
** CUL_MAX_MSG_LENGTH specifies the maximum number of characters
** in a message. The actual size of the buffers should be one
** character larger to allow for the terminating null. This
** value is given by the constant CUL_MSG_BUF_SIZE.
** Note that on Unix machines, CUL_MSG_BUF_SIZE should be
** no larger than the constant PIPE_BUF.
*/

#define CUL_MAX_MSG_LENGTH 255
#define CUL_MSG_BUF_SIZE (CUL_MAX_MSG_LENGTH + 1)

cul_messageStatus cul_sendCPMessage(volatile struct cul_CPMsgChannel
	*const channel, const char *const text);

cul_messageStatus cul_sendCPMessageWait(volatile struct cul_CPMsgChannel
	*const channel, const char *const text, Boolean (*giveUp)());

cul_messageStatus cul_printCPMessage(volatile struct cul_CPMsgChannel
	*const channel, const char *const format, ...);

cul_messageStatus cul_vprintCPMessage(volatile struct cul_CPMsgChannel
	*const channel, const char *const format, va_list args);

cul_messageStatus cul_printCPMessageWait( volatile struct cul_CPMsgChannel *const channel,
                                          Boolean (*giveUp)(),
                                          const char *const format, ...);

cul_messageStatus cul_vprintCPMessageWait(
	volatile struct cul_CPMsgChannel *const channel,
	Boolean (*giveUp)(), const char *const format, va_list args);

cul_messageStatus cul_readCPMessage(volatile struct cul_CPMsgChannel
	*const channel, char *const text);

#if defined(unix)
int cul_initCPMessageChannel(struct cul_CPMsgChannel *const channel,
	const unsigned char channelID);
#elif defined(_WIN32)
int cul_initCPMessageChannel(struct cul_CPMsgChannel *const channel,
	const unsigned char channelID, void *ce);
#endif

void
cul_attachCPMessageChannel(struct cul_CPMsgChannel *const channel,
	int readFD, int writeFD, const unsigned char channelID);

void cul_destroyCPMessageChannel(struct cul_CPMsgChannel
	*const channel);

unsigned long
cul_GetCPMsgChannelID(const struct cul_CPMsgChannel *const channel);

#ifdef unix

int cul_getCPMsgReadFD(const struct cul_CPMsgChannel *const msgChannelP);

int cul_getCPMsgWriteFD(const struct cul_CPMsgChannel *const msgChannelP);

#endif

/* Macros for constructing version and copyright strings in ANSI C. */

/* Utility macros for turning tokens into strings. */
#define CUL_STRING1(theString)	#theString
#define CUL_STRING(theString)	CUL_STRING1(theString)

/* Version and copyright constants. */
#define CUL_VERS_SEPARATOR		"; "
#define	CUL_COPYRIGHT_TAG1		"Copyright (c) 2000-"
#define	CUL_COPYRIGHT_TAG2		"Copyright (c)"
#define CUL_COPYRIGHT_SEPARATOR		" "

#if defined(_WINDOWS) || defined(_WIN32)
	#define	CUL_PRODUCT_NAME		"CAChe WorkSystem for Windows"
	#define CUL_SCCS_TAG			""
#else
	#define	CUL_PRODUCT_NAME		"CAChe"
	#define CUL_SCCS_TAG			"@(#)"
#endif

/* Version string for use with the SCCS what command. */
#define CUL_VERS_WHAT(name, vers)			\
	CUL_SCCS_TAG					\
	CUL_STRING(name)	CUL_VERS_SEPARATOR	\
	CUL_STRING(vers)	CUL_VERS_SEPARATOR	\
	__DATE__		CUL_VERS_SEPARATOR	\
	__TIME__

/* Version string to be sent across a network prepended with a name. */
#define CUL_VERS_NET(vers)				\
	CUL_STRING(vers)	CUL_VERS_SEPARATOR	\
	__DATE__		CUL_VERS_SEPARATOR	\
	__TIME__

/* Copyright notice to be embedded in the source code. */
#define CUL_COPYRIGHT1(year, comp) 			\
	CUL_COPYRIGHT_TAG1 \
	CUL_STRING(year)	CUL_COPYRIGHT_SEPARATOR	\
	CUL_STRING(comp)	CUL_COPYRIGHT_SEPARATOR	\
	CUL_COPYRIGHT_TAG2	CUL_COPYRIGHT_SEPARATOR	\
	"1989-2000 Oxford Molecular Ltd."

#if !defined(RC_INVOKED)
#define CUL_COPYRIGHT(year, comp) CUL_SCCS_TAG CUL_COPYRIGHT1(year, comp)
#else
/* Microsoft rc does not catenate empty strings as in ANSI C. */
#define CUL_COPYRIGHT(year, comp) CUL_COPYRIGHT1(year, comp)
#endif

#ifdef __cplusplus	/* For type-safe linkage */
}
#endif

#endif /* __CUL__ */
