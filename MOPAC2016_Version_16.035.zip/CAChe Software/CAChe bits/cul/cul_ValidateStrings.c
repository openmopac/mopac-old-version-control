/*
** cul_ValidateStrings.c --	A collection of routines to validate
**							the contents of strings.
*/

#include <compat.h>
#include <CType.h>
#include <Types.h>

#include "cul.h"

/*
** cul_IsValidFloat() -- Is text string a valid floating pt number?
**
**	cul_IsValidFloat() returns true if the specified text string
**	is a valid floating point number, false otherwise. 'Valid' is
**	defined as being acceptable for scanning by scanf(). Leading and
**	trailing blank space is ignored.
**
**	Float specification:
**
**		<ws><-><integer><.><fraction><[eE]<[+-]>exponent><ws|EOS>
**		integer, fraction, exponent: [0-9]+
**		ws: whitespace; EOS: end of string
**		To be valid, an integer or fraction must be found.
*/

Boolean
cul_IsValidFloat(const char *const text)
{
	register const char *c = text;
	Boolean foundDigits = false;

	/* skip leading white space, if any */
	
	while (isascii(*c) && isspace(*c))
		c++;

	if (!*c)	/* if end of string� */
		return(false);

	/* check for leading minus sign */

	if (*c == '-')
		c++;	/* move on */

	if (!*c)	/* if end of string� */
		return(false);

	/* check for digit */

	if (isascii(*c) && isdigit(*c))
	{
		foundDigits = true;
		c++;
	}

	if (!*c)	/* if end of string� */
		return(foundDigits);

	/* skip remaining digits */

	while (isascii(*c) && isdigit(*c))
		c++;

	if (!*c)	/* if end of string� */
		return(foundDigits);

	/* check for decimal point */

	if (*c == '.')
		c++;	/* move on */

	if (!*c)	/* if end of string� */
		return(foundDigits);

	/* check for digit */

	if (isascii(*c) && isdigit(*c))
	{
		foundDigits = true;
		c++;
	}

	if (!*c)	/* if end of string� */
		return(foundDigits);

	/* It this point, some digits had better have been seen */
	
	if (!foundDigits)
		return(false);

	/* skip remaining digits */

	while (isascii(*c) && isdigit(*c))
		c++;

	/* check for an exponent specifier */

	if (*c == 'e' || *c == 'E')
	{
		c++;	/* move on */

		/* check for optional sign */
	
		if (*c == '-' || *c == '+')
			c++;	/* move on */
	
		/*
		** Now check for the exponent.
		** Note: This check also catches the case of
		** unexpected end-of-string
		*/

		if (!isascii(*c) || !isdigit(*c))
			return(false);	/* didn't find 1st digit of exponent */

		/* Found first digit of exponent -- move on */
		
		c++;

		/* skip remaining digits of exponent */
		
		while (isascii(*c) && isdigit(*c))
			c++;
	}

	if (!*c)	/* if end of string� */
		return(true);

	/* skip trailing white space */
	
	while (isascii(*c) && isspace(*c))
		c++;

	/* must now be at end of string */
	
	if (*c)	/* If actually at a garbage character� */
		return(false);

	return(true);
}

/*
** cul_IsValidInteger() -- Is text string a valid integer number?
**
**	cul_IsValidInteger() returns true if the specified text string
**	is a valid integer number, false otherwise. 'Valid' is
**	defined as being acceptable for scanning by scanf(). Leading and
**	trailing blank space is ignored.
**
**	Float specification:
**
**		<ws><->digits<.><ws>EOS
**		ws: whitespace; EOS: end of string
*/

Boolean
cul_IsValidInteger(const char *const text)
{
	register const char *c = text;
	Boolean foundDigits = false;

	/* skip leading white space, if any */
	
	while (isascii(*c) && isspace(*c))
		c++;

	if (!*c)	/* if end of string� */
		return(false);

	/* check for leading minus sign */

	if (*c == '-')
		c++;	/* move on */

	if (!*c)	/* if end of string� */
		return(false);

	/* check for digit */

	if (!isascii(*c) || !isdigit(*c))
		return(false);	/* didn't find it */
	else
		c++;	/* Move past first digit */

	/* skip remaining digits */

	while (isascii(*c) && isdigit(*c))
		c++;

	/* check for optional decimal point */

	if (*c == '.')
		c++;	/* move on */

	/* skip trailing white space */
	
	while (isascii(*c) && isspace(*c))
		c++;

	/* must now be at end of string */
	
	if (*c)	/* If actually at a garbage character� */
		return(false);

	return(true);
}
