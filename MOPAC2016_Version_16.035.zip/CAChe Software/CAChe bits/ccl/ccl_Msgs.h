/*
** ccl_Msgs.h
*/

#ifndef	CCL_MSGS_H
#define	CCL_MSGS_H

#if defined(_WIN32)
# define ccl_MsgPipeHandle HANDLE
#endif

enum ccl_Msg_Flags {
 	CCL_MSG_FLAGS_NONE = 0,
 	CCL_MSG_FLAGS_BLOCKING = 1,
	CCL_MSG_FLAGS_MAX = 255
};

enum ccl_Msg_Types {
	CCL_MSG_TYPE_UNKNOWN  = 0,
	CCL_MSG_TYPE_STATUS,
	CCL_MSG_TYPE_DO_PROC,
	CCL_MSG_TYPE_INIT_DONE,
	CCL_MSG_TYPE_CONTINUE,
	CCL_MSG_TYPE_STOP,
	CCL_MSG_TYPE_DISCONNECT,
	CCL_MSG_TYPE_MAX = 255
};

class LogMgr;

class ccl_Msg {
public:
	// message header
	unsigned char m_type;
	unsigned char m_flags; // CCL_MSG_BLOCKING

	// member functions
	ccl_Msg(unsigned char type, unsigned char flags);
};

// Derived classes of ccl_Msg
// ccl_Msg_Status is a message with type CCL_MSG_TYPE_STATUS
class ccl_Msg_Status : public ccl_Msg {
public:
	int m_channelID;
	unsigned long m_status_len;
	char *m_status;

	ccl_Msg_Status(
		unsigned char type,
		unsigned char flags,
		int channelID,
		unsigned long status_len,
		char *status);

	~ccl_Msg_Status(void);
};


typedef long ccl_MsgPipeStatus;

class ccl_MsgPipe {
private:
	long					m_bufferSize;
	SECURITY_ATTRIBUTES 	m_securityAttributes;
	ccl_Err					m_status;
	FILE					*m_logFile;
	LogMgr					*m_logMgr;
	void					DebugPrintf(char *fmt, ...);

public:
	ccl_MsgPipeHandle		m_readHandle;
	ccl_MsgPipeHandle		m_writeHandle;
							
	ccl_MsgPipe(FILE *logfile);

	ccl_MsgPipe(
		ccl_MsgPipeHandle readHandle,
		ccl_MsgPipeHandle writeHandle,
		FILE *logfile);
	~ccl_MsgPipe(void);

	ccl_Boolean 			Valid(void);
	ccl_Boolean				Read(unsigned long len, unsigned char *buf);
	ccl_Boolean				Write(unsigned long len, unsigned char *buf);
	void					Disconnect(void);
};

//typedef long ccl_MsgChannel_Status;

class ccl_MsgChannel {

private:
	ccl_Err					m_status;
	FILE					*m_logFile;
	LogMgr					*m_logMgr;
	void					DebugPrintf(char *fmt, ...);

public:

	ccl_MsgPipe 			*m_data_pipe;
	ccl_MsgPipe 			*m_ack_pipe;
	ccl_MsgChannel(FILE *logfile);
	ccl_MsgChannel(
		ccl_MsgPipeHandle d_r_phandle,
		ccl_MsgPipeHandle d_w_phandle,
		ccl_MsgPipeHandle a_r_phandle,
		ccl_MsgPipeHandle a_w_phandle,
		FILE *logfile);

	~ccl_MsgChannel(void);
	
	ccl_Boolean 			Valid(void);
	ccl_Boolean 			ReadData(unsigned long len, void *buf);
	ccl_Boolean 			WriteData(unsigned long len, void *buf);
	ccl_Boolean 			SendAck(void);
	ccl_Boolean 			WaitForAck(void);
	void					Disconnect(void);
};

//typedef long ccl_MsgConnectionStatus;

class ccl_MsgConnection {
private:
 	ccl_Err					m_status;
	FILE					*m_logFile;
	LogMgr					*m_logMgr;
	void					DebugPrintf(char *fmt, ...);

public:	
	ccl_MsgChannel			*m_recv_channel;
	ccl_MsgChannel			*m_send_channel;
	ccl_MsgConnection(FILE *logfile);
	ccl_MsgConnection(
			ccl_MsgPipeHandle rd_r_phandle,	// receive data read pipe handle
			ccl_MsgPipeHandle ra_w_phandle,	// receive ack write pipe handle
			ccl_MsgPipeHandle sd_w_phandle,	// send data write pipe handle
			ccl_MsgPipeHandle sa_r_phandle,	// send ack read pipe handle
			FILE *logfile);
	
	~ccl_MsgConnection(void);
	
	ccl_Boolean 			Valid(void);
	ccl_Msg					*GetNextMessage();
	ccl_Boolean				SendMessage(ccl_Msg *msg);
	ccl_Boolean				SendMessage(ccl_Msg_Status *msg);
	void					Disconnect(void);

};


#endif
