/*
 * ccl_Event.cpp
 *
 * Implementation of ccl_Events	methods
 * Merlin R. Miller
 * Copyright 1995 CAChe Scientic,
 */


#include <windows.h>

#include <SimpleExceptions.h>

#include "ccl.h"
#include "ccl_Event.h"

ccl_EventWait ccl_WaitForMultipleEvents(
	long numOfEvents,	   		// number of ccl_events in the array.
	ccl_Event *EventArray[],	// array of ccl_events
	ccl_Boolean WaitAll,	   	// if true, then wait for all events to be set
	ccl_EventTimeOut timeout 	// timeout value in milliseconds
)
{
	long wfmo_ret;
	ccl_EventWait my_ret;
	HANDLE *OSEventArray = new HANDLE[numOfEvents];

	SPX_TRY {

		if (OSEventArray == NULL) SPX_THROW(err_OutOfMemory);

		// Init the event array from the ccl_Event array
		for (int i = 0; i < numOfEvents; i++)
			OSEventArray[i] = EventArray[i]->m_hEvent;

		wfmo_ret = WaitForMultipleObjects(numOfEvents, OSEventArray, WaitAll, (long)timeout);
	
		switch (wfmo_ret) {
			case WAIT_FAILED:		my_ret = CCL_EVENTWAIT_FAILED; break;
			case WAIT_ABANDONED:	my_ret = CCL_EVENTWAIT_FAILED; break;
			case WAIT_TIMEOUT:		my_ret = CCL_EVENTWAIT_TIMEDOUT; break;
			default: 				my_ret = (ccl_EventWait)wfmo_ret;	// index of event that was signaled
		}

	}
	SPX_CATCH(err_OutOfMemory) {
		my_ret = CCL_EVENTWAIT_FAILED;
	}

	delete[] OSEventArray;

	return (my_ret); 		
}

ccl_Event::ccl_Event()
{
	m_Type = CCL_EVENTTYPE_UNDEFINED;
	m_hEvent = NULL;
	m_status = ccl_Err_None;
}


ccl_Boolean ccl_Event::Init(ccl_EventType etype)
{
	BOOL win32_type;
	ccl_Err retcode = ccl_Err_None;

	SPX_TRY {

		m_Type = etype;

		switch (etype) {
			case CCL_EVENTTYPE_MANUAL:	win32_type = FALSE;	break;
			case CCL_EVENTTYPE_AUTO:	win32_type = FALSE;	break;
			default:					SPX_THROW(err_ccl_EventType_invalid);
		}

		m_hEvent = CreateEvent(
	                NULL    	// No security
	               ,win32_type	// event type
	               ,FALSE		// Initially Event set to non-signaled state
	               ,NULL		// No name
	             );

		if (m_hEvent == NULL) SPX_THROW(err_ccl_createevent_failed);

	}
	SPX_CATCH(err_ccl_EventType_invalid) {
		m_status = ccl_Err_EventTypeInvalid;
	}
	SPX_CATCH(err_ccl_createevent_failed) {
		m_status = ccl_Err_EventInitFailed;
	}

	if (m_status != ccl_Err_None)
		return ccl_Boolean_False;
	return ccl_Boolean_True;
}

ccl_Event::~ccl_Event()
{
	if (m_hEvent != NULL) CloseHandle(m_hEvent);
}

ccl_Boolean ccl_Event::Set()
{ 
	ccl_Boolean ret = ccl_Boolean_False;

	if (m_hEvent != NULL)
		ret = (ccl_Boolean)SetEvent(m_hEvent);
	return (ret);
}

ccl_Boolean ccl_Event::Reset()
{
	ccl_Boolean ret = ccl_Boolean_False;

	if (m_hEvent != NULL)
		ret = (ccl_Boolean)ResetEvent(m_hEvent);
	return (ret);
}

ccl_EventWait ccl_Event::Wait(ccl_EventTimeOut timeout)
{
	long wfso_ret;
	ccl_EventWait my_ret;

	if (m_hEvent != NULL)
		wfso_ret = WaitForSingleObject(m_hEvent, (long)timeout);
	else
		wfso_ret = WAIT_FAILED;
	
	switch (wfso_ret) {
	case WAIT_FAILED:		my_ret = CCL_EVENTWAIT_FAILED; break;
	case WAIT_ABANDONED:	my_ret = CCL_EVENTWAIT_FAILED; break;
	case WAIT_OBJECT_0:		my_ret = CCL_EVENTWAIT_OBJECT0; break;
	case WAIT_TIMEOUT:		my_ret = CCL_EVENTWAIT_TIMEDOUT; break;
	default: 				my_ret = CCL_EVENTWAIT_FAILED;
	}
	
	return (my_ret); 		
}

