/*
** CE_CEM_Recv.cpp
*/

// System includes
#include <windows.h>
#include <stdio.h>
#include <process.h>

// CAChe includes
#include <SimpleExceptions.h>
#include <ccl.h>
#include <ccl_Event.h>
#include <ccl_Msgs.h>

// Local includes
#include "ComputeEngine.h"

CE_CEM_Recv::CE_CEM_Recv(void)
{
	m_status = ce_Err_None;
	m_state = CE_STATE_CREATING;
	m_thread = NULL;
	m_threadID = NULL;
	
	m_ce = NULL;
	m_exit_evt = NULL;
	m_msg_connection = NULL;

}

CE_CEM_Recv::~CE_CEM_Recv(void)
{
}

ccl_Msg *CE_CEM_Recv::GetNextMessage()
{
	ccl_Msg *msg = m_msg_connection->GetNextMessage();

	return (msg);
}

static unsigned __stdcall
ce_CEM_Recv_Run_Routine(void *ce_recv)
{
	((CE_CEM_Recv *)ce_recv)->Run();
	return (0);
}

ce_Boolean CE_CEM_Recv::Init(ComputeEngine *ce, ccl_MsgConnection *msgConnection)
{
	const char *my_name = "CE_CEM_Recv::Init";

 	DBPRINTF(("%s: begin\n", my_name));

	m_state = CE_STATE_INITING;
	m_ce = ce;
	m_exit_evt = m_ce->m_cem_recv_exit_evt;
    
	m_msg_connection = msgConnection;

	m_thread = (ce_Thread)_beginthreadex(
		NULL,								// default security
		0,									// default stack size
		ce_CEM_Recv_Run_Routine,			// start address
		(void *)this, 						// argument list
		0,									// thread state
		&m_threadID);						// thread address
	
	DBPRINTF(("%s: thread number %d\n",my_name, m_thread));
	if (m_thread == NULL) 
		m_status = ce_Err_CEM_Recv_Creation_Failed;
		
 	DBPRINTF(("%s: end\n", my_name));

	return ce_Boolean(m_status == ce_Err_None);
}

void CE_CEM_Recv::Term(void)
{
	const char *my_name = "CE_CEM_Recv::Term";
 	DWORD		waitResult;
	long		lastError;
	const DWORD	waitTimeout = INFINITE;

	DBPRINTF(("%s: begin\n", my_name));

	SPX_TRY {

		SpecificKillDumbCE();
		Disconnect();

		waitResult = WaitForSingleObject(m_thread, waitTimeout);
 		if (waitResult == ~0) {
			lastError = GetLastError();
			DBPRINTF(("%s: WaitForSingleObject %d\n", my_name, lastError));
		}

	}
	SPX_CATCH(err_xxx_failed) {
		DBPRINTF(("%s: err_xxx_failed\n", my_name));
	}

	m_state = CE_STATE_DONE;

 	DBPRINTF(("%s: end\n", my_name));
}

void CE_CEM_Recv::Run(void)
{
	const char *my_name = "CE_CEM_Recv::Run";
	ccl_Msg *msg;

	ce_SetThreadTag("CEM_Recv");

	DBPRINTF(("%s: begin\n", my_name));

 	m_state = CE_STATE_RUNNING;
	m_status = ce_Err_None;

	// wait for ce messages

	while (m_status == ce_Err_None) {
		msg = GetNextMessage();	// blocks until a new CE message arrives or a comm error occurs
		m_status = DispatchMessage(msg);
		delete msg;
	}
	
	m_state = CE_STATE_DONE;

	SpecificKillDumbCE();
	Disconnect();

	Exit();

	DBPRINTF(("%s: end\n", my_name));
}

void CE_CEM_Recv::Exit(void)
{
	// This will wake up the CE_Main and tell it that we are done.
	m_exit_evt->Set();

	if (m_status == ce_Err_Disconnect_Msg)
		ExitProcess(0);
}

ce_Err CE_CEM_Recv::DispatchMessage(ccl_Msg *msg)
{
	const char *my_name = "CE_CEM_Recv::DispatchMessage";
	ce_Err ce_err = ce_Err_None;

 	DBPRINTF(("%s: begin\n", my_name));

	SPX_TRY {

		if (msg == NULL) SPX_THROW(err_ce_Err_CEM_Recv_Comm_Failure);

		switch(msg->m_type) {
		case CCL_MSG_TYPE_CONTINUE:
			DBPRINTF(("%s: CCL_MSG_TYPE_CONTINUE recv'ed\n",my_name));
			m_ce->m_continue_evt->Set();
			break;

		case CCL_MSG_TYPE_STOP:
			DBPRINTF(("%s: CCL_MSG_TYPE_STOP recv'ed\n",my_name));
			m_ce->m_stop_evt->Set();
			break;

		case CCL_MSG_TYPE_DISCONNECT:
			ce_err = ce_Err_Disconnect_Msg;
			break;

		default:
			SPX_THROW(err_bad_msg);
			break;

		}

	}
	SPX_CATCH(err_ce_Err_CEM_Recv_Comm_Failure) {
		DBPRINTF(("%s: err_ce_Err_CEM_Recv_Comm_Failure\n", my_name));
		ce_err = ce_Err_CEM_Recv_Comm_Failure;
	}
	SPX_CATCH(err_bad_msg) {
		DBPRINTF(("%s: err_bad_msg: msg->m_type=%d\n", my_name, msg->m_type));
		ce_err = ce_Err_Bad_Msg;
	}
	SPX_CATCH(err_xxx_failed) {
		DBPRINTF(("%s: err_xxx_failed\n", my_name));
	}

  	DBPRINTF(("%s: end\n", my_name));

	return(ce_err);
}

void CE_CEM_Recv::Disconnect(void)
{
	const char *my_name = "CE_CEM_Recv::Disconnect";
	ccl_Msg *msg;

 	DBPRINTF(("%s: begin\n", my_name));

	SPX_TRY {

		if (m_msg_connection == NULL) SPX_THROW(err_m_msg_connection_null);

		msg = new ccl_Msg(CCL_MSG_TYPE_DISCONNECT, CCL_MSG_FLAGS_NONE);
		if (msg == NULL) SPX_THROW(err_new_ccl_Msg_failed);
		
		if (!m_msg_connection->SendMessage(msg)) {
			DBPRINTF(("%s: m_msg_connection->SendMessage failed\n", my_name));
		}

		delete msg;
		
		m_msg_connection->Disconnect();

	}
	SPX_CATCH(err_m_msg_connection_null) {
		DBPRINTF(("%s: err_m_msg_connection_null\n", my_name));
	}
	SPX_CATCH(err_new_ccl_Msg_failed) {
		DBPRINTF(("%s: err_new_ccl_Msg_failed\n", my_name));
	}
	SPX_CATCH(err_xxx_failed) {
		DBPRINTF(("%s: err_xxx_failed\n", my_name));
	}

  	DBPRINTF(("%s: end\n", my_name));

}
