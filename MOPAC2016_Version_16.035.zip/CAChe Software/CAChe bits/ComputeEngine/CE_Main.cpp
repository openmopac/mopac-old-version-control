/*
** CE_Main.cpp
*/

/* System includes */
#include <windows.h>
#include <stdio.h>
#include <process.h>
#include <stdlib.h>

// CAChe includes
#include <SimpleExceptions.h>
#include <ccl.h>
#include <ccl_Event.h>
#include <ccl_Msgs.h>

// Local includes
#include "ComputeEngine.h"

const unsigned long COMPUTE_ENGINE_STACKSIZE = 4*1024*1024;

CE_Main::CE_Main(void)
{
	m_state = CE_STATE_CREATING;
	m_status = ce_Err_None;

	m_thread = NULL;
	m_threadID = NULL;

	m_threadComp = NULL;
	m_threadIDComp = NULL;
	m_stacksize = 0;

	m_ce = NULL;
	m_exit_evt = NULL;

}

CE_Main::~CE_Main(void)
{
}

static unsigned __stdcall
ce_Main_Run_Routine(void *ce_Main)
{
	((CE_Main *)ce_Main)->Run();
	return (0);
}

ce_Boolean CE_Main::Init(ComputeEngine *ce)
{
	const char *my_name = "CE_Main::Init";

	DBPRINTF(("%s: begin\n", my_name));

	SPX_TRY {

		m_state = CE_STATE_INITING;

		m_ce = ce;
		m_exit_evt = m_ce->m_main_exit_evt; // ???? really need this since we do PostQuitMessage
		m_MainEvents[MAIN_OSTERM]		= m_ce->m_os_term_evt;
		m_MainEvents[MAIN_CEMRECVEXIT]	= m_ce->m_cem_recv_exit_evt,
		m_MainEvents[MAIN_STOP]			= m_ce->m_stop_evt,
		m_MainEvents[MAIN_CECONTEXIT]	= m_ce->m_continue_evt;

		m_stacksize = ce->StackSize();

		m_thread = (ce_Thread)_beginthreadex(
			NULL,								// default security
			0,									// default stack size
			ce_Main_Run_Routine,				// start address
			(void *)this, 						// argument list
			0,									// thread state
			&m_threadID);						// thread address
	
		if (m_thread == 0) SPX_THROW(err_beginthreadex_failed);

		DBPRINTF(("%s: m_thread=%d m_threadID=%d\n", my_name, m_thread, m_threadID));

	}
	SPX_CATCH(err_beginthreadex_failed) {
		DBPRINTF(("%s: err_beginthreadex_failed: %d (%s)\n",
			my_name, errno, _sys_errlist[errno]));
		m_status = ce_Err_Main_Creation_Failed;
	}
		
	DBPRINTF(("%s: end\n", my_name));

	return ce_Boolean(m_status == ce_Err_None);
}

void CE_Main::Term(void)
{
	const char *my_name = "CE_Main::Term";
 	DWORD		waitResult;
	long		lastError;
	const DWORD	waitTimeout = INFINITE;

	DBPRINTF(("%s: begin\n", my_name));

	SPX_TRY {

		waitResult = WaitForSingleObject(m_thread, waitTimeout);
 		if (waitResult == ~0) {
			lastError = GetLastError();
			DBPRINTF(("%s: WaitForSingleObject %d\n", my_name, lastError));
		}

	}
	SPX_CATCH(err_xxx_failed) {
		DBPRINTF(("%s: err_xxx_failed\n", my_name));
	}

	m_state = CE_STATE_TERMINATED;

	DBPRINTF(("%s: end\n", my_name));
}

void CE_Main::Run(void)
{
	const char *my_name = "CE_Main::Run";
	ccl_EventWait eWait;
	ce_Boolean done = ce_Boolean_False;
 	ce_Boolean do_compute = ce_Boolean_True;

	ce_SetThreadTag("CE_Main ");

	DBPRINTF(("%s: begin\n", my_name));

 	m_state = CE_STATE_RUNNING;
	m_status = ce_Err_None;

	// wait for continue event
	if (m_ce->m_standalone) done = ce_Boolean_True;

	while (!done) {

		eWait = ccl_WaitForMultipleEvents(
			MAIN_NUMBER_OF_EVTS,
			m_MainEvents,
			ccl_Boolean_False,
			CCL_INFINITE_TIMEOUT);

		switch(eWait) {
		case MAIN_OSTERM:
			DBPRINTF(("%s: osterm detected\n",my_name));
			done = ce_Boolean_True;
			do_compute = ce_Boolean_False;
			break;
		case MAIN_CEMRECVEXIT:
			DBPRINTF(("%s: cem_recv exit detected\n",my_name));
			m_MainEvents[MAIN_OSTERM]->Set(); // fake an os term if the cm recv exits.
			m_MainEvents[MAIN_CEMRECVEXIT]->Reset(); // reset the recv exit
			do_compute = ce_Boolean_False;
			break;
		case MAIN_CECONTEXIT:
 			DBPRINTF(("%s: continue received\n",my_name));
			m_MainEvents[MAIN_CECONTEXIT]->Reset();
			done = ce_Boolean_True;
			break;
		case CCL_EVENTWAIT_FAILED:
		case CCL_EVENTWAIT_TIMEDOUT:
		default:
			DBPRINTF(("%s: unknown event detected\n",my_name));
			m_MainEvents[MAIN_OSTERM]->Set(); // fake an os term if an unknown event occurs
			done = ce_Boolean_True;
			do_compute = ce_Boolean_False;
			break;
		}

	}

	if (do_compute) {
		StartComp();
		WaitComp();
	}

	Exit();
	
	DBPRINTF(("%s: end\n", my_name));
}

void CE_Main::Exit(void)
{
	PostMessage(m_ce->m_hWnd, WM_DESTROY, NULL, NULL);
}

static unsigned __stdcall ce_DoComputation_Run_Routine(void *cePtr)
{
	ComputeEngine *ce = (ComputeEngine *)cePtr;

	ce_SetThreadTag("DoComp  ");

	ce->Send_CEM_Status(ssq_ScrollChannel, ce->m_version, CCL_MSG_FLAGS_NONE);
	ce->Send_CEM_Status(ssq_ScrollChannel, "\n", CCL_MSG_FLAGS_NONE);

	ce->DoComputation();

	return (0);
}

void CE_Main::StartComp(void)
{
	const char *my_name = "CE_Main::StartComp";
	long		lastError;

	DBPRINTF(("%s: begin\n", my_name));

	SPX_TRY {

		m_threadComp = (ce_Thread)_beginthreadex(
			NULL,								// default security
			m_stacksize,						// stack size
			ce_DoComputation_Run_Routine,		// start address
			(void *)m_ce, 						// argument list
			CREATE_SUSPENDED,					// thread state
			&m_threadIDComp);					// thread address
	
		if (m_threadComp == 0) SPX_THROW(err_beginthreadex_failed);

		DBPRINTF(("%s: m_threadComp=%d m_threadIDComp=%d\n", my_name, m_threadComp, m_threadIDComp));

		if (!SetThreadPriority(m_threadComp, THREAD_PRIORITY_BELOW_NORMAL)) {
			lastError = GetLastError();
			DBPRINTF(("%s: SetThreadPriority failed %d\n", my_name, lastError));
		}

		if (ResumeThread(m_threadComp) != 1) {
			lastError = GetLastError();
			DBPRINTF(("%s: ResumeThread failed %d\n", my_name, lastError));
		}

	}
	SPX_CATCH(err_beginthreadex_failed) {
		DBPRINTF(("%s: err_beginthreadex_failed: %d (%s)\n",
			my_name, errno, _sys_errlist[errno]));
		m_status = ce_Err_Comp_Creation_Failed;
	}
	SPX_CATCH(err_xxx_failed) {
		DBPRINTF(("%s: err_xxx_failed\n", my_name));
	}

	DBPRINTF(("%s: end\n", my_name));
}

void CE_Main::WaitComp(void)
{
	const char *my_name = "CE_Main::WaitComp";
 	DWORD			waitResult;
	long			lastError;
	const DWORD		waitTimeout = INFINITE;
	DWORD			exit_code = 0;

	DBPRINTF(("%s: begin\n", my_name));

	SPX_TRY {

		waitResult = WaitForSingleObject(m_threadComp, waitTimeout);
 		if (waitResult == ~0) {
			lastError = GetLastError();
			DBPRINTF(("%s: WaitForSingleObject %d\n", my_name, lastError));
		}
		
		if (!GetExitCodeThread(m_threadComp, &exit_code)) {
			DBPRINTF(("%s: GetExitCodeThread failed %d\n", my_name, GetLastError()));
		}

		DBPRINTF(("%s: m_threadComp=0x%08x (%d)  exit_code=0x%08x (%d)\n",
			my_name, m_threadComp, m_threadComp, exit_code, exit_code));

		m_ce->m_status = exit_code;

	}
	SPX_CATCH(err_xxx_failed) {
		DBPRINTF(("%s: err_xxx_failed\n", my_name));
	}

	m_state = CE_STATE_TERMINATED;

	DBPRINTF(("%s: end\n", my_name));
}

