#include <stdio.h>



void SpecificKillDumbCE(void)

// Dummy function for killing dumb compute engine (e.g., DGauss).

{
/* Extracted from DGauss_CE/callDGaussWin32.c
    static char *my_name = "SpecificKillDumbCE";
    UINT exitCode = 0;
#if defined (_DEBUG)
    char errs[LONG_STRING];
#endif

    if (ce_process == NULL)
    {
#if defined (_DEBUG)
        sprintf(errs, "%s: ce_process is NULL", my_name);
        alert_user(errs);
#endif
    } else {
#if defined (_DEBUG)
        sprintf(errs, "%s: killing ce_process", my_name);
        alert_user(errs);
#endif
        TerminateProcess(ce_process, exitCode);
#if defined (_DEBUG)
        sprintf(errs, "%s: exitCode is %d", my_name, exitCode);
        alert_user(errs);
#endif
    }
*/
}
