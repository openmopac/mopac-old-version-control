/*

 * CE.cpp

 */



// System includes

#include <windows.h>

#include <process.h>

#include <time.h>

#include <stdio.h>



// CAChe Includes

#include <cul.h>

#include "CACheVersion.h"

#include <LogMgr.h>

#include <SimpleExceptions.h>

#include <ccl.h>

#include <ccl_Event.h>



// Local includes

#include "ComputeEngine.h"



/* log file manager */

static LogMgr* ce_pTheLogMgr;



void ce_DebugPrintf(char *fmt, ...)

{

    if (ce_pTheLogMgr == NULL) return;

    va_list argp;

    va_start(argp, fmt);

    ce_pTheLogMgr->VPrint(fmt, argp);

    va_end(argp);

}



void

ce_SetThreadTag(

char*    tag

) {

    if (ce_pTheLogMgr == NULL) return;

    ce_pTheLogMgr->SetTag(tag);

}



static

void

ce_LogTime(const char* my_name) {

    time_t t = time(NULL);

    // String returned by ctime already has a newline.

    if (t != NULL) DBPRINTF(("%s: %s", my_name, ctime(&t)));

}



void ComputeEngine::ResetLogFile(void)

{

    if (ce_pTheLogMgr == NULL) return;

    ce_pTheLogMgr->Rewind("ComputeEngine"); // Put date, time, version info here.

}



/*

** ComputeEngine constructor

*/

ComputeEngine::ComputeEngine(void)

{

    m_standalone = ce_Boolean_False;

#if defined(_WIN32)

    m_process    = GetCurrentProcess();

    m_processID    = GetCurrentProcessId();

    m_thread    = GetCurrentThread();

    m_threadID    = GetCurrentThreadId();

#elif defined(unix)

    m_process    = getpid();

    m_processID    = getpid();

    m_thread    = 0;

    m_threadID    = 0;

#else

# error "Need to define method for getting process id"

#endif

    m_programName[0] = '\0';

    m_inputFileList = NULL;

    

    m_version = EVAL_MACRO(CACHE_MY_NAME) " " CACHE_VERSION " " __DATE__ " "  __TIME__;

    m_copyright = "Copyright " CACHE_COPYRIGHT;



    m_logFile = NULL;

    m_logFileBaseName = "ComputeEngine";

    memset(m_logFileName, 0, sizeof(m_logFileName));

    

    // initialize all of the active objects

    m_main = NULL;

    m_cem_recv = NULL;



    // initialize the event objects

    m_os_term_evt = NULL;

    m_cem_recv_exit_evt = NULL;

    m_stop_evt = NULL;

    m_continue_evt = NULL;

    m_main_exit_evt = NULL;

}



/*

** ComputeEngine destructor

*/

ComputeEngine::~ComputeEngine()

{



    delete m_main;

    delete m_cem_recv;



    delete m_os_term_evt;

    delete m_cem_recv_exit_evt;

    delete m_stop_evt;

    delete m_continue_evt;

    delete m_main_exit_evt;

}



/*

** ComputeEngine::Init function

**    return: true if succeeded, false if failed

*/



#define NEXT_ARG(xp) (((xp) - argv + 1) < argc ? (xp) + 1: NULL)





ce_Boolean ComputeEngine::Init(int argc, char *argv[], HWND hWnd)

{

     const char *my_name = "ComputeEngine::Init";

     char **p;


    SPX_TRY {



        m_argc = argc;

        m_argv = argv;

        m_hWnd = hWnd;

        m_state = CE_STATE_INITING;

        GetModuleFileName(NULL, m_programName, CE_FILE_NAME_SIZE);



        if (strstr(argv[0], ".exe") != NULL)

            p = NEXT_ARG(argv);

        else

            p = argv;



        while (p) {

            if (0) {

                ;

            }

            else if   (strncmp(*p, "-r", 2) == 0) {              // rPort or rPortAck

                if (*(*p+2) == 'a')

                    m_rPortAck = (PORTHANDLE)atoi(*p+4);

                else

                    m_rPort = (PORTHANDLE)atoi(*p+3);

                p = NEXT_ARG(p);

            } else if (strncmp(*p, "-s", 2) == 0) {            // sPort or sPortAck

                if (*(*p+2) == 'a')

                    m_sPortAck = (PORTHANDLE)atoi(*p+4);

                else

                    m_sPort = (PORTHANDLE)atoi(*p+3);

                p = NEXT_ARG(p);

            } else if (strncmp(*p, "-S", 2) == 0) {

                m_standalone = ce_Boolean_True;

            } else if (strncmp(*p, "-d", 2) == 0) {



                sprintf(m_logFileName, "%s%d.log", m_logFileBaseName, m_processID);

                ce_pTheLogMgr = new LogMgr(m_logFileName);

                if (ce_pTheLogMgr == NULL) SPX_THROW(err_LogMgr_failed);

                ce_SetThreadTag("CompEng ");

                m_logFile = ce_pTheLogMgr->GetFile();



                m_debugFlag = ce_Boolean_True;



            } else if (strncmp(*p, "-cft", 4) == 0) { // generic cache file type

                p = NEXT_ARG(p);                      // get file type

                unsigned long cftype = atol(*p);

                p = NEXT_ARG(p);                      // get file name

                AddInputFile(cftype, *p);

            } else if (strncmp(*p, "-fi\0", 4) == 0) { // input file 1

                p = NEXT_ARG(p);                      // get pointer to the file name

                AddInputFile(ssq_file_molecule, *p);

//

// Comment extracted from ServerStepQueue/SSQFileTypes.h:

//

// The following five defines were extracted from the Standalone/ServerStepQueue version

// of this file.  They conflict with the set defined in CommonLibs/Utility/ExternInclude

// since both ssq_file_output and ssq_file_input are defined to be "4".  In addition, it

// is necessary to (1) maintain the value of ssq_file_custom as "9" in order to maintain

// compatibility with previous versions of CAChe, and (2) reserve the values after

// "9" for (especially "10" see cachedir.c).  The following five defines were commented

// out since they did not seem to be necessary.  References to these defines were also

// commented out in the following files under wincache/src/Standalone:

//

// CEMgr/CEMgr.cpp

// ComputeEngine/CE.cpp

// MOPAC_Mgr/CEM_PreProcess.cpp

//

// (MSS Dec 2003)

//

//          } else if (strncmp(*p, "-fi2", 4) == 0) { // input file 2

//              p = NEXT_ARG(p);                      // get pointer to the file name

//              AddInputFile(ssq_file_input2, *p);

            } else if (strncmp(*p, "-fs", 3) == 0) { // settings file

                p = NEXT_ARG(p);                      // get pointer to the file name

                AddInputFile(ssq_file_settings, *p);

//          } else if (strncmp(*p, "-fd", 3) == 0) { // data dictionary

//              p = NEXT_ARG(p);                      // get pointer to the file name

//              AddInputFile(ssq_file_datadict, *p);

//          } else if (strncmp(*p, "-fp\0", 4) == 0) { // parameters file 1

//              p = NEXT_ARG(p);                      // get pointer to the file name

//              AddInputFile(ssq_file_params, *p);

//          } else if (strncmp(*p, "-fp2", 4) == 0) { // parameters file 2

//              p = NEXT_ARG(p);                      // get pointer to the file name

//              AddInputFile(ssq_file_params2, *p);

            } else {

                ParseOtherFlags(*p);

            }

            p = NEXT_ARG(p);

        }



        DBPRINTF(("%s: begin\n", my_name));



        ce_LogTime(my_name);



        for (int i = 0; i < argc; i++)

            DBPRINTF(("%s\n",argv[i]));



        DBPRINTF(("%s: rPort=%d rPortAck=%d sPort=%d sPortAck=%d\n",

            my_name, m_rPort, m_rPortAck, m_sPort, m_sPortAck));



        if (!m_standalone && m_rPort == 0 && m_rPortAck == 0 &&

                m_sPort == 0 && m_sPortAck == 0)

            SPX_THROW(err_process_flags_incorrect);

                 

        // Construct and init the event objects used to communicate between

        // active objects.

        m_os_term_evt = new ccl_Event;

        if ((m_os_term_evt == NULL) || !m_os_term_evt->Init(CCL_EVENTTYPE_MANUAL))

             SPX_THROW(err_ccl_event_creation_failed);



        m_cem_recv_exit_evt = new ccl_Event;

        if ((m_cem_recv_exit_evt == NULL) || !m_cem_recv_exit_evt->Init(CCL_EVENTTYPE_MANUAL))

             SPX_THROW(err_ccl_event_creation_failed);



        m_stop_evt = new ccl_Event;

        if ((m_stop_evt == NULL) || !m_stop_evt->Init(CCL_EVENTTYPE_MANUAL))

             SPX_THROW(err_ccl_event_creation_failed);



        m_continue_evt = new ccl_Event;

        if ((m_continue_evt == NULL) || !m_continue_evt->Init(CCL_EVENTTYPE_MANUAL))

             SPX_THROW(err_ccl_event_creation_failed);



        m_main_exit_evt = new ccl_Event;

        if ((m_main_exit_evt == NULL) || !m_main_exit_evt->Init(CCL_EVENTTYPE_MANUAL))

             SPX_THROW(err_ccl_event_creation_failed);

        

        // If not standalone then create the cm_recv (uem).

        if (!m_standalone) {

            /* create the connection object */

            m_msg_connection = new ccl_MsgConnection(m_rPort, m_rPortAck,

                                                        m_sPort, m_sPortAck, m_logFile);

            if (m_msg_connection == NULL)

                SPX_THROW(err_create_msg_connection_failed);



            m_cem_recv = new CE_CEM_Recv;

            if (m_cem_recv == NULL || !m_cem_recv->Init(this, m_msg_connection))

                SPX_THROW(err_create_cem_recv_failed);

        } else {

            m_continue_evt->Set(); // lets the compute engine continue

        }



        // Create the cem_Main active object.

        m_main = new CE_Main;

        if (m_main == NULL || !m_main->Init(this))

            SPX_THROW(err_create_main_failed);



    }

    SPX_CATCH(err_LogMgr_failed) {

        m_status = ce_Err_LogMgr_Creation_Failed;

    }

    SPX_CATCH(err_process_flags_incorrect) {

        m_status = ce_Err_Main_Creation_Failed;

    }

    SPX_CATCH(err_ccl_event_creation_failed) {

        DBPRINTF(("%s: err_ccl_event_creation_failed\n",my_name));

        m_status = ce_Err_Event_Creation_Failed;

    }

    SPX_CATCH(err_create_msg_connection_failed) {

        DBPRINTF(("%s: err_create_msg_connection_failed\n",my_name));

        m_status = ce_Err_Msg_Connection_Creation_Failed;

    }



    SPX_CATCH(err_create_cem_recv_failed) {

        DBPRINTF(("%s: err_create_cm_recv_failed\n",my_name));

        m_status = ce_Err_CEM_Recv_Creation_Failed;

    }

    SPX_CATCH(err_create_main_failed) {

        DBPRINTF(("%s: err_create_main_failed\n",my_name));

        m_status = ce_Err_Main_Creation_Failed;

    }



    DBPRINTF(("%s: end\n", my_name));



    return ce_Boolean(m_status == ce_Err_None);

}



int ComputeEngine::Term()

{

     const char *my_name = "ComputeEngine::Term";



    DBPRINTF(("%s: begin\n", my_name));



    // Terminate the active objects

    m_os_term_evt->Set();

    

    if (m_main != NULL)

        m_main->Term();

        

    if (m_cem_recv != NULL)

        m_cem_recv->Term();



    delete m_msg_connection;

    m_msg_connection = NULL;

    

    m_state = CE_STATE_TERMINATED;



    DBPRINTF(("%s: m_status=0x%08x (%d)\n", my_name, m_status, m_status));



    ce_LogTime(my_name);

    

    DBPRINTF(("%s: end\n", my_name));



    if (ce_pTheLogMgr != NULL) ce_pTheLogMgr->Flush();

    delete ce_pTheLogMgr;

    ce_pTheLogMgr = NULL;



    return(m_status);

}



#define CE_MAX_INPUT_FILES ssq_file_custom



ce_Boolean ComputeEngine::AddInputFile(

    unsigned long cftype,

    char *fileName)

{

    const char *my_name = "ComputeEngine::AddInputFile";

    

    DBPRINTF(("%s: file='%s' type=%d\n", my_name, fileName, cftype));

    

    if (m_inputFileList == NULL) {

        m_inputFileList =  (ssq_FileTransferList *) new char[ssq_SIZEOF_LIST(ssq_FileTransferList, CE_MAX_INPUT_FILES, files)];

        if (m_inputFileList == NULL)

            return ce_Boolean_False;

        m_inputFileList->numFiles = 0;

    }



    if (m_inputFileList->numFiles >= CE_MAX_INPUT_FILES)

        return ce_Boolean_False;



    strncpy(m_inputFileList->files[m_inputFileList->numFiles].fileName,

            fileName,

            ssq_FileNameSize);



    m_inputFileList->files[m_inputFileList->numFiles].CACheFileType = cftype;

    m_inputFileList->files[m_inputFileList->numFiles].CACheTransferFormat = ssq_ASCII;

    m_inputFileList->files[m_inputFileList->numFiles].CACheFolderType = ssq_folder_molecule;



    m_inputFileList->numFiles++;



    return ce_Boolean_True;

}



ce_Boolean    ComputeEngine::Send_CEM_Status(

    unsigned int channel,

    char *status,

    unsigned char flag

)

{

    const char *my_name = "ComputeEngine::Send_CEM_Status";

    int stat_len = strlen(status) + 1; // make sure NULL terminator is sent

    ce_Boolean ret = ce_Boolean_True;



    DBPRINTF(("%s: chan=%d status=\n    '%s'\n", my_name, channel, status));



    if (!m_standalone) {



        ccl_Msg_Status *msg = new ccl_Msg_Status(CCL_MSG_TYPE_STATUS,

                flag, channel, stat_len, status);

    

        ret = ce_Boolean((msg != NULL) && m_msg_connection->SendMessage(msg));



        delete msg;

    }

    

    return ret;



}



ce_Boolean    ComputeEngine::Send_CEM_DoProc(unsigned char flag)

{

    const char *my_name = "ComputeEngine::Send_CEM_DoProc";

    ce_Boolean ret = ce_Boolean_True;



    DBPRINTF(("%s: begin\n", my_name));



    if (!m_standalone) {



        ccl_Msg *msg = new ccl_Msg(CCL_MSG_TYPE_DO_PROC, flag);

    

        ret = ce_Boolean(m_msg_connection->SendMessage(msg));



        delete msg;

    }



    DBPRINTF(("%s: end\n", my_name));

    

    return ret;

}



void ComputeEngine::ParseOtherFlags(char *p)

{

}



void ComputeEngine::DoComputation(void)

{

}



unsigned long ComputeEngine::StackSize(void)

{

    return (CE_DEFAULT_STACKSIZE);

}

