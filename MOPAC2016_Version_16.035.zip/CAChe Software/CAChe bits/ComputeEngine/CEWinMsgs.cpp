/*
** CEWinMsgs.cpp
*/

#include <cel.h>
#include <CACheFileLib.h>
#include <ServerStepQueue.h>
#include <SimpleExceptions.h>

#include "ComputeEngine.h"

LRESULT ComputeEngine::WmPaint(HWND hWnd, UINT message, WPARAM uParam, LPARAM lParam)
{
	const char*	my_name = "ComputeEngine::WmPaint";
	const int	xStart = 20;
	const int	yStart = 20;
	PAINTSTRUCT	ps;
	HDC			hdc;
	TEXTMETRIC	tm;

	hdc = BeginPaint(hWnd, &ps);
	if (m_version != NULL && m_copyright != NULL && GetTextMetrics(hdc, &tm)) {
		TextOut(hdc, xStart, yStart, m_version, strlen(m_version));
		TextOut(hdc, xStart, yStart + tm.tmHeight + tm.tmExternalLeading,
			m_copyright, strlen(m_copyright));
	}
	EndPaint(hWnd, &ps);

	return(0);
}


LRESULT ComputeEngine::WmCopyData(HWND hWnd, UINT message, WPARAM uParam, LPARAM lParam)
{
	const char*	my_name = "ComputeEngine::WmCopyData";
	PCOPYDATASTRUCT cdsp;

	cdsp = (PCOPYDATASTRUCT) lParam;
	DBPRINTF(("%s: 0x%x 0x%x 0x%x 0x%x dwData=0x%08x\n", my_name,
		hWnd, message, uParam, lParam, cdsp->dwData));

	return(TRUE);
}

