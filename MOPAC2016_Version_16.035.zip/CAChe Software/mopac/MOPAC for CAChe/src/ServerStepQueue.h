/* ServerStepQueue.h */

#ifndef __ServerStepQueue__
#define __ServerStepQueue__

#ifndef RC_INVOKED     	// Do only error #defines if compiling resources

/******************************************************
 *
 * ServerStepQueue Constants that can be used by C or Rez.
 *
 ******************************************************/
#include <CACheMacros.h>
 
#define	ssq_ApplNameSize		32
#define	ssq_RsrcStrSize			10
#define CACHE_RESOURCE_TYPE 		CM_C4TOLONG('C','A','C','H')	/* Resource type identifying CAChe Appl */
#define CACHE_APPLMGR_FILE_TYPE 	CM_C4TOLONG('A','P','M','G')	/* Mac FileType identifying Application Mgr */
#define CACHE_88K_FILE_TYPE 		CM_C4TOLONG('A','p','8','8')	/* Mac FileType identifying 88K Appl */
#define CACHE_CXP_FILE_TYPE 		CM_C4TOLONG('A','C','X','P')	/* Mac FileType identifying CXP Appl */
#define amgr_RES_ID			128		/* Resource ID of CAChe type identifying ApplMgr */
#define amgr_RES_88KID			129		/* Resource ID of CAChe type identifying 88K Code */
#define aui_RES_ID			130		/* Resource ID of CAChe type identifying UserIntfc */
#define AUI_Personal			0x0001		/* Appl UI is Personal (not network-savvy) type */
#define AUI_NetworkSavvy		0x0002		/* Appl UI is network-savvy (not Personal) type */
#define AUI_NetworkMask			0x0003		/* Appl UI network type mask */
#define AUI_Graphical			0x0004		/* Graphical UI mask */
#define	ssq_88KServerPrefix		"88K Slot "	/* prefix for 88K Server */
#define	ssq_CXPServerPrefix		"CXP Slot "	/* prefix for CXP Server */
#define	ssq_PersonalServerName		"This Macintosh"/* Server name for personal servers */
#define	ssq_QueueLimit			40		/* size limit for UserQueue and ServerQueue */

/***********************************************************
 *
 *		ServerStepQueue Error and Cause Codes
 *
 ***********************************************************/

#define	ssq_ErrorCodesID		8000
#define	ssq_MiscErrorStringsID		8001
#define	ssq_FirstErrorCode		-8099
#define ssq_ErrorCodeOffset		-8100

/* Misc Error Strings */
#define	ssq_StepTitle			1
#define	ssq_MachineName			2
#define	ssq_ServerName			3

#endif 	// RC_INVOKED     	// Do only error #defines if compiling resources

/* Error Codes */
#define	ssq_NoErr			0
#define	ssq_LaunchError			-8099
#define	ssq_FileLocked			-8098
#define	ssq_ServerFileNotFound		-8097
#define	ssq_UserFileNotFound		-8096
#define	ssq_ServerDiskFull		-8095
#define	ssq_UserDiskFull		-8094
#define	ssq_ServerIOError		-8093
#define	ssq_UserIOError			-8092
#define	ssq_KillStep			-8091
#define	ssq_StopStep			-8090
#define	ssq_InputFileError		-8089
#define	ssq_OutputFileError		-8088
#define	ssq_ServerDied			-8087
#define	ssq_ServerTimeOut		-8086
#define	ssq_UserTimeOut			-8085
#define	ssq_UserOutOfMemory		-8084
#define	ssq_ServerOutOfMemory		-8083
#define	ssq_OutOfMemory			-8082
#define	ssq_UserQDied			-8081
#define	ssq_ServerNotResponding		-8080
#define	ssq_UserNotResponding		-8079
#define	ssq_OpenPort			-8078
#define	ssq_DuplicateAppMgr		-8077
#define	ssq_ServerNotRegistered		-8076
#define	ssq_ServerNotFound		-8075
#define	ssq_NoCACheLoc			-8074
#define	ssq_CACheSystemErr		-8073
#define	ssq_FileBusy			-8072
#define	ssq_ServerDirNotFound		-8071
#define	ssq_UserDirNotFound		-8070
#define	ssq_UQNotFound			-8069
#define	ssq_UQOutOfMemory		-8068
#define	ssq_QMNotFound			-8067
#define	ssq_QMOutOfMemory		-8066
#define	ssq_TooManyFiles		-8065
#define	ssq_UnixClientDied		-8064
#define	ssq_OpenCheckPointErr		-8063
#define	ssq_ReadCheckPointErr		-8062
#define	ssq_WriteCheckPointErr		-8061
#define	ssq_Illegal_ID			-8060
#define	ssq_QueueEmpty			-8059
#define	ssq_Illegal_Subscriber		-8058
#define	ssq_BadArguments		-8057
#define	ssq_DataXfrAbort		-8056
#define	ssq_ServerBadFileSize		-8055
#define	ssq_GuestNotAllowed		-8054
#define	ssq_ProcNotValid		-8053
#define	ssq_CannotHandleProc		-8052
#define	ssq_IllegalEventSent		-8051
#define	ssq_QueueLimitExceeded		-8050

#ifndef RC_INVOKED     	// Do only error #defines if compiling resources

#ifdef rez
	/* Include next portion only for Rez */
	type CACHE_RESOURCE_TYPE (amgr_RES_ID)		/* This resource should be in all Appl Managers */
	{
		unsigned longint;			/* version */
		longint;				/* MacOS file type for 88K code or
										NULL if 68K application manager */
	};
	
	type CACHE_RESOURCE_TYPE (amgr_RES_88KID)	/* This resource should be in all 88K appl files */
	{
		unsigned longint;			/* version */
		longint;					/* memory requirement in MBytes (NULL, if no requirement) */
		cstring[ssq_RsrcStrSize];	/* string to be used in place of 88K memory size when displaying
										server name in browser.  NULL string, if not applicable. */
	};
	
	type CACHE_RESOURCE_TYPE (aui_RES_ID)		/* This resource should be in all UserIntfcs */
	{
		unsigned longint;			/* version */
		unsigned longint;			/* flag specifying application kind */
									/* AUI_Personal or AUI_NetworkSavvy */
		cstring[ssq_ApplNameSize];	/* application name */
	};
	
		
#else			
	/* Include rest of file for C, C++ */

#include <stddef.h>

/******************************************************
 *
 *      Include file and folder type definitions
 *
 ******************************************************/
 #include <SSQFileTypes.h>

/******************************************************
 *
 *		ServerStepQueue Macros
 *
 ******************************************************/
 
/******************************************************
 *	This macro gets the size of a list for use in
 *	allocating it.
 ******************************************************/
 
 #define ssq_SIZEOF_LIST(theListType, numElems, firstElem) \
 			(offsetof(theListType, firstElem) + \
			(numElems) * sizeof(((theListType *) 0)->firstElem))


/******************************************************
 *
 *		ServerStepQueue Constants
 *
 ******************************************************/
 
#define	ssq_StepNotYetQueued			0
#define	ssq_StepAccepted			1
#define	ssq_ReceivingInputData			2
#define	ssq_SendingInputData			3
#define	ssq_ReceivingOutputData			4
#define	ssq_SendingOutputData			5
#define	ssq_StepCompleted			6
#define	ssq_StepExecuting			7
#define	ssq_StepPending				8
#define	ssq_SendingOutputDataError		9
#define ssq_ReceivingOutputDataError		10
#define ssq_RemovalPending			11
#define ssq_KillPending				12
#define ssq_StopPending				13
#define	ssq_StepSuspended			14
#define	ssq_StepNoLongerQueuedNormal		15
#define	ssq_StepNoLongerQueuedAbnormal		16
#define	ssq_StepCompletedErr			17
#define	ssq_ProcTransition			18
#define	ssq_numStepStates			19

#define ssq_DataFork 0
#define ssq_ResourceFork 1

#define ssq_ReturnOutputFiles	0
#define ssq_DeleteOutputFiles	1

/*
 * Modifiers specifying if Option-key is held down when user chooses to Kill or Stop
 * a step.  The modifier is passed in the appropriate AppleEvent.
 */
#define ssq_NormalKill		0
#define ssq_OptionKill		1

#define ssq_ImmediateKill	0
#define ssq_ConvenientKill	1

#define	ssq_SERVERQ_ID		0
#define	ssq_USERQ_ID		1

#define ssq_NoPendingMsg	0
#define ssq_PendingMsgExists	1

#define ssq_OutputFileAlreadyExisted	0
#define ssq_OutputFileCreated		1

/* The following constants define the status channels for the AUIs */
#define	ssq_CurrentCalcChannel		1		/* Current calculation field */
#define	ssq_CurrentOpChannel		2		/* Current operation field */
#define	ssq_ScrollChannel		3		/* Scrolling region */

#define ssq_DateTimeFormat		"%a %b %d, %Y  %H:%M:%S"
#define	ssq_DateSize			32
#define	ssq_ServerNameSize		64 // user@server can be longer than 32 chars! Changed (JAS 13/11/96)
#define	ssq_UserNameSize		32
#define	ssq_MachineNameSize		32
#define	ssq_StepTitleSize		32
#define	ssq_FileNameSize		256
#define	ssq_PathNameSize		1024
#define	ssq_SubscriberFilterSize	32
#define	ssq_StatusMessageSize		256
#define	ssq_NotificationStringSize	1024

/***********************************************************
 *
 *		ServerStepQueue typedefs
 *
 ***********************************************************/
 
typedef long		ssq_StepID;
typedef long		ssq_Err;
typedef	long		ssq_ErrorCodes;	
typedef	long		ssq_MiscErrorStrings;	
typedef	long		ssq_stepState;	
typedef unsigned char	ssq_Date[ssq_DateSize], *ssq_DatePtr;
typedef	unsigned long	ssq_CACheFileType;
typedef	unsigned long	ssq_CACheFolderType;
typedef	unsigned long	ssq_CACheTransferFormat;
 

struct ssq_UnixNetAddr
{
	unsigned long	x;
};
typedef struct ssq_UnixNetAddr ssq_UnixNetAddr;
typedef struct ssq_UnixNetAddr* ssq_UnixNetAddrPtr;
 
typedef ssq_UnixNetAddr ssq_NetAddr;

struct ssq_UnixProcessSerialNumber
{
	unsigned long	x;
};
typedef struct ssq_UnixProcessSerialNumber ssq_UnixProcessSerialNumber;
typedef struct ssq_UnixProcessSerialNumber* ssq_UnixProcessSerialNumberPtr;

typedef ssq_UnixProcessSerialNumber ssq_ProcessSerialNumber;

/***********************************************************
 *
 *		ServerStepQueue data structures
 *
 ***********************************************************/
 
/***********************************************************
 * StepControl is formed by the Application User Interface
 * and modified by the user and server queues
 ***********************************************************/
struct ssq_StepControl 
{
    ssq_Date		dateSubmitted;
	ssq_Date		dateStarted;
	long			stepState;
	ssq_StepID		userQStepID;
	ssq_StepID		serverQStepID;
	unsigned long	applSignature;
	char			applName[ssq_ApplNameSize];
	char			serverName[ssq_ServerNameSize];
	char			userName[ssq_UserNameSize];
	char			machineName[ssq_MachineNameSize];
	char			stepTitle[ssq_StepTitleSize];
};
typedef struct ssq_StepControl ssq_StepControl;
typedef ssq_StepControl* ssq_StepControlPtr;

struct ssq_StepControlList
{
	long 					numEntries;
	ssq_StepControl			entry[1];
};
typedef struct ssq_StepControlList ssq_StepControlList;
typedef struct ssq_StepControlList* ssq_StepControlListPtr;

/***********************************************************
 * FileTransferSpec is created by UserQueue from an
 *  InputFile or ServerQueue from an OutputFile
 ***********************************************************/
struct ssq_UnixFileTransferSpec
{
	char fileName[ssq_FileNameSize];
	ssq_CACheFileType CACheFileType;
	ssq_CACheFolderType CACheFolderType;
	ssq_CACheTransferFormat CACheTransferFormat;
};
typedef struct ssq_UnixFileTransferSpec ssq_UnixFileTransferSpec;
typedef struct ssq_UnixFileTransferSpec* ssq_UnixFileTransferSpecPtr;

typedef struct ssq_UnixFileTransferSpec ssq_FileTransferSpec;

typedef ssq_FileTransferSpec* ssq_FileTransferSpecPtr;

/***********************************************************
 * FileTransferList is used by applications to pass file names
 ***********************************************************/
struct ssq_FileTransferList
{
    long numFiles;
    ssq_FileTransferSpec files[1];
};
typedef struct ssq_FileTransferList ssq_FileTransferList;
typedef struct ssq_FileTransferList* ssq_FileTransferListPtr;
/* This is used to create a file list with no entries */
typedef struct ssq_FileTransferList ssq_MinimalFileTransferList;


struct ssq_UnixFileTransferList
{
    long numFiles;
    ssq_UnixFileTransferSpec files[1];
};
typedef struct ssq_UnixFileTransferList ssq_UnixFileTransferList;
typedef struct ssq_UnixFileTransferList* ssq_UnixFileTransferListPtr;


/***********************************************************
 * PrimaryOutputFile is created by Application user interface
 *  and modified by user queue
 ***********************************************************/
struct ssq_UnixPrimaryOutputFile
{
	char			fileName[ssq_FileNameSize];
	long			createdByUserQueue;
};
typedef struct ssq_UnixPrimaryOutputFile ssq_UnixPrimaryOutputFile;
typedef struct ssq_UnixPrimaryOutputFile* ssq_UnixPrimaryOutputFilePtr;

typedef struct ssq_UnixPrimaryOutputFile ssq_PrimaryOutputFile;

typedef ssq_PrimaryOutputFile* ssq_PrimaryOutputFilePtr;


/***********************************************************
 * PrimaryOutputFileList is created by Application user interface
 *  and modified by user queue
 ***********************************************************/
struct ssq_PrimaryOutputFileList
{
	long 					numFiles;
	ssq_PrimaryOutputFile	files[1];
};
typedef struct ssq_PrimaryOutputFileList ssq_PrimaryOutputFileList;
typedef struct ssq_PrimaryOutputFileList* ssq_PrimaryOutputFileListPtr;


struct ssq_UnixPrimaryOutputFileList
{
	long 						numFiles;
	ssq_UnixPrimaryOutputFile	files[1];
};
typedef struct ssq_UnixPrimaryOutputFileList ssq_UnixPrimaryOutputFileList;
typedef struct ssq_UnixPrimaryOutputFileList* ssq_UnixPrimaryOutputFileListPtr;


/***********************************************************
 * OutputFolder is created by Application user interface
 ***********************************************************/
struct ssq_UnixOutputFolder
{
	char fileName[ssq_FileNameSize];
	ssq_CACheFolderType CACheFolderType;
};
typedef struct ssq_UnixOutputFolder ssq_UnixOutputFolder;
typedef struct ssq_UnixOutputFolder* ssq_UnixOutputFolderPtr;

typedef struct ssq_UnixOutputFolder ssq_OutputFolder;

typedef ssq_OutputFolder* ssq_OutputFolderPtr;

/***********************************************************
 * OutputFolderList is created by Application user interface
 ***********************************************************/
struct ssq_OutputFolderList
{
	long				numFolders;
	ssq_OutputFolder	folders[1];
};

typedef	struct ssq_OutputFolderList ssq_OutputFolderList;
typedef	struct ssq_OutputFolderList* ssq_OutputFolderListPtr;


struct ssq_UnixOutputFolderList
{
	long					numFolders;
	ssq_UnixOutputFolder	folders[1];
};

typedef	struct ssq_UnixOutputFolderList ssq_UnixOutputFolderList;
typedef	struct ssq_UnixOutputFolderList* ssq_UnixOutputFolderListPtr;


/***********************************************************
 * Subscriber is created by Server Queue
 ***********************************************************/
struct ssq_Subscriber
{
	ssq_NetAddr		identifier;
	char			filter[ssq_SubscriberFilterSize];
};

typedef	struct ssq_Subscriber ssq_Subscriber;
typedef	struct ssq_Subscriber* ssq_SubscriberPtr;

/***********************************************************
 * SubscriberEntry is created by Server Queue
 ***********************************************************/
struct ssq_SubscriberEntry
{
	struct ssq_SubscriberEntry		*next;
	struct ssq_SubscriberEntry		*prev;
	ssq_Subscriber					subscriber;
};

typedef	struct ssq_SubscriberEntry ssq_SubscriberEntry;
typedef	struct ssq_SubscriberEntry* ssq_SubscriberEntryPtr;


/***********************************************************
 * StatusMsg is created by Application Manager
 ***********************************************************/
struct ssq_StatusMsg
{
	long		channelID;
	ssq_Date	statusDate;
	char		status[ssq_StatusMessageSize];	
};
typedef	struct ssq_StatusMsg ssq_StatusMsg;
typedef	struct ssq_StatusMsg* ssq_StatusMsgPtr;


/***********************************************************
 * StatusMsgList is created by Server Queue 
 ***********************************************************/
struct ssq_StatusMsgList
{
	long					numChannels;
	ssq_StatusMsg			statusMsg[1];
};

typedef	struct ssq_StatusMsgList ssq_StatusMsgList;
typedef	struct ssq_StatusMsgList* ssq_StatusMsgListPtr;


/***********************************************************
 * TempOutputFileDest is created by Server Queue
 ***********************************************************/
struct ssq_UnixTempOutputFileDest
{
	char			dirName[ssq_PathNameSize];
};
typedef	struct ssq_UnixTempOutputFileDest ssq_UnixTempOutputFileDest;
typedef	struct ssq_UnixTempOutputFileDest* ssq_UnixTempOutputFileDestPtr;
typedef struct ssq_UnixTempOutputFileDest ssq_TempOutputFileDest;

typedef ssq_TempOutputFileDest* ssq_TempOutputFileDestPtr;


/***********************************************************
 * MsgReason is created by Server Queue
 ***********************************************************/
struct ssq_MsgReason
{
	ssq_Err	primaryCauseCode;
	ssq_Err secondaryCauseCode;
	char	userName[ssq_UserNameSize];
};
typedef	struct ssq_MsgReason ssq_MsgReason;
typedef	struct ssq_MsgReason* ssq_MsgReasonPtr;


/***********************************************************
 * StepInputFileSpec is created by CACheProject
 ***********************************************************/
struct ssq_StepInputFileSpec
{
	char fileName[ssq_FileNameSize];
	ssq_CACheFileType CACheFileType;
};
typedef struct ssq_StepInputFileSpec ssq_StepInputFileSpec;
typedef	struct ssq_StepInputFileSpec* ssq_StepInputFileSpecPtr;


/***********************************************************
 * StepInputFileList is created by CACheProject
 ***********************************************************/
struct ssq_StepInputFileList
{
	long					numEntries;
	ssq_StepInputFileSpec	entry[1];
};

typedef	struct ssq_StepInputFileList ssq_StepInputFileList;
typedef	struct ssq_StepInputFileList* ssq_StepInputFileListPtr;


/***********************************************************
 * ProcedureSpec is created by CACheProject
 ***********************************************************/
struct ssq_ProcedureSpec
{
	char						applName[ssq_ApplNameSize];
	unsigned long				applSignature;
	ssq_StepInputFileListPtr	stepFileList;
};

typedef	struct ssq_ProcedureSpec ssq_ProcedureSpec;
typedef	struct ssq_ProcedureSpec* ssq_ProcedureSpecPtr;

/***********************************************************
 * ProcedureList is created by CACheProject
 ***********************************************************/
struct ssq_ProcedureList
{
	long						numEntries;
	char						submitterName[ssq_ApplNameSize];
	ssq_ProcedureSpec			entry[1];
};

typedef	struct ssq_ProcedureList ssq_ProcedureList;
typedef	struct ssq_ProcedureList* ssq_ProcedureListPtr;


/***********************************************************
 * Step is formed by UserQueue and ServerQueue
 ***********************************************************/
struct ssq_Step
{
	struct ssq_StepControl			control;
	ssq_FileTransferListPtr			inputTransferFiles;
	ssq_PrimaryOutputFileListPtr	primOutputFiles;
	ssq_OutputFolderListPtr			outputFolders;
	ssq_NetAddr						msgDest;
	ssq_SubscriberEntryPtr			firstStatusSubscriber;
	ssq_FileTransferListPtr			outputTransferFiles;
	ssq_TempOutputFileDest			outputFilesDest;
	ssq_ProcessSerialNumber			applMgrPSN;
	long							finalStatus;
	long							outputFileDisposition;
	long							pendingMsg;
	ssq_MsgReason					msgReason;
	ssq_StatusMsgListPtr			statusMessages;
	long							procExec;	/* If not a procedure, set to 0. If a procedure,
												 * initialized to 1.  Then incremented after
												 * each step in procedure completes. */
	ssq_ProcedureListPtr			procList;
};
typedef struct ssq_Step ssq_Step;
typedef struct ssq_Step* ssq_StepPtr;


/***********************************************************
 * QueueEntries are created by this library
 ***********************************************************/
 
struct ssq_QueueEntry
{
	struct ssq_QueueEntry		*next;
	struct ssq_QueueEntry		*prev;
	ssq_StepPtr					step;
	
};
typedef struct ssq_QueueEntry ssq_QueueEntry;
typedef struct ssq_QueueEntry* ssq_QueueEntryPtr;


/***********************************************************
 * Queues are created by applications
 ***********************************************************/
 
struct ssq_Queue
{
	ssq_QueueEntryPtr		first;
	ssq_QueueEntryPtr		last;
	ssq_SubscriberEntryPtr	first_subscriber;
};
typedef struct ssq_Queue ssq_Queue;
typedef struct ssq_Queue* ssq_QueuePtr;


/***********************************************************
 *
 *		ServerQueue data structures
 *
 ***********************************************************/

/***********************************************************
 * ServerQueue contains the ptr and name of a server queue.
 * For the Mac Server Queues, it also contains the portList
 * and network visible flag.
 ***********************************************************/

struct ssq_ServerQueue
{
	ssq_Queue				serverQueue;
	char					serverName[ssq_ServerNameSize];
	long					serverAliveCount;
};

typedef struct ssq_ServerQueue ssq_ServerQueue;
typedef struct ssq_ServerQueue* ssq_ServerQueuePtr;

/***********************************************************
 * ServerQueueList contains ptrs to the various ServerQueues
 ***********************************************************/
 
struct ssq_ServerQueueList
{
	long				numServerQueues;
	ssq_ServerQueue		serverQueue[1];
};
typedef struct ssq_ServerQueueList ssq_ServerQueueList;
typedef struct ssq_ServerQueueList* ssq_ServerQueueListPtr;

#if defined(__cplusplus)
extern "C" {
#endif

/******************************************************
 *
 *		ServerStepQueue Prototypes
 *
 ******************************************************/

/*************************************************************************************
 ***************	The following routines are located in Queue.c	******************
 *************************************************************************************/


/*************************************************************************************
 *	This routine initializes the first and last pointers of an existing queue.  The
 *	application that requires the queue should create the queue on the stack with
 *	a declaration.
 *************************************************************************************/
void		ssq_InitQueue (
	ssq_QueuePtr	queue);
	
/*************************************************************************************
 *	This routine adds a step to a queue.  It allocates a queue entry and sticks
 *	it into the queue.
 *************************************************************************************/
ssq_Err	ssq_AddStepToQueue (
	ssq_QueuePtr	queue,
	ssq_StepPtr		step);
	
/*************************************************************************************
 *	This routine searches a queue, based on the serverQID, and returns a ptr to the
 *	found step.
 *************************************************************************************/
ssq_Err	ssq_GetStepUsingServerQID (
	ssq_QueuePtr	queue,
	ssq_StepID		serverQID,
	ssq_StepPtr		*step);
	
/*************************************************************************************
 *	This routine searches a queue, based on the userQID, and returns a ptr to the
 *	found step.
 *************************************************************************************/
ssq_Err	ssq_GetStepUsingUserQID (
	ssq_QueuePtr	queue,
	ssq_StepID		userQID,
	ssq_StepPtr		*step);
	
/*************************************************************************************
 *	This routine searches a queue, based on the serverQID, and returns an index to
 *	the found step.
 *************************************************************************************/
ssq_Err	ssq_GetIndexUsingServerQID (
	ssq_QueuePtr	queue,
	ssq_StepID		serverQID,
	long			*index);
	
/*************************************************************************************
 *	This routine searches a queue, based on the userQID, and returns an index to
 *	the found step.
 *************************************************************************************/
ssq_Err	ssq_GetIndexUsingUserQID (
	ssq_QueuePtr	queue,
	ssq_StepID		userQID,
	long			*index);
	
/*************************************************************************************
 *	This routine searches a queue, based on the serverQID, and returns a ptr to the
 *	next step.
 *************************************************************************************/
ssq_Err	ssq_GetNextStepUsingServerQID (
	ssq_QueuePtr	queue,
	ssq_StepID		serverQID,
	ssq_StepPtr		*step);
	
/*************************************************************************************
 *	This routine searches a queue, based on the userQID, and returns a ptr to the
 *	next step.
 *************************************************************************************/
ssq_Err	ssq_GetNextStepUsingUserQID (
	ssq_QueuePtr	queue,
	ssq_StepID		userQID,
	ssq_StepPtr		*step);
	
/*************************************************************************************
 *	This routine searches a queue, based on the serverQID, removes and deallocates
 *	the queue entry, and returns a ptr to the step that was removed from the queue.
 *************************************************************************************/
ssq_Err	ssq_RemoveStepUsingServerQID (
	ssq_QueuePtr	queue,
	ssq_StepID		serverQID,
	ssq_StepPtr		*step);
	
/*************************************************************************************
 *	This routine searches a queue, based on the userQID, removes and deallocates
 *	the queue entry, and returns a ptr to the step that was removed from the queue.
 *************************************************************************************/
ssq_Err	ssq_RemoveStepUsingUserQID (
	ssq_QueuePtr	queue,
	ssq_StepID		userQID,
	ssq_StepPtr		*step);
	
/*************************************************************************************
 *	This routine adds the subscriber to queue's subscriber list.  It allocates the
 *	SubscriberEntry and fills it in.
 *************************************************************************************/
ssq_Err	ssq_AddSubscriberToQueue (
	ssq_QueuePtr		queue,
	ssq_SubscriberPtr	subscriber);

/*************************************************************************************
 *	This routine removes the subscriber from queue's subscriber list.  It deallocates
 *	the SubscriberEntry.
 *************************************************************************************/
ssq_Err	ssq_RemoveSubscriberFromQueue (
	ssq_QueuePtr		queue,
	ssq_NetAddr*		identifier);

/*************************************************************************************
 *	This routine returns a unique StepID for the UserQueue.
 *************************************************************************************/
ssq_StepID	ssq_CreateNewUQID (
	ssq_QueuePtr	queue);

/*************************************************************************************
 *	This routine returns a unique StepID for the ServerQueue.
 *************************************************************************************/
ssq_StepID	ssq_CreateNewSQID (
	ssq_QueuePtr	queue);

/*************************************************************************************
 *	This routine returns a unique StepID for the queue.
 *************************************************************************************/
ssq_StepID	ssq_CreateNewID (
	ssq_QueuePtr	queue,
	long			idType);

/*************************************************************************************
 *	This routine returns the number of steps in a queue.
 *************************************************************************************/
long	ssq_NumberOfSteps (
	ssq_QueuePtr	queue);

/*************************************************************************************
 *	This routine checks to see if a queue is full.
 *************************************************************************************/
ssq_Err	ssq_IsQueueFull (
	ssq_QueuePtr	queue);

/*************************************************************************************
 ***************	The following routines are located in Step.c	******************
 *************************************************************************************/


/*************************************************************************************
 *	This routine allocates a step structure and initializes the structure's fields.
 *************************************************************************************/
ssq_Err	ssq_CreateStep (
	ssq_StepControlPtr				stepControl,
	ssq_FileTransferListPtr			inputFiles,
	ssq_PrimaryOutputFileListPtr	primaryOutputFiles,
	ssq_OutputFolderListPtr			outputFolders,
	ssq_NetAddr*					msgDest,
	ssq_StepPtr						*step);

/*************************************************************************************
 *	This routine deallocates a step structure as well as calling routines to deallocate
 *	any lists that are associated with the step.
 *************************************************************************************/
void	ssq_DisposeStep (
	ssq_StepPtr		step);

/*************************************************************************************
 *	This routine initializes a minimal file transfer list to NIL.
 *************************************************************************************/
ssq_Err	ssq_InitMinimalFileTransferList (
	ssq_MinimalFileTransferList		*transferFiles);

/*************************************************************************************
 *	This routine allocates a file transfer list and initializes all the fields to NIL.
 *************************************************************************************/
ssq_Err	ssq_AllocateFileTransferList (
	long						numFiles,
	ssq_FileTransferListPtr		*transferFiles);

/*************************************************************************************
 *	This routine deallocates a file transfer list as well as deallocating any aliases
 *	that are in the list.
 *************************************************************************************/
void	ssq_DeallocateFileTransferList (
	ssq_FileTransferListPtr		transferFiles);

/*************************************************************************************
 *	This routine allocates a primary output file list and initializes all the fields
 *	to NIL.
 *************************************************************************************/
ssq_Err	ssq_AllocatePrimaryOutputFileList (
	long							numFiles,
	ssq_PrimaryOutputFileListPtr	*primOutputFiles);

/*************************************************************************************
 *	This routine deallocates a primary output file list as well as deallocating any
 *	aliases that are in the list.
 *************************************************************************************/
void	ssq_DeallocatePrimaryOutputFileList (
	ssq_PrimaryOutputFileListPtr	primOutputFiles);

/*************************************************************************************
 *	This routine allocates an output folder list and initializes all the fields
 *	to NIL.
 *************************************************************************************/
ssq_Err	ssq_AllocateOutputFolderList (
	long						numFolders,
	ssq_OutputFolderListPtr		*outputFolders);

/*************************************************************************************
 *	This routine deallocates an output folder list as well as deallocating any
 *	aliases that are in the list.
 *************************************************************************************/
void	ssq_DeallocateOutputFolderList (
	ssq_OutputFolderListPtr		outputFolders);

/*************************************************************************************
 *	This routine allocates a Step Input File List and initializes all the fields
 *	to NIL.
 *************************************************************************************/
ssq_Err	ssq_AllocateStepInputFileList (
	long						numFiles,
	ssq_StepInputFileListPtr	*stepInputFiles);

/*************************************************************************************
 *	This routine deallocates a Step Input File List.
 *************************************************************************************/
void	ssq_DeallocateStepInputFileList (
	ssq_StepInputFileListPtr	stepInputFiles);

/*************************************************************************************
 *	This routine allocates a Procedure List and initializes all the fields
 *	to NIL.
 *************************************************************************************/
ssq_Err	ssq_AllocateProcedureList (
	long						numEntries,
	ssq_ProcedureListPtr		*procList);

/*************************************************************************************
 *	This routine deallocates a Procedure List as well as deallocating any
 *	Step Input File Lists that are in the list.
 *************************************************************************************/
void	ssq_DeallocateProcedureList (
	ssq_ProcedureListPtr		procList);

/*************************************************************************************
 *	This routine allocates a StepControl List and initializes all the fields
 *	to NIL.
 *************************************************************************************/
ssq_Err	ssq_AllocateStepControlList (
	long						numEntries,
	ssq_StepControlListPtr		*stepControlList);

/*************************************************************************************
 *	This routine deallocates a StepControl List.
 *************************************************************************************/
void	ssq_DeallocateStepControlList (
	ssq_StepControlListPtr		stepControlList);

/*************************************************************************************
 *	This routine adds the subscriber to step's status subscriber list.  It allocates
 *	the SubscriberEntry and fills it in.
 *************************************************************************************/
ssq_Err	ssq_AddStatusSubscriberToStep (
	ssq_StepPtr			step,
	ssq_SubscriberPtr	subscriber);

/*************************************************************************************
 *	This routine removes the subscriber from step's status subscriber list.  It
 *	deallocates the SubscriberEntry.
 *************************************************************************************/
ssq_Err	ssq_RemoveStatusSubscriberFromStep (
	ssq_StepPtr		step,
	ssq_NetAddr*	identifier);

/*************************************************************************************
 *	This routine returns the number of subscribers to a step or queue.
 *************************************************************************************/
long	ssq_NumberOfSubscribers (
	ssq_SubscriberEntryPtr	subscriber_entry);

/*************************************************************************************
 *	This routine returns a pointer to the requested subscriber in a list.
 *************************************************************************************/
ssq_Err	ssq_GetSubscriber (
	ssq_SubscriberEntryPtr	first_subscriber,
	ssq_NetAddr*			identifier,
	ssq_SubscriberEntryPtr	*subscriber_entry);
	
/*************************************************************************************
 *	This routine adds the status message to the step.  If there is no entry in the
 *	the status message list for the channel, it allocates the entry.  It then fills
 *	in the status message, including adding the date.
 *************************************************************************************/
ssq_Err	ssq_AddStatusMsgToStep (
	ssq_StepPtr			step,
	ssq_StatusMsgPtr	statusMessage);

/*************************************************************************************
 *	This routine returns the proper out of memory error code.
 *************************************************************************************/
ssq_Err	ssq_ReturnOutOfMemoryError (
	void);
	
/*************************************************************************************
 **********	The following routines are located in chdirToOutputFileDest.c	**********
 *************************************************************************************/

/*************************************************************************************
 *	This routine changes the directory to the one specified in OutputFileDest.
 *************************************************************************************/
int			ssq_chdirToOutputFileDest (
	const ssq_TempOutputFileDest *const tempOutputFileDest);
	

/*************************************************************************************
 **********	The following routines are located in FormValidOutputFileList.c	**********
 *************************************************************************************/

/*************************************************************************************
 *	This routine makes sure there are no non-existent files in an output file list.
 *************************************************************************************/
ssq_Err	ssq_FormValidOutputFileList (
	ssq_FileTransferListPtr		origList,
	int							removeEmptyFiles,
	ssq_FileTransferListPtr		*newList);
	
/*************************************************************************************
 **********	The following routines are located in GrabInputTransferListFile.c	******
 *************************************************************************************/

/***************************************************************************************
 *	This routine returns a filename of a particular CACheFileType in an input file list.
 ***************************************************************************************/
ssq_Err ssq_GrabInputTransferListFile( ssq_FileTransferList *const inputFileListP, /* file transfer list */
                                       ssq_CACheFileType CACheFileType, /* type of file */
                                       int occurance, /* the sequential number of the occurance of this type of file starting at 1 */
                                       char *string /* output string of length ssq_FileNameSize that contains the file name. */ );

#if defined(__cplusplus)
}
#endif

#endif /* if rez else */

#endif	// RC_INVOKED     	// Do only error #defines if compiling resources

#endif
