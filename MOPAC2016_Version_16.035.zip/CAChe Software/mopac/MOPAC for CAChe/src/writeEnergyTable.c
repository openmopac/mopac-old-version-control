#include <compat.h>

#if defined(_WIN32)
#include <windows.h>
#endif

#include <math.h>

#include <ServerStepQueue.h>

#if defined(unix)
#include <UnixAppMgr.h>
#endif

#include <CACheFileLibAD.h>
#include <CACheFileLib.h>
#include <cpu.h>
#include <MOPACDriver.h>
#include <CACheFileTypes.h>

extern FILE	*movie_fp;
extern char mv_name[32];

int writeEnergyTable(MolStruct *molStruct, MoleculeInfo *moleculeInfo,
					double coord_shift[], short outputCalcNumber, 
					char *keyWords, Boolean ProcessMOPACoutput)
{
	int i, j, k, l, n, m, units, rtn_code, atom1, atom2;
	int NAtoms, NAtoms_in_output, NAtoms_incl_dummy;
	int firstDriver, secondDriver, num_steps_1, num_steps_2;
	short pointsInOutput, actualStepsFirstDriver, actualStepsSecondDriver;
	ObjclsID offset;
	long istep, ij, nLinear, numberBonds, bond, Idx;
   	float values[8];
	FILE *MOPACoutput = NULL;
	char string[256];
	char *substring;
	double (*tmpcoord)[3] = NULL;
	double low_value_1, low_value_2, high_value_1, high_value_2;
	double value1, value2;
	float *xyz = NULL;
    float *bondOrders = NULL;
    float *bond_order = NULL;
    double *pcharge = NULL;
    float *pchrg = NULL, zero;
	Zmatrix *zMatrix = NULL;
	double *temp_coord = NULL;
	long *nuclearNumber = NULL;
	long *indexWithoutDummy = NULL;
	int *matchDist = NULL;
	int *matchAngle = NULL;
	int *matchDihed = NULL;
   	long *bondListPointer;
	Boolean cartesianCoords = FALSE;
    ObjectID (*bondList)[2] = NULL;
    MOP_YIELD();
	if ((MOPACoutput = fopen(MOPACOutputFile, "r")) == NULL) {
		alert_user("writeEnergyTable: Unable to open MOPAC Output.");
		return -1;
	} else {
		ProcessMOPACoutput = TRUE;
		/* Determine the true number of atoms in the output so that dummy
		   atoms will be handled correctly */
		NAtoms_in_output = 0;
		NAtoms_incl_dummy = 0;
		for (;;) { /* find beginning of first Z-matrix listing */
			if (cfl_fgets(string, sizeof(string), MOPACoutput) == 0) break;
			if (strncmp(string, " NUMBER    SYMBOL", 17) == 0)
				break;
		}
		cfl_fgets(string, sizeof(string), MOPACoutput); /* skip one blank line */
		for (;;) {
			if (cfl_fgets(string, sizeof(string), MOPACoutput) == 0) break;
			if (strncmp(string,"          CARTESIAN COORDINATES",31) == 0) {
				break;
			}
			if (strlen(string) > 2) {
				NAtoms_incl_dummy++;
				if (strncmp(&string[11],"XX",2) != 0) /* don't count dummy atoms */
					NAtoms_in_output++;
			}
		}

		if (NAtoms_in_output == 0) {
			alert_user("writeEnergyTable: no atoms in MOPAC Output file.");
			goto errorReturn;
		}

		/* Get the number of steps from the keywords line */
		substring = strstr(keyWords,"POINT1=");
		if (substring != NULL)
			sscanf(&substring[7],"%ld \n",&num_steps_1);
		else
			num_steps_1 = 0;
		substring = strstr(keyWords,"POINT2=");
		if (substring != NULL)
			sscanf(&substring[7],"%d \n",&num_steps_2);
		else
			num_steps_2 = 0;
				
		if ((num_steps_2 == 0) || (num_steps_1 == 0)) {
			alert_user("writeEnergyTable:  unable to get value for number of steps.");
			goto errorReturn;
		}
		
		/* determine the number of points finished by MOPAC so that partial
		   map files can be written */
		pointsInOutput = 0;
		cartesianCoords = FALSE;
		for (;;) {
			/* look for "FIRST VARIABLE, etc., first, because if a user starts
			   the title line with a ":", then bogus information will be read in */
			if (cfl_fgets(string, sizeof(string), MOPACoutput) == 0) 
				break;
			if (strstr(string, "FIRST VARIABLE   SECOND VARIABLE") != NULL) {
				if (cfl_fgets(string, sizeof(string), MOPACoutput) == 0) break;
				if (strlen(string) > 3) {
					sscanf(&string[3],"%lf %lf \n",&value1,&value2);
					++pointsInOutput;
				}
				if (pointsInOutput == 1) {
					low_value_1 = value1;
					low_value_2 = value2;
					high_value_1 = value1;
					high_value_2 = value2;
				} else if (pointsInOutput == num_steps_2) 
					high_value_2 = value2;
			}
		
		}
		
		if (pointsInOutput < num_steps_2)
			high_value_2 = value2;
		high_value_1 = value1;

		if (ProcessMOPACoutput) {
		
			double first_val, second_val, r1, r2;
			
			if ((zMatrix = (Zmatrix *) malloc(sizeof(Zmatrix)*NAtoms_incl_dummy)) == NULL) {
				alert_user("writeEnergyTable: Unable to allocate zMatrix array");
				goto errorReturn;
			}
			if ((matchDist = (int *) malloc(sizeof(int)*NAtoms_incl_dummy)) == NULL) {
				alert_user("writeEnergyTable: Unable to allocate matchDist array");
				goto errorReturn;
			}
			if ((matchAngle = (int *) malloc(sizeof(int)*NAtoms_incl_dummy)) == NULL) {
				alert_user("writeEnergyTable: Unable to allocate matchAngle array");
				goto errorReturn;
			}
			if ((matchDihed = (int *) malloc(sizeof(int)*NAtoms_incl_dummy)) == NULL) {
				alert_user("writeEnergyTable: Unable to allocate matchDihed array");
				goto errorReturn;
			}

			for (i=0; i<NAtoms_incl_dummy; i++) { /* initialize Z matrix info */
				matchDist[i] = 0;
				matchAngle[i] = 0;
				matchDihed[i] = 0;
				zMatrix[i].distance = 0.0;
				zMatrix[i].angle = 0.0;
				zMatrix[i].dihedral = 0.0;
				zMatrix[i].atomA = 0;
				zMatrix[i].atomB = 0;
				zMatrix[i].atomC = 0;
				zMatrix[i].varyDistance = 0;
				zMatrix[i].varyAngle = 0;
				zMatrix[i].varyDihedral = 0;
			} /* i loop */
			if ((temp_coord = (double *) 
					malloc(sizeof(double)*3*NAtoms_incl_dummy)) == NULL) {
				alert_user("writeEnergyTable: Unable to allocate temp_coord array");
				goto errorReturn;
			}
			if ((nuclearNumber = (long *) 
					malloc(sizeof(long)*NAtoms_incl_dummy)) == NULL) {
				alert_user("writeEnergyTable: Unable to allocate nuclearNumber array");
				goto errorReturn;
			}
			if ((indexWithoutDummy = (long *) 
					malloc(sizeof(long)*NAtoms_incl_dummy)) == NULL) {
				alert_user("writeEnergyTable: Unable to allocate indexWithoutDummy array");
				goto errorReturn;
			}
			
			/* Determine the atomic numbers */
			fseek(MOPACoutput,0,0);
			for (;;) { /* find beginning of first Z-matrix listing */
				if (cfl_fgets(string, sizeof(string), MOPACoutput) == 0) break;
				if (strncmp(string, " NUMBER    SYMBOL", 17) == 0)
					break;
			}
			cfl_fgets(string, sizeof(string), MOPACoutput); /* skip one blank line */
			for (i=0,j=0 ;i < NAtoms_incl_dummy; i++) {
				char sym[3];
				if (cfl_fgets(string, sizeof(string), MOPACoutput) == 0) break;
				if (string[11] == ' ') {
					sym[0] = string[12];
					sym[1] = 0;
				} else {
					sym[0] = string[11];
					sym[1] = string[12];
				}
				sym[2] = 0;
				nuclearNumber[i] = determineAtomicNumber(sym);
				/* get CAChe atom number */
				if (nuclearNumber[i] != 54) {
					indexWithoutDummy[i] = moleculeInfo->locationWithoutDummies[j];
					j++;
				} else
					indexWithoutDummy[i] = -1;

			} /* i loop */

			/* Determine the search labels for this calculation */

			/* Initialize the search labels */
			for (i=0; i<2; i++) {
				moleculeInfo->searchLabels[i].objclsID = -1;
				moleculeInfo->searchLabels[i].atomList[0] = 0;
			} /* i loop */
			
			/* find the Z-matrix for the first point */
			for (;;) {
			/* look for "FIRST VARIABLE, etc., first, because if a user starts
			   the title line with a ":", then bogus information will be read in */
				if (cfl_fgets(string, sizeof(string), MOPACoutput) == 0) break;
				if (strstr(string, "FIRST VARIABLE   SECOND VARIABLE")
					!= NULL) break;
			}
			for (;;) {
				if (cfl_fgets(string, sizeof(string), MOPACoutput) == 0) break;
				if (string[1] == ':' && string[0] == ' ') break;
			}
			/* Get the search label values */
			sscanf(string," : %lf %lf\n", &first_val, &second_val);
	
			/* read Z matrix */
			for (;;) { /* locate first line of internal coordinates */
				if (cfl_fgets(string, sizeof(string), MOPACoutput) == 0) break;
				if (strlen(string)>59) {
					if (strncmp(&string[59], "0     0     0     0", 19) == 0) 
					break;
				}
			}
			for (k=1; k < NAtoms_incl_dummy; k++) {
				if (cfl_fgets(string, sizeof(string), MOPACoutput) == 0) break;
				if (strlen(string) > 12) {
					sscanf(&string[12],"%lf %hd",
							&zMatrix[k].distance, &zMatrix[k].varyDistance);
					if (strncmp(&string[5],"XX",2) != 0 && (zMatrix[k].varyDistance == 0 || zMatrix[k].varyDistance == -1)) {
						if (fabs(zMatrix[k].distance - first_val) < 0.01)
							matchDist[k] |= 1;
						if (fabs(zMatrix[k].distance - second_val) < 0.01)
							matchDist[k] |= 2;
					}
				} else {
					alert_user("writeEnergyTable:  error reading coordinates");
					goto errorReturn;
				}
				if (k>1) {
					if (strlen(string) > 31) {
						sscanf(&string[31],"%lf %hd",
								&zMatrix[k].angle, &zMatrix[k].varyAngle);
						if (strncmp(&string[5],"XX",2) != 0 && ((zMatrix[k].varyAngle == 0)||(zMatrix[k].varyAngle == -1))) { 
							r1 = fabs(zMatrix[k].angle - first_val)/360.0;
							r1 = fabs(r1 - floor(r1+0.5));
							r2 = fabs(zMatrix[k].angle - second_val)/360.0;
							r2 = fabs(r2 - floor(r2+0.5));
							if (r1 < 0.00003)
								matchAngle[k] |= 1;
							if (r2 < 0.00003)
								matchAngle[k] |= 2;
						}
					} else {
						alert_user("writeEnergyTable:  error reading coordinates");
						goto errorReturn;
					}
				}
				if (k>2) {
					if (strlen(string) > 45) {
						sscanf(&string[45],"%lf %hd",
								&zMatrix[k].dihedral, &zMatrix[k].varyDihedral);
						if (strncmp(&string[5],"XX",2) != 0 && ((zMatrix[k].varyDihedral == 0) || (zMatrix[k].varyDihedral == -1))) { 
							r1 = fabs(zMatrix[k].dihedral - first_val)/360.0;
							r1 = fabs(r1 - floor(r1+0.5));
							r2 = fabs(zMatrix[k].dihedral - second_val)/360.0;
							r2 = fabs(r2 - floor(r2+0.5));
							if (r1 < 0.00003)
								matchDihed[k] |= 1;
							if (r2 < 0.00003)
								matchDihed[k] |= 2;
						}
					} else {
						alert_user("writeEnergyTable:  error reading coordinates");
						goto errorReturn;
					}
				}
			} /* k loop */
	
			/* 
				find the Z-matrix for the second point.
				The only non-optimized coordinate that should have changed in
				going from the first point to the second point should be
				the coordinate cooresponding to the second search label
			*/
			for (;;) {
			/* look for "FIRST VARIABLE, etc., first, because if a user starts
			   the title line with a ":", then bogus information will be read in */
				if (cfl_fgets(string, sizeof(string), MOPACoutput) == 0) break;
				if (strstr(string, "FIRST VARIABLE   SECOND VARIABLE")
					!= NULL) break;
			}
			for (;;) {
				if (cfl_fgets(string, sizeof(string), MOPACoutput) == 0) break;
				if (string[1] == ':' && string[0] == ' ') break;
			}
			/* Get the search label values */
			sscanf(string," : %lf %lf\n", &first_val, &second_val);
	
			/* read Z matrix */
			for (;;) { /* locate first line of internal coordinates */
				if (cfl_fgets(string, sizeof(string), MOPACoutput) == 0) break;
				if (strlen(string)>59) {
					if (strncmp(&string[59], "0     0     0     0", 19) == 0) 
					break;
				}
			}
			for (k=1; k < NAtoms_incl_dummy; k++) {
				if (cfl_fgets(string, sizeof(string), MOPACoutput) == 0) break;
				if (strlen(string) > 60) {
					sscanf(&string[12],"%lf %hd",
							&zMatrix[k].distance, &zMatrix[k].varyDistance);
					sscanf(&string[60],"%d",&m);
					zMatrix[k].atomA = m - 1;
				} else {
					alert_user("writeEnergyTable:  error reading coordinates");
					goto errorReturn;
				}
				if ((matchDist[k] & 2) &&
					(fabs(zMatrix[k].distance - second_val) < 0.01)) {
					/* Found the second search label */
					matchDist[k] = 0; /* mark this coordinate as already matched */
					moleculeInfo->searchLabels[1].atomList[0] = 2; /* distance label */
					moleculeInfo->searchLabels[1].objclsID = Atom_distID;
					moleculeInfo->searchLabels[1].atomList[1] = 
							indexWithoutDummy[k];
					moleculeInfo->searchLabels[1].atomList[2] = 
							indexWithoutDummy[zMatrix[k].atomA];
					break;
				}
				if (k>1) {
					if (strlen(string) > 66) {
						sscanf(&string[31],"%lf %hd",
								&zMatrix[k].angle, &zMatrix[k].varyAngle);
						sscanf(&string[66],"%d",&m);
						zMatrix[k].atomB = m - 1;
					} else {
						alert_user("writeEnergyTable:  error reading coordinates");
						goto errorReturn;
					}
					if (matchAngle[k] & 2) { 
						r2 = fabs(zMatrix[k].angle - second_val)/360.0;
						r2 = fabs(r2 - floor(r2+0.5));
						if (r2 < 0.00003) {
							/* Found the second search label */
							matchAngle[k] = 0; /* mark this coordinate as already matched */
							moleculeInfo->searchLabels[1].atomList[0] = 3; /* angle label */
							moleculeInfo->searchLabels[1].objclsID = Bond_angID;
							moleculeInfo->searchLabels[1].atomList[1] = 
									indexWithoutDummy[k];
							moleculeInfo->searchLabels[1].atomList[2] = 
									indexWithoutDummy[zMatrix[k].atomA];
							moleculeInfo->searchLabels[1].atomList[3] = 
									indexWithoutDummy[zMatrix[k].atomB];
							break;
						}
					}
				}
				if (k>2) {
					if (strlen(string) > 72) {
						sscanf(&string[45],"%lf %hd",
								&zMatrix[k].dihedral, &zMatrix[k].varyDihedral);
						sscanf(&string[72],"%d",&m);
						zMatrix[k].atomC = m - 1;
					} else {
						alert_user("writeEnergyTable:  error reading coordinates");
						goto errorReturn;
					}
					if (matchDihed[k] & 2) {
						r2 = fabs(zMatrix[k].dihedral - second_val)/360.0;
						r2 = fabs(r2 - floor(r2+0.5));
						if (r2 < 0.00003) {
							/* Found the second search label */
							matchDihed[k] = 0; /* mark this coordinate as already matched */
							moleculeInfo->searchLabels[1].atomList[0] = 4; /* dihedral label */
							moleculeInfo->searchLabels[1].objclsID = DihedralID;
							moleculeInfo->searchLabels[1].atomList[1] = 
									indexWithoutDummy[k];
							moleculeInfo->searchLabels[1].atomList[2] = 
									indexWithoutDummy[zMatrix[k].atomA];
							moleculeInfo->searchLabels[1].atomList[3] = 
									indexWithoutDummy[zMatrix[k].atomB];
							moleculeInfo->searchLabels[1].atomList[4] = 
									indexWithoutDummy[zMatrix[k].atomC];
							break;
						}
					}
				}
			} /* k loop */
			/* 
				find the Z-matrix for the point for which the first search 
				label has changed.
				The only non-optimized coordinate that should have changed in
				going from the first point to the second point should be
				the coordinate cooresponding to the second search label
			*/
	
			for (i=2; i <= num_steps_2; i++) {
				for (;;) {
				/* look for "FIRST VARIABLE, etc., first, because if a user starts
				   the title line with a ":", then bogus information will be read in */
					if (cfl_fgets(string, sizeof(string), MOPACoutput) == 0) break;
					if (strstr(string, "FIRST VARIABLE   SECOND VARIABLE")
						!= 0) break;
				}
			} /* i loop */
			for (;;) {
				if (cfl_fgets(string, sizeof(string), MOPACoutput) == 0) break;
				if (string[1] == ':' && string[0] == ' ') break;
			}
			/* Get the search label values */
			sscanf(string," : %lf %lf\n", &first_val, &second_val);
	
			/* read Z matrix */
			for (;;) { /* locate first line of internal coordinates */
				if (cfl_fgets(string, sizeof(string), MOPACoutput) == 0) break;
				if (strlen(string)>59) {
					if (strncmp(&string[59], "0     0     0     0", 19) == 0) 
					break;
				}
			}
			for (k=1; k < NAtoms_incl_dummy; k++) {
				if (cfl_fgets(string, sizeof(string), MOPACoutput) == 0) break;
				if (strlen(string) > 60) {
					sscanf(&string[12],"%lf %hd",
							&zMatrix[k].distance, &zMatrix[k].varyDistance);
					sscanf(&string[60],"%d",&m);
					zMatrix[k].atomA = m - 1;
				} else {
					alert_user("writeEnergyTable:  error reading coordinates");
					goto errorReturn;
				}
				if ((matchDist[k] | 1) &&
					(fabs(zMatrix[k].distance - first_val) < 0.01)) {
					/* Found the first search label */
					matchDist[k] = 0; /* mark this coordinate as already matched */
					moleculeInfo->searchLabels[0].atomList[0] = 2; /* distance label */
					moleculeInfo->searchLabels[0].objclsID = Atom_distID;
					moleculeInfo->searchLabels[0].atomList[1] = 
							indexWithoutDummy[k];
					moleculeInfo->searchLabels[0].atomList[2] = 
							indexWithoutDummy[zMatrix[k].atomA];
					break;
				}
				if (k>1) {
					if (strlen(string) > 66) {
						sscanf(&string[31],"%lf %hd",
								&zMatrix[k].angle, &zMatrix[k].varyAngle);
						sscanf(&string[66],"%d",&m);
						zMatrix[k].atomB = m - 1;
					} else {
						alert_user("writeEnergyTable:  error reading coordinates");
						goto errorReturn;
					}
					if (matchAngle[k] & 1) {
						r1 = fabs(zMatrix[k].angle - first_val)/360.0;
						r1 = fabs(r1 - floor(r1+0.5));
						if (r1 < 0.00003) {
							/* Found the first search label */
							matchAngle[k] = 0; /* mark this coordinate as already matched */
							moleculeInfo->searchLabels[0].atomList[0] = 3; /* angle label */
							moleculeInfo->searchLabels[0].objclsID = Bond_angID;
							moleculeInfo->searchLabels[0].atomList[1] = 
									indexWithoutDummy[k];
							moleculeInfo->searchLabels[0].atomList[2] = 
									indexWithoutDummy[zMatrix[k].atomA];
							moleculeInfo->searchLabels[0].atomList[3] = 
									indexWithoutDummy[zMatrix[k].atomB];
							break;
						}
					}
				}
				if (k>2) {
					if (strlen(string) > 72) {
						sscanf(&string[45],"%lf %hd",
								&zMatrix[k].dihedral, &zMatrix[k].varyDihedral);
						sscanf(&string[72],"%d",&m);
						zMatrix[k].atomC = m - 1;
					} else {
						alert_user("writeEnergyTable:  error reading coordinates");
						goto errorReturn;
					}
					if (matchDihed[k] & 1) {
						r1 = fabs(zMatrix[k].dihedral - first_val)/360.0;
						r1 = fabs(r1 - floor(r1+0.5));
						if (r1 < 0.00003) {
							/* Found the first search label */
							matchDihed[k] = 0; /* mark this coordinate as already matched */
							moleculeInfo->searchLabels[0].atomList[0] = 4; /* dihedral label */
							moleculeInfo->searchLabels[0].objclsID = DihedralID;
							moleculeInfo->searchLabels[0].atomList[1] = 
									indexWithoutDummy[k];
							moleculeInfo->searchLabels[0].atomList[2] = 
									indexWithoutDummy[zMatrix[k].atomA];
							moleculeInfo->searchLabels[0].atomList[3] = 
									indexWithoutDummy[zMatrix[k].atomB];
							moleculeInfo->searchLabels[0].atomList[4] = 
									indexWithoutDummy[zMatrix[k].atomC];
							break;
						}
					}
				}
			} /* k loop */
			/* Set the range on the search labels */
			moleculeInfo->searchLabels[0].lowValue = low_value_1;
			moleculeInfo->searchLabels[0].highValue = high_value_1;
			moleculeInfo->searchLabels[0].numSteps = num_steps_1 - 1;
			moleculeInfo->searchLabels[1].lowValue = low_value_2;
			moleculeInfo->searchLabels[1].highValue = high_value_2;
			moleculeInfo->searchLabels[1].numSteps = num_steps_2 - 1;
			DebugBreak(); 
			for (i=0; i<=1; i++) {
				/* Don't attempt to create search labels that have dummy atoms */
				for (k=0; k < moleculeInfo->searchLabels[i].atomList[0]; k++) {
					if (moleculeInfo->searchLabels[i].atomList[k+1] < 0) {
						moleculeInfo->searchLabels[i].atomList[0] = 0;
						break;
					}
				} /* k loop */
			} /* i loop */
			
			/* And finally, put the search labels in the molstruct 
			   with many thanks to Andy Spencer */
			if (moleculeInfo->searchLabels[0].atomList[0] == 0 || 
				moleculeInfo->searchLabels[1].atomList[0] == 0) {
				alert_user("Unable to create search labels for map file.  Your molecule may "
							"contain dummy atoms.");
			} else {
				CSUObj objs[4];
				ObjectID label_index;
				for (i=0; i < moleculeInfo->searchLabels[0].atomList[0]; i++) {
					objs[i].oci = AtomID;
					objs[i].obi = moleculeInfo->searchLabels[0].atomList[i+1];
				} /*i loop */
		
				if ((rtn_code = cpu_CreateSearchLabel(molStruct, 
							moleculeInfo->searchLabels[0].objclsID,
							objs, &label_index, 
							moleculeInfo->searchLabels[0].lowValue,
							moleculeInfo->searchLabels[0].highValue, 
							moleculeInfo->searchLabels[0].numSteps)) < 0) {
					sprintf(string,
						"writeEnergyTable:  unable to create first search label. rtn_code %d",
						rtn_code);
					alert_user(string);
				}

				for (i=0; i < moleculeInfo->searchLabels[1].atomList[0]; i++) {
					objs[i].oci = AtomID;
					objs[i].obi = moleculeInfo->searchLabels[1].atomList[i+1];
				} /* i loop */
		
				if ((rtn_code = cpu_CreateSearchLabel(molStruct, 
							moleculeInfo->searchLabels[1].objclsID,
							objs, &label_index, 
							moleculeInfo->searchLabels[1].lowValue,
							moleculeInfo->searchLabels[1].highValue, 
							moleculeInfo->searchLabels[1].numSteps)) < 0) {
					sprintf(string,
						"writeEnergyTable:  unable to create second search label. rtn_code %d",
						rtn_code);
					alert_user(string);
				}
			}
		} /* Process MOPAC Output */	
	} /* Open output file */
/*
*  Force all partial charges to zero, to ensure that they are defined
*/
zero = 0.0;
pchrg = &zero;
	  for (i = 0; i < NAtoms_in_output; i++) {
		if ((rtn_code = csu_AddObjVal (molStruct, AtomID, PchrgID, 
									   (moleculeInfo->locationWithoutDummies[i]),
									   MOPAC_SRC, CSU_FLOATING, 1, Charge_AU, 
									   4, (char*)pchrg, 0,
			                           BY_INDEX)) < 0) {

		  alert_user("Unable to set up partial charges.");
		goto errorReturn;
		}

	  }
      if ((numberBonds = cpu_getBondList(molStruct, &bondList)) > 0) {
        for (i=0; i<numberBonds; i++) {
		 if((rtn_code = csu_AddObjVal (molStruct, BondID, Bond_OrderID,
						i, MOPAC_SRC, CSU_FLOATING, 1, NoUnit, 4, 
						(char*)pchrg,0, BY_INDEX)) < 0) {
		   alert_user("Unable to set up bonds.");
		goto errorReturn;
		 }
        }	 
	  }


	if (startMovieHeader(molStruct, ".Map", CFT_EMAP) < 0) {
		alert_user("Unable to save the results because the disk may be full"
			       " or the file file may be locked.");
		goto errorReturn;
	}
	
	if ((outputCalcNumber >= 0) && ProcessMOPACoutput) {
		char buff[32];

		/* echo map file name  so user will know where the results got put */
		if ((i = strlen(moleculeInfo->molStructName)) > 27) 
			i = 27;
		strncpy(buff, moleculeInfo->molStructName, i);
		strcpy(buff+i, ".Map");
		sprintf(string,"Writing energy map in %s\n", buff);
		mam_SendStatus(MOPAC_STATUS_SCROLL, string);
	}
	
    MOP_YIELD();
	
   /*
    *  Find out how many of each object class there are.
    */
    
	if (csu_ExistsObjclsID (molStruct, AtomID, &offset))
		NAtoms = (long) ((GetPtr(molStruct->objclsH) + offset)->num_objs);
	else {
		alert_user ("writeEnergyTable: Error attempting to locate AtomID index.");
	}
    nLinear = (NAtoms*(NAtoms+1))/2;
    if ((bondOrders = (float *) NewHandle(nLinear*sizeof(double))) == NULL) {
	    alert_user("writeReactionCoord: Unable to allocate bondOrders array");
    }
#if 0
	if (!ProcessMOPACoutput || 
		(moleculeInfo->searchLabels[0].atomList[0] != 0 && 
			moleculeInfo->searchLabels[1].atomList[0] != 0)) {
		/* have two valid search labels */
		if (moleculeInfo->searchLabels[0].atomList[1] == 
			moleculeInfo->searchLabels[1].atomList[1]) {
		   if (moleculeInfo->searchLabels[0].objclsID == Atom_distID) {
			   firstDriver = 0;
			   secondDriver = 1;
		   } else if (moleculeInfo->searchLabels[1].objclsID == Atom_distID) {
			   firstDriver = 1;
			   secondDriver = 0;
		   } else if (moleculeInfo->searchLabels[0].objclsID == Bond_angID) {
			   firstDriver = 0;
			   secondDriver = 1;
		   } else {
			   firstDriver = 1;
			   secondDriver = 0;
		   }
		} else if (moleculeInfo->searchLabels[0].atomList[1] < 
					moleculeInfo->searchLabels[1].atomList[1]) {
			firstDriver = 0;
			secondDriver = 1;
		} else {
			firstDriver = 1;
			secondDriver = 0;
		}
	} else {
		/* don't rely on the search labels for the header information */
		firstDriver = 0;
		secondDriver = 1;
	}
#endif 
	/* For MOPAC 2000 the above logic produces weird results, just make it simple */
	firstDriver = 0;
	secondDriver = 1;


	/* Adjust number of steps to the ones actually in the output file */

	if (pointsInOutput == 
		((moleculeInfo->searchLabels[firstDriver].numSteps+1)*
		(moleculeInfo->searchLabels[secondDriver].numSteps+1)))
		actualStepsFirstDriver = 
			moleculeInfo->searchLabels[firstDriver].numSteps+1;
	else
		actualStepsFirstDriver = 
			((pointsInOutput-1) /
				(moleculeInfo->searchLabels[secondDriver].numSteps+1)+1);
	
	/* get original coordinates from molStruct to have coordinates for dummy atoms */
	if ((rtn_code = csu_GrabVal (molStruct, AtomID, XYZID, (char **)&(tmpcoord))) < 0) {
 		sprintf (string,"writeReactionCoord: csu_GrabVal XYZ, errno %d", rtn_code);
		alert_user(string);
		goto errorReturn;
	}

	/* Write out driver header */
	if (ProcessMOPACoutput && 
		(moleculeInfo->searchLabels[0].atomList[0] == 0 || 
			moleculeInfo->searchLabels[1].atomList[0] == 0)) {
		/* don't have valid search labels in the molstruct */
		fprintf(movie_fp, "%s%d %s %f %f %d\n",
			"Coord",  						/* name */
			1,							 	/* label index */
			"noUnits", 						/* units */
			low_value_1, high_value_1, num_steps_1);
		fprintf(movie_fp, "%s%d %s %f %f %d\n",
			"Coord",  						/* name */
			2,							 	/* label index */
			"noUnits", 						/* units */
			low_value_2, high_value_2, num_steps_2);
	} else {
		j=(GetPtr(DataDict.objclsdictH) + 
			moleculeInfo->searchLabels[firstDriver].objclsID)->objclsN;
		if (moleculeInfo->searchLabels[firstDriver].objclsID == Atom_distID) 
			units = Angstrom_U;
		else units = Degree_U;
		fprintf(movie_fp, "%s%d %s %f %f %d\n",
				GetPtr(DataDict.namesH)[j],  /* object class name */
				firstDriver,				 /* label index */
				GetPtr(DataDict.namesH)[units],  /* units */
				moleculeInfo->searchLabels[firstDriver].lowValue, 
				moleculeInfo->searchLabels[firstDriver].highValue,
				moleculeInfo->searchLabels[firstDriver].numSteps+1);
	
		j=(GetPtr(DataDict.objclsdictH) + 
			moleculeInfo->searchLabels[secondDriver].objclsID)->objclsN;
		if (moleculeInfo->searchLabels[secondDriver].objclsID == Atom_distID) 
			units = Angstrom_U;
		else units = Degree_U;
		fprintf(movie_fp, "%s%d %s %f %f %d\n",
				GetPtr(DataDict.namesH)[j],  /* object class name */
				secondDriver,				 /* label index */
				GetPtr(DataDict.namesH)[units],  /* units */
				moleculeInfo->searchLabels[secondDriver].lowValue, 
				moleculeInfo->searchLabels[secondDriver].highValue,
				moleculeInfo->searchLabels[secondDriver].numSteps + 1);
	}
	
	/* Write out dependent header */
	/* end of Axes, introduce start of calculated values */
	fprintf(movie_fp, "Dependents\n");
	/* total energy */
	if (dependentHeader(molStruct, CalcHistID, CalcEnergyID, 4, 1, 3,
						Energy_Kcal_mole, -1, NULL) < 1) {
		alert_user("writeEnergyTable: depend_hdr returned wrong number of energies");
		goto errorReturn;
	}

	/* atom coordinates */
	if (NAtoms != dependentHeader(molStruct, AtomID, XYZID, 4, 3, 3, Angstrom_U, 0, NULL)) {
		alert_user("writeEnergyTable: depend_hdr returned wrong number of atoms");
		goto errorReturn;
	}
    /* partial charges */
	if (NAtoms != dependentHeader(molStruct, AtomID, PchrgID, 4, 1, 3, Charge_AU, 0, NULL)) {
		alert_user("writeEnergyTable: depend_hdr returned wrong number of partial charges");
		goto errorReturn;
	}
     /* bond orders */
     numberBonds = cpu_getBondList(molStruct, &bondList);
	if (numberBonds != dependentHeader(molStruct, BondID, Bond_OrderID, 4, 1, 3, NoUnit, 0, NULL)) {
		alert_user("writeEnergyTable: depend_hdr returned wrong number of bond-orders");
		goto errorReturn;
	}
	if (moleculeInfo->searchLabels[secondDriver].numSteps > NumberOfGridSteps) {
		sprintf(string,"writeEnergyTable: Too many steps in grid %d",
				moleculeInfo->searchLabels[secondDriver].numSteps);
		alert_user(string);
		goto errorReturn;
	}

	/* mark end of ASCII movie header and start of binary movie data */
	fprintf(movie_fp, "StartFrames\n");
#if defined(_WIN32)
	/*  change to binary mode */
	cfl_MacFClose(movie_fp);
	if ((movie_fp = cfl_MacFOpen(mv_name, "rb+", 0, 0)) == NULL) {
		alert_user("Unable to re-open movie file in binary mode.");
		goto errorReturn;
	}
	/* start at the end of the movie header */
	if (fseek(movie_fp, 0, 2)) {
		fclose(movie_fp);
		alert_user("Unable to fseek to the end of the movie file.");
		goto errorReturn;
	}
#endif
	/* start writing the frame information */
	
    MOP_YIELD();

	fseek(MOPACoutput,0,0);
	
	if ((xyz = (float *) 
			malloc(sizeof(float)*(NumberOfGridSteps+1)*3*NAtoms)) == NULL) {
		alert_user("writeEnergyTable: Unable to allocate xyz array");
		goto errorReturn;
	}
    if ((pcharge = (double *) malloc(sizeof(double)*NAtoms_incl_dummy)) == NULL) {
		alert_user("writeEnergyTable: Unable to allocate partial charge array");
		goto errorReturn;
	}
    if ((pchrg = (float *) malloc(sizeof(float)*(NumberOfGridSteps+1)*NAtoms)) == NULL) {
		alert_user("writeEnergyTable: Unable to allocate partial charge array");
		goto errorReturn;
	}
    if ((bond_order = (float *) malloc(sizeof(float)*(NumberOfGridSteps+1)*numberBonds)) == NULL) {
		alert_user("writeEnergyTable: Unable to allocate bond order array");
		goto errorReturn;
	}

	/* put original molstruct xyz coordinates into present coordinates */
	for (j=0; j < moleculeInfo->searchLabels[secondDriver].numSteps+1; j++)
		for (k=0; k<NAtoms ; k++)
			for (l=0; l<3; l++)
				xyz[(NAtoms*j + k)*3 + l]= (float)tmpcoord[k][l];

	for (istep=0, i = 0; i < actualStepsFirstDriver; i++) {
		float float_val[NumberOfGridSteps+1];
		
        MOP_YIELD();
		for (j=0, actualStepsSecondDriver=0;
			j < moleculeInfo->searchLabels[secondDriver].numSteps+1; j++) {

			/* total energy */

			for (;;) {
			/* look for "FIRST VARIABLE, etc., first, because if a user starts
			   the title line with a ":", then bogus information will be read in */
				if (cfl_fgets(string, sizeof(string), MOPACoutput) == 0) break;
				if (strstr(string, " FIRST VARIABLE   SECOND VARIABLE")
					!= NULL) break;
			}
			for (;;) {
				if (cfl_fgets(string, sizeof(string), MOPACoutput) == 0) break;
				if (string[1] == ':' && string[0] == ' ') break;
			}
			sscanf(string," : %f %f %f\n", &float_val[j], &float_val[j], &float_val[j]);

			/* read coordinates */
			if (cartesianCoords) { /* read in Cartesian coordinates */
				/* skip 6 lines */
				for (k=0; k<6; k++) {
					if (cfl_fgets(string, sizeof(string), MOPACoutput) == 0) break;
				}
				
				for (k=0; k<NAtoms_in_output; k++) {
					float x[3];
					
					if (cfl_fgets(string, sizeof(string), MOPACoutput) == 0) break;
					sscanf(string,"%d %*c%*c %f %f %f", &n, &x[0], &x[1], &x[2]);
					if (n != k+1) {
					   alert_user("writeEnergyTable: atoms out of sync");
					   goto errorReturn;
					}
					for (l=0; l<3; l++) 
						xyz[(NAtoms*j + moleculeInfo->locationWithoutDummies[k])*3 + l] = 
							(float)(x[l] + coord_shift[l]);
				}
				if (k == NAtoms_in_output) actualStepsSecondDriver++;
			} else { /* read in internal coordinates and convert to Cartesians */
                                memset(pcharge,0,sizeof(double)*NAtoms);
				for (;;) { /* locate first line of internal coordinates */
					if (cfl_fgets(string, sizeof(string), MOPACoutput) == 0) break;
					if (strlen(string)>59) {
						if (strncmp(&string[59], "0     0     0     0", 19) == 0) 
						{ 
							sscanf(&string[78],"%lf",&pcharge[0]);  
							break;
						}
					}
				}
				for (k=1; k < NAtoms_incl_dummy; k++) {
					if (cfl_fgets(string, sizeof(string), MOPACoutput) == 0) break;
					if (strlen(string) > 60) {
						sscanf(&string[12],"%lf",&zMatrix[k].distance);
						sscanf(&string[60],"%d",&m);
						zMatrix[k].atomA = m - 1;
					} else {
						alert_user("writeEnergyTable:  error reading coordinates");
						goto errorReturn;
					}
					if (k>1) {
						if (strlen(string) > 66) {
							sscanf(&string[31],"%lf",&zMatrix[k].angle);
							sscanf(&string[66],"%d",&m);
							zMatrix[k].atomB = m - 1;
						} else {
							alert_user("writeEnergyTable:  error reading coordinates");
							goto errorReturn;
						}
					}
					if (k>2) {
						if (strlen(string) > 72) {
							sscanf(&string[45],"%lf",&zMatrix[k].dihedral);
							sscanf(&string[72],"%d",&m);
							zMatrix[k].atomC = m - 1;
						} else {
							alert_user("writeEnergyTable:  error reading coordinates");
							goto errorReturn;
						}
					}
					if (strlen(string) > 78)
                    				sscanf(&string[78],"%lf",&pcharge[k]);
				}

				if (k == NAtoms_incl_dummy) {
					if (internalToCartesian (temp_coord, NAtoms_incl_dummy, zMatrix, NULL) < 0) {
						 alert_user("writeEnergyTable: error converting internal coordinates");
						 goto errorReturn;	 
					}
					/* remove dummy atoms from list */
					for (n=0, m=0; n < NAtoms_incl_dummy; n++) {
						if (nuclearNumber[n] != 54) {
							for (l=0; l<3; l++)
								xyz[(NAtoms*j + moleculeInfo->locationWithoutDummies[m])*3 + l] = 
									(float)(temp_coord[n*3 + l] + coord_shift[l]);
							m++;
						}
					}
                    /* Put charges in their correct locations */
                    for (l=0, m=0; l<NAtoms_incl_dummy; l++)
                        if (nuclearNumber[l] != 54) {
                      pchrg[NAtoms*j + moleculeInfo->locationWithoutDummies[m]] = (float)pcharge[l];
                      m++;
                        }
					actualStepsSecondDriver++;
				}
/*
*   Read in Bond Orders  FIXME: This was copied more-or-less verbatim from "updateMolStruct.c"
*/
        for (;;) {
	    	if (cfl_fgets(string, sizeof(string), MOPACoutput) == NULL) 
						break;
            if (strncmp(string, 
						"                    BOND ORDERS AND VALENCIES", 45) == 0) 
                        break;
        }
				/* initialize bond order matrix */
				for (ij=0; ij < (nLinear -1); ij++)
					(GetPtr( bondOrders))[ij] = 0.0;
					ij = 0;
					while (ij < (nLinear - 1)) {
						int num_accross, j_val[6];
						num_accross = 0;
						if (strlen(string) > 15) {
							num_accross += 
								sscanf(&string[19],"%ld", &j_val[0]);
							num_accross += 
								sscanf(&string[30],"%ld", &j_val[1]);
							num_accross += 
								sscanf(&string[41],"%ld", &j_val[2]);
							num_accross += 
								sscanf(&string[52],"%ld", &j_val[3]);
							num_accross += 
								sscanf(&string[63],"%ld", &j_val[4]);
							num_accross += 
								sscanf(&string[74],"%ld", &j_val[5]);
						}
	
						if (num_accross<=0) 
							break;
						cfl_fgets(string, sizeof(string), MOPACoutput); /* skip a line */
						for (;;) {
							if (cfl_fgets(string, sizeof(string), MOPACoutput) == NULL) 
								break;
							if (strlen(string) < 3)
								break;
							if (strlen(string) > 7) 
								num_accross = sscanf(&string[7],"%ld %f %f %f %f %f %f\n",
											&l, &values[0], &values[1], &values[2], &values[3],
											&values[4], &values[5]);
							else
								num_accross = 0;
							if (num_accross<=0) break;
							for (k=0; k<(num_accross-1); k++) {
								ij = ((l*(l-1))/2) + j_val[k] -1;
								if (ij > (nLinear -1)) {
								alert_user("writeEnergyTable:  software bug!");
								goto errorReturn;
								}
								(GetPtr(bondOrders))[ij] = values[k];
							}
							if (ij >= (nLinear - 1))
								break;
						}
	
						if (ij >= (nLinear -1)) 
							break;
						if (cfl_fgets(string, sizeof(string), MOPACoutput) == NULL) 
							break;
						if (strlen(string) < 3) {
							/* skip a line */
							cfl_fgets(string, sizeof(string), MOPACoutput); 
						}
						if (strlen(string) < 3) {
							/* skip a second line line (for some VAX output) */
							cfl_fgets(string, sizeof(string), MOPACoutput); 
						}
					} /* ij < nLinear -1 */
  /* build the list of bonds */	
    /* Add the bond order to each bond and mark the bondOrderDefined
	   array to indicate that the bond order has already been filled
	   in.
	*/
	for (bond=0; bond<numberBonds; bond++) {
	  bondListPointer = bondList[bond];
	  atom1 = whichAtomIndex(bondListPointer[0], NAtoms, moleculeInfo->locationWithoutDummies);
	  if (atom1 >= 0) {
		 atom2 = whichAtomIndex(bondListPointer[1], NAtoms, moleculeInfo->locationWithoutDummies);
		 Idx = (atom1>atom2) ? ((atom1*(atom1+1))/2 + atom2) : ((atom2*(atom2+1))/2 + atom1);
          bond_order[j*numberBonds + bond] = bondOrders[Idx];
		 
        }
  }
			}
		}
			for (j=0; j < actualStepsSecondDriver; j++, istep++) {
				/* write the frame number */
				if (fwrite(&istep, 4, 1, movie_fp) < 1) {
					alert_user("writeEnergyTable: map write failed");
					goto errorReturn;
				} 
		
				/* write out value as binary float */
				if (fwrite(&float_val[j], 4, 1, movie_fp) < 1) {
					alert_user("writeEnergyTable: map write failed");
					goto errorReturn;
				}
				/* write out xyz value as binary float */
				if (fwrite(&xyz[j*NAtoms*3], 4, 3*NAtoms, movie_fp) < 1) {
					alert_user("writeEnergyTable: map write failed");
					goto errorReturn;
                }
                 /* write out partial charges as binary float */
				if (fwrite(&pchrg[j*NAtoms], 4, NAtoms, movie_fp) < 1) {
					alert_user("writeEnergyTable: pchrge map write failed");
					goto errorReturn;
				} 
                  /* write out bond orders as binary float */
	        	if (fwrite(&bond_order[j*numberBonds], 4, numberBonds, movie_fp) < 1) {
	        		alert_user("writeReactionCoord: bond order map write failed");
		        	goto errorReturn;
	        	} 
			
		
		}
	}

	if (MOPACoutput != NULL) fclose(MOPACoutput);

    MOP_YIELD();
	
	if (movie_fp != NULL) fflush(movie_fp);
	if (movie_fp != NULL) cfl_MacFClose(movie_fp);
	
	if (matchDist != NULL) free(matchDist);
	if (matchAngle != NULL) free(matchAngle);
	if (matchDihed != NULL) free(matchDihed);
	if (temp_coord != NULL) free(temp_coord);
	if (nuclearNumber != NULL) free(nuclearNumber);
	if (indexWithoutDummy != NULL) free(indexWithoutDummy);
	if (zMatrix != NULL) free(zMatrix);
	if (xyz != NULL) free(xyz);
	return (0);

errorReturn:
	if (MOPACoutput != NULL) fclose(MOPACoutput);

    MOP_YIELD();
	
	if (movie_fp != NULL) fflush(movie_fp);
	if (movie_fp != NULL) cfl_MacFClose(movie_fp);
	
	if (matchDist != NULL) free(matchDist);
	if (matchAngle != NULL) free(matchAngle);
	if (matchDihed != NULL) free(matchDihed);
	if (temp_coord != NULL) free(temp_coord);
	if (nuclearNumber != NULL) free(nuclearNumber);
	if (indexWithoutDummy != NULL) free(indexWithoutDummy);
	if (zMatrix != NULL) free(zMatrix);
	if (xyz != NULL) free(xyz);
    if (bondList != NULL) free(bondList);
	return -1;
}

