#include <compat.h>
#include <string.h>
#include <ctype.h>
#include <stddef.h>
#include <ServerStepQueue.h>

#if defined(unix)
#include <UnixAppMgr.h>
#endif

#include <ZINDODriver.h>

FILE *zindoOutputFileList = NULL;
char ZINDOoutputFileList[32] = ZINDO_TMPFILE_NAME;

#define MIN_OUT_FILES 3
int max_out_files = MIN_OUT_FILES; /* molecule, map & OUTPUT file will be returned */


int initOutputFileList(ZINDOControl *Control)
{
	if (max_out_files == MIN_OUT_FILES) { /* count how many files may be returned */
		if (Control->saveInput)
			max_out_files++;
		if (Control->saveBasis)
			max_out_files++;
		if (Control->saveVectors)
			max_out_files++;
		if (Control->saveGraphics)
			max_out_files++;
		if (Control->saveOutput)
			max_out_files++;
		if (Control->saveCon)
			max_out_files++;
		if (Control->saveOpt)
			max_out_files++;
		if (Control->saveSummary)
			max_out_files++;
		if (Control->saveLog)
			max_out_files++;
	}

	if (zindoOutputFileList == NULL) {
		if ((zindoOutputFileList = fopen(ZINDOoutputFileList, "w")) == NULL)
			return(ZINDO_ALLOC_OUTFILE);
		fclose(zindoOutputFileList);
	}
	return 0;
}

void addToOutputFileList(
	char 			*fileName,
	unsigned long	macFileType,
	unsigned long	macFileCreator,
	unsigned long	CACheFileType,
	unsigned long	CACheFolderType,
	unsigned long	cacheTransferFormat
) {
	OutputFileAttributes fileAttrib;

	memset(&fileAttrib, 0, sizeof(fileAttrib));
	strcpy(fileAttrib.fileName, fileName);
	fileAttrib.macFileType = macFileType;
	fileAttrib.macFileCreator = macFileCreator;
	fileAttrib.CACheFileType = CACheFileType;
	fileAttrib.CACheFolderType = CACheFolderType;
	fileAttrib.cacheTransferFormat = cacheTransferFormat;
	if ((zindoOutputFileList = fopen(ZINDOoutputFileList, "a"))
		== NULL) {
		alert_user("addToOutputFileList: Unable to open temporary "
						"transfer list file.\n");
	}
	if (fwrite(&fileAttrib, sizeof(OutputFileAttributes), 1, 
				zindoOutputFileList) != 1) {
		alert_user("addToOutputFileList: Unable to write to temporary "
						"transfer list file.\n");
	}
	fflush(zindoOutputFileList);
	fclose(zindoOutputFileList);
}
