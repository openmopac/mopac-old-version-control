#include <compat.h>
#include <CACheFileLibAD.h>
#include <CACheFileLib.h>
#include <CACheFileTypes.h>
#include <ZINDODriver.h>

/* Data dictionary name index for kcal/mole units string */
#define Energy_Kcal_mole 51
#define String_Len 512

FILE *movie_fp = NULL;
char mv_name[32]=""; /* name of movie file */

int writeOptimizationPath(MolStruct *molStruct, long atomLocation[],
                          char *molStructName, Boolean ZINDOinputFile)
{
	int i, j;
	long istep, lastFrame;
	FILE *ZINDOcon = NULL;
	float xyz[ZINDOlimit][3];
	int NAtoms;
	ObjclsID offset;
	char errs[256], string[String_Len];

/*
   If a conformation file has been generated, then
   build a map file.
 */
 
 	/* If running from a ZINDO Input file, extract the molecule name
	 * from the ZINDO Input file
	 */

	if (ZINDOinputFile) {
		if (isFileZINDOinput("ZINDO Input", errs)) {
			/* Truncate to 20 characters, since FILEOP does */
			errs[20] = 0;
			makeCompoundName(errs, ".con", string);
		} else {
			alert_user("writeOptimizationPath:  unable to open ZINDO Input file.");
			return -1;
		}
		/* make sure the molStruct name is in the molStruct */
		strcpy(molStruct->ms_name, molStructName); 
 	} else {
		/* Truncate to 20 characters, since FILEOP does */
#if defined(unix)
		cfl_MacNameToADNames(molStructName, CFL_AD_HEADER_PREFIX, 
			CFL_AD_ESCAPE_CHAR, "/", 72, errs, string);
		strncpy(errs, string, 20);
#else
		strncpy(errs, molStructName, 20);
#endif
		errs[20] = 0;
		makeCompoundName(errs, ".con", string);
	}

	if ((ZINDOcon = fopen(string, "r")) != NULL) {

	/* 
	 * Determine that this is an OK file to read and
	 * determine the number of points calculated 
	 */
	lastFrame = 0;
	for (;;) {
		if (cfl_fgets(string, String_Len, ZINDOcon) == NULL) break;
		if (strlen(string) > (String_Len - 100)) {
			alert_user("writeOptimizationPath: molecule.con file is the wrong form.");
			fclose(ZINDOcon);
			return -1;
		}
		if (strncmp(&string[4],"ZINDO", 5) == 0) lastFrame++;
	}
	
    if (lastFrame < 3) {
		alert_user("writeOptimizationPath:  not enough geometries to write "
			"a .map file.");
		fclose(ZINDOcon);
		return -1;
	}

    lastFrame--;
	
	if (startMovieHeader(molStruct,".map",CFT_EMAP) < 0) {
		alert_user("Unable to save the results because the disk may be full"
			       " or the file file may be locked.");
		fclose(ZINDOcon);
		return -1;
	}

   /*
    *  Find out how many of each object class there are.
    */
    
   if (csu_ExistsObjclsID (molStruct, AtomID, &offset))
     NAtoms = (long) ((GetPtr(molStruct->objclsH) + offset)->num_objs);
   else {
     alert_user (" Error attempting to locate AtomID index.");
   }

	/* Write out driver header */
	fprintf(movie_fp, "%s%d %s %d %d %d\n",
		"steps",  						/* name */
		1,							 	/* label index */
		"steps", 						/* units */
		1, lastFrame, lastFrame);
	
	/* Write out dependent header */
	/* end of Axes, introduce start of calculated values */
	fprintf(movie_fp, "Dependents\n");

	/* total energy */
	if (dependentHeader(molStruct, CalcHistID, CalcEnergyID, 4, 1, 3,
						Energy_AU, -1, NULL) < 1) {
		alert_user("writeOptimizationPath: "
			"depend_hdr returned wrong number of energies.");
		fclose(ZINDOcon);
		if (movie_fp != NULL) cfl_MacFClose(movie_fp);
		return -1;
	}

	/* Energy gradient */
	fprintf(movie_fp, "not_objcls Energy_Gradient 4 1 3 Hartrees/Angstrom 1\n");
	fprintf(movie_fp, "-1\n");

	/* atom coordinates */
	if (NAtoms != dependentHeader(molStruct, AtomID, XYZID, 4, 3, 3, Angstrom_U, 0, NULL)) {
		alert_user("writeOptimizationPath: "
			"depend_hdr returned wrong number of atoms.");
		fclose(ZINDOcon);
		if (movie_fp != NULL) cfl_MacFClose(movie_fp);
		return -1;
	}

	/* mark end of ASCII movie header and start of binary movie data */
	fprintf(movie_fp, "StartFrames\n");
#if defined(_WIN32)
	/*  change to binary mode */
	cfl_MacFClose(movie_fp);
	if ((movie_fp = cfl_MacFOpen(mv_name, "rb+", 0, 0)) == NULL) {
		alert_user("Unable to re-open movie file in binary mode.");
		return -1;
	}
	/* start at the end of the movie header */
	if (fseek(movie_fp, 0, 2)) {
		cfl_MacFClose(movie_fp);
		alert_user("Unable to fseek to the end of the movie file.");
		return -1;
	}
#endif
	/* start writing the frame information */
	
	/* Rewind .con file */
	fseek(ZINDOcon, 0, 0);


    /* Skip the first conformation, since the energy is 0. */
	for (i=0; i < (NAtoms + 1); i++) {
		if (cfl_fgets(string, String_Len, ZINDOcon) == 0) {
			alert_user("writeOptimizationPath: unable to get first conformation.");
			fclose(ZINDOcon);
			if (movie_fp != NULL) fclose(movie_fp);
			return -1;
		}
	}

	for (istep=0; istep < lastFrame; istep++) {
		float float_val;
	
		/* write the frame number */
		if (fwrite(&istep, 4, 1, movie_fp) < 1) {
			alert_user("movie write failed");
			break;
		} 

		/* write out the dependent values */
			
		if (cfl_fgets(string, String_Len, ZINDOcon) == 0) goto endOfFile;

		/* total energy */
		if (sscanf(&string[50],"%f", &float_val) != 1) {
			alert_user("writeOptimizationPath: unable to get energy value.");
			break;
		}

		/* write out value as binary float */
		if (fwrite(&float_val, 4, 1, movie_fp) < 1) {
			alert_user("movie write failed");
			break;
		} 

		/* energy gradient */
		if (sscanf(&string[61],"%f", &float_val) != 1) {
			alert_user("writeOptimizationPath: unable to get gradient value.");
			break;
		}

		/* write out value as binary float */
		if (fwrite(&float_val, 4, 1, movie_fp) < 1) {
			alert_user("movie write failed");
			break;
		} 

		for (i=0; i < NAtoms; i++) {
		    float x[3];
			if (cfl_fgets(string, String_Len, ZINDOcon) == 0) goto endOfFile;
			if (sscanf(&string[8],"%f %f %f", &x[0], &x[1], &x[2]) != 3) {
				alert_user("writeOptimizationPath: unable to read coordinates.");
				goto endOfFile;
			}
			for (j=0; j<3; j++) xyz[atomLocation[i]][j] = x[j];
   		}

		/* write out value as binary float */
		if (fwrite(xyz, 4, 3*NAtoms, movie_fp) < 1) {
			alert_user("movie write failed");
			break;
		} 
	}

endOfFile:
	fclose(ZINDOcon);
	
	fflush(movie_fp);
	if (movie_fp != NULL) cfl_MacFClose(movie_fp);
  } else {
    sprintf(errs,"writeOptimizationPath: can't open .con file '%s'",string);
    alert_user(errs);
	return -1;
  }
  return 0;
}
