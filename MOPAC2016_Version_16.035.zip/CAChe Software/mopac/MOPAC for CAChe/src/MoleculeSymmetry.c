#include <compat.h>
#include <csu.h>
#include <cmu.h>

#define LOOP_LIMIT			50
#define NUMBER_OF_BITS		20
#define NUMBER_OF_GROUPS	57
#define	SYM_LONG_STRING		256
#define ICOSAHEDRAL_ANGLE	0.707106781186
#define TWO_PI				6.2831853071796
#define HALF_PI				1.5707963268
#define SMALL_FLOAT			0.00000001
#define SMALL_TOLERANCE		0.01
#define LARGE_TOLERANCE		0.1
#define FORTY				40.0

#define JACOBI_ROTATE(a,i,j,k,l) { g=a[i][j];h=a[k][l];a[i][j]=g-s*(h+g*tau);\
                          a[k][l]=h+s*(g-h*tau); }

void	alert_user(char *s);
void 	alert_user_watch(char *errs);

long	ElementMatch[NUMBER_OF_BITS];
double	Elements[NUMBER_OF_BITS * 9];
double	Cube[9];

int JacobiDiag(
	double	*a_array,
	int		n,
	double	*d,
	double	*v_array
)
{
	static char functionName[] = "JacobiDiag";
	char	errs[SYM_LONG_STRING];
	int		j, iq, ip, i, nrot = 0;
	double	**a = NULL, **v = NULL;
	double	*b = NULL, *z = NULL;
	double	thresh, theta, tau, t, sm, s, h, g, c;
	Boolean	converged = false;
	
	b = (double *)malloc( (n+1)*sizeof(double));
	
	if (b == NULL) {
		sprintf(errs, "%s: unable to allocate b array, size = %d\n",
			functionName, n);
		alert_user(errs);
		goto freeAndReturn;
	}
	
  	z = (double *)malloc( (n+1)*sizeof(double));

	if (z == NULL) {
		sprintf(errs, "%s: unable to allocate z array, size = %d\n",
			functionName, n);
		alert_user(errs);
		goto freeAndReturn;
	}
	
	a = (double **)malloc( (n)*sizeof(double*));
	if (a == NULL) {
		sprintf(errs, "%s: unable to allocate a array, size = %d\n",
			functionName, n);
		alert_user(errs);
		goto freeAndReturn;
	}
	
	v = (double **)malloc( (n)*sizeof(double*));
	if (v == NULL) {
		sprintf(errs, "%s: unable to allocate v array, size = %d\n",
			functionName, n);
		alert_user(errs);
		goto freeAndReturn;
	}
	
	for (i = 0; i < n; i++, a_array += n, v_array += n) {
	   a[i] = a_array;
	   v[i] = v_array;
	}
	for (ip = 0; ip < n; ip++) {
		for (iq = 0; iq < n ;iq++) {
#if defined (_DEBUG)
			sprintf(errs, "%s: a[%d][%d] = %f \n", functionName, ip, iq, a[ip][iq]);
			alert_user(errs);
#endif
			v[ip][iq]=0.0;
        } /* iq loop */

   		v[ip][ip] = 1.0;
		b[ip] = d[ip] = a[ip][ip];
		z[ip] = 0.0;
	} /* ip loop */

	for (i = 1; i < LOOP_LIMIT; i++) {
#if defined (_DEBUG)
		sprintf(errs, "%s: jacobi iteration %d\n", functionName, i);
		alert_user(errs);
#endif
		sm = 0.0;	
		for (ip = 0; ip < n - 1; ip++) 
			for (iq = ip+1; iq < n ; iq++)
				sm += fabs(a[ip][iq]);

		if (sm == 0.0 ) {
			converged = true;
			break;
		}

		if (i < 4 ) 
			thresh = 0.2*sm/(n*n);
		else
			thresh = 0.0;

		for (ip = 0; ip < n-1; ip++) {
			for (iq = ip+1; iq <n; iq++) {
#if defined (_DEBUG)
				{
					int x;
					for (x = 0 ; x < n ; x++) {
						sprintf(errs, "%s: d[%d] = %f \n",functionName, x, d[x]);
						alert_user(errs);
					}
				}
#endif
				g = 100.0*fabs(a[ip][iq]);

				if (i > 4 && fabs(d[ip]) + g == fabs(d[ip])
					   && fabs(d[iq])+g == fabs(d[iq]) )
					a[ip][iq] = 0.0;
				
				else if (fabs(a[ip][iq]) > thresh) {
					h = d[iq]-d[ip];
					
					if ( fabs(h)+g == fabs(h) ) {
						t=(a[ip][iq])/h;
					} else {
						theta=0.5*h/(a[ip][iq]);
						t=1.0/(fabs(theta)+sqrt(1.0+theta*theta));
						if ( theta < 0.0 ) t = -t;
					}
					c = 1.0 /sqrt(1+t*t);
					s = t*c;
					tau = s/(1.0+c);
					h=t*a[ip][iq];
					z[ip] -= h;
					z[iq] += h;
					d[ip] -= h;
					d[iq] += h;
					a[ip][iq] = 0.0;
					for ( j = 0; j <= ip-1;j++) 
						JACOBI_ROTATE(a,j,ip,j,iq);
					for ( j = ip+1; j <= iq-1;j++)
						JACOBI_ROTATE(a,ip,j,j,iq);
					for ( j = iq+1; j < n;j++)
						JACOBI_ROTATE(a,ip,j,iq,j);
					for ( j = 0; j < n;j++)
						JACOBI_ROTATE(v,j,ip,j,iq);
					++nrot;
				} /* fabs(a[ip][iq]) > thresh */
			} /* iq loop */
		} /* ip loop */

		for (ip = 0; ip < n; ip++) {
			b[ip] += z[ip];
			d[ip] = b[ip];
			z[ip] = 0.0;
		}
	} /* i loop */
	
	if (converged == false) {
		sprintf(errs, "%s: too many jacobi iterations.\n", functionName);
		alert_user(errs);
		nrot = -1;
	}

freeAndReturn:
	if (b != NULL)
		free(b);
	if (z != NULL)
		free(z);
	if (a != NULL)
		free(a);
	if (v != NULL)
		free(v);
		
	return nrot;

} /* JacobiDiag */

Boolean MatchSymmetry(
	long	NumberToMatch
)
/*
 *   MatchSymmetry 
 *          matches up a set of symmetry operations for the system
 *          with a point-group.  The set of symmetry operations are
 *          stored in IELEM.  Point-groups are represented by a
 *          number, N1, which is expanded into binary.
 *
 *          A system has the symmetry of a specific point-group if
 *          every operation of the point-group is present in the
 *          system.  Extra operations may also be present, but are
 *          ignored.  This allows a controlled descent in symmetry.
 *          The symmetry groups in the calling routine, CARTAB, are
 *          stored in order of symmetry - C1 to R3.
 *  MatchSymmetry  returns a  TRUE if the system matches point-group N1.
 */
{
	long i, numberCopy, lastBit;
	
	numberCopy = NumberToMatch;
	
	for (i = 0; i < NUMBER_OF_BITS; i++) {
		lastBit = numberCopy % 2;
		if (ElementMatch[i] != 1 && lastBit == 1)
			return(false);
		numberCopy /= 2;
	}
	return(true);
} /* MatchSymmetry */

void GetGroupName(
	char *name
)
{
	short	groupNumber; 
	long	binaryRepresentation[NUMBER_OF_GROUPS];

	name[0] = 0;
	
	binaryRepresentation[0] = 0;
	binaryRepresentation[1] = 8;
	binaryRepresentation[2] = 64;
	binaryRepresentation[3] = 4;
	binaryRepresentation[4] = 7;
	binaryRepresentation[5] = 52;
	binaryRepresentation[6] = 76;
	binaryRepresentation[7] = 127;
	binaryRepresentation[8] = 128;
	binaryRepresentation[9] = 260;
	binaryRepresentation[10] = 8196;
	binaryRepresentation[11] = 129;
	binaryRepresentation[12] = 144;
	binaryRepresentation[13] = 136;
	binaryRepresentation[14] = 512;
	binaryRepresentation[15] = 1156;
	binaryRepresentation[16] = 16576;
	binaryRepresentation[17] = 2048;
	binaryRepresentation[18] = 4356;
	binaryRepresentation[19] = 33028;
	binaryRepresentation[20] = 308;
	binaryRepresentation[21] = 263;
	binaryRepresentation[22] = 8244;
	binaryRepresentation[23] = 528;
	binaryRepresentation[24] = 1204;
	binaryRepresentation[25] = 1159;
	binaryRepresentation[26] = 8524;
	binaryRepresentation[27] = 153;
	binaryRepresentation[28] = 16594;
	binaryRepresentation[29] = 2064;
	binaryRepresentation[30] = 2056;
	binaryRepresentation[31] = 4404;
	binaryRepresentation[32] = 4359;
	binaryRepresentation[33] = 33076;
	binaryRepresentation[34] = 8575;
	binaryRepresentation[35] = 520;
	binaryRepresentation[36] = 513;
	binaryRepresentation[37] = 537;
	binaryRepresentation[38] = 66130;
	binaryRepresentation[39] = 17612;
	binaryRepresentation[40] = 17663;
	binaryRepresentation[41] = 140468;
	binaryRepresentation[42] = 2049;
	binaryRepresentation[43] = 2073;
	binaryRepresentation[44] = 2130;
	binaryRepresentation[45] = 45388;
	binaryRepresentation[46] = 45439;
	binaryRepresentation[47] = 262276;
	binaryRepresentation[48] = 270516;
	binaryRepresentation[49] = 262273;
	binaryRepresentation[50] = 278732;
	binaryRepresentation[51] = 287231;
	binaryRepresentation[52] = 262143;
	binaryRepresentation[53] = 344786;
	binaryRepresentation[54] = 524340;
	binaryRepresentation[55] = 524415;
	binaryRepresentation[56] = 524992;

	for (groupNumber = NUMBER_OF_GROUPS - 1; groupNumber >= 0; groupNumber--) {
		if (MatchSymmetry(binaryRepresentation[groupNumber]))
			break;
	}

	if (groupNumber == 0)
		strcat(name, "C1");
	else if (groupNumber == 1)
		strcat(name, "Cs");
	else if (groupNumber == 2)
		strcat(name, "Ci");
	else if (groupNumber == 3)
		strcat(name, "C2");
	else if (groupNumber == 4)
		strcat(name, "D2");
	else if (groupNumber == 5)
		strcat(name, "C2v");
	else if (groupNumber == 6)
		strcat(name, "C2h");
	else if (groupNumber == 7)
		strcat(name, "D2h");
	else if (groupNumber == 8)
		strcat(name, "C3");
	else if (groupNumber == 9)
		strcat(name, "C4");
	else if (groupNumber == 10)
		strcat(name, "S4");
	else if (groupNumber == 11)
		strcat(name, "D3");
	else if (groupNumber == 12)
		strcat(name, "C3v");
	else if (groupNumber == 13)
		strcat(name, "C3h");
	else if (groupNumber == 14)
		strcat(name, "C5");
	else if (groupNumber == 15)
		strcat(name, "C6");
	else if (groupNumber == 16)
		strcat(name, "S6");
	else if (groupNumber == 17)
		strcat(name, "C7");
	else if (groupNumber == 18)
		strcat(name, "C8");
	else if (groupNumber == 19)
		strcat(name, "S8");
	else if (groupNumber == 20)
		strcat(name, "C4v");
	else if (groupNumber == 21)
		strcat(name, "D4");
	else if (groupNumber == 22)
		strcat(name, "D2d");
	else if (groupNumber == 23)
		strcat(name, "C5v");
	else if (groupNumber == 24)
		strcat(name, "C6v");
	else if (groupNumber == 25)
		strcat(name, "D6");
	else if (groupNumber == 26)
		strcat(name, "C4h");
	else if (groupNumber == 27)
		strcat(name, "D3h");
	else if (groupNumber == 28)
		strcat(name, "D3d");
	else if (groupNumber == 29)
		strcat(name, "C7v");
	else if (groupNumber == 30)
		strcat(name, "C7h");
	else if (groupNumber == 31)
		strcat(name, "C8v");
	else if (groupNumber == 32)
		strcat(name, "D8");
	else if (groupNumber == 33)
		strcat(name, "D4d");
	else if (groupNumber == 34)
		strcat(name, "D4h");
	else if (groupNumber == 35)
		strcat(name, "C5h");
	else if (groupNumber == 36)
		strcat(name, "D5");
	else if (groupNumber == 37)
		strcat(name, "D5h");
	else if (groupNumber == 38)
		strcat(name, "D5d");
	else if (groupNumber == 39)
		strcat(name, "C6h");
	else if (groupNumber == 40)
		strcat(name, "D6h");
	else if (groupNumber == 41)
		strcat(name, "D6d");
	else if (groupNumber == 42)
		strcat(name, "D7");
	else if (groupNumber == 43)
		strcat(name, "D7h");
	else if (groupNumber == 44)
		strcat(name, "D7d");
	else if (groupNumber == 45)
		strcat(name, "C8h");
	else if (groupNumber == 46)
		strcat(name, "D8h");
	else if (groupNumber == 47)
		strcat(name, "T");
	else if (groupNumber == 48)
		strcat(name, "Td");
	else if (groupNumber == 49)
		strcat(name, "O");
	else if (groupNumber == 50)
		strcat(name, "Th");
	else if (groupNumber == 51)
		strcat(name, "Oh");
	else if (groupNumber == 52)
		strcat(name, "I");
	else if (groupNumber == 53)
		strcat(name, "Ih");
	else if (groupNumber == 54)
		strcat(name, "C*v");
	else if (groupNumber == 55)
		strcat(name, "D*h");
	else if (groupNumber == 56)
		strcat(name, "R3");
	else
		strcat(name, "????");
		
	return;
} /* GetGroupName */

void EulerRotation(
	double	*Matrix,
	short	Place
)
/*
 *   EulerRotation performs a eulerian rotation on a symmetry operation.
 *
 *    The symmetry operation Place, stored in Element is subjected
 *    to the operation stored in Matrix.
 */
{
	double	Help[9];
	int		i, j, k, m;

	for (i = 0; i < 3; i++) {
		for (j = 0; j < 3; j++) {
			Help [j*3 + i] = 0.0;
			for (k = 0; k < 3; k++) {
				for (m = 0; m < 3; m++) {
					Help[j*3 + i] += 
						Matrix[m*3 + i] * Matrix[k*3 + j] * Elements[Place*9 + k*3 + m];
				} /* m loop */
			} /* k loop */
		} /* j loop */
	} /* i loop */
	
	for (i = 0 ; i < 3; i++) {
		for (j = 0; j < 3; j++) {
			Elements[Place*9 + j*3 + i] = Help[j*3 + i];
		} /* j loop */
	} /* i loop */
	return;	
} /* EulerRotation */

void BuildSymmetry(
	int	Operation,
	int	Place
)
/*
 *
 *   BuildSymmetry  constructs the point-group symmetry operations as
 *           3 by 3 matrices, NUMBER_OF_BITS in all.  The operations are, in
 *           order
 *   1 C2(X)         6 Sigma(YZ)     11 C6      16 S8
 *   2 C2(Y)         7 inversion     12 C7      17 S10
 *   3 C2(Z)         8 C3            13 C8      18 S12
 *   4 Sigma(XY)     9 C4            14 S4      19 S(5) ?
 *   5 Sigma(XZ)    10 C5            15 S6      20 C(infinity)
 */
{
	short i, k;
	short Jay[60];

	Jay[0] = 1;
	Jay[1] = -1;
	Jay[2] = -1;
	
	Jay[3] = -1;
	Jay[4] = 1;
	Jay[5] = -1;
	
	Jay[6] = -1;
	Jay[7] = -1;
	Jay[8] = 1;
	
	Jay[9] = 1;
	Jay[10] = 1;
	Jay[11] = -1;
	
	Jay[12] = 1;
	Jay[13] = -1;
	Jay[14] = 1;
	
	Jay[15] = -1;
	Jay[16] = 1;
	Jay[17] = 1;
	
	Jay[18] = -1;
	Jay[19] = -1;
	Jay[20] = -1;
	
	Jay[21] = 3;
	Jay[22] = 0;
	Jay[23] = 1;
	
	Jay[24] = 4;
	Jay[25] = 0;
	Jay[26] = 1;
	
	Jay[27] = 5;
	Jay[28] = 0;
	Jay[29] = 1;
	
	Jay[30] = 6;
	Jay[31] = 0;
	Jay[32] = 1;
	
	Jay[33] = 7;
	Jay[34] = 0;
	Jay[35] = 1;
	
	Jay[36] = 8;
	Jay[37] = 0;
	Jay[38] = 1;
	
	Jay[39] = 4;
	Jay[40] = 0;
	Jay[41] = -1;
	
	Jay[42] = 6;
	Jay[43] = 0;
	Jay[44] = -1;
	
	Jay[45] = 8;
	Jay[46] = 0;
	Jay[47] = -1;
	
	Jay[48] = 10;
	Jay[49] = 0;
	Jay[50] = -1;
	
	Jay[51] = 12;
	Jay[52] = 0;
	Jay[53] = -1;
	
	Jay[54] = 5;
	Jay[55] = 0;
	Jay[56] = -1;
	
	Jay[57] = 0;
	Jay[58] = 0;
	Jay[59] = -1;
	
	for (i = 0; i < 3; i++) {
		for (k = 0; k < 3; k++)
			Elements[Place*9 + k*3 + i] = 0.0;
		Elements[Place*9 + i*3 + i] = Jay[Operation*3 + i];
	}
	
	if (Operation == 19) {
		Elements[Place*9 + 3] = 1.0;
		Elements[Place*9 + 1] = 1.0;
		return;
	}
	
	if (Jay[Operation*3] > 1) {
		double angle;
		angle = TWO_PI/Jay[Operation*3];
		Elements[Place*9] = cos(angle);
		Elements[Place*9 + 4] = cos(angle);
		Elements[Place*9 + 1] = sin(angle);
		Elements[Place*9 + 3] = -sin(angle);
	}
	
	if (Operation == 7 || Operation == 14) {
		short itemp;
		itemp = (short) Place;
		EulerRotation(Cube, itemp);
	}
	return;
} /* BuildSymmetry */

void Character(
	int		NumberOfAtoms,
	short	*AtomicNumber,
	long	*AtomElementMatch,
	double	*coordinates,
	double	tolerance,
	int		Operation,
	int		*equality
)
/* 
 * Character returns a "1" in ElementMatch[operation] if the symmetry operation
 * Elements[operation] leaves the system unchanged.  Otherwise, Character
 * returns a "0" in ElementMatch[operation].
 */
{
	int	i, j, result;
	double	h[3];
	Boolean	zeroResult = true;
	
	result = 1;
	*equality = 1;
	
	for (i = 0; i < NumberOfAtoms; i++) {
		zeroResult = true;
		h[0] = coordinates[i*3] * Elements[Operation*9] + 
				coordinates[i*3 + 1] * Elements[Operation*9 + 3] +
				coordinates[i*3 + 2] * Elements[Operation*9 + 6];
		h[1] = coordinates[i*3] * Elements[Operation*9 + 1] + 
				coordinates[i*3 + 1] * Elements[Operation*9 + 4] +
				coordinates[i*3 + 2] * Elements[Operation*9 + 7];
		h[2] = coordinates[i*3] * Elements[Operation*9 + 2] + 
				coordinates[i*3 + 1] * Elements[Operation*9 + 5] +
				coordinates[i*3 + 2] * Elements[Operation*9 + 8];
		for (j = 0; j < NumberOfAtoms; j++) {
			if (AtomicNumber[i] != AtomicNumber[j])
				continue;
			if (fabs(coordinates[j*3] - h[0]) > tolerance)
				continue;
			if (fabs(coordinates[j*3 + 1] - h[1]) > tolerance)
				continue;
			if (fabs(coordinates[j*3 + 2] - h[2]) > tolerance)
				continue;
			AtomElementMatch[i*20 + Operation] = j;
			if (i == j)
				*equality++;
			zeroResult = false;
			break;
 		} /* j loop */
		if (zeroResult == true)
			result = 0;
	} /* i loop */
	ElementMatch[Operation] = result;
} /* Character */

void BondAngle(
	double	*coordinates,
	int		i,
	int		j,
	int		k,
	double	*angle
)
/* Calculates the angle between atoms i, j and  k */
{
	int m;
	double dij, djk, dik, temp;
	
	for (m = 0, dij = 0.0; m < 3; m++) {
		temp = coordinates[i*3 + m] - coordinates[j*3 + m];
		dij += temp * temp;
	}
	
	for (m = 0, djk = 0.0; m < 3; m++) {
		temp = coordinates[j*3 + m] - coordinates[k*3 + m];
		djk += temp * temp;
	}
	
	for (m = 0, dik = 0.0; m < 3; m++) {
		temp = coordinates[i*3 + m] - coordinates[k*3 + m];
		dik += temp * temp;
	}
	
	temp = (dij + djk -dik)/(2.0 * sqrt(dij * djk));
	
	if (temp > 1.0) 
		temp = 1.0;
	if (temp < -1.0)
		temp = -1.0;
	
	*angle = cos(temp);

} /* BondAngle */

void CoordDotR(
	int 	NumberOfAtoms,
	double	*coordinates,
	double	*r
)
{
	double	temp[3];
	int 	i, j, k;
	
	for (i = 0; i < NumberOfAtoms; i++) {
		for (j = 0; j < 3; j++) {
			temp[j] = coordinates[i*3 + j];
			coordinates[i*3 + j] = 0.0;
		}
		
		for (j = 0; j < 3; j++) {
			for (k = 0; k < 3; k++)
				coordinates[i*3 + j] += r[j*3 + k] * temp[k];
  		} /* j loop */
	} /* i loop */
} /* CoordDotR */

void RDotCoord(
	int 	NumberOfAtoms,
	double	*coordinates,
	double	*r
)
{
	double	temp[3];
	int 	i, j, k;
	
	for (i = 0; i < NumberOfAtoms; i++) {
		for (j = 0; j < 3; j++) {
			temp[j] = coordinates[i*3 + j];
			coordinates[i*3 + j] = 0.0;
		}
		
		for (j = 0; j < 3; j++) {
			for (k = 0; k < 3; k++)
				coordinates[i*3 + j] += r[k*3 + j] * temp[k];
  		} /* j loop */
	} /* i loop */
} /* RDotCoord */

void Platonic(
	int NumberOfAtoms,
	double *coordinates,
	double *r
)
/*
 * Generates the unitary transform which orients the system so that
 * the Z axis is the axis of rotation.  Plantonic is called when the
 * molecule belongs to the cubic point group.
 * Atoms nearest to the center of symmetry are identified.
 * If there are 4, 6, 8, 12 or 20, they outline one of the Platonic solids
 * (tetrahedron, octahedron, cube, ocosahedron or pentagonal dodecahedron.
 * In this case, each atom lies on a 3, 4 or 5-fold symmetry axis.
 * In other cases, the axis of symmetry goes trough a regular polygon; this
 * polygon may be an equilateral triangle, a square or a regular pentagon.
 * The unitary transform is returned in r.
 */
{
	static	char functionName[] = "Platonic";
	char	errs[SYM_LONG_STRING];
	int 	*nearby = NULL,
			polyhedron[3],
			polyi, polyj,
			i, j, k, m, isav, jsav,
			index, nearfirst, jnear;
	double	tolerance = LARGE_TOLERANCE,
			angle, x, distance, ijdistance, 
			sumsquares, temp1, temp2, dtemp,
			allR[3],
			xyz[9];
	Boolean	jumpOut = false;

	/* Allocate nearby array */
	nearby = (int *) malloc(NumberOfAtoms * sizeof(int));

	if (nearby == NULL) {
		sprintf(errs, "%s: unable to allocate nearby array\n", functionName);
		alert_user_watch(errs);
		return;
	}
	
	RDotCoord(NumberOfAtoms, coordinates, r);
	
	index = -1;
	
	for (i = 0; i < 3; i++) {
		polyhedron[i] = 0;
		allR[i] = 0.0;
	}
	
	for (i = 0; i < 9; i++)
		xyz[i] = 0.0;
	for (i = 0; i < NumberOfAtoms; i++)
		nearby[i] = -1;
		
	for (i = 0; i < NumberOfAtoms; i++) {
		x = coordinates[i*3] * coordinates[i*3] + 
			coordinates[i*3 + 1] * coordinates[i*3 + 1] +
			coordinates[i*3 + 2] * coordinates[i*3 + 2];
		if (x >= tolerance)
			break;
	}

	m = 0;
	
	for (i = 0; i < NumberOfAtoms; i++) {
		distance = coordinates[i*3] * coordinates[i*3] + 
					coordinates[i*3 + 1] * coordinates[i*3 + 1] +
					coordinates[i*3 + 2] * coordinates[i*3 + 2];
		if (distance < tolerance)
			continue;
		if (distance > x + tolerance)
			continue;
		if (fabs(distance - x) < tolerance) {
			m++;
			nearby[m - 1] = i;
		} else
			m = 0;
		index = i;
		x = distance;
	}
	
	if (m == 4 || m == 6 || m == 8 || m == 12 || m == 20) {
		/* The system is a Platonic solid; an atom lies on a high-symmetry axis */
		r[6] = coordinates[index*3]/distance;
		r[7] = coordinates[index*3 + 1]/distance;
		r[8] = coordinates[index*3 + 2]/distance;
	} else {
		nearfirst = nearby[0];
		for (i = 0; i < 3; i++) {
			x = 100.0;
			for (j = 1; j < m; j++) {
				jnear = nearby[j];
				jumpOut = false;
				for (k = 0; k < i; k++) {
					if (polyhedron[k] == jnear) {
						jumpOut = true;
						break;
					}
				}
				if (jumpOut == false) {
					
					dtemp = coordinates[nearfirst*3] - coordinates[jnear*3];
					ijdistance = dtemp * dtemp;
					dtemp = coordinates[nearfirst*3 + 1] - coordinates[jnear*3 + 2];
					ijdistance += dtemp * dtemp;
					dtemp = coordinates[nearfirst*3 + 2] - coordinates[jnear*3 + 2];
					ijdistance += dtemp * dtemp;
					
					if (x > ijdistance) {
						x = ijdistance;
						polyhedron[i] = jnear;
						allR[i] = ijdistance;
					}
				}
			} /* j loop */
		} /* i loop */
		
		for (i = 0; i < 3; i++)
			allR[i] = sqrt(allR[i]);
			
		/* Identify the two atoms in the regular polygon */
		jumpOut = false;
		for (i = 0; i < 2; i++) {
		    isav = i;
			for (j = i + 1; j < 3; j++) {
			    jsav = j;
				if (fabs(allR[i] - allR[j]) < SMALL_TOLERANCE) {
					jumpOut = true;
					break;
				}
			}
			if (jumpOut == true)
				break;
		}
		
		for (k = 0; k < 3; k++) {
			xyz[6 + k] = coordinates[polyhedron[isav]*3 + k];
			xyz[3 + k] = coordinates[polyhedron[jsav]*3 + k];
			xyz[k] = coordinates[nearfirst*3 + k];
		}
		polyi = polyhedron[isav];
		polyj = polyhedron[jsav];
		polyhedron[0] = polyi;
		polyhedron[1] = polyj;
		
		BondAngle(xyz, 2, 0, 1, &angle);

		if (fabs(angle - 1.0472) < LARGE_TOLERANCE) {
			/* triangle */
			for (i = 0; i < 3; i++) {
				r[6 + i] = coordinates[nearfirst*3 + i] +
							coordinates[polyj*3 + i] +
							coordinates[polyi*3 + i];
			}
		} else if (fabs(angle - 1.5707963) < LARGE_TOLERANCE) {
			/* square */
			for (i = 0; i < 3; i++) {
				r[6 + i] = coordinates[polyj*3 + i] +
							coordinates[polyi*3 + i];
			}
		} else if (fabs(angle - 1.885) < LARGE_TOLERANCE) {
			/* pentagon */
			for (i = 0; i < 3; i++) {
				r[6 + i] = coordinates[polyj*3 + i] +
							coordinates[polyi*3 + i] -
							coordinates[nearfirst*3 + i];
			}
 		}
	} /* not a platonic solid */
	
	for (i = 0, sumsquares = 0.0; i < 3; i++)
		sumsquares += r[6 + i] * r[6 + i];
	
	sumsquares = sqrt(sumsquares);

	if (sumsquares == 0.0) {
		alert_user("Platonic: Sum of squares is zero");
		return;
	}

	for (i = 0; i < 3; i++)
		r[6 + i] /= sumsquares;
		
	temp1 = sqrt(r[6] * r[6] + r[7] * r[7]);
	temp2 = sqrt(r[6] * r[6] + r[8] * r[8]);
	
	if (temp1 < temp2) {
		r[0] = r[8]/temp2;
		r[1] = 0.0;
		r[2] = -r[6]/temp2;
	} else {
		r[0] = r[7]/temp1;
		r[1] = -r[6]/temp1;
		r[2] = 0.0;
	}
	
	r[3] = r[7]*r[2] - r[1]*r[8];
	r[4] = r[8]*r[0] - r[2]*r[6];
	r[5] = r[6]*r[1] - r[0]*r[7];
	
	CoordDotR(NumberOfAtoms, coordinates, r);
} /* Platonic */

void RotateMolecule(
	int		NumberOfAtoms,
	double	*coordinates,
	double	this_sine,
	double	this_cosine,
	int		i,
	int		j,
	double	*r
)
{
	int		k;
	double	b1, b2;
	
	RDotCoord(NumberOfAtoms, coordinates, r);
	
	for (k = 0; k < 3; k++) {
		b1 = this_cosine * r[j*3 + k] - this_sine * r[i*3 + k];
		b2 = this_cosine * r[i*3 + k] + this_sine * r[j*3 + k];
		r[i*3 + k] = b2;
		r[j*3 + k] = b1;
	}
	CoordDotR(NumberOfAtoms, coordinates, r);
} /* RotateMolecule */

void OrientMolecule(
	int		NumberOfAtoms,
	short	*AtomicNumber,
	long	*AtomElementMatch,
	double	*coordinates,
	double	*rtemp
)
/*
 * In cubic systems, the three moments of inertia are identical.
 * Use the nearest atom to the center of mass to determine the z axis.
 */
{
	int		i, j, int_dummy;
	double	tolerance = SMALL_TOLERANCE,
			dummy,
			this_sine,
			that_sine,
			this_cosine,
			that_cosine,
			twister,
			twist[2];
	
	/*
	 * twist[0] rotates a cubic molecule through 1/2 the tetrahedral angle
	 * it is the arc cosine of (sqrt(1/3))
	 * twist[1] is similar for icosahedral systems
	 * it is the arc cosine of ((47 + 21*sqrt(5))/(75+33*sqrt(5))) = 37.377366 deg
	 */
	twist[0] = 0.955316618125;
	twist[1] = 0.65235813978437;
	
	if (ElementMatch[7] >= 1) {
		/* Check for an S4 or C5 axis */
		for (i = 0; i < 2; i++) {

			j = 17 - 4*i;
			twister = twist[0];
			this_sine = sin(twister);
			this_cosine = cos(twister);

			RotateMolecule(NumberOfAtoms, coordinates, this_sine,
				this_cosine, 0, 2, rtemp);
			Character(NumberOfAtoms, AtomicNumber, AtomElementMatch, coordinates, tolerance, j, &int_dummy);
			
			if (ElementMatch[j] > 0)
				break;
			
			if (i == 0) {
				Character(NumberOfAtoms, AtomicNumber, AtomElementMatch, coordinates, tolerance, 2, &int_dummy);
				
				if (ElementMatch[2] > 0)
					break;
			} /* i == 0 */
			
			twister = -twister;
			that_sine = sin(2.0 * twister);
			that_cosine = cos(2.0 * twister);
			RotateMolecule(NumberOfAtoms, coordinates, that_sine,
				that_cosine, 0, 2, rtemp);
			Character(NumberOfAtoms, AtomicNumber, AtomElementMatch, coordinates, tolerance, j, &int_dummy);
			
			if (ElementMatch[j] > 0)
				break;

			if (i == 0) {
				Character(NumberOfAtoms, AtomicNumber, AtomElementMatch, coordinates, tolerance, 2, &int_dummy);
				
				if (ElementMatch[2] > 0)
					break;
			} /* i == 0 */

			RotateMolecule(NumberOfAtoms, coordinates, this_sine,
				this_cosine, 0, 2, rtemp);
 		} /* i loop */
		
		Character(NumberOfAtoms, AtomicNumber, AtomElementMatch, coordinates, tolerance, 8, &int_dummy);
		
		if (ElementMatch[9] > 0)
			Character(NumberOfAtoms, AtomicNumber, AtomElementMatch, coordinates, tolerance, 16, &int_dummy);
	} /* ElementMatch[7] >= 1 */
	else { /* ElementMatch[7] == 0 */
		twister = -twist[0];
		if (ElementMatch[9] > 0)
			twister = -twist[1];

		this_sine = -sin(twister);
		this_cosine = cos(twister);
		
		RotateMolecule(NumberOfAtoms, coordinates, this_sine,
			this_cosine, 0, 2, rtemp);
		Character(NumberOfAtoms, AtomicNumber, AtomElementMatch, coordinates, tolerance, 7, &int_dummy);
		RotateMolecule(NumberOfAtoms, coordinates, -this_sine,
			this_cosine, 0, 2, rtemp);
		
		if (ElementMatch[7] == 0 && ElementMatch[8] == 0)
			twister = -twister;
			
		if (ElementMatch[7] == 0 && ElementMatch[8] == 0) { /* after rotation */
			dummy = ICOSAHEDRAL_ANGLE;
			RotateMolecule(NumberOfAtoms, coordinates, dummy, dummy, 0, 1, rtemp);
		} /* ElementMatch[7] == 0 after rotation */
	} /* ElementMatch[7] == 0 */
	
	j = 0;
	for (i = 0, j = 0; i < 16; i++)
		j += ElementMatch[i];
	
	if (j == 2 && (ElementMatch[0] + ElementMatch[7]) == 2)
		return;

    Cube[0] = cos(twister);
    Cube[8] = cos(twister);
	Cube[6] = sin(twister);
	Cube[2] = -sin(twister);
	
	EulerRotation(Cube, 7);
	EulerRotation(Cube, 14);
	Character(NumberOfAtoms, AtomicNumber, AtomElementMatch, coordinates, tolerance, 7, &int_dummy);
	Character(NumberOfAtoms, AtomicNumber, AtomElementMatch, coordinates, tolerance, 14, &int_dummy);
} /* OrientMolecule */

int GetMoments(
	int			NumberOfAtoms,
	double		*AtomMasses,
	double		*coordinates,
	double		*moments
)
/*
 * Calculates the three moments of inertia in units of 
 * 10**(-40)gram-cm**2.
 * 
 * conversion_constant from angstrom-amu to cm-1
 * (Planck's constant)*(Avogadro's number)*10**16/(8*pi*pi*(speed of light))
 */
{
	static char functionName[] = "GetMoments";
	char	errs[SYM_LONG_STRING];
	int		i, smallest, middle, largest, 
			rtn_code, return_code = 0;
	double	f[9], eigenvalues[3], vectors[9],
			xi, yi, zi,
			xoffset = 0.0, 
			yoffset = 0.0, 
			zoffset = 0.0,
			molecularWeight = 0.0,
			conversion_constant = 16.85763143188;

	/* get center-of-mass offsets */
	for (i = 0; i < NumberOfAtoms; i++) {
		molecularWeight += AtomMasses[i];
		xoffset += AtomMasses[i]*coordinates[i*3];
		yoffset += AtomMasses[i]*coordinates[i*3 + 1];
		zoffset += AtomMasses[i]*coordinates[i*3 + 2];
	}

	if (molecularWeight < SMALL_TOLERANCE) {
		return_code = -1;
		sprintf(errs, "%s: molecular weight %lf is too small.\n", 
			functionName, molecularWeight);
		alert_user(errs);
		goto return_now;
	}

	xoffset /= molecularWeight;
	yoffset /= molecularWeight;
	zoffset /= molecularWeight;

	/* "fuzz" the matrix */
	for (i = 0; i < 9; i++)
		f[i] = i*0.000000001;
	
	/* Populate the matrix */
	for (i = 0; i < NumberOfAtoms; i++) {
		xi = coordinates[i*3] - xoffset;
		yi = coordinates[i*3 + 1] - yoffset;
		zi = coordinates[i*3 + 2] - zoffset;
		f[0] += AtomMasses[i] * (yi*yi + zi*zi);
		f[3] += AtomMasses[i] * xi * yi;
		f[4] += AtomMasses[i] * (zi*zi + xi*xi);
		f[6] += AtomMasses[i] * xi * zi;
		f[7] += AtomMasses[i] * yi * zi;
		f[8] += AtomMasses[i] * (xi*xi + yi*yi);
	}
	f[1] = f[3];
	f[2] = f[6];
	f[5] = f[7];
	
	/* Diagonalize f */
	rtn_code = JacobiDiag(f, 3, eigenvalues, vectors);
	
	if (rtn_code < 0) {
		return_code = -1;
		sprintf(errs, "%s: failed to diagonalize for moments.\n", functionName);
		alert_user(errs);
		goto return_now;
	}

	/* Order eigenvalues in increasing order */
	smallest = 0;
	if (eigenvalues[1] < eigenvalues[0])
		smallest = 1;
	if (eigenvalues[2] < eigenvalues[smallest])
		smallest = 2;

	if (smallest == 0) {
		middle = 1;
		largest = 2;
		if (eigenvalues[2] < eigenvalues[1]) {
			middle = 2;
			largest = 1;
		}
	} else if (smallest == 1) {
		middle = 0;
		largest = 2;
		if (eigenvalues[2] < eigenvalues[0]) {
			middle = 2;
			largest = 0;
		}
	} else { /* smallest is 2 */
		middle = 0;
		largest = 1;
		if (eigenvalues[1] < eigenvalues[0]) {
			middle = 1;
			largest = 0;
		}
	}
	
	/* Transfer eigenvalues to moments */
	moments[0] = eigenvalues[smallest];
	moments[1] = eigenvalues[middle];
	moments[2] = eigenvalues[largest];
	
	/* Convert the moments of inertia */
	for (i = 0; i < 3; i++) {
		if (moments[i] < 0.0003)
			moments[i] = 0.0;
		else
			moments[i] = conversion_constant/moments[i];
	}
return_now:
	return(return_code);
} /* GetMoments */

int GetMolecularSymmetry(
	int			NumberOfAtoms,
	double		*OriginalCoordinates,
	short		*AtomicNumber,
	double		*AtomMasses,
	double		*moments,
	double		*molecularWeight,
	char		*symmetryName
)
/* 
 * Calculates the point group symmetry of the molecule as a 
 * character string
 *
 */
{
	static	char functionName[] = "GetMolecularSymmetry";
	char	errs[SYM_LONG_STRING];
	int		return_code = 0,
			rtn_code,
			i, j, k,
			smallest, middle, largest,
			turn, equality, secondindex,
			axisCheck[6], 
			xIndex, yIndex, zIndex,
			numberOfAxes;
	long	*AtomElementMatch = NULL;
	double	*ShiftedCoordinates = NULL,
			dtemp,
			temp_dummy,
			rtemp[9], 
			f[9], 
			vectors[9],
			eigenvalues[3],
			help[3], 
			rHelp[9], 
			shift[6],
			tmp_moments[3],
			largeMoment,
			tolerance_factor = SMALL_TOLERANCE,
			tolerance,
			xydistance,
			jxydistance,
			minimumdistance,
			this_sine,
			this_cosine,
			theta;

	Boolean	isSphere = false,
			isLinear = false,
			isCubic = false,
			hasAxis = false,
			hasCnAxis = true,
			hasSigmaXY = false,
			hasC2X = false,
			doTurns = true;
			
	
	ShiftedCoordinates = (double *) malloc(NumberOfAtoms * 3 * sizeof(double));

	if (ShiftedCoordinates == NULL) {
		return_code = -1;
		sprintf(errs, "%s: unable to allocate ShiftedCoordinates array\n", functionName);
		alert_user_watch(errs);
		goto return_now;
	}
	
	AtomElementMatch = (long *) malloc(NumberOfAtoms * NUMBER_OF_BITS * sizeof(long));

	if (AtomElementMatch == NULL) {
		return_code = -1;
		sprintf(errs, "%s: unable to allocate AtomElementMatch array\n", functionName);
		alert_user_watch(errs);
		goto return_now;
	} else {
		for (i = 0; i < NumberOfAtoms * NUMBER_OF_BITS; i++)
			AtomElementMatch[i] = 0;
	}
	
	*molecularWeight = 0.0;
	
	symmetryName[0] = 0;
	
	for (i = 0; i < 9; i++)
		Cube[i] = 0.0;
	Cube[0] = Cube[4] = Cube[8] = 1.0;
	
	for (i = 0; i < NUMBER_OF_BITS - 2; i++)
		BuildSymmetry(i, i);

	for (i = 0; i < NUMBER_OF_BITS; i++)
		ElementMatch[i] = 0;
		
	/* Get the moments of inertia */
	rtn_code = GetMoments(NumberOfAtoms, AtomMasses, OriginalCoordinates, moments);

	if (rtn_code < 0) {
		return_code = -1;
		goto return_now;
	}

	/* Center the molecule on the molecule's center of mass */
	for (i = 0; i < 3; i++)
		shift[i] = 0.0;
		
	for (i = 0; i < NumberOfAtoms; i++) {
		*molecularWeight += AtomMasses[i];
		for (j = 0; j < 3; j++) {
			shift[j] += AtomMasses[i] * OriginalCoordinates[i*3 + j];
		}
	}

	if (*molecularWeight < SMALL_TOLERANCE) {
		return_code = -1;
		sprintf(errs, "%s: molecular weight %lf is too small.\n", 
			functionName, *molecularWeight);
		alert_user(errs);
		goto return_now;
	} 
	
	for (j = 0; j < 3; j++)
		shift[j] /= *molecularWeight;
	
	for (i = 0; i < NumberOfAtoms; i++)
		for (j = 0; j < 3; j++)
			ShiftedCoordinates[i*3 + j] = OriginalCoordinates[i*3 + j] - shift[j];
	
	/* Calculate the moments of inertia and axes of inertia */
	for (i = 0; i < 3; i++) {
		for (j = 0; j <= i; j++) {
			f[i*3 + j] = (float) (((i + 1)*i)/2 + j + 1) * SMALL_FLOAT;
			for (k = 0; k < NumberOfAtoms; k++) {
				f[i*3 + j] += AtomMasses[k] * 
							ShiftedCoordinates[k*3 + i] *
								ShiftedCoordinates[k*3 + j];
			} /* k loop */
		if (j != i)
			f[j*3 + i] = f[i*3 + j];
		} /* j loop */
	} /* i loop */

	/* Diagonalize f */
	rtn_code = JacobiDiag(f, 3, eigenvalues, vectors);
	
	if (rtn_code < 0) {
		return_code = -1;
		sprintf(errs, "%s: failed to diagonalize for moments.\n", functionName);
		alert_user(errs);
		goto return_now;
	}

	/* Order eigenvalues in increasing order */
	smallest = 0;
	if (eigenvalues[1] < eigenvalues[0])
		smallest = 1;
	if (eigenvalues[2] < eigenvalues[smallest])
		smallest = 2;

	if (smallest == 0) {
		middle = 1;
		largest = 2;
		if (eigenvalues[2] < eigenvalues[1]) {
			middle = 2;
			largest = 1;
		}
	} else if (smallest == 1) {
		middle = 0;
		largest = 2;
		if (eigenvalues[2] < eigenvalues[0]) {
			middle = 2;
			largest = 0;
		}
	} else { /* smallest is 2 */
		middle = 0;
		largest = 1;
		if (eigenvalues[1] < eigenvalues[0]) {
			middle = 1;
			largest = 0;
		}
	}
	
	/* Transfer eigenvalues to moments, and vectors to r */
	tmp_moments[0] = eigenvalues[smallest];
	tmp_moments[1] = eigenvalues[middle];
	tmp_moments[2] = eigenvalues[largest];
	
	for (k = 0; k < 3; k++) {
		rtemp[k] = vectors[smallest + k*3];
		rtemp[3 + k] = vectors[middle + k*3];
		rtemp[6 + k] = vectors[largest + k*3];
	}

	rtemp[6] = rtemp[1]*rtemp[5] - rtemp[2]*rtemp[4];
	rtemp[7] = rtemp[2]*rtemp[3] - rtemp[0]*rtemp[5];
	rtemp[8] = rtemp[0]*rtemp[4] - rtemp[1]*rtemp[3];
	
	/* determine if this is a special group */
	if (tmp_moments[1] < SMALL_TOLERANCE)
		isLinear = true;
	if (tmp_moments[2] < SMALL_TOLERANCE)
		isSphere = true;
	if (tmp_moments[2] < FORTY)
		largeMoment = tmp_moments[2];
	else
		largeMoment = FORTY;
	
	if ((tmp_moments[2] - tmp_moments[0]) < 0.005*largeMoment)
		isCubic = true;
		
	/* Special flags for sphere */
	if (isSphere) {
		ElementMatch[6] = 1;
		ElementMatch[7] = 1;
		ElementMatch[9] = 1;
		ElementMatch[19] = 1;
		
		for (i = 0; i < 9; i++)
			Cube[i] = 0.0;
			
		Cube[3] = Cube[7] = Cube[2] = 1.0;
	} /* isSphere */
	else if (isLinear) {
		CoordDotR(NumberOfAtoms, ShiftedCoordinates, rtemp);
		ElementMatch[19] = 1;
	} /* isLinear */

	if (!isLinear && !isSphere) {
		if (!isCubic && 
			((tmp_moments[2] - tmp_moments[1]) <  SMALL_TOLERANCE * tmp_moments[2])) {
			/* Two-fold degeneracy */
			for (i = 0; i < 3; i++) {
				temp_dummy = -rtemp[i];
				rtemp[i] = rtemp[6 + i];
				rtemp[6 + i] = temp_dummy;
			}
			temp_dummy = tmp_moments[0];
			tmp_moments[0] = tmp_moments[2];
			tmp_moments[2] = temp_dummy;
		} /* !isCubic etc. */

		hasAxis = (fabs(tmp_moments[0] - tmp_moments[1]) < SMALL_TOLERANCE * tmp_moments[1]);

		/* Check for a plane of symmetry perpendicular to the Z axis */
		CoordDotR(NumberOfAtoms, ShiftedCoordinates, rtemp);
		
		if (isCubic == true) {
			ElementMatch[18] = 1;
			Platonic(NumberOfAtoms, ShiftedCoordinates, rtemp); 
		}

		if (hasAxis == true) {
			/* 
			 * The molecule has degenerate symmetry.  At this point, the
			 * z-axis is defined.  The molecule is Cn, Cnv, Cnh, Dn, etc.
			 * or a special group such as Td, Oh, Ih.
			 */
			doTurns = true;
			while (doTurns == true) {
				doTurns = false;
				turn = 7;
				j = 0;
				
				/* Check for the existence of C3 through C9 or S3 through S13 */
				for (i = 7; i < 18 ; i++) {
					/* Tighten tolerance as the n in Cn increases */
					if (i < 13)
						tolerance = (9.0 * tolerance_factor)/((i - 4) * (i - 4));
					else
						tolerance = (16.0 * tolerance_factor)/((2*i - 22) * (2*i - 22));

					Character(NumberOfAtoms, AtomicNumber, AtomElementMatch, ShiftedCoordinates, tolerance, i, &equality);
					
					if (ElementMatch[i] == 1 && i < 13) {
						if (turn > 9) {
							doTurns = true;
							tolerance_factor *= 0.5;
							break;
						}
						turn = i + 1;
					}
				} /* i loop */
				
				if (doTurns == false) {
					if ((ElementMatch[13] +
						 ElementMatch[14] +
						 ElementMatch[16] > 1) ||
						(ElementMatch[14] +
						 ElementMatch[15] +
						 ElementMatch[16] > 1) ||
						(ElementMatch[15] +
						 ElementMatch[16] +
						 ElementMatch[17] > 1)) {
						tolerance_factor *= 0.5;
						doTurns = true;
					}
				}
				if (doTurns == false)
					turn = turn - 5;
			} /* doTurns */
			
			/*
			 * Use two adjacent equivalent atoms, not on the z axis,
			 * to define the x axis
			 */
			for (i = 0; i < NumberOfAtoms; i++) {
				xydistance = ShiftedCoordinates[i*3]*ShiftedCoordinates[i*3] +
							ShiftedCoordinates[i*3 + 1]*ShiftedCoordinates[i*3 + 1];
				
				if (xydistance < tolerance)
					continue;
				
				/* Atom i is the first atom */
				minimumdistance = 1000.;
				secondindex =  -1;
				
				for (j = i + 1; j < NumberOfAtoms; j++) {
				
					if (fabs(fabs(ShiftedCoordinates[i*3 + 2]) -
						fabs(ShiftedCoordinates[j*3 + 2])) > 0.2)
					continue;
					jxydistance = ShiftedCoordinates[j*3]*ShiftedCoordinates[j*3] +
								ShiftedCoordinates[j*3 + 1]*ShiftedCoordinates[j*3 + 1];
					
					if (AtomicNumber[i] != AtomicNumber[j] ||
						fabs(jxydistance - xydistance) > tolerance)
						continue;
						
					dtemp = ShiftedCoordinates[i*3] - ShiftedCoordinates[j*3];
					jxydistance = dtemp * dtemp;
					dtemp = ShiftedCoordinates[i*3 + 1] - ShiftedCoordinates[j*3 + 1];
					jxydistance += dtemp * dtemp;
						
					if (jxydistance > minimumdistance)
						continue;
					secondindex = j;
					minimumdistance = jxydistance;
				} /* j loop */
				
				/* secondindex is the second, adjacent atom, equivalent to atom i */
				break;
			} /* i loop */
			if (secondindex < 0) {
				/* The system does not have a Cn axis; treat it as an Abelian group */
				hasCnAxis = false;
			} /* secondindex < 0 */
			
			if (hasCnAxis == true ) {
				help[0] = ShiftedCoordinates[i*3] + 
							ShiftedCoordinates[secondindex*3];
				help[1] = ShiftedCoordinates[i*3 + 1] + 
							ShiftedCoordinates[secondindex*3 + 1];
				
				xydistance = sqrt(help[0] * help[0] + help[1] * help[1]);
				this_sine = help[1]/xydistance;
				this_cosine = help[0]/xydistance;
				RotateMolecule(NumberOfAtoms, ShiftedCoordinates, this_sine,
					this_cosine, 0, 1, rtemp);
				
				/* Is there a SigmaXZ plane? */
				Character(NumberOfAtoms, AtomicNumber, AtomElementMatch, ShiftedCoordinates, tolerance, 4, &equality);
				
				if (ElementMatch[4] == 1)
					hasSigmaXY = true;
					
				if (hasSigmaXY == false) {

					/* Check on C2X axis */
					Character(NumberOfAtoms, AtomicNumber, AtomElementMatch, ShiftedCoordinates, tolerance, 0, &equality);

					if (ElementMatch[0] == 0)
						hasC2X = true;

					if (hasC2X == false) {
					
						/* Check for improper axis of rotation */
						theta = HALF_PI/((double) turn);
						this_sine = sin(theta);
						this_cosine = cos(theta);
						
						RotateMolecule(NumberOfAtoms, ShiftedCoordinates, this_sine,
								this_cosine, 0, 1, rtemp);
						Character(NumberOfAtoms, AtomicNumber, AtomElementMatch, ShiftedCoordinates, tolerance, 4, &equality);

						if (ElementMatch[4] == 0) {
							this_sine = -this_sine;
							RotateMolecule(NumberOfAtoms, ShiftedCoordinates, this_sine,
								this_cosine, 0, 1, rtemp);
						}
					} /* hasC2X == false */
	  			} /* hasSigmaXY == false */
	  		} /* hasCnAxis == false */
	  	} /* hasAxis == true */
		
		if (hasCnAxis == false)
			hasAxis = false;
		
		if (isCubic)
			OrientMolecule(NumberOfAtoms, AtomicNumber, AtomElementMatch, ShiftedCoordinates, rtemp);

  		if (hasAxis == false) {
			tolerance = 0.2;
				
			/* Molecule belongs to an Abelian group (C1, C2, Ci, C2, C2v, D2, C2h, D2h) */
			for (i = 0; i < 6; i++) {
				Character(NumberOfAtoms, AtomicNumber, AtomElementMatch, ShiftedCoordinates, tolerance, i, &equality);
				axisCheck[i] = (1 + equality)*ElementMatch[i];
			}
			numberOfAxes = ElementMatch[0] + ElementMatch[1] + ElementMatch[2];
			
			/* Determine the principal axis by atom counts */
			if (numberOfAxes > 1) {
				zIndex = 0;
				if (axisCheck[1] > axisCheck[0])
					zIndex = 1;
				if (axisCheck[2] > axisCheck[1])
					zIndex = 2;
			} else {
				zIndex = 0;
				if (ElementMatch[0] != 1) {
					zIndex = 1;
					if (ElementMatch[1] != 1) {
						zIndex = 2;
						if (ElementMatch[2] != 1) {
							if (axisCheck[4] > axisCheck[3])
								zIndex = 1;
							if (axisCheck[5] > axisCheck[5 - zIndex])
								zIndex = 0;
						} /* ElementMatch[2] != 1 */
					} /* ElementMatch[1] != 1 */
				} /* ElementMatch[0] != 1 */
			}
			axisCheck[5 - zIndex] = -1;
			
			xIndex = 0;
			if (axisCheck[4] > axisCheck[5])
				xIndex = 1;
			if (axisCheck[3] > axisCheck[5 - xIndex])
				xIndex = 2;
				
			yIndex = 3 - xIndex - zIndex;
			
			if (yIndex < 0) {
				return_code = -1;
				sprintf(errs, "%s: yIndex is negative - symmetry not determined\n", functionName);
				alert_user_watch(errs);
				goto return_now;
			}
			
			/* Orient the molecule so the principal axis is the Z axis */
			
			for (i = 0; i < 3; i++) {
				rHelp[i] = rtemp[xIndex*3 + i];
				rHelp[3 + i] = rtemp[yIndex*3 + i];
			}
			rHelp[6] = rtemp[xIndex*3 + 1]*rtemp[yIndex*3 + 2] -
						rtemp[xIndex*3 + 2]*rtemp[yIndex*3 + 1];
			rHelp[7] = rtemp[xIndex*3 + 2]*rtemp[yIndex*3] -
						rtemp[xIndex*3]*rtemp[yIndex*3 + 2];
			rHelp[8] = rtemp[xIndex*3]*rtemp[yIndex*3 + 1] -
						rtemp[xIndex*3 + 1]*rtemp[yIndex*3];
	
			RDotCoord(NumberOfAtoms, ShiftedCoordinates, rtemp);
			for (i = 0; i < 9; i++)
				rtemp[i] = rHelp[i];
	
			CoordDotR(NumberOfAtoms, ShiftedCoordinates, rtemp);
		} /* hasAxis == false */
	} /* !isLinear && !isSphere*/
	if (!isSphere) {
		/* 
		 * Recalculate the first 7 characters: 
		 * C2x, C2y, C2z, SigmaXY, SigmaXZ, SigmaYZ
		 */
		for (i = 0; i < 7; i++)
			Character(NumberOfAtoms, AtomicNumber, AtomElementMatch, ShiftedCoordinates, tolerance, i, &equality);
	} /* !isSphere */
	
	RDotCoord(NumberOfAtoms, ShiftedCoordinates, rtemp);
	
	for (i = 0, temp_dummy = 0.0; i < 3; i++)
		temp_dummy += tmp_moments[i];

	for (i = 0; i < 3; i++)
		tmp_moments[i] = temp_dummy - tmp_moments[i];

	GetGroupName(symmetryName);
		
return_now:
	if (ShiftedCoordinates != NULL)
		free(ShiftedCoordinates);
	
	if (AtomElementMatch != NULL)
		free(AtomElementMatch);

	return(return_code);

} /* GetMolecularSymmetry */
