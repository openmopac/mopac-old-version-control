#include <compat.h>
#include <math.h>
#include <csu.h>
#include "MOPACDriver.h"

long getProductMolecule(MolStruct *molStruct, MolStruct *productMolStruct, 
						MOPACControl *controlPanel)
{
	long 		NAtomProduct=0, NAtomReactant=0;
	ObjclsID	offset;
	short		*reactantElement, *productElement;
	int 		i, j, rtn_code;
	double  	(*reactantCoord)[3];
	double  	(*productCoord)[3];
	char		errs[256], productMolecule[256];
	int			same;

	getProductMoleculeName(controlPanel, productMolecule);

	if ((rtn_code = csu_GetMolstruct (productMolecule,
        							  productMolStruct, 1, 1)) < 0) {
     	sprintf (errs,
				"getProductMolecule : Unable to read product molecule structure file '%s'."
				" Error %d.\n", productMolecule, rtn_code);
	 	alert_user(errs);
     	invalidateProductMolecule(controlPanel);
   	}

	if (!hasProductMolecule(controlPanel)) return (-1);

   	if (csu_ExistsObjclsID (productMolStruct, AtomID, &offset))
     	NAtomProduct = (long) ((GetPtr(productMolStruct->objclsH) + offset)->num_objs);
   	else {
     	alert_user ("getProductMolecule: Unable to locate AtomID index for the product molecule.");
		if (hasProductMolecule(controlPanel)) {
			csu_DeleteMolstruct(productMolStruct, true, true);
			invalidateProductMolecule(controlPanel);
		}
     	return (-1);
   	}
      
   	if (csu_ExistsObjclsID (molStruct, AtomID, &offset))
     	NAtomReactant = (long) ((GetPtr(molStruct->objclsH) + offset)->num_objs);
   	else {
     	alert_user ("getProductMolecule: Unable to locate AtomID index for the reactant.");
		if (hasProductMolecule(controlPanel)) {
			csu_DeleteMolstruct(productMolStruct, true, true);
			invalidateProductMolecule(controlPanel);
		}
     	return (-1);
   	}
	
	if (NAtomProduct != NAtomReactant) {
		sprintf(errs, "The product molecule and the reactant molecule must have"
				   " the same number of atoms.  The reactant has %d atoms, but the"
				   " product has %d atoms.", NAtomReactant, NAtomProduct);
	    alert_user(errs);
		if (hasProductMolecule(controlPanel)) {
			csu_DeleteMolstruct(productMolStruct, true, true);
			invalidateProductMolecule(controlPanel);
		}
		return(-1);
    }
	
  	if ((rtn_code = csu_GrabVal (productMolStruct, AtomID, 
	                             AnumID, (char **)&productElement)) < 0) {
    	sprintf(errs,
				"getProductMolecule : csu_GrabVal AnumID, errno %d",
				rtn_code);
		alert_user(errs);
		if (hasProductMolecule(controlPanel)) {
			csu_DeleteMolstruct(productMolStruct, true, true);
			invalidateProductMolecule(controlPanel);
		}
    	return(-1);
  	}
	
  	if ((rtn_code = csu_GrabVal (molStruct, AtomID, 
	                             AnumID, (char **)&reactantElement)) < 0) {
    	sprintf(errs,
				"getProductMolecule : csu_GrabVal AnumID, errno %d",
				rtn_code);
		alert_user(errs);
		if ((rtn_code = csu_ReleaseVal (productMolStruct, AtomID, AnumID)) < 0) {
			sprintf (errs,
					"getProductMolecule : csu_ReleaseVal AnumID, errno %d", 
					rtn_code);
			alert_user(errs);
		}
		if (hasProductMolecule(controlPanel)) {
			csu_DeleteMolstruct(productMolStruct, true, true);
			invalidateProductMolecule(controlPanel);
		}
    	return(-1);
  	}

	for (i=0; i < NAtomReactant; i++) {
		if (productElement[i] != reactantElement[i]) {
			sprintf(errs,"Reactant and products must be numbered the same."
						 "  Atom %d has atomic number %d in the reactant,"
						 " and atomic number %d in the product. "
						 " Starting with a copy of the reactant,"
				   		 " use the Editor to build the product by"
						 " moving and rebonding atoms in the reactant.",
						 i, reactantElement[i], productElement[i]);
			alert_user(errs);
	
    		if ((rtn_code = csu_ReleaseVal (molStruct, AtomID, AnumID)) < 0) {
       			sprintf (errs,
						" getProductMolecule : csu_ReleaseVal AnumID, errno %d", 
						rtn_code);
	   			alert_user(errs);
    		}
	
    		if ((rtn_code = csu_ReleaseVal (productMolStruct, AtomID, AnumID)) < 0) {
       			sprintf (errs,
						" getProductMolecule : csu_ReleaseVal AnumID, errno %d", 
						rtn_code);
	   			alert_user(errs);
    		}
			if (hasProductMolecule(controlPanel)) {
				csu_DeleteMolstruct(productMolStruct, true, true);
				invalidateProductMolecule(controlPanel);
			}
			return(-1);
		};
	
	
    if ((rtn_code = csu_ReleaseVal (molStruct, AtomID, AnumID)) < 0) {
       sprintf (errs," getProductMolecule : csu_ReleaseVal AnumID, errno %d", rtn_code);
	   alert_user(errs);
	   if (hasProductMolecule(controlPanel)) {
		   csu_DeleteMolstruct(productMolStruct, true, true);
		   invalidateProductMolecule(controlPanel);
	   }
	   return (-1);
    }
	
	/* Now check to see that coordinates are different */
  	if ((rtn_code = csu_GrabVal (productMolStruct, AtomID, 
	                             XYZID, (char **)&productCoord)) < 0) {
    	sprintf(errs,
				"getProductMolecule : csu_GrabVal XYZID, errno %d",
				rtn_code);
		alert_user(errs);
		if ((rtn_code = csu_ReleaseVal (productMolStruct, AtomID, AnumID)) < 0) {
			sprintf (errs,
					" getProductMolecule : csu_ReleaseVal AnumID, errno %d", 
					rtn_code);
			alert_user(errs);
		}
		if (hasProductMolecule(controlPanel)) {
			csu_DeleteMolstruct(productMolStruct, true, true);
			invalidateProductMolecule(controlPanel);
		}
    	return(-1);
  	}
	
  	if ((rtn_code = csu_GrabVal (molStruct, AtomID, 
	                             XYZID, (char **)&reactantCoord)) < 0) {
    	sprintf(errs,
				"getProductMolecule : csu_GrabVal XYZID, errno %d",
				rtn_code);
		alert_user(errs);
		if (hasProductMolecule(controlPanel)) {
			csu_DeleteMolstruct(productMolStruct, true, true);
			invalidateProductMolecule(controlPanel);
		}
    	return(-1);
  	}

	for (same = true, i=0; i < NAtomReactant; i++)
	for (j=0; j<3; j++) 
		if (fabs(productCoord[i][j] - reactantCoord[i][j]) > 0.0001 ) same = false;
		
		if (same) {
			sprintf(errs,"Reactant and products are the same."
						 "  At least one atom must be in a different location"
						 " in the product molecule."
						 " Starting with a copy of the reactant,"
				   		 " use the Editor to build the product by"
						 " moving and rebonding atoms in the reactant.");
			alert_user(errs);
	
    		if ((rtn_code = csu_ReleaseVal (molStruct, AtomID, XYZID)) < 0) {
       			sprintf (errs,
						"getProductMolecule : csu_ReleaseVal XYZID, errno %d", 
						rtn_code);
	   			alert_user(errs);
    		}
	
    		if ((rtn_code = csu_ReleaseVal (productMolStruct, AtomID, XYZID)) < 0) {
       			sprintf (errs,
						"getProductMolecule : csu_ReleaseVal XYZID, errno %d", 
						rtn_code);
	   			alert_user(errs);
    		}
    		if ((rtn_code = csu_ReleaseVal (productMolStruct, AtomID, AnumID)) < 0) {
       			sprintf (errs,
						" getProductMolecule : csu_ReleaseVal AnumID, errno %d", 
						rtn_code);
	   			alert_user(errs);
    		}
			if (hasProductMolecule(controlPanel)) {
				csu_DeleteMolstruct(productMolStruct, true, true);
				invalidateProductMolecule(controlPanel);
			}
			return(-1);
		}

	if ((rtn_code = csu_ReleaseVal (molStruct, AtomID, XYZID)) < 0) {
		sprintf (errs, "getProductMolecule : csu_ReleaseVal XYZID, errno %d", 
				rtn_code);
		alert_user(errs);
	}
	if ((rtn_code = csu_ReleaseVal (productMolStruct, AtomID, XYZID)) < 0) {
		sprintf (errs, "getProductMolecule : csu_ReleaseVal XYZID, errno %d", 
				rtn_code);
		alert_user(errs);
	}
	if ((rtn_code = csu_ReleaseVal (productMolStruct, AtomID, AnumID)) < 0) {
		sprintf (errs, "getProductMolecule : csu_ReleaseVal AnumID, errno %d", 
				rtn_code);
		alert_user(errs);
	}
    if ((rtn_code = csu_ReleaseVal (molStruct, AtomID, AnumID)) < 0) {
       sprintf (errs,"getProductMolecule : csu_ReleaseVal AnumID, errno %d", rtn_code);
	   alert_user(errs);
    }
  }	
  return (1);
}
