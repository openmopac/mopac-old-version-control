#include "compat.h"
#include "csu.h"
#include "CACheFileLib.h"
#include "MOPACDriver.h"

long getKeywords(char *MOPACOutputFile, char *keywords, double coord_shift[], 
				Boolean *typeRXNCOORD, int *mol_charge, short outputCalcNumber)
{
	FILE	*input = NULL;
	int		j;
	char 	aString[255];
	char    *ptr;

	*typeRXNCOORD = FALSE;
	*mol_charge = 0;
		
	if (!(input = fopen("keywords","r"))) {
		sprintf(aString,"getKeywords: Cannot get keywords from MOPAC.\nOutput calculation number %d.\n",
				outputCalcNumber);
		alert_user(aString);
		return -1;
	}

	/* read keywords */
	if (cfl_fgets(keywords, 248, input) == 0) {
		sprintf(aString,"getKeywords: Cannot get keywords from MOPAC.\nOutput calculation number %d.\n",
				outputCalcNumber);
		alert_user(aString);
		fclose(input);
		return -1;
	}
	fclose(input);

	/* strip trailing blanks from keywords string */
	if(strlen(keywords) > 0) {
		ptr = keywords + strlen(keywords) - 1;
		while (*ptr == ' ')
			*ptr-- = 0;
	}

	/* get CAChe coordinate shift */
	for (j=0; j<3; j++)
		coord_shift[j] = 0.0;
	if (!(input = fopen(MOPACOutputFile,"r"))) {
		sprintf(aString,"getKeywords: The file '%s' cannot be opened.\nOutput calculation number %d.\n",
				MOPACOutputFile, outputCalcNumber);
		alert_user(aString);
		return -1;
	} else {
		while (TRUE) {
			if (cfl_fgets(aString, sizeof(aString), input) == 0) 
				break;
			/* look for CHARGE by the way */
			if (strncmp(aString, " *                 CHARGE ON SYSTEM =", 37) == 0)
				sscanf(&aString[37], "%d", mol_charge);
			/* is it reaction coordinate calculation */
			if (strncmp(aString,"           POINTS ON REACTION COORDINATE", 40) == 0)
				*typeRXNCOORD = TRUE;
			/* look for coordinate shift */
			if ((strncmp(aString," CAChe_MOPAC_coordinate_shift:",30) == 0)
				&& (strlen(aString) > 30)) {
				sscanf(&aString[30],"%lf  %lf  %lf",
					&coord_shift[0],&coord_shift[1],&coord_shift[2]);
				break;
			}
		}
	}

	/* all done */			
	fclose(input);
	return 0;
}
