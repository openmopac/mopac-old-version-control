#include "compat.h"
#include <stdio.h>
#include <string.h>
#include <CACheFileLib.h>
#include "MOPACDriver.h"

/* The following defines are to preserve backwards compatibility with
 * CAChe MOPAC 2.n versions.  They should NOT be changed to agree with
 * CAChe MOPAC 3.0 and later dialogs
 */
#define detailsLowCheckBoxIN		5
#define detailsHiCheckBoxIN			33
#define detailsLowRadioControlIN	34	
#define detailsHiRadioControlIN		35
#define controlLowCheckBoxIN		19	
#define controlHiCheckBoxIN			20
#define DRCdetailsLowCheckBoxIN		14
#define DRCdetailsHiCheckBoxIN		17
#define searchLowRadioControlIN		5	
#define searchHiRadioControlIN		6

#define detailsMMOKCB				5
#define detailsEnergyPartCB			6
#define detailsESRCB				7
#define detailsLocalizeCB			8
#define detailsMullikenCB			9	
#define detailsPICB					10
#define detailsPolarCB				11
#define detailsThermoCB				12	
#define detailsBondOrderCB			13	
#define detailsDensityCB			14
#define detailsFockCB				15
#define detailsGradientsCB			16
#define detailsInterADistCB			17
#define detailsXYZCoordCB			18	
#define detailsSpinCB				19
#define detailsVectorsCB			20
#define detailsPreciseCB			21
#define accessoryDensityCB			22
#define accessoryIsotopeCB			23
#define accessoryGraphicsCB			24	
#define detailsLargeCB				26
#define detailsAnalytGradCB			27
#define detailsExternParamCB		29
#define detailsUseXYZCB				30	
#define detailsDIISCB				32
#define detailsKeepOrientCB			33	
#define	detailsCartesianRC			34	
#define detailsZMatrixRC			35	
#define DRCdampKineticCB			14	
#define controlRestartCB			19	
#define controlOldgeoCB				20	
#define searchRxnCoordRC			5	
#define searchGridRC				6	
#define hPrioCB						15
#define tPrioCB						16
#define xPrioCB						17
/* end of CAChe MOPAC 2.n compatibility defines */

/*************************************************************************************
 *
 *  GetMOPACParams			programmer George D. Purvis III 8/20/89
 *
 *  This function reads in the input control parameters from the controlfile. This
 *  information is put into the Control data structure
 *
 *	parameters		:		Control		;pointer to MOPACControl data structure.
 *							controlfile ;file to read control parameters from.
 *
 *	calls			:		fscanf.
 *
 *	returns			:		Boolean  TRUE if no errors, else FALSE.
 *
 *	caveat			:		controlfile must already be open and positioned
 *							for reading at the start of a startMOPAC line
 *							when this routine is called.
 *							The controlfile is not opened or closed by 
 *							this routine.
 *
 ***********************************************************************************/
 
Boolean GetMOPACParams (FILE *controlfile, MOPACControl *Control)
{
 static  char    buff1[80];
 char	dummy[256];
 int	itemp, i;
 float	ftemp;
 double dtemp;
 /*
  * For compatibility with CAChe 2.n versions of MOPAC, read
  * values of checkboxes and radio controls if present 
  */
  short controlDialogCheckBoxes[controlHiCheckBoxIN+2];
  short searchRadioControl[searchHiRadioControlIN+2];
  short DRCdetailsDialogCheckBoxes[DRCdetailsHiCheckBoxIN+2];
  short detailsDialogCheckBoxes[detailsHiCheckBoxIN+2];
  short detailsRadioControl[detailsHiRadioControlIN+2];
  
/* Set all parameters to default values initially. */
 
 GetDefaultParams(Control);

 /* Read settings from the file */

	if (fscanf(controlfile,"%s",buff1) == EOF
	 || strcmp("startMOPAC", buff1) != 0)
		return (FALSE); /* start of parameter block was not found */

/* Continue processing strings until error or end of block. */

	while (fscanf(controlfile, "%s", buff1) != EOF) {

	   /* if end of parameter block is found, return TRUE */
	   if (strcmp("endMOPAC", buff1) == 0
	    || strcmp("endSettings", buff1) == 0)
			return (TRUE);

	   /* else, process string inside parameter block */
	   if (strcmp("calculate", buff1) == 0) {
		 if (fscanf (controlfile, "%s", buff1) != EOF) {
			if (sscanf(buff1, "%ld", &itemp) == 1) 
				Control->calculate = itemp;
		 }
	   } else if (strcmp ("multiplicity", buff1) == 0) {
		 if (fscanf (controlfile, "%s", buff1) != EOF) {
			if (sscanf(buff1, "%ld", &itemp) == 1) 
				Control->multiplicity = itemp;
		 }
	   } else if (strcmp ("parameters", buff1) == 0) {
		 if (fscanf (controlfile, "%s", buff1) != EOF) {
			if (sscanf(buff1, "%ld", &itemp) == 1) 
				Control->parameters = itemp;
		 }
	   } else if (strcmp ("geometrySearch", buff1) == 0) {
		 if (fscanf (controlfile, "%s", buff1) != EOF) {
			if (sscanf(buff1, "%ld", &itemp) == 1) 
				Control->geometrySearch = itemp;
		 }
	   } else if (strcmp ("minimizeGradient", buff1) == 0) {
		 if (fscanf (controlfile, "%s", buff1) != EOF) {
			if (sscanf(buff1, "%ld", &itemp) == 1) 
				Control->minimizeGradient = itemp;
		 }
	   } else if (strcmp ("spinHamiltonian", buff1) == 0) { /* CAChe 2 backwards compat. */
		 if (fscanf (controlfile, "%s", buff1) != EOF) {
			if (sscanf(buff1, "%ld", &itemp) == 1) 
				Control->multiplicity = itemp;
		 }
	   } else if (strcmp ("spinMult", buff1) == 0) { 
		 if (fscanf (controlfile, "%s", buff1) != EOF) {
			if (sscanf(buff1, "%ld", &itemp) == 1) 
				Control->multiplicity = itemp;
		 }
	   } else if (strcmp ("rotationalSymmetry", buff1) == 0) {
		 if (fscanf (controlfile, "%s", buff1) != EOF) {
			if (sscanf(buff1, "%ld", &itemp) == 1) 
				Control->rotationalSymmetry = itemp;
		 }
	   } else if (strcmp ("maxSCFiterations", buff1) == 0) {
		 if (fscanf (controlfile, "%s", buff1) != EOF) {
			if (sscanf(buff1, "%ld", &itemp) == 1) 
				Control->maxSCFiterations = itemp;
		 }
	   } else if (strcmp ("scfConverger", buff1) == 0) {
		 if (fscanf (controlfile, "%s", buff1) != EOF) {
			if (sscanf(buff1, "%ld", &itemp) == 1) 
				Control->scfConverger = itemp;
		 }
	   } else if (strcmp ("CIlevel", buff1) == 0) {
		 if (fscanf (controlfile, "%s", buff1) != EOF) {
			if (sscanf(buff1, "%ld", &itemp) == 1) 
				Control->CIlevel = itemp;
		 }
/* plonkaw */
	   } else if (strcmp ("CItype", buff1) == 0) {
		 if (fscanf (controlfile, "%s", buff1) != EOF) {
			if (sscanf(buff1, "%ld", &itemp) == 1) 
				Control->CItype = itemp;
		 }
	   } else if (strcmp ("CIroot", buff1) == 0) {
		 if (fscanf (controlfile, "%s", buff1) != EOF) {
			if (sscanf(buff1, "%ld", &itemp) == 1) 
				Control->CIroot = itemp;
		 }
	   } else if (strcmp ("timeLimit", buff1) == 0) {
		 if (fscanf (controlfile, "%s", buff1) != EOF) {
			if (sscanf(buff1, "%ld", &itemp) == 1) 
				Control->timeLimit = itemp;
		 }
	   } else if (strcmp ("timeLimitUnits", buff1) == 0) {
		 if (fscanf (controlfile, "%s", buff1) != EOF) {
			if (sscanf(buff1, "%ld", &itemp) == 1) 
				Control->timeLimitUnits = itemp;
		 }
	   } else if (strcmp ("extraKeyWords", buff1) == 0) {
		 cfl_fgets (dummy, 255, controlfile); /* pick up the new line character */
		 cfl_fgets (Control->extraKeyWords, 255, controlfile);
	   } else if (strcmp ("title", buff1) == 0) {
		 cfl_fgets (dummy, 255, controlfile); /* pick up the new line character */
		 cfl_fgets (Control->title, 255, controlfile);
	   } else if (strcmp ("controlDialogCheckBoxes", buff1) == 0) {
			for (i=0; i <= controlHiCheckBoxIN; i++) {
				if (fscanf (controlfile, "%s", buff1) != EOF) {
					if (sscanf(buff1, "%ld", &itemp) == 1) 
						controlDialogCheckBoxes[i] = itemp;
				}
			}
			if (controlDialogCheckBoxes[controlRestartCB])
				Control->controlRestart = true;
			else
				Control->controlRestart = false;
	   } else if (strcmp ("controlRestart", buff1) == 0) {
		 if (fscanf (controlfile, "%s", buff1) != EOF) {
			if (sscanf(buff1, "%ld", &itemp) == 1) 
				Control->controlRestart = itemp;
		 }
	   } else if (strcmp ("searchType", buff1) == 0) {
		 if (fscanf (controlfile, "%s", buff1) != EOF) {
			if (sscanf(buff1, "%ld", &itemp) == 1) 
				Control->searchType = itemp;
		 }
	   } else if (strcmp ("detailsDialogCheckBoxes", buff1) == 0) {
			for (i=0; i <= detailsHiCheckBoxIN; i++) {
				if (fscanf (controlfile, "%s", buff1) != EOF) {
					if (sscanf(buff1, "%ld", &itemp) == 1) 
						detailsDialogCheckBoxes[i] = itemp;
				}
			}

			if (detailsDialogCheckBoxes[detailsMMOKCB])
				Control->detailsMMOK = true;
			else
				Control->detailsMMOK = false;
			if (detailsDialogCheckBoxes[detailsEnergyPartCB])
				Control->detailsEnergyPart = true;
			else
				Control->detailsEnergyPart = false;
			if (detailsDialogCheckBoxes[detailsESRCB])
				Control->detailsESR = true;
			else
				Control->detailsESR = false;
			if (detailsDialogCheckBoxes[detailsLocalizeCB])
				Control->detailsLocalize = true;
			else
				Control->detailsLocalize = false;
			if (detailsDialogCheckBoxes[detailsMullikenCB])
				Control->detailsMulliken = true;
			else
				Control->detailsMulliken = false;
			if (detailsDialogCheckBoxes[detailsPICB])
				Control->detailsPI = true;
			else
				Control->detailsPI = false;
			if (detailsDialogCheckBoxes[detailsPolarCB])
				Control->detailsPolar = true;
			else
				Control->detailsPolar = false;
			if (detailsDialogCheckBoxes[detailsThermoCB])
				Control->detailsThermo = true;
			else
				Control->detailsThermo = false;
			if (detailsDialogCheckBoxes[detailsBondOrderCB])
				Control->detailsBondOrder = true;
			else
				Control->detailsBondOrder = false;
			if (detailsDialogCheckBoxes[detailsDensityCB])
				Control->detailsDensity = true;
			else
				Control->detailsDensity = false;
			if (detailsDialogCheckBoxes[detailsFockCB])
				Control->detailsFock = true;
			else
				Control->detailsFock = false;
			if (detailsDialogCheckBoxes[detailsGradientsCB])
				Control->detailsGradients = true;
			else
				Control->detailsGradients = false;
			if (detailsDialogCheckBoxes[detailsInterADistCB])
				Control->detailsInterADist = true;
			else
				Control->detailsInterADist = false;
			if (detailsDialogCheckBoxes[detailsXYZCoordCB])
				Control->detailsXYZCoord = true;
			else
				Control->detailsXYZCoord = false;
			if (detailsDialogCheckBoxes[detailsSpinCB])
				Control->detailsSpin = true;
			else
				Control->detailsSpin = false;
			if (detailsDialogCheckBoxes[detailsVectorsCB])
				Control->detailsVectors = true;
			else
				Control->detailsVectors = false;
			if (detailsDialogCheckBoxes[detailsPreciseCB])
				Control->detailsPrecise = true;
			else
				Control->detailsPrecise = false;
			if (detailsDialogCheckBoxes[accessoryDensityCB])
				Control->accessoryDensity = true;
			else
				Control->accessoryDensity = false;
			if (detailsDialogCheckBoxes[accessoryIsotopeCB])
				Control->accessoryIsotope = true;
			else
				Control->accessoryIsotope = false;
			if (detailsDialogCheckBoxes[accessoryGraphicsCB])
				Control->accessoryGraphics = true;
			else
				Control->accessoryGraphics = false;
			if (detailsDialogCheckBoxes[detailsLargeCB])
				Control->detailsLarge = true;
			else
				Control->detailsLarge = false;
			if (detailsDialogCheckBoxes[detailsAnalytGradCB])
				Control->detailsAnalytGrad = true;
			else
				Control->detailsAnalytGrad = false;
			if (detailsDialogCheckBoxes[detailsExternParamCB])
				Control->detailsExternParam = true;
			else
				Control->detailsExternParam = false;
			if (detailsDialogCheckBoxes[detailsUseXYZCB])
				Control->detailsUseXYZ = true;
			else
				Control->detailsUseXYZ = false;
			if (detailsDialogCheckBoxes[detailsDIISCB])
				Control->detailsDIIS = true;
			else
				Control->detailsDIIS = false;
			if (detailsDialogCheckBoxes[detailsKeepOrientCB])
				Control->detailsKeepOrient = true;
			else
				Control->detailsKeepOrient = false;
	   } else if (strcmp ("detailsMMOK", buff1) == 0) {
		 if (fscanf (controlfile, "%s", buff1) != EOF) {
			if (sscanf(buff1, "%ld", &itemp) == 1) 
				Control->detailsMMOK = itemp;
		 }
	   } else if (strcmp ("detailsEnergyPart", buff1) == 0) {
		 if (fscanf (controlfile, "%s", buff1) != EOF) {
			if (sscanf(buff1, "%ld", &itemp) == 1) 
				Control->detailsEnergyPart = itemp;
		 }
	   } else if (strcmp ("detailsESR", buff1) == 0) {
		 if (fscanf (controlfile, "%s", buff1) != EOF) {
			if (sscanf(buff1, "%ld", &itemp) == 1) 
				Control->detailsESR = itemp;
		 }
	   } else if (strcmp ("detailsLocalize", buff1) == 0) {
		 if (fscanf (controlfile, "%s", buff1) != EOF) {
			if (sscanf(buff1, "%ld", &itemp) == 1) 
				Control->detailsLocalize = itemp;
		 }
	   } else if (strcmp ("detailsMulliken", buff1) == 0) {
		 if (fscanf (controlfile, "%s", buff1) != EOF) {
			if (sscanf(buff1, "%ld", &itemp) == 1) 
				Control->detailsMulliken = itemp;
		 }
	   } else if (strcmp ("detailsPI", buff1) == 0) {
		 if (fscanf (controlfile, "%s", buff1) != EOF) {
			if (sscanf(buff1, "%ld", &itemp) == 1) 
				Control->detailsPI = itemp;
		 }
	   } else if (strcmp ("detailsPolar", buff1) == 0) {
		 if (fscanf (controlfile, "%s", buff1) != EOF) {
			if (sscanf(buff1, "%ld", &itemp) == 1) 
				Control->detailsPolar = itemp;
		 }
	   } else if (strcmp ("detailsThermo", buff1) == 0) {
		 if (fscanf (controlfile, "%s", buff1) != EOF) {
			if (sscanf(buff1, "%ld", &itemp) == 1) 
				Control->detailsThermo = itemp;
		 }
	   } else if (strcmp ("detailsBondOrder", buff1) == 0) {
		 if (fscanf (controlfile, "%s", buff1) != EOF) {
			if (sscanf(buff1, "%ld", &itemp) == 1) 
				Control->detailsBondOrder = itemp;
		 }
	   } else if (strcmp ("detailsDensity", buff1) == 0) {
		 if (fscanf (controlfile, "%s", buff1) != EOF) {
			if (sscanf(buff1, "%ld", &itemp) == 1) 
				Control->detailsDensity = itemp;
		 }
	   } else if (strcmp ("detailsFock", buff1) == 0) {
		 if (fscanf (controlfile, "%s", buff1) != EOF) {
			if (sscanf(buff1, "%ld", &itemp) == 1) 
				Control->detailsFock = itemp;
		 }
	   } else if (strcmp ("detailsGradients", buff1) == 0) {
		 if (fscanf (controlfile, "%s", buff1) != EOF) {
			if (sscanf(buff1, "%ld", &itemp) == 1) 
				Control->detailsGradients = itemp;
		 }
	   } else if (strcmp ("detailsInterADist", buff1) == 0) {
		 if (fscanf (controlfile, "%s", buff1) != EOF) {
			if (sscanf(buff1, "%ld", &itemp) == 1) 
				Control->detailsInterADist = itemp;
		 }
	   } else if (strcmp ("detailsXYZCoord", buff1) == 0) {
		 if (fscanf (controlfile, "%s", buff1) != EOF) {
			if (sscanf(buff1, "%ld", &itemp) == 1) 
				Control->detailsXYZCoord = itemp;
		 }
	   } else if (strcmp ("detailsSpin", buff1) == 0) {
		 if (fscanf (controlfile, "%s", buff1) != EOF) {
			if (sscanf(buff1, "%ld", &itemp) == 1) 
				Control->detailsSpin = itemp;
		 }
	   } else if (strcmp ("detailsVectors", buff1) == 0) {
		 if (fscanf (controlfile, "%s", buff1) != EOF) {
			if (sscanf(buff1, "%ld", &itemp) == 1) 
				Control->detailsVectors = itemp;
		 }
	   } else if (strcmp ("detailsPrecise", buff1) == 0) {
		 if (fscanf (controlfile, "%s", buff1) != EOF) {
			if (sscanf(buff1, "%ld", &itemp) == 1) 
				Control->detailsPrecise = itemp;
		 }
	   } else if (strcmp ("detailsLarge", buff1) == 0) {
		 if (fscanf (controlfile, "%s", buff1) != EOF) {
			if (sscanf(buff1, "%ld", &itemp) == 1) 
				Control->detailsLarge = itemp;
		 }
	   } else if (strcmp ("detailsAnalytGrad", buff1) == 0) {
		 if (fscanf (controlfile, "%s", buff1) != EOF) {
			if (sscanf(buff1, "%ld", &itemp) == 1) 
				Control->detailsAnalytGrad = itemp;
		 }
	   } else if (strcmp ("detailsExternParam", buff1) == 0) {
		 if (fscanf (controlfile, "%s", buff1) != EOF) {
			if (sscanf(buff1, "%ld", &itemp) == 1) 
				Control->detailsExternParam = itemp;
		 }
	   } else if (strcmp ("detailsUseXYZ", buff1) == 0) {
		 if (fscanf (controlfile, "%s", buff1) != EOF) {
			if (sscanf(buff1, "%ld", &itemp) == 1) 
				Control->detailsUseXYZ = itemp;
		 }
	   } else if (strcmp ("detailsDIIS", buff1) == 0) {
		 if (fscanf (controlfile, "%s", buff1) != EOF) {
			if (sscanf(buff1, "%ld", &itemp) == 1) 
				Control->detailsDIIS = itemp;
		 }
	   } else if (strcmp ("detailsKeepOrient", buff1) == 0) {
		 if (fscanf (controlfile, "%s", buff1) != EOF) {
			if (sscanf(buff1, "%ld", &itemp) == 1) 
				Control->detailsKeepOrient = itemp;
		 }
/* plonkaw */
	   } else if (strcmp ("MOZYME", buff1) == 0) {
		 if (fscanf (controlfile, "%s", buff1) != EOF) {
			if (sscanf(buff1, "%ld", &itemp) == 1) 
				Control->MOZYME = itemp;
		 }
	   } else if (strcmp ("DRCdetailsCheckBoxes", buff1) == 0) {
			for (i=0; i <= DRCdetailsHiCheckBoxIN; i++) {
				if (fscanf (controlfile, "%s", buff1) != EOF) {
					if (sscanf(buff1, "%ld", &itemp) == 1) 
						DRCdetailsDialogCheckBoxes[i] = itemp;
				}
			}
			if (DRCdetailsDialogCheckBoxes[DRCdampKineticCB])
				Control->DRCdampKinetic = true;
			else
				Control->DRCdampKinetic = false;
			if (DRCdetailsDialogCheckBoxes[hPrioCB])
				Control->DRChPrio = true;
			else
				Control->DRChPrio = false;
			if (DRCdetailsDialogCheckBoxes[tPrioCB])
				Control->DRCtPrio = true;
			else
				Control->DRCtPrio = false;
			if (DRCdetailsDialogCheckBoxes[xPrioCB])
				Control->DRCxPrio = true;
			else
				Control->DRCxPrio = false;
	   } else if (strcmp ("DRCdampKinetic", buff1) == 0) {
		 if (fscanf (controlfile, "%s", buff1) != EOF) {
			if (sscanf(buff1, "%ld", &itemp) == 1) 
				Control->DRCdampKinetic = itemp;
		 }
	   } else if (strcmp ("DRChPrio", buff1) == 0) {
		 if (fscanf (controlfile, "%s", buff1) != EOF) {
			if (sscanf(buff1, "%ld", &itemp) == 1) 
				Control->DRChPrio = itemp;
		 }
	   } else if (strcmp ("DRCtPrio", buff1) == 0) {
		 if (fscanf (controlfile, "%s", buff1) != EOF) {
			if (sscanf(buff1, "%ld", &itemp) == 1) 
				Control->DRCtPrio = itemp;
		 }
	   } else if (strcmp ("DRCxPrio", buff1) == 0) {
		 if (fscanf (controlfile, "%s", buff1) != EOF) {
			if (sscanf(buff1, "%ld", &itemp) == 1) 
				Control->DRCxPrio = itemp;
		 }
	   } else if (strcmp ("saveHOMO", buff1) == 0) {
		 if (fscanf (controlfile, "%s", buff1) != EOF) {
			if (sscanf(buff1, "%ld", &itemp) == 1) 
				Control->saveHOMO = itemp;
		 }
	   } else if (strcmp ("saveLUMO", buff1) == 0) {
		 if (fscanf (controlfile, "%s", buff1) != EOF) {
			if (sscanf(buff1, "%ld", &itemp) == 1) 
				Control->saveLUMO = itemp;
		 }
	   } else if (strcmp ("detailsRadioControls", buff1) == 0) {
			for (i=0; i <= detailsHiRadioControlIN; i++) {
				if (fscanf (controlfile, "%s", buff1) != EOF) {
					if (sscanf(buff1, "%ld", &itemp) == 1) 
						detailsRadioControl[i] = itemp;
				}
			}
			/* Set one and only one to true */
			for (i = 0; i <= detailsHiRadioControlIN; i++)
				if (detailsRadioControl[i])
					break;
			if (i > detailsHiRadioControlIN)
				detailsRadioControl[detailsZMatrixRC] = true;
			while (++i <= detailsHiRadioControlIN)
				detailsRadioControl[i] = false;
			if (detailsRadioControl[detailsCartesianRC])
				Control->detailsGeoType = CARTESIAN_COORD;
			else
				Control->detailsGeoType = INTERNAL_COORD;

	   } else if (strcmp ("detailsGeoType", buff1) == 0) {
		 if (fscanf (controlfile, "%s", buff1) != EOF) {
			if (sscanf(buff1, "%ld", &itemp) == 1) 
				Control->detailsGeoType = itemp;
		 }
	   } else if (strcmp ("searchTypeRadioControls", buff1) == 0) {
			for (i=0; i <= searchHiRadioControlIN; i++) {
				if (fscanf (controlfile, "%s", buff1) != EOF) {
					if (sscanf(buff1, "%ld", &itemp) == 1) 
						searchRadioControl[i] = itemp;
				}
			}
			/* Set one and only one to true */
			for (i = 0; i <= searchHiRadioControlIN; i++)
				if (searchRadioControl[i])
					break;
			if (i > searchHiRadioControlIN)
				searchRadioControl[searchRxnCoordRC] = true;
			while (++i <= searchHiRadioControlIN)
				searchRadioControl[i] = false;
				
			if (searchRadioControl[searchGridRC])
				Control->searchType = SRCHTYPE_GRID;
			else
				Control->searchType = SRCHTYPE_RXN;

	   } else if (strcmp ("ircMode", buff1) == 0) {
		 if (fscanf (controlfile, "%s", buff1) != EOF) {
			if (sscanf(buff1, "%ld", &itemp) == 1) 
				Control->ircMode = itemp;
		 }
	   } else if (strcmp ("drcMode", buff1) == 0) {
		 if (fscanf (controlfile, "%s", buff1) != EOF) {
			if (sscanf(buff1, "%ld", &itemp) == 1) 
				Control->drcIrcMode = itemp;
		 }
	   } else if (strcmp ("addKEforIRC", buff1) == 0) {
		  if (fscanf (controlfile, "%s", buff1) != EOF) {
			if (sscanf(buff1, "%f", &ftemp) == 1) 
				Control->addKEforIRC = ftemp;
		 }
	   } else if (strcmp ("addKEforDRC", buff1) == 0) {
		  if (fscanf (controlfile, "%s", buff1) != EOF) {
			if (sscanf(buff1, "%f", &ftemp) == 1) 
				Control->addKEforDRC = ftemp;
		 }
	   } else if (strcmp ("halfLifeForDRC", buff1) == 0) {
		  if (fscanf (controlfile, "%s", buff1) != EOF) {
			if (sscanf(buff1, "%f", &ftemp) == 1) 
				Control->halfLifeForDRC = ftemp;
		 }
	   } else if (strcmp ("hPrioStep", buff1) == 0) {
		  if (fscanf (controlfile, "%s", buff1) != EOF) {
			if (sscanf(buff1, "%f", &ftemp) == 1) 
				Control->hPrioStep = ftemp;
		 }
	   } else if (strcmp ("tPrioStep", buff1) == 0) {
		  if (fscanf (controlfile, "%s", buff1) != EOF) {
			if (sscanf(buff1, "%f", &ftemp) == 1) 
				Control->tPrioStep = ftemp;
		 }
	   } else if (strcmp ("xPrioStep", buff1) == 0) {
		  if (fscanf (controlfile, "%s", buff1) != EOF) {
			if (sscanf(buff1, "%f", &ftemp) == 1) 
				Control->xPrioStep = ftemp;
		 }
	   } else if (strcmp ("controlUseCosmo", buff1) == 0) {
		 if (fscanf (controlfile, "%s", buff1) != EOF) {
			if (sscanf(buff1, "%ld", &itemp) == 1) 
				Control->controlUseCosmo = itemp;
		 }
	   } else if (strcmp ("cosmoDielectric", buff1) == 0) {
		  if (fscanf (controlfile, "%s", buff1) != EOF) {
			if (sscanf(buff1, "%lf", &dtemp) == 1) 
				Control->cosmoDielectric = dtemp;
		 }
	   } else if (strcmp ("cosmoRadius", buff1) == 0) {
		  if (fscanf (controlfile, "%s", buff1) != EOF) {
			if (sscanf(buff1, "%lf", &dtemp) == 1) 
				Control->cosmoRadius = dtemp;
		 }
	  } else if (strcmp ("temperature", buff1) == 0) {
		 cfl_fgets (dummy, 255, controlfile); /* pick up the new line character */
		 cfl_fgets (Control->temperature, 31, controlfile);
		 Control->temperature[31] = 0;
	  } else if (strcmp ("cosmoSolvent", buff1) == 0) {
		 cfl_fgets (dummy, 255, controlfile); /* pick up the new line character */
		 cfl_fgets (Control->cosmoSolvent, 31, controlfile);
		 Control->cosmoSolvent[31] = 0;
	  }
	} /* loop over strings in parameter block until end is found */

	return (FALSE); /* end of parameter block was not found */
}
