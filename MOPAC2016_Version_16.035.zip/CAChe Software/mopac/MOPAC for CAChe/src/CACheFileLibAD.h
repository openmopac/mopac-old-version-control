/*
** MODULE:
**	CACheFileLibAD.h
**
** DESCRIPTION:
**	Header file that contains defines, structures and proto types for
**	AppleDouble file routines that are intended for public use. 
**
** NOTES:
**	This code is intended to be portable to all hosts that have ANSI C and
**	16 bit shorts and 32 bit longs and unsigned data types. So ANSI C functions
**	should be used, not Mac functions.
**
123456789012345678901234567890123456789012345678901234567890123456789012345678*/

#ifndef __CFL_AD__
#define __CFL_AD__

#include <stdio.h>
#include <stdlib.h>

#ifndef _COMPAT_
#include <compat.h>
#endif

/* Special AppleDouble characters as defined by Apple. */
#define CFL_AD_HEADER_PREFIX		'%'
#define CFL_AD_ESCAPE_CHAR			'%'

/* Return status for AppleDouble file format code */
#define CFL_AD_NO_ERROR				0
#define CFL_AD_FILE_NOT_FOUND		1
#define CFL_AD_BAD_FILE				2
#define CFL_AD_CANNOT_CREATE_FILE	3
#define CFL_AD_NAME_TOO_LONG		4
#define CFL_AD_NO_SUCH_ENTRY		5
#define CFL_AD_ENTRY_EXISTS			6
#define CFL_AD_BAD_ENTRY			7
#define CFL_AD_FILE_ERROR			8
#define CFL_AD_MEMORY_ERROR			9

/* AppleDouble headers entry descriptors IDs. */
#define CFL_AD_DATA_FORK		1
#define CFL_AD_RESOURCE_FORK	2
#define CFL_AD_REAL_NAME		3
#define CFL_AD_COMMENT			4
#define CFL_AD_BW_ICON			5
#define CFL_AD_COLOR_ICON		6
#define CFL_AD_FILE_DATES		8
#define CFL_AD_FINDER_INFO		9
#define CFL_AD_MAC_FILE_INFO	10
#define CFL_AD_PRODOS_FILE_INFO	11

#define CFL_AD_SHORT_NAME		13
#define CFL_AD_AFP_FILE_INFO	14
#define CFL_AD_DIRECTORY_ID		15

#define CFL_AD_USER_ENTRY		0x8000000L

/* Bits used in MAC file info structure. */
#define CFL_AD_LOCK_BIT			0x01
#define CFL_AD_PROTECT_BIT		0x02

/* Verbosity levels for dumping AppleDouble header file. */
#define CFL_AD_DUMP_HEADER_DESC	1
#define CFL_AD_DUMP_SHORT		2
#define CFL_AD_DUMP_ALL			3

/* Size of internal and structure buffers for AppleDouble operations */
#define CFL_AD_BUFFER_SIZE			256

/* Size of buffer to allocate for AppleDouble file conversions */
#define CFL_AD_COPY_BUFFER_SIZE		32768

#ifdef __cplusplus	/* For type-safe linkage */
extern "C" {		/* Specify "C"-style linkage */
#endif

/* Definition of structures and types used for AppleDouble */

/*
** When target isn't the Mac these Mac typedefs need to be included in.
*/

#if defined(unix) || defined(_WINDOWS) || defined(_WIN32)

typedef unsigned long OSType;

struct FInfo {
 OSType fdType;						/*the type of the file*/
 OSType fdCreator;					/*file's creator*/
 unsigned short fdFlags;			/*flags ex. hasbundle,invisible,locked, etc.*/
 Point fdLocation;					/*file's location in folder*/
 short fdFldr;						/*folder containing file*/
};
typedef struct FInfo FInfo;

struct FXInfo {
 short fdIconID;					/*Icon ID*/
 short fdUnused[3];					/*unused but reserved 6 bytes*/
 char fdScript;						/*Script flag and number*/
 char fdXFlags;						/*More flag bits*/
 short fdComment;					/*Comment ID*/
 long fdPutAway;					/*Home Dir ID*/
};
typedef struct FXInfo FXInfo;

#endif /* unix || _WINDOWS || _WIN32 */

typedef unsigned char cfl_ADBoolean;

struct cfl_ADHdrDesc {
	unsigned long			magic_number;
	unsigned long			version_number;
	unsigned long			filler[4];
	unsigned short			num_entries;
};
typedef struct cfl_ADHdrDesc cfl_ADHdrDesc;

struct cfl_ADHdrEntryDesc {
	unsigned long			id;
	unsigned long			offset;
	unsigned long			length;
};
typedef struct cfl_ADHdrEntryDesc cfl_ADHdrEntryDesc;

struct cfl_AD_ResourceFork {
	size_t					length;
	unsigned char			*data;
};
typedef struct cfl_AD_ResourceFork cfl_AD_ResourceFork;

struct cfl_AD_RealName {
	size_t					length;
	char					name[CFL_AD_BUFFER_SIZE];
};
typedef struct cfl_AD_RealName cfl_AD_RealName;

struct cfl_AD_Comment {
	size_t					length;
	char					comment[CFL_AD_BUFFER_SIZE];
};
typedef struct cfl_AD_Comment cfl_AD_Comment;

struct cfl_AD_FileDatesInfo {
	long	 				creation_date;
	long					modification_date;
	long					backup_date;
	long					access_date;
};
typedef struct cfl_AD_FileDatesInfo cfl_AD_FileDatesInfo;

struct cfl_AD_FinderInfo {
	FInfo			finfo;
	FXInfo			fxinfo;
};
typedef struct cfl_AD_FinderInfo cfl_AD_FinderInfo;

struct cfl_AD_FileInfo {
	unsigned				attributes;
};
typedef struct cfl_AD_FileInfo cfl_AD_FileInfo;

struct cfl_AD_UserDefined {
	size_t					length;
	unsigned char			*data;
};
typedef struct cfl_AD_UserDefined cfl_AD_UserDefined;

struct cfl_ADHdrEntry {
	unsigned				id;
	union {
		char					marker;			/* Used to get unions address */
		cfl_AD_ResourceFork		resource_fork;
		cfl_AD_RealName			real_name;
		cfl_AD_Comment			comment;
		cfl_AD_FileDatesInfo	file_dates_info;
		cfl_AD_FinderInfo		finder_info;
		cfl_AD_FileInfo			file_info;
		cfl_AD_UserDefined		user_defined;
	} u;
};
typedef struct cfl_ADHdrEntry cfl_ADHdrEntry;

/* Prototypes for AppleDouble functions. */
extern int cfl_MacToAD(
	const char		*Mac_file_name,
	const char		*header_file_name,
	const char		*data_file_name);

extern int cfl_ADToMac(
	const char		*header_file_name,
	const char		*data_file_name,
	const char		*target_file_name);

extern int cfl_ADToWindows(
	const char		*header_file_name,
	const char		*data_file_name,
	const char		*target_file_name);

extern int cfl_MacNameToADNames(
	const char		*Mac_file_name,
	const char		header_prefix_char,
	const char		escape_char,
	const char		*escape_char_str,
	const size_t	length,
	char			*header_file_name,
	char			*data_file_name);

extern int cfl_ADNameToMacName(
	const char		*AD_file_name,
	const char		header_prefix_char,
	const char		escape_char,
	const size_t	length,
	char			*Mac_file_name);

extern cfl_ADBoolean cfl_IsValidMacName(
	const char		*Mac_file_name,
	const char		*invalid_char_str);

extern char *cfl_Get_Root_File_Name(
	char			*data_name);

extern int cfl_GetADHdrDesc(
	const char			*header_file_name,
	cfl_ADHdrDesc		**header_pointer,
	cfl_ADHdrEntryDesc	*descriptor_table[]);

extern void cfl_DisposeADHdrDesc(
	cfl_ADHdrDesc		*header_ptr,
	cfl_ADHdrEntryDesc	*descriptor_table);

extern int cfl_AddADHdrEntry(
	const char				*header_file_name,
	const cfl_ADHdrEntry	*new_entry_ptr);

extern int cfl_DeleteADHdrEntry(
	const char		*header_file_name,
	const unsigned	id);

extern int cfl_DumpAD(
	const char		*header_file_name,
	const char		*output_file_name,
	int				verbosity);

extern FILE *cfl_MacFOpen(
	const char		*filename,
	const char		*mode,
	OSType			creator,
	OSType			type);

extern int cfl_MacFClose(
	FILE			*fp);

extern int cfl_MacRemove(
	const char		*file_name);

extern int cfl_MacRename(
	const char		*old_name,
	const char		*new_name);

extern int cfl_MacFSetFileInfo(
	const char		*filename,
	OSType			newCreator,
	OSType			newType);

#ifdef __cplusplus	/* For type-safe linkage */
}
#endif

#endif /* !defined(__CFL_AD__) */
