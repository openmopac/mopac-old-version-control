#include "compat.h"
#include "csu.h"
#include "MOPACDriver.h"

long reorderForLockedLabels(double coords[][3],long NAtom, long atomLocation[],
	 			 LockedLabel lockedLabels[], long numLockedLabels,
				 long numDummyAtoms)
/*
	LockedLabels defined in the Molecule Editor are used to mark certain internal
	coordinates in a molecule during an optimization so that they are not varied.
	So that MOPAC can implement search labels, the locked internal coordinates 
	must be defined in the z-matrix.  Defining a z-matrix with specific internal
	coordinates may require renumbering the atoms in the molecule.  This 
	function does that renumbering.
*/
{
	long i, j, k, l, m, n;

	for (m = 0; m < numLockedLabels > 0; m++) { 
		/* 
		  The critical point is that the first atom in the label must come after
		  the other atoms in the label.  The order of the other atoms is not
		  important.
		*/
		n = findAtom(lockedLabels[m].atomList[1], atomLocation, NAtom);
		for (j=lockedLabels[m].atomList[0]; j > 1; j--) {
			k = findAtom(lockedLabels[m].atomList[j],
						 atomLocation, NAtom);
			/* atom is beyond the first one in the label */
			if (k > n) {
				Boolean first_atom;
				/* Check to see if the atom to be slid to the front is the first
					atom in a previous label */
				first_atom = false;
				for (i=0; i<m; i++) {
					if (k == findAtom(lockedLabels[i].atomList[1], 
						atomLocation, NAtom))
							first_atom = true;
				}
				
				if (!first_atom) { /* move atom in label to in front of first atom */
					slideAtoms(k, n, coords, atomLocation, numDummyAtoms);
				} else { /* move moving atom to come after other atom in label */
					Boolean part_of_label;
					part_of_label = false;
					
					/* See if the atom to be moved (n) is part (not the first atom)
					   of a previous label.  If it is, then it should not be moved */

					for (i=0; i<m; i++) {
						for (l=lockedLabels[i].atomList[0]; l > 1; l--) {
							if (n == findAtom(lockedLabels[i].atomList[l], 
								atomLocation, NAtom))
									part_of_label = true;
						}
					}
					if (!part_of_label) {
						slideAtomForward(k, n, coords, atomLocation, numDummyAtoms);
						/* location of first atom has changed */
						n = findAtom(lockedLabels[m].atomList[1], atomLocation, NAtom);
					} else {
						alert_user("Unable to organize locked labels in the"
									" input file.  Delete one or more of the locked"
									" labels in order to run this calculation.");
						return (-1);
					}
				}
			}
		}
	 }
	 return (0);
	 
}

void slideAtomForward(long k, long next, double coords[][3],
         		long atomLocation[], long numDummyAtoms)
{
   long l, i, j;
   double x, y, z;
  

	if (k > next) { /* don't do this if k == next or k < next */   
		x = coords[next][0];
		y = coords[next][1];
		z = coords[next][2];
		j = atomLocation[next];
	
		if ((next == 0) && (numDummyAtoms > 0)) {
		/* slide the atom following the dummy atoms to the "0" position, but 
		   leave dummy atoms immediatly after the "0" position */
			for (l=0; l < 3; l++) coords[0][l] = coords[numDummyAtoms+1][l];
			atomLocation[0] = atomLocation[numDummyAtoms+1];
		   
			for (i = numDummyAtoms+1; i < k ; i++) {
				for (l=0; l < 3; l++) coords[i][l] = coords[i+1][l];
				atomLocation[i] = atomLocation[i+1];
			}
			
		} else {
			for (i = next; i < k; i++) {
				for (l=0; l < 3; l++) coords[i][l] = coords[i+1][l];
				atomLocation[i] = atomLocation[i+1];
			}
		}
	
		coords[k][0] = x;
		coords[k][1] = y;
		coords[k][2] = z;
		atomLocation[k] = j;
		
		/* if a new atom was placed in the "0" position, reset the Y coordinate
		   on the first dummy atom, and the Z coordinate on all the dummy atoms */
		   
		if ((next == 0) && (numDummyAtoms > 0)) {
			coords[1][1] = coords[next][1];
			for (i=0; i < numDummyAtoms; i++)
				coords[i+1][2] = coords[next][2];
		}
	}
}
