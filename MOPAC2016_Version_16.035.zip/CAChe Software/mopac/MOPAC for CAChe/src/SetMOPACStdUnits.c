#include "compat.h"
#include "MOPACDriver.h"

CelErr SetMOPACStdUnits()
{
	char errs[256];
	CelErr rtn_code;

	/* change standard units to what MOPAC needs */
	if ((rtn_code = csu_SetStdUnits(Angstrom_U)) < 0) {
		sprintf (errs,"Error: csu_SetStdUnits Angstrom_U, errno %d",
		         rtn_code);
		alert_user(errs);
		return rtn_code;
	}

	if ((rtn_code = csu_SetStdUnits(Degree_U)) < 0) {
		sprintf (errs,"Error: csu_SetStdUnits Degree_U, errno %d",
		         rtn_code);
		alert_user(errs);
		return rtn_code;
	}

	if ((rtn_code = csu_SetStdUnits(Charge_AU)) < 0) {
		sprintf (errs,"Error: csu_SetStdUnits Charge_AU, errno %d",
		         rtn_code);
		alert_user(errs);
		return rtn_code;
	}

	if ((rtn_code = csu_SetStdUnits(Energy_Kcal_mole)) < 0) {
		sprintf (errs,"Error: csu_SetStdUnits Energy_Kcal_mole, errno %d",
				 rtn_code);
		alert_user(errs);
		return rtn_code;
	}

	if ((rtn_code = csu_SetStdUnits(AngstromCubic_U)) < 0) {
		sprintf (errs,"Error: csu_SetStdUnits AngstromCubic_U, errno %d",
				 rtn_code);
		alert_user(errs);
		return rtn_code;
	}

	if ((rtn_code = csu_SetStdUnits(Kcal_mol_angstrom_U)) < 0) {
		sprintf (errs,"Error: csu_SetStdUnits Kcal_mol_angstrom_U, errno %d",
				 rtn_code);
		alert_user(errs);
		return rtn_code;
	}

	return 0;
}
