/*
**	CACheFileLib.h
*/

#ifndef __CFL__
#define __CFL__

#if defined _CACHE_DLL
	#if defined _CFL
		#define CFL_IMPORT_EXPORT	__declspec(dllexport)
	#else
		#define CFL_IMPORT_EXPORT	__declspec(dllimport)
	#endif
#else
	#define CFL_IMPORT_EXPORT
#endif

#ifndef RC_INVOKED     	   // Do only error #defines if compiling resources

#include <stdio.h>
#include <cel.h>
#include <ServerStepQueue.h>

#ifdef __cplusplus	   // For type-safe linkage 
extern "C" {		   // Specify "C"-style linkage
#endif

#if defined(_WIN32)
// ini file name should not change in foreign language versions
// Or if you do change it, then we need to put name in Win.ini
// and rewrite some of the routines below.
#define CACHE_INI_NAME  		"\\cache.ini"

#define CACHE_XLATOR_FILE_EXT	"\\*.dll"

// CAChe files can live in 3 different places
CFL_IMPORT_EXPORT CelErr cfl_GetCACheUserDirectory(char* buffer, int maxLength);
CFL_IMPORT_EXPORT CelErr cfl_GetCACheGroupDirectory(char* buffer, int maxLength);
CFL_IMPORT_EXPORT CelErr cfl_GetCACheSystemDirectory(char* buffer, int maxLength);

// Start the calculation manager
CFL_IMPORT_EXPORT CelErr cfl_StartCalcMgr();

// Get particular file paths
CFL_IMPORT_EXPORT char* cfl_MakeTemporaryName( const char* dir, const char* prefix );
CFL_IMPORT_EXPORT void  cfl_FreeTemporaryName( char *name );

// Logical directories and file paths within the CAChe system
typedef enum 
{
	ExperimentModuleDir,	// Directory containing experiment environment module DLLs
	FileTranslatorDir,	// Directory containing file translator DLLs
	ApplicExtensionDir,	// Directory containing Workspace application extensions
	EngineRootDir,		// Directory containing calculation manager and engines

	TCPConfigName,		// Full path to TCP/IP configuration file
	LogFileName,		// Full path to calculation manager log file
	CCMLogFileName,		// Something similar for CCM
	CheckPointName,		// Full path to check point file
	SpaceGroupsName,	// Full path to crystal space groups file
	DataDictionaryName	// Full path to data dictionary file
} CACheLogicalDir;

CFL_IMPORT_EXPORT CelErr cfl_GetCACheDirectory( CACheLogicalDir dirID, char* buffer, int maxLength);

// User relative
CFL_IMPORT_EXPORT CelErr cfl_GetCACheIniFileName( char *buffer, int maxLength );
CFL_IMPORT_EXPORT CelErr cfl_GetCACheTempDirectory(char* buffer, int maxLength);
CFL_IMPORT_EXPORT CelErr cfl_GetCACheTCPConfigPath(char* buffer, int maxLength);
CFL_IMPORT_EXPORT CelErr cfl_GetCACheChkPtPath(char* buffer, int maxLength);
CFL_IMPORT_EXPORT CelErr cfl_GetCACheLogfilePath(char* buffer, int maxLength);
CFL_IMPORT_EXPORT CelErr cfl_GetCACheCCMLogPath(char* buffer, int maxLength);

// System relative
CFL_IMPORT_EXPORT CelErr cfl_GetCACheExpModDirectory(char* buffer, int maxLength);
CFL_IMPORT_EXPORT CelErr cfl_GetCACheXlatorDirectory(char* buffer, int maxLength);
CFL_IMPORT_EXPORT CelErr cfl_GetCACheAppExtDirectory(char* buffer, int maxLength);
CFL_IMPORT_EXPORT CelErr cfl_GetCACheProcedureDirectory(char* buffer, int maxLength);
CFL_IMPORT_EXPORT CelErr cfl_GetCACheDataDictPath(char* buffer, int maxLength);
CFL_IMPORT_EXPORT CelErr cfl_GetCAChePropertyIndexPath(char* buffer, int maxLength);
CFL_IMPORT_EXPORT CelErr cfl_GetInstallationID(char* buffer, int maxLength);

CFL_IMPORT_EXPORT CelErr cfl_GetOwnerName(char* buffer, int maxLength);

CFL_IMPORT_EXPORT CelErr cfl_GetDefaultServer(char* serverName, int maxLength);
CFL_IMPORT_EXPORT CelErr cfl_SetDefaultServer(const char* serverName);

CFL_IMPORT_EXPORT CelErr cfl_GetFileTypeFromSwitch(const char* procSwitch, ssq_CACheFileType* fileType);
CFL_IMPORT_EXPORT CelErr cfl_GetApplSignature(const char* applName, unsigned long *applSig);
CFL_IMPORT_EXPORT CelErr cfl_GetGedraStereoDriverDLLName(char *driverDllName, int maxLength);

CFL_IMPORT_EXPORT CelErr cfl_GetCACheSpaceGroupsPath(char *buffer, int maxLength);

// Utility to check locale settings
CFL_IMPORT_EXPORT CelErr cfl_CheckRegionalSettings(char* buffer, int maxLength);

// Utility to read registry value
CFL_IMPORT_EXPORT CelErr cfl_GetRegistryValue(char* buffer, int maxLength);

CFL_IMPORT_EXPORT CelErr cfl_GetStringFromIniFile (
const char * section,
const char * entry,
char* defaultEntry,
char* tempStr,
int maxLength
);

// Utilities used by server software only
CFL_IMPORT_EXPORT CelErr cfl_GetCACheBinDirectory(char* buffer, int maxLength);
CFL_IMPORT_EXPORT CelErr cfl_GetCACheConDirectory(char* buffer, int maxLength);
CFL_IMPORT_EXPORT CelErr cfl_GetCACheCalcMgrConPath(char* buffer, int maxLength);
CFL_IMPORT_EXPORT CelErr cfl_GetCACheCalcMgrLogPath(char* buffer, int maxLength);
CFL_IMPORT_EXPORT CelErr cfl_GetCACheCalcMgrChkptPath(char* buffer, int maxLength);

// Routines to return directory names of various types of files
CFL_IMPORT_EXPORT CelErr cfl_GetMapDirectory(
	const char*	baseName,		// IN: Name of primary file (molecule) which is used for directory name
	char*		buffer,			// OUT: Directory name for map files associated with basename
	size_t		maxLength		// IN: Size of buffer (including space for terminating '\0')
);

CFL_IMPORT_EXPORT CelErr cfl_GetGridDirectory(
	const char*	baseName,		// IN: Name of primary file (molecule) which is used for directory name
	char*		buffer,			// OUT: Directory name for grid files associated with basename
	size_t		maxLength		// IN: Size of buffer (including space for terminating '\0')
);

CFL_IMPORT_EXPORT CelErr cfl_GetPlaneDirectory(
	const char*	baseName,		// IN: Name of primary file (molecule) which is used for directory name
	char*		buffer,			// OUT: Directory name for plane files associated with basename
	size_t		maxLength		// IN: Size of buffer (including space for terminating '\0')
);

CFL_IMPORT_EXPORT CelErr cfl_GetSurfaceDirectory(
	const char*	baseName,		// IN: Name of primary file (molecule) which is used for directory name
	char*		buffer,			// OUT: Directory name for surface files associated with basename
	size_t		maxLength		// IN: Size of buffer (including space for terminating '\0')
);

CFL_IMPORT_EXPORT CelErr cfl_GetAccessoryDirectory(
	const char*	baseName,		// IN: Name of primary file (molecule) which is used for directory name
	char*		buffer,			// OUT: Directory name for accessory files associated with basename
	size_t		maxLength		// IN: Size of buffer (including space for terminating '\0')
);

// Routines to return alpha filename associated with input alpha extension (via CAChe.ini) 
CFL_IMPORT_EXPORT CelErr cfl_GetMapFileName(
	const char*	sourceName,		// IN: Alpha name of extension to use in look up of cache.ini
	char*		fileName,		// OUT: Alpha name of file associated with extension
	size_t		maxLength		// IN: Size of filename (including space for terminating '\0')
);

CFL_IMPORT_EXPORT CelErr cfl_GetGridFileName(
	const char*	sourceName,		// IN: Alpha name of extension to use in look up of cache.ini
	char*		fileName,		// OUT: Alpha name of file associated with extension
	size_t		maxLength		// IN: Size of filename (including space for terminating '\0')
);

CFL_IMPORT_EXPORT CelErr cfl_GetPlaneFileName(
	const char*	sourceName,		// IN: Alpha name of extension to use in look up of cache.ini
	char*		fileName,		// OUT: Alpha name of file associated with extension
	size_t		maxLength		// IN: Size of filename (including space for terminating '\0')
);

CFL_IMPORT_EXPORT CelErr cfl_GetSurfaceFileName(
	const char*	sourceName,		// IN: Alpha name of extension to use in look up of cache.ini
	char*		fileName,		// OUT: Alpha name of file associated with extension
	size_t		maxLength		// IN: Size of filename (including space for terminating '\0')
);

CFL_IMPORT_EXPORT CelErr cfl_GetAccessoryFileName(
	const char*	sourceName,		// IN: Alpha name of extension to use in look up of cache.ini
	char*		fileName,		// OUT: Alpha name of file associated with extension
	size_t		maxLength		// IN: Size of filename (including space for terminating '\0')
);

//routine to create a directory
CFL_IMPORT_EXPORT CelErr cfl_CreateWindowsDirectory(
	char*	dirName
);

//routine to convert filenames to Windows filename
CFL_IMPORT_EXPORT CelErr cfl_CacheNameToWindows(
	const char*	sourceName,		// IN: Name of original file
	const char*	baseName,		// IN: Name of primary file (molecule) which is used for directory name
	long		fileType,		// IN: Type of file (ssq_folder_accessory, ssq_folder_assemblage, or
						//     ssq_folder_surface) which are defined in SSQFileTypes.h
	char*		destName,		// OUT: Relative path for converted file name (without leading \)
	size_t		maxLength		// IN: Buffer size of destName (including space for terminating '\0'
);

#endif

/* prototypes for all systems */

CFL_IMPORT_EXPORT int cfl_Rename(const char* oldName, const char* newName);
CFL_IMPORT_EXPORT int cfl_MakeDuplicateName( const char* originalName, char * duplicateName, unsigned short maxLength);

CFL_IMPORT_EXPORT char *cfl_fgets(char *s, int n, FILE *iop);

CFL_IMPORT_EXPORT int cfl_fcsscanf(unsigned char *inputString, char *fmtString,
	unsigned long flags, ...);

#ifdef __cplusplus	/* For type-safe linkage */
}
#endif

/* cfl_fcsscanf() flag bits */

#define CFL_FCSSF_ASSIGNMENTSUPPRESSION	1	/* used internally */
#define CFL_FCSSF_BLANKEQZERO		2	/* treat blank integer fields as zero */

#if defined(_WIN32)
#define CFL_PATH_MAX	256
#elif defined(unix)
#include <sys/param.h>
#define CFL_PATH_MAX	MAXPATHLEN
#else
#error "Maximum path length is not defined for this machine"
#endif

#if defined(unix)

#ifdef __cplusplus	/* For type-safe linkage */
extern "C" {		/* Specify "C"-style linkage */
#endif

CFL_IMPORT_EXPORT int cfl_GetCACheSystemLocC(char *const pathBuf);

#ifdef __cplusplus	/* For type-safe linkage */
}
#endif /* __cplusplus */

#endif /* defined(unix) */

/* Universal prototypes */

#ifdef __cplusplus	/* For type-safe linkage */
extern "C" {		/* Specify "C"-style linkage */
#endif

CFL_IMPORT_EXPORT int cfl_GetCACheTempPath(char *const cTempPath);

#ifdef __cplusplus	/* For type-safe linkage */
}
#endif /* __cplusplus */

#endif	// RC_INVOKED     	// Do only error #defines if compiling resources

/* non-OS return codes from cfl_GetLock() call */

#define CFL_GL_CANNOT_LOCK		-1401	/* unable to get exclusive access to resource */

/* cfl_fcsscanf() error codes */

#define CFL_FCSSF_EOFMT			-1402	/* unexpected EOF on format string */
#define CFL_FCSSF_BADFMT		-1403	/* bad format string */

#define	CFL_FSPFFSS_NO_ROOM1		-1404	/* path too long */
#define	CFL_FSPFFSS_NO_ROOM2		-1405	/* path too long */
#define	CFL_FSPFFSS_NO_ROOM3		-1406	/* path too long */
#define	CFL_FSPFFSS_GFP_FAILED		-1407	/* cfl_GetFullPath() failed */
#define	CFL_IBCPB_NO_BOARDS		-1408	/* No suitable CP boards avail. */
#define	CFL_IBCPB_NO_SELECTION		-1409	/* Error selecting CP board */

#define CFL_NO_FULL_PATH		-1410   /* couldn't make a full path name */
#define CFL_BUFFER_TOO_SMALL		-1411	/* buffer too small */
#define CFL_DUPLICATE_NAME_ERR		-1412	/* couldn't make a duplicate name */
#define CFL_CANT_RENAME			-1413	/* couldn't rename a file */
#define CFL_CANT_CREATE_TEMPDIR		-1414	/* couldn't create temporary directory */
#define CFL_MEM_ERROR        		-1415 	/* couldn't allocate memory */
#define CFL_SOURCE_FILE_NOT_FOUND   	-1416   /* source file not found on rename */
#define CFL_UNKNOWN_FILE_ERROR      	-1417   /* unexpected file error */
#define CFL_DISK_FULL			-1418   /* disk is full */

#endif /* __CFL__ */
