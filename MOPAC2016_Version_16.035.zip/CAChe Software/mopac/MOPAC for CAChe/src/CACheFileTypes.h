/* CACheFileTypes.h -- CAChe file types and creator defines. */
#ifndef _CACHE_FILE_TYPES_H_
#define _CACHE_FILE_TYPES_H_

#include <CACheMacros.h>

/* types */
#define CFT_BINA    CM_C4TOLONG('B','I','N','A')
#define CFT_DENP    CM_C4TOLONG('D','E','N','P')
#define CFT_DENS    CM_C4TOLONG('D','E','N','S')
#define CFT_ELSP    CM_C4TOLONG('E','L','S','P')
#define CFT_EMAP    CM_C4TOLONG('E','M','A','P')
#define CFT_MOLS    CM_C4TOLONG('M','O','L','S')
#define CFT_ORBL    CM_C4TOLONG('O','R','B','L')
#define CFT_ORBP    CM_C4TOLONG('O','R','B','P')
#define CFT_POTL    CM_C4TOLONG('P','O','T','L')
#define CFT_SEQN    CM_C4TOLONG('S','E','Q','N')
#define CFT_TEXT    CM_C4TOLONG('T','E','X','T')
#define CFT_TRAJ    CM_C4TOLONG('T','R','A','J')
#define CFT_STGS    CM_C4TOLONG('S','T','G','S')

/* creators */
#define CFT_DYNAMICS         CM_C4TOLONG('C','D','Y','N')
#define CFT_EDITOR           CM_C4TOLONG('C','A','C','H')
#define CFT_HUCK             CM_C4TOLONG('H','U','C','K')
#define CFT_MECHANICS        CM_C4TOLONG('M','E','C','H')
#define CFT_MOPAC            CM_C4TOLONG('M','O','P','C')
#define CFT_PROJECTLEADER    CM_C4TOLONG('P','R','L','D')
#define CFT_TTXT             CM_C4TOLONG('t','t','x','t')
#define CFT_VISUALIZER       CM_C4TOLONG('V','I','Z','U')
#define CFT_ZINDO            CM_C4TOLONG('Z','I','N','D')
#define CFT_MULLIKEN         CM_C4TOLONG('M','U','L','K')

#endif /* _CACHE_FILE_TYPES_H_ */

