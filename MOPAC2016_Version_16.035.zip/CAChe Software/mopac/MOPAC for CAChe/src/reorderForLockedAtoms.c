#include "compat.h"
#include "csu.h"
#include "MOPACDriver.h"

int reorderForLockedAtoms(double coords[][3], long NAtom, long atomLocation[],
				long lockedAtoms[], long numLockedAtoms,
				SearchLabel searchLabels[], long numSearchLabels,
	 			LockedLabel lockedLabels[], long numLockedLabels,
				long numDummyAtoms)
/*
	Locked Atoms defined in the Molecule Editor are used to mark certain internal
	coordinates in a molecule during an optimization so that they are not varied.
	So that MOPAC can implement locked atoms, the first atom in the z-matrix must
	be a locked atom; else, the first atom's coordinates will not be optimized with
	respect to locked atoms.  This function renumbers the atoms so that a locked atom
	appears first.
	
	NOTE:  This routine assumes that the atoms have already been ordered for search
	labels and locked labels.
*/
{
	long i, j, k;

    /* If there are no locked atoms, return */

	if (numLockedAtoms == 0)
		return (0);

	/* If the first atom is already a locked atom, return */

	if (lockedAtoms[atomLocation[0]] != 0) {
		return (0);
	}
		
	/* 
	 * Look through the search labels first to try to find a locked atom.
	 * Assumptions:	The moving atom in a search label cannot be locked
	 *				The moving atom in a search label comes later in the
	 *					atom list than the other atoms in the label, so it
	 *					is safe to swap a locked label into the first position.
	 * NOTE:  WHAT about 2 SEARCH LABELS>>>>>>>>
	 */
	for (i=0; i < numSearchLabels; i++) {
		for (j=searchLabels[i].atomList[0]; j > 1; j--) {
			k = findAtom(searchLabels[i].atomList[j],
						 atomLocation, NAtom);
			if (lockedAtoms[searchLabels[i].atomList[j]] != 0) {
				/* 
				 * Found a locked atom.  
				 * Put this atom in the first position, and return.
				 */
				slideAtoms(k, 0, coords, atomLocation, numDummyAtoms);
				return (0);
			}
		}
	}
	
	/* 
	 * Then look through the locked labels to try to find a locked atom.
	 *
	 * Assumptions:	The first atom in the locked label will not be locked 
	 *				unless both the first and last atoms in the label are 
	 *				both locked, so the first atom does not need to be considered
	 *
	 *				If a locked atom found in a locked label is also part of a 
	 *				search label, it will already have been moved to the begining of
	 *				the Z-matrix.
	 */
	for (i=0; i < numLockedLabels; i++) {
		for (j=lockedLabels[i].atomList[0]; j > 1; j--) {
			k = findAtom(lockedLabels[i].atomList[j],
						 atomLocation, NAtom);
			if (lockedAtoms[lockedLabels[i].atomList[j]] != 0) {
				/* 
				 * Found a locked atom.  
				 * Put this atom in the first position, and return 
				 */
				slideAtoms(k, 0, coords, atomLocation, numDummyAtoms);
				return (0);
			}
		}
	}
	
	/* and finally look for the first locked atom in the list */
	
	for (i = numDummyAtoms + 1; i < NAtom + numDummyAtoms; i++) {
		if (lockedAtoms[atomLocation[i]] != 0) {
			slideAtoms(i, 0, coords, atomLocation, numDummyAtoms);
			return (0);
		}
	}
	
	/* failed to place a locked atom at the begining of the Z matrix */

	return (-1);
	 
}
