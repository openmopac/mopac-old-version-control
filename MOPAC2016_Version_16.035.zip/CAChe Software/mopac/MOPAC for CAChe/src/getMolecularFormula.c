#include "compat.h"
#include <ctype.h>
#include "csu.h"
#include "MOPACDriver.h"
 
#define		TOTAL_NUM_ELEMS	103

long getMolecularFormula(MolStruct *molStruct, char *formula, int maxLength)
{
	double  (*tmpcoord)[3];
	short	*atomic_number, *atomID;
	ObjclsID offset;
	int		NAtom;
	int		rtn_code;

	int		i;
	int		numberEach[TOTAL_NUM_ELEMS];
	char 	errs[255];

   if (csu_ExistsObjclsID (molStruct, AtomID, &offset))
     NAtom = (long) ((GetPtr(molStruct->objclsH) + offset)->num_objs);
   else {
     alert_user ("getMolecularFormula: Unable to locate AtomID index.");
     goto errorReturn;
   }

   /*
    *  Set the array pointers for the atomic symbols.
    */
    
   if ((rtn_code = csu_GrabVal (molStruct, AtomID, ID_ID, (char **)&(atomID))) < 0) {
     sprintf (errs,"getMolecularFormula: csu_GrabVal ID, errno %d", rtn_code);
	 alert_user(errs);
     goto errorReturn;
   }

   if ((rtn_code = csu_GrabVal (molStruct, AtomID, XYZID, (char **)&(tmpcoord))) < 0) {
     sprintf (errs,"getMolecularFormula: csu_GrabVal XYZ, errno %d", rtn_code);
	 alert_user(errs);
     goto errorReturn;
   }
      
  if ((rtn_code = csu_GrabVal (molStruct, AtomID, AnumID, (char **)&atomic_number)) < 0) {
    sprintf (errs,"getMolecularFormula: csu_GrabVal Anum, errno %d", rtn_code);
	alert_user(errs);
    goto errorReturn;
  }

	/* Initializations */

	for (i=0; i<TOTAL_NUM_ELEMS; i++) { 
		numberEach[i] = 0;
	}
				
 	for (i=0; i<NAtom; i++)
		numberEach[atomic_number[i]-1]++;

	buildFormula(numberEach, formula, maxLength, TOTAL_NUM_ELEMS);
	
	return (strlen(formula));

errorReturn:
	return (-1);
}

void buildFormula(
	int numberEach[], 
	char *formula, 
	int maxLength, 
	int TotalNumberElements
)
{
	int i, length=0;
	char string[32];

	formula[0] = 0;
	
	for (i=0; i<TotalNumberElements; i++) {
		if (numberEach[i] > 0) {
		  if ((length+2) > maxLength) {
		  	alert_user("Empirical formula has exceded string length and is being truncated.");
			return;
		  } else {
			  if (i == 0) {
				  strncat(formula, "H", 1);
				  length += 1;
			  }
			  if (i == 1) {
				  strncat(formula, "He", 2);
				  length += 2;
			  }
			  if (i == 2) {
				  strncat(formula, "Li", 2);
				  length += 2;
			  }
			  if (i == 3) {
				  strncat(formula, "Be", 2);
				  length += 2;
			  }
			  if (i == 4) {
				  strncat(formula, "B", 1);
				  length += 2;
			  }
			  if (i == 5) {
				  strncat(formula, "C", 1);
				  length += 1;
			  }
			  if (i == 6) {
				  strncat(formula, "N", 1);
				  length += 1;
			  }
			  if (i == 7) {
				  strncat(formula, "O", 1);
				  length += 1;
			  }
			  if (i == 8) {
				  strncat(formula, "F", 1);
				  length += 1;
			  }
			  if (i == 9) {
				  strncat(formula, "Ne", 2);
				  length += 1;
			  }
			  if (i == 10) {
				  strncat(formula, "Na", 2);
				  length += 2;
			  }
			  if (i == 11) {
				  strncat(formula, "Mg", 2);
				  length += 2;
			  }
			  if (i == 12) {
				  strncat(formula, "Al", 2);
				  length += 2;
			  }
			  if (i == 13) {
				  strncat(formula, "Si", 2);
				  length += 2;
			  }
			  if (i == 14) {
				  strncat(formula, "P", 1);
				  length += 1;
			  }
			  if (i == 15) {
				  strncat(formula, "S", 1);
				  length += 1;
			  }
			  if (i == 16) {
				  strncat(formula, "Cl", 2);
				  length += 2;
			  }
			  if (i == 17) {
				  strncat(formula, "Ar", 2);
				  length += 2;
			  }
			  if (i == 18) {
				  strncat(formula, "K", 1);
				  length += 1;
			  }
			  if (i == 19) {
				  strncat(formula, "Ca", 2);
				  length += 2;
			  }
			  if (i == 20) {
				  strncat(formula, "Sc", 2);
				  length += 2;
			  }
			  if (i == 21) {
				  strncat(formula, "Ti", 2);
				  length += 2;
			  }
			  if (i == 22) {
				  strncat(formula, "V", 1);
				  length += 1;
			  }
			  if (i == 23) {
				  strncat(formula, "Cr", 2);
				  length += 2;
			  }
			  if (i == 24) {
				  strncat(formula, "Mn", 2);
				  length += 2;
			  }
			  if (i == 25) {
				  strncat(formula, "Fe", 2);
				  length += 2;
			  }
			  if (i == 26) {
				  strncat(formula, "Co", 2);
				  length += 2;
			  }
			  if (i == 27) {
				  strncat(formula, "Ni", 2);
				  length += 2;
			  }
			  if (i == 28) {
				  strncat(formula, "Cu", 2);
				  length += 2;
			  }
			  if (i == 29) {
				  strncat(formula, "Zn", 2);
				  length += 2;
			  }
			  if (i == 30) {
				  strncat(formula, "Ga", 2);
				  length += 2;
			  }
			  if (i == 31) {
				  strncat(formula, "Ge", 2);
				  length += 2;
			  }
			  if (i == 32) {
				  strncat(formula, "As", 2);
				  length += 2;
			  }
			  if (i == 33) {
				  strncat(formula, "Se", 2);
				  length += 2;
			  }
			  if (i == 34) {
				  strncat(formula, "Br", 2);
				  length += 2;
			  }
			  if (i == 35) {
				  strncat(formula, "Kr", 2);
				  length += 2;
			  }
			  if (i == 36) {
				  strncat(formula, "Rb", 2);
				  length += 2;
			  }
			  if (i == 37) {
				  strncat(formula, "Sr", 2);
				  length += 2;
			  }
			  if (i == 38) {
				  strncat(formula, "Y", 1);
				  length += 1;
			  }
			  if (i == 39) {
				  strncat(formula, "Zr", 2);
				  length += 2;
			  }
			  if (i == 40) {
				  strncat(formula, "Nb", 2);
				  length += 2;
			  }
			  if (i == 41) {
				  strncat(formula, "Mo", 2);
				  length += 2;
			  }
			  if (i == 42) {
				  strncat(formula, "Tc", 2);
				  length += 2;
			  }
			  if (i == 43) {
				  strncat(formula, "Ru", 2);
				  length += 2;
			  }
			  if (i == 44) {
				  strncat(formula, "Rh", 2);
				  length += 2;
			  }
			  if (i == 45) {
				  strncat(formula, "Pd", 2);
				  length += 2;
			  }
			  if (i == 46) {
				  strncat(formula, "Ag", 2);
				  length += 2;
			  }
			  if (i == 47) {
				  strncat(formula, "Cd", 2);
				  length += 2;
			  }
			  if (i == 48) {
				  strncat(formula, "In", 2);
				  length += 2;
			  }
			  if (i == 49) {
				  strncat(formula, "Sn", 2);
				  length += 2;
			  }
			  if (i == 50) {
				  strncat(formula, "Sb", 2);
				  length += 2;
			  }
			  if (i == 51) {
				  strncat(formula, "Te", 2);
				  length += 2;
			  }
			  if (i == 52) {
				  strncat(formula, "I", 1);
				  length += 1;
			  }
			  /* Do not put Xe in formula, since these are dummy atoms 
			  if (i == 53) {
				  strncat(formula, "Xe", 2);
				  length += 2;
			  } */
			  if (i == 54) {
				  strncat(formula, "Cs", 2);
				  length += 2;
			  }
			  if (i == 55) {
				  strncat(formula, "Ba", 2);
				  length += 2;
			  }
			  if (i == 56) {
				  strncat(formula, "La", 2);
				  length += 2;
			  }
			  if (i == 57) {
				  strncat(formula, "Ce", 2);
				  length += 2;
			  }
			  if (i == 58) {
				  strncat(formula, "Pr", 2);
				  length += 2;
			  }
			  if (i == 59) {
				  strncat(formula, "Nd", 2);
				  length += 2;
			  }
			  if (i == 60) {
				  strncat(formula, "Pm", 2);
				  length += 2;
			  }
			  if (i == 61) {
				  strncat(formula, "Sm", 2);
				  length += 2;
			  }
			  if (i == 62) {
				  strncat(formula, "Eu", 2);
				  length += 2;
			  }
			  if (i == 63) {
				  strncat(formula, "Gd", 2);
				  length += 2;
			  }
			  if (i == 64) {
				  strncat(formula, "Tb", 2);
				  length += 2;
			  }
			  if (i == 65) {
				  strncat(formula, "Dy", 2);
				  length += 2;
			  }
			  if (i == 66) {
				  strncat(formula, "Ho", 2);
				  length += 2;
			  }
			  if (i == 67) {
				  strncat(formula, "Er", 2);
				  length += 2;
			  }
			  if (i == 68) {
				  strncat(formula, "Tm", 2);
				  length += 2;
			  }
			  if (i == 69) {
				  strncat(formula, "Yb", 2);
				  length += 2;
			  }
			  if (i == 70) {
				  strncat(formula, "Lu", 2);
				  length += 2;
			  }
			  if (i == 71) {
				  strncat(formula, "Hf", 2);
				  length += 2;
			  }
			  if (i == 72) {
				  strncat(formula, "Ta", 2);
				  length += 2;
			  }
			  if (i == 73) {
				  strncat(formula, "W", 1);
				  length += 1;
			  }
			  if (i == 74) {
				  strncat(formula, "Re", 2);
				  length += 2;
			  }
			  if (i == 75) {
				  strncat(formula, "Os", 2);
				  length += 2;
			  }
			  if (i == 76) {
				  strncat(formula, "Ir", 2);
				  length += 2;
			  }
			  if (i == 77) {
				  strncat(formula, "Pt", 2);
				  length += 2;
			  }
			  if (i == 78) {
				  strncat(formula, "Au", 2);
				  length += 2;
			  }
			  if (i == 79) {
				  strncat(formula, "Hg", 2);
				  length += 2;
			  }
			  if (i == 80) {
				  strncat(formula, "Tl", 2);
				  length += 2;
			  }
			  if (i == 81) {
				  strncat(formula, "Pb", 2);
				  length += 2;
			  }
			  if (i == 82) {
				  strncat(formula, "Bi", 2);
				  length += 2;
			  }
			  if (i == 83) {
				  strncat(formula, "Po", 2);
				  length += 2;
			  }
			  if (i == 84) {
				  strncat(formula, "At", 2);
				  length += 2;
			  }
			  if (i == 85) {
				  strncat(formula, "Rn", 2);
				  length += 2;
			  }
			  if (i == 86) {
				  strncat(formula, "Fr", 2);
				  length += 2;
			  }
			  if (i == 87) {
				  strncat(formula, "Ba", 2);
				  length += 2;
			  }
			  if (i == 88) {
				  strncat(formula, "Ac", 2);
				  length += 2;
			  }
			  if (i == 89) {
				  strncat(formula, "Th", 2);
				  length += 2;
			  }
			  if (i == 90) {
				  strncat(formula, "Pa", 2);
				  length += 2;
			  }
			  if (i == 91) {
				  strncat(formula, "U", 1);
				  length += 1;
			  }
			  if (i == 92) {
				  strncat(formula, "Np", 2);
				  length += 2;
			  }
			  if (i == 93) {
				  strncat(formula, "Pu", 2);
				  length += 2;
			  }
			  if (i == 94) {
				  strncat(formula, "Am", 2);
				  length += 2;
			  }
			  if (i == 95) {
				  strncat(formula, "Cm", 2);
				  length += 2;
			  }
			  if (i == 96) {
				  strncat(formula, "Bk", 2);
				  length += 2;
			  }
			  if (i == 97) {
				  strncat(formula, "Cf", 2);
				  length += 2;
			  }
			  if (i == 98) {
				  strncat(formula, "Es", 2);
				  length += 2;
			  }
			  if (i == 99) {
				  strncat(formula, "Fm", 2);
				  length += 2;
			  }
			  if (i == 100) {
				  strncat(formula, "Md", 2);
				  length += 2;
			  }
			  if (i == 101) {
				  strncat(formula, "No", 2);
				  length += 2;
			  }
			  if (i == 102) {
				  strncat(formula, "Lr", 2);
				  length += 2;
			  }
			  if (i == 103) {
				  strncat(formula, "Tv", 2);
				  length += 2;
			  }
			  if (numberEach[i] > 1) {
				  sprintf(string,"%d",numberEach[i]);
				  if ((int)(length+strlen(string)) > maxLength) {
					  alert_user("Empirical formula has exceded string length and is being truncated.");
					  return;
				  } else {
					  strncat(formula, string, strlen(string));
				  }
			  }
		  }
		}
	}
}
