 /* 
  * Structures used for processing molecule to make MOPAC Input file and
  * for writing output files
  */
 typedef struct {
 	double		lowValue;
	double		highValue;
 	ObjclsID	objclsID;
	long		numSteps;
	long		atomList[5];  /* atomList[0] is the number of atoms in this label */
 } SearchLabel;

typedef struct  {
	char		molStructName[256]; /* the name of the molecule file */

	/* Not a problem for UNIX boxes? */
	short		molStructvRefNum;
	char		startupVolume[32];
	char		CACheSystemPath[256];
	char		SystemFolderPath[256];

	short		netCharge;
	long		numberOfAtoms;	/* Total number of atoms */
	long		numberOfHAtoms;	/* ALL the rest are heavy atoms */
	long		atomLocation[MOPAClimit]; 
				/* 2*MOPAClimit array for correspondence of MOPAC 
				 * atom order to molecule structure file atom numbering */
	long		locationWithoutDummies[MOPAClimit];
	SearchLabel searchLabels[4];
	long		numSearchLabels;
	long		numLockedLabels;
	long		numLockedAtoms;
	long		numUserDummyAtoms;
} MoleculeInfo;
