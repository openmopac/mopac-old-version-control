/* default colors for atoms -- colors are stored in 6 byte RGB format */
/* the colors from black through yellow are defined in Inside Mac V. */

#ifndef _COLOR_DEFS_
#define _COLOR_DEFS_

/* color ramp indexes for 88K */
#define GRAY		0
#define DK_GRAY		1
#define RED			2
#define YELLOW		3
#define GREEN		4
#define BLUE		5
#define PURPLE		6
#define BROWN		7
#define BKGROUND	8

#endif /* _COLOR_DEFS_ */
