#include <compat.h>
#include <math.h>
#include <cpu.h>
#include <ServerStepQueue.h>
#if defined(unix)
#include <UnixAppMgr.h>
#elif defined(_WIN32)
#include <windows.h>
#endif
#include <CACheFileLibAD.h>
#include <CACheFileLib.h>
#include <MOPACDriver.h>
#include <CACheFileTypes.h>

extern FILE	*movie_fp;
extern char mv_name[32];

int writeDRC(MolStruct *molStruct, MoleculeInfo *moleculeInfo, 
	double coord_shift[], short drcIrcMode, short outputCalcNumber, 
	Boolean ProcessMOPACoutput)
{
	int i, j, rtn_code, ij, nLinear, bond,  atom1, atom2, Idx;
	long istep, lastFrame;
	FILE *MOPACoutput = NULL;
	char string[256], buff[32];
	double (*tmpcoord)[3] = NULL;
	float (*xyz)[3] = NULL;
	int NAtoms, NAtoms_in_output;
	ObjclsID offset;
	float femtoseconds, potential, kinetic, total, 
        distance,  time;
	long  point;
    long numberBonds;
    ObjectID (*bondList)[2] = NULL;
    float *bond_order = NULL;
    float values[8];
   	long *bondListPointer;
    float *bondOrders = NULL;
    float *pcharge = NULL;
	if ((MOPACoutput = fopen(MOPACOutputFile, "r")) == NULL) {
		alert_user("writeDRC: Unable to open MOPAC Output.");
		return -1;
	}
	
	string[0] = 0;
  	if (drcIrcMode == 0)
		sprintf(string, ".DRC");
	else
		sprintf(string, ".DRC%d", drcIrcMode);
	j = strlen(string);

	if (startMovieHeader(molStruct, string, CFT_EMAP) < 0) {
		alert_user("Unable to save the results because the disk may be full"
			       " or the file file may be locked.");
		return -1;
	}

	if ((outputCalcNumber >= 0) && ProcessMOPACoutput) {
		/* echo DRC file name  so user will know where the results got put */
		if ((i = strlen(moleculeInfo->molStructName)) > (31 - j)) 
			i = 31 - j;
		strncpy(buff, moleculeInfo->molStructName, i);
		strcpy(buff+i, string);
		sprintf(string, "Writing DRC trajectory in %s\n", 
			buff);
		mam_SendStatus(MOPAC_STATUS_SCROLL, string);
	}

   /*
    *  Find out how many atoms there are.
    */
    
   if (csu_ExistsObjclsID (molStruct, AtomID, &offset))
     NAtoms = (long) ((GetPtr(molStruct->objclsH) + offset)->num_objs);
   else {
     alert_user (" Error attempting to locate AtomID index.");
   }
	
   MOP_YIELD();

	/* Determine the true number of atoms in the output so that dummy
	   atoms will be handled correctly */
	NAtoms_in_output = 0;
	for (;;) { /* find beginning of first Z-matrix listing */
		if (cfl_fgets(string, sizeof(string), MOPACoutput) == 0) break;        
		if (strncmp(string, " NUMBER    SYMBOL", 17) ==0 || strncmp(string, "    NO.       ATOM           X", 30)== 0)
			break;
	}
	cfl_fgets(string, sizeof(string), MOPACoutput); /* skip one blank line */
	for (;;) {
		if (cfl_fgets(string, sizeof(string), MOPACoutput) == 0) break;
		if (strlen(string) > 2) {
			if (strncmp(&string[11],"XX",2) != 0 &&
				strncmp(&string[11],"xx",2) != 0) {
				/* don't count dummy atoms */
				NAtoms_in_output++;
			} 
		} else
			break;
	}
	if (NAtoms_in_output == 0) {
		alert_user("writeDRC: no atoms in MOPAC Output file.");
		goto errorReturn;
	}
		
	/* count the number of frames in the MOPAC Output file */
	lastFrame = 0;
	for (;;) {
		if (cfl_fgets(string, sizeof(string), MOPACoutput) == 0) break;
		if (strncmp(string," FEMTOSECONDS  POINT  POTENTIAL", 31) == 0) {
			for (;;) {
                string[71] = 0;
				if (cfl_fgets(string, sizeof(string), MOPACoutput) == 0) break;
				if (string[71] == '%') {
                    lastFrame++;
                  	sscanf(string," %f ", &time);
   
                }
			}
		}
	}
    if (lastFrame) time /= lastFrame;
	
	/* get original coordinates from molStruct to have coordinates for dummy atoms */
	if ((rtn_code = csu_GrabVal (molStruct, AtomID, XYZID, (char **)&(tmpcoord))) < 0) {
 		sprintf (string,"writeReactionCoord: csu_GrabVal XYZ, errno %d", rtn_code);
		alert_user(string);
		goto errorReturn;
	}

	/* Write out driver header */
    	fprintf(movie_fp, "%s %s %f %f %d\n",
		"Time",  						/* name */
		"femtoseconds", 				/* units */
		time, lastFrame*time, lastFrame);
	/* 		Write out dependent header end of Axes, 	*/
	/* 		introduce start of calculated values 		*/
	fprintf(movie_fp, "Dependents\n");

	/* Potential Energy */
	fprintf(movie_fp, "not_objcls Potential_Energy 4 1 3 kcal/mole 1\n");
	fprintf(movie_fp, "-1\n");

	/* 		Total Energy 								*/
	if (dependentHeader(molStruct, CalcHistID, CalcEnergyID, 4, 1, 3,
						Energy_Kcal_mole, -1, NULL) < 1) {
		alert_user("depend_hdr returned wrong number of energies\n");
		goto errorReturn;
	}

	/* Kinetic Energy */
	fprintf(movie_fp, "not_objcls Kinetic_Energy 4 1 3 kcal/mole 1\n");
	fprintf(movie_fp, "-1\n");

	/* atom coordinates */
	if (NAtoms != dependentHeader(molStruct, AtomID, XYZID, 4, 3, 3, Angstrom_U, 0, NULL)) {
		printf("depend_hdr returned wrong number of atoms\n");
		goto errorReturn;
	}
    /* partial charges */
	if (NAtoms != dependentHeader(molStruct, AtomID, PchrgID, 4, 1, 3, Charge_AU, 0, NULL)) {
		alert_user("depend_hdr returned wrong number of partial charges");
		goto errorReturn;
	}
       /* bond orders */
    numberBonds = cpu_getBondList(molStruct, &bondList);
	if (numberBonds != dependentHeader(molStruct, BondID, Bond_OrderID, 4, 1, 3, NoUnit, 0, NULL)) {
		alert_user("depend_hdr returned wrong number of bond-orders");
		goto errorReturn;
	}

	/* mark end of ASCII movie header and start of binary movie data */
	fprintf(movie_fp, "StartFrames\n");
#if defined(_WIN32)
	/*  change to binary mode */
	cfl_MacFClose(movie_fp);
	if ((movie_fp = cfl_MacFOpen(mv_name, "rb+", 0, 0)) == NULL) {
		alert_user("Unable to re-open movie file in binary mode.");
		goto errorReturn;
	}
	/* start at the end of the movie header */
	if (fseek(movie_fp, 0, 2)) {
		fclose(movie_fp);
		alert_user("Unable to fseek to the end of the movie file.");
		goto errorReturn;
	}
#endif
    MOP_YIELD();

	/* start writing the frame information */
	if (MOPACoutput != NULL) fclose(MOPACoutput);
	if ((MOPACoutput = fopen("xyzmap", "r")) == NULL) {
		alert_user("writeDRC: Unable to open 'xyzmap' file (no points generated?)");
		return -1;
	}

	if ((xyz = (float (*)[3]) 
			malloc(sizeof(float)*3*NAtoms)) == NULL) {
		alert_user("writeDRC: Unable to allocate xyz array");
		goto errorReturn;
	}
      if ((pcharge = (float *) 
			malloc(sizeof(float)*NAtoms)) == NULL) {
		alert_user("writeIRC: Unable to allocate partial charge array");
		goto errorReturn;
    }
            nLinear = (NAtoms*(NAtoms+1))/2;
    if ((bondOrders = (float *) NewHandle(nLinear*sizeof(double))) == NULL) {
	    alert_user("writeIRC: Unable to allocate bondOrders array");
    }
    if ((bond_order = (float *) 
			malloc(sizeof(float)*numberBonds)) == NULL) {
		alert_user("writeIRC: Unable to allocate bond order array");
		goto errorReturn;
	}

	/* put original molstruct xyz coordinates into present coordinates */
	for (i=0; i<NAtoms ; i++)
		for (j=0; j<3; j++)
			xyz[i][j] = (float) tmpcoord[i][j] ;
	for (istep=0; istep < lastFrame; istep++) {
	
        MOP_YIELD();
		/* write the frame number */
		if (fwrite(&istep, 4, 1, movie_fp) < 1) {
			alert_user("movie write failed");
			break;
		} 

		/* write out the dependent values */
			
		/* total energy */
		if (cfl_fgets(string, sizeof(string), MOPACoutput) == 0) goto endOfFile;
		sscanf(string,"%d %f %f %f %f %f", &point, &potential,
				&kinetic, &total, &femtoseconds, &distance);
			/* write out value as binary float */
		if (fwrite(&potential, 4, 1, movie_fp) < 1) {
			alert_user("movie write failed potential");
			break;
		} 
		if (fwrite(&total, 4, 1, movie_fp) < 1) {
			alert_user("movie write failed totalEnergy");
			break;
		} 
		if (fwrite(&kinetic, 4, 1, movie_fp) < 1) {
			alert_user("movie write failed kinetic");
			break;
		} 
		
		for (i=0; i < NAtoms_in_output; i++) {
		    float x[3];
			if (cfl_fgets(string, sizeof(string), MOPACoutput) == 0) goto endOfFile;
			if (strlen(string) > 10) {
				sscanf(string,"%f %f %f %f", &x[0], &x[1], &x[2],&pcharge[moleculeInfo->locationWithoutDummies[i]]);
				for (j=0; j<3; j++) 
					xyz[moleculeInfo->locationWithoutDummies[i]][j] = 
						(float) (x[j] + coord_shift[j]);
			} else {
				alert_user("writeDRC:  error reading coordinates");
				goto errorReturn;
			}
		}
/*
*   Read in Bond Orders  FIXME: This was copied more-or-less verbatim from "updateMolStruct.c"
*/
        for (;;) {
	    	if (cfl_fgets(string, sizeof(string), MOPACoutput) == NULL) 
						break;
            if (strncmp(string, 
						"                    BOND ORDERS AND VALENCIES", 45) == 0) 
                        break;
        }
				/* initialize bond order matrix */
				for (ij=0; ij < (nLinear -1); ij++)
					(GetPtr( bondOrders))[ij] = 0.0;
					ij = 0;
					while (ij < (nLinear - 1)) {
						int num_accross, j_val[6];
						num_accross = 0;
						if (strlen(string) > 15) {
							num_accross += 
								sscanf(&string[19],"%ld", &j_val[0]);
							num_accross += 
								sscanf(&string[30],"%ld", &j_val[1]);
							num_accross += 
								sscanf(&string[41],"%ld", &j_val[2]);
							num_accross += 
								sscanf(&string[52],"%ld", &j_val[3]);
							num_accross += 
								sscanf(&string[63],"%ld", &j_val[4]);
							num_accross += 
								sscanf(&string[74],"%ld", &j_val[5]);
						}
	
						if (num_accross<=0) 
							break;
						cfl_fgets(string, sizeof(string), MOPACoutput); /* skip a line */
						for (;;) {
							if (cfl_fgets(string, sizeof(string), MOPACoutput) == NULL) 
								break;
							if (strlen(string) < 3)
								break;
							if (strlen(string) > 7) 
								num_accross = sscanf(&string[7],"%ld %f %f %f %f %f %f\n",
											&i, &values[0], &values[1], &values[2], &values[3],
											&values[4], &values[5]);
							else
								num_accross = 0;
							if (num_accross<=0) break;
							for (j=0; j<(num_accross-1); j++) {
								ij = ((i*(i-1))/2) + j_val[j] -1;
			    				(GetPtr(bondOrders))[ij] = values[j];
							}
							if (ij >= (nLinear - 1))
								break;
						}
	
						if (ij >= (nLinear -1)) 
							break;
						if (cfl_fgets(string, sizeof(string), MOPACoutput) == NULL) 
							break;
						if (strlen(string) < 3) {
							/* skip a line */
							cfl_fgets(string, sizeof(string), MOPACoutput); 
						}
						if (strlen(string) < 3) {
							/* skip a second line line (for some VAX output) */
							cfl_fgets(string, sizeof(string), MOPACoutput); 
						}
					} /* ij < nLinear -1 */
  /* build the list of bonds */	
    /* Add the bond order to each bond and mark the bondOrderDefined
	   array to indicate that the bond order has already been filled
	   in.
	*/
	for (bond=0; bond<numberBonds; bond++) {
	  bondListPointer = bondList[bond];
	  atom1 = whichAtomIndex(bondListPointer[0], NAtoms, moleculeInfo->locationWithoutDummies);
	  if (atom1 >= 0) {
		 atom2 = whichAtomIndex(bondListPointer[1], NAtoms, moleculeInfo->locationWithoutDummies);
		 Idx = (atom1>atom2) ? ((atom1*(atom1+1))/2 + atom2) : ((atom2*(atom2+1))/2 + atom1);
          bond_order[bond] = bondOrders[Idx];
		 
        }
   }
    /*  Dummy read to end of this block */
            for (;;) {
	    	if (cfl_fgets(string, sizeof(string), MOPACoutput) == NULL) 
						goto endOfFile;
            if (strncmp(string,"EndOfBlock",10) == 0)
                        break;
        }
			/* write out value as binary float */
			if (fwrite(xyz, 4, 3*NAtoms, movie_fp) < 1) {
				alert_user("movie write failed xyz coordinates");
				break;
			} 
            /* write out partial charges as binary float */
	    	if (fwrite(pcharge, 4, NAtoms, movie_fp) < 1) {
		    	alert_user("movie write pcharge failed");
		    	break;
            } 
             /* write out bond orders as binary float */
		    if (fwrite(bond_order, 4, numberBonds, movie_fp) < 1) {
			    alert_user("writeReactionCoord: bond order map write failed");
		    	break;
		    } 
	}

errorReturn:
	if (MOPACoutput != NULL) fclose(MOPACoutput);

    MOP_YIELD();
	
	if (movie_fp != NULL) fflush(movie_fp);
	if (movie_fp != NULL) cfl_MacFClose(movie_fp);
	
	if (xyz != NULL) free(xyz);
    if (pcharge != NULL) free(pcharge);
    if (bondOrders != NULL) free(bondOrders);
	return -1;
endOfFile:
	if (MOPACoutput != NULL) fclose(MOPACoutput);
	
    MOP_YIELD();
	
	if (movie_fp != NULL) fflush(movie_fp);
	if (movie_fp != NULL) cfl_MacFClose(movie_fp);

	if (xyz != NULL) free(xyz);
    if (pcharge != NULL) free(pcharge);
    if (bondOrders != NULL) free(bondOrders);
	return(0);
}


int writeIRC(MolStruct *molStruct, MoleculeInfo *moleculeInfo, 
	double coord_shift[], short ircMode, short outputCalcNumber, 
	Boolean ProcessMOPACoutput)
{
	int i, j, rtn_code;
	long istep, lastFrame;
	FILE *MOPACoutput = NULL;
	char string[256], buff[32];
	double (*tmpcoord)[3] = NULL;
	float (*xyz)[3] = NULL;
    float *pcharge = NULL;
    long numberBonds;
    ObjectID (*bondList)[2] = NULL;
    float *bond_order = NULL;
    float values[8];
    double zero, *pchrg = NULL;
   	long *bondListPointer;
    float *bondOrders = NULL;
	int NAtoms, NAtoms_in_output;
	ObjclsID offset;
	float potential, eLoss, total, distance,
        integral_of_distance, old_distance;
	long  point, bond, atom1, atom2;
    int ij, nLinear, Idx;

	if ((MOPACoutput = fopen(MOPACOutputFile, "r")) == NULL) {
		alert_user("writeIRC: Unable to open MOPAC Output.");
		return -1;
	}
	string[0] = 0;
	if (ircMode == 0)
		sprintf(string, ".IRC");
	else
		sprintf(string, ".IRC%d", ircMode);
	j = strlen(string);
   /*
    *  Find out how many atoms there are.
    */
    
   if (csu_ExistsObjclsID (molStruct, AtomID, &offset))
     NAtoms = (long) ((GetPtr(molStruct->objclsH) + offset)->num_objs);
   else {
     alert_user (" Error attempting to locate AtomID index.");
   }
/*
*  Force all partial charges to zero, to ensure that they are defined
*/
zero = 0.0;
pchrg = &zero;
	  for (i = 0; i < NAtoms; i++) {
		if ((rtn_code = csu_AddObjVal (molStruct, AtomID, PchrgID, 
									   (moleculeInfo->locationWithoutDummies[i]),
									   MOPAC_SRC, CSU_FLOATING, 1, Charge_AU, 
									   4, (char*)pchrg, 0,
			                           BY_INDEX)) < 0) {

		  alert_user (" Error attempting to set partial charges to zero.");
		  goto errorReturn;
		}

	  }
      if ((numberBonds = cpu_getBondList(molStruct, &bondList)) > 0) {
        for (i=0; i<numberBonds; i++) {
		 if((rtn_code = csu_AddObjVal (molStruct, BondID, Bond_OrderID,
						i, MOPAC_SRC, CSU_FLOATING, 1, NoUnit, 4, 
						(char*)pchrg,0, BY_INDEX)) < 0) {
		   alert_user(" Error attempting to initialize bond orders.");
		 }
        }
	  }

	if (startMovieHeader(molStruct, string, CFT_EMAP) < 0) {
		alert_user("Unable to save the results because the disk may be full"
			       " or the file file may be locked.");
		return -1;
	}

	if ((outputCalcNumber >= 0) && ProcessMOPACoutput) {
		/* echo IRC file name  so user will know where the results got put */
		if ((i = strlen(moleculeInfo->molStructName)) > (31 - j)) 
			i = 31 - j;
		strncpy(buff, moleculeInfo->molStructName, i);
		strcpy(buff+i, string);
		sprintf(string,"Writing IRC trajectory in %s\n", 
			buff);
		mam_SendStatus(MOPAC_STATUS_SCROLL, string);
	}

  
	
   MOP_YIELD();

	/* Determine the true number of atoms in the output so that dummy
	   atoms will be handled correctly */
	NAtoms_in_output = 0;
	for (;;) { /* find beginning of first Z-matrix listing */
		if (cfl_fgets(string, sizeof(string), MOPACoutput) == 0) break;
		if (strncmp(string, " NUMBER    SYMBOL", 17) == 0 || 
            strncmp(string, "    NO.       ATOM           X", 30) == 0)
			break;
	}
	cfl_fgets(string, sizeof(string), MOPACoutput); /* skip one blank line */
	for (;;) {
		if (cfl_fgets(string, sizeof(string), MOPACoutput) == 0) break;
		if (strlen(string) < 11)
			break;
		if (strncmp(&string[11],"XX",2) != 0 &&
			strncmp(&string[11],"xx",2) != 0) {
			/* don't count dummy atoms */
			NAtoms_in_output++;
		} 
	}

	if (NAtoms_in_output == 0) {
		alert_user("writeIRC: no atoms in MOPAC Output file.");
		goto errorReturn;
	}
/* count the number of frames in the MOPAC Output file */
	lastFrame = 0;
    integral_of_distance = 0.0;
    old_distance = -10.0;
    i = 0;
	for (;;) {
		if (cfl_fgets(string, sizeof(string), MOPACoutput) == 0) break;
		if (strncmp(string,"     POINT   POTENTIAL  +", 25) == 0) {
			for (;;) {
                string[71] = 0;
				if (cfl_fgets(string, sizeof(string), MOPACoutput) == 0) break;
                if (string[71] == '%') {
                    lastFrame++;
                  	sscanf(string," %d %f %f %f %f %f %*c %f", &point, &potential,
				&eLoss, &total, &distance, &distance, &distance);
                    if (old_distance > 0.0)
                    {
                        integral_of_distance += (float) fabs( distance - old_distance);
/*  Check to see if two points are the same (in an ICR=1*, for example */
                        if (fabs( distance - old_distance) < 0.0001) i = 1;
                    }
                    old_distance = distance;                    
                }
			}
			break;
		}
	}
	 if (lastFrame > 1) distance = integral_of_distance/(lastFrame - 1 - i);	
	/* get original coordinates from molStruct to have coordinates for dummy atoms */
	if ((rtn_code = csu_GrabVal (molStruct, AtomID, XYZID, (char **)&(tmpcoord))) < 0) {
 		sprintf (string,"writeReactionCoord: csu_GrabVal XYZ, errno %d", rtn_code);
		alert_user(string);
		goto errorReturn;
	}

	/* Write out driver header */
	fprintf(movie_fp, "%s %s %f %f %d\n",
		"Distance",  						/* name */
		"Angstroms", 						/* units */
		distance, lastFrame*distance, lastFrame);
	
	/* 		Write out dependent header end of Axes, 	*/
	/* 		introduce start of calculated values 		*/
	fprintf(movie_fp, "Dependents\n");

	/* Potential Energy */
	fprintf(movie_fp, "not_objcls Potential_Energy 4 1 3 kcal/mole 1\n");
	fprintf(movie_fp, "-1\n");

	/* 		Total Energy 								*/
	if (dependentHeader(molStruct, CalcHistID, CalcEnergyID, 4, 1, 3,
						Energy_Kcal_mole, -1, NULL) < 1) {
		alert_user("depend_hdr returned wrong number of energies\n");
		goto errorReturn;
	}

	/* atom coordinates */
	if (NAtoms != dependentHeader(molStruct, AtomID, XYZID, 4, 3, 3, Angstrom_U, 0, NULL)) {
		printf("depend_hdr returned wrong number of atoms\n");
		goto errorReturn;
	}
        /* partial charges */
	if (NAtoms != dependentHeader(molStruct, AtomID, PchrgID, 4, 1, 3, Charge_AU, 0, NULL)) {
		alert_user("depend_hdr returned wrong number of partial charges");
		goto errorReturn;
	}
       /* bond orders */
    numberBonds = cpu_getBondList(molStruct, &bondList);
	if (numberBonds != dependentHeader(molStruct, BondID, Bond_OrderID, 4, 1, 3, NoUnit, 0, NULL)) {
		alert_user("depend_hdr returned wrong number of bond-orders");
		goto errorReturn;
	}

	/* mark end of ASCII movie header and start of binary movie data */
	fprintf(movie_fp, "StartFrames\n");
#if defined(_WIN32)
	/*  change to binary mode */
	cfl_MacFClose(movie_fp);
	if ((movie_fp = cfl_MacFOpen(mv_name, "rb+", 0, 0)) == NULL) {
		alert_user("Unable to re-open movie file in binary mode.");
		goto errorReturn;
	}
	/* start at the end of the movie header */
	if (fseek(movie_fp, 0, 2)) {
		fclose(movie_fp);
		alert_user("Unable to fseek to the end of the movie file.");
		goto errorReturn;
	}
#endif
    MOP_YIELD();
	/* start writing the frame information */
	if (MOPACoutput != NULL) fclose(MOPACoutput);
	if ((MOPACoutput = fopen("xyzmap", "r")) == NULL) {
		alert_user("writeIRC: Unable to open MOPAC Output.");
		return -1;
	}

	if ((xyz = (float (*)[3]) 
			malloc(sizeof(float)*3*NAtoms)) == NULL) {
		alert_user("writeIRC: Unable to allocate xyz array");
		goto errorReturn;
	}
    if ((pcharge = (float *) 
			malloc(sizeof(float)*NAtoms)) == NULL) {
		alert_user("writeIRC: Unable to allocate partial charge array");
		goto errorReturn;
    }
        nLinear = (NAtoms*(NAtoms+1))/2;
    if ((bondOrders = (float *) NewHandle(nLinear*sizeof(double))) == NULL) {
	    alert_user("writeIRC: Unable to allocate bondOrders array");
    }
    if ((bond_order = (float *) 
			malloc(sizeof(float)*numberBonds)) == NULL) {
		alert_user("writeIRC: Unable to allocate bond order array");
		goto errorReturn;
	}
	/* put original molstruct xyz coordinates into present coordinates */
	for (i=0; i<NAtoms ; i++)
		for (j=0; j<3; j++)
			xyz[i][j] = (float)tmpcoord[i][j];
	for (istep=0; istep < lastFrame; istep++) {
	
        MOP_YIELD();
		/* write the frame number */
		if (fwrite(&istep, 4, 1, movie_fp) < 1) {
			alert_user("movie write failed");
			break;
		} 

		/* write out the dependent values */
			
		/* total energy */
		if (cfl_fgets(string, sizeof(string), MOPACoutput) == 0) goto endOfFile;
		sscanf(string," %d %f %f %f %f %f", &point, &potential,
				&eLoss, &total, &distance, &distance);		
			/* write out value as binary float */

		if (fwrite(&potential, 4, 1, movie_fp) < 1) {
			alert_user("movie write failed potential");
			break;
		} 

		if (fwrite(&total, 4, 1, movie_fp) < 1) {
			alert_user("movie write failed totalEnergy");
			break;
		} 

        /* read Cartesian coordinates and charges */
		for (i=0; i < NAtoms_in_output; i++) {
		    float x[3];
			if (cfl_fgets(string, sizeof(string), MOPACoutput) == 0) goto endOfFile;

			sscanf(string,"%f %f %f %f", &x[0], &x[1], &x[2], &pcharge[moleculeInfo->locationWithoutDummies[i]]);	
     //       	sscanf(string,"%f %f %f ", &x[0], &x[1], &x[2]);	
			for (j=0; j<3; j++) 
				xyz[moleculeInfo->locationWithoutDummies[i]][j] = (float)(x[j] + coord_shift[j]);
   		}
/*
*   Read in Bond Orders  FIXME: This was copied more-or-less verbatim from "updateMolStruct.c"
*/
        for (;;) {
	    	if (cfl_fgets(string, sizeof(string), MOPACoutput) == NULL) 
						break;
            if (strncmp(string, 
						"                    BOND ORDERS AND VALENCIES", 45) == 0) 
                        break;
        }
				/* initialize bond order matrix */
				for (ij=0; ij < (nLinear -1); ij++)
					(GetPtr( bondOrders))[ij] = 0.0;
					ij = 0;
					while (ij < (nLinear - 1)) {
						int num_accross, j_val[6];
						num_accross = 0;
						if (strlen(string) > 15) {
							num_accross += 
								sscanf(&string[19],"%ld", &j_val[0]);
							num_accross += 
								sscanf(&string[30],"%ld", &j_val[1]);
							num_accross += 
								sscanf(&string[41],"%ld", &j_val[2]);
							num_accross += 
								sscanf(&string[52],"%ld", &j_val[3]);
							num_accross += 
								sscanf(&string[63],"%ld", &j_val[4]);
							num_accross += 
								sscanf(&string[74],"%ld", &j_val[5]);
						}
	
						if (num_accross<=0) 
							break;
						cfl_fgets(string, sizeof(string), MOPACoutput); /* skip a line */
						for (;;) {
							if (cfl_fgets(string, sizeof(string), MOPACoutput) == NULL) 
								break;
							if (strlen(string) < 3)
								break;
							if (strlen(string) > 7) 
								num_accross = sscanf(&string[7],"%ld %f %f %f %f %f %f\n",
											&i, &values[0], &values[1], &values[2], &values[3],
											&values[4], &values[5]);
							else
								num_accross = 0;
							if (num_accross<=0) break;
							for (j=0; j<(num_accross-1); j++) {
								ij = ((i*(i-1))/2) + j_val[j] -1;
			    				(GetPtr(bondOrders))[ij] = values[j];
							}
							if (ij >= (nLinear - 1))
								break;
						}
	
						if (ij >= (nLinear -1)) 
							break;
						if (cfl_fgets(string, sizeof(string), MOPACoutput) == NULL) 
							break;
						if (strlen(string) < 3) {
							/* skip a line */
							cfl_fgets(string, sizeof(string), MOPACoutput); 
						}
						if (strlen(string) < 3) {
							/* skip a second line line (for some VAX output) */
							cfl_fgets(string, sizeof(string), MOPACoutput); 
						}
					} /* ij < nLinear -1 */
  /* build the list of bonds */	
    /* Add the bond order to each bond and mark the bondOrderDefined
	   array to indicate that the bond order has already been filled
	   in.
	*/
	for (bond=0; bond<numberBonds; bond++) {
	  bondListPointer = bondList[bond];
	  atom1 = whichAtomIndex(bondListPointer[0], NAtoms, moleculeInfo->locationWithoutDummies);
	  if (atom1 >= 0) {
		 atom2 = whichAtomIndex(bondListPointer[1], NAtoms, moleculeInfo->locationWithoutDummies);
		 Idx = (atom1>atom2) ? ((atom1*(atom1+1))/2 + atom2) : ((atom2*(atom2+1))/2 + atom1);
          bond_order[bond] = bondOrders[Idx];
		 
        }
   }
    /*  Dummy read to end of this block */
            for (;;) {
	    	if (cfl_fgets(string, sizeof(string), MOPACoutput) == NULL) 
						goto endOfFile;
            if (strncmp(string,"EndOfBlock",10) == 0)
                        break;
        }
						/* write out Cartesian coordinates as binary float */
			if (fwrite(xyz, 4, 3*NAtoms, movie_fp) < 1) {
				alert_user("movie write failed xyz coordinates");
				break;
			} 
                     /* write out partial charges as binary float */
	    	if (fwrite(pcharge, 4, NAtoms, movie_fp) < 1) {
		    	alert_user("movie write pcharge failed");
		    	break;
            } 
            /* write out bond orders as binary float */
		    if (fwrite(bond_order, 4, numberBonds, movie_fp) < 1) {
			    alert_user("writeReactionCoord: bond order map write failed");
		    	break;
		    } 
	}

errorReturn:
	if (MOPACoutput != NULL) fclose(MOPACoutput);

    MOP_YIELD();
	
	if (movie_fp != NULL) fflush(movie_fp);
	if (movie_fp != NULL) cfl_MacFClose(movie_fp);
	
	if (xyz != NULL) free(xyz);
    if (pcharge != NULL) free(pcharge);
    if (bondOrders != NULL) free(bondOrders);
	return -1;

endOfFile:
	fclose(MOPACoutput);
	
	if (movie_fp != NULL) fflush(movie_fp);
	if (movie_fp != NULL) cfl_MacFClose(movie_fp);

	if (xyz != NULL) free(xyz);
    if (pcharge != NULL) free(pcharge);
    if (bondOrders != NULL) free(bondOrders);
	return(0);
}
