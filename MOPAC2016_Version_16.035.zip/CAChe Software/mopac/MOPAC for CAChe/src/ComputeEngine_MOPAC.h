/*
** ComputeEngine_MOPAC.h
*/

#include <ComputeEngine.h>

#if defined(__cplusplus)
extern "C" {
#endif
void ce_ApplMain(char *programName, int processOutputFlag, void *CompEng);

#if defined(__cplusplus)
}
#endif

class ComputeEngine_MOPAC : public ComputeEngine {

public:
    int m_ProcessOutputFile;

    ComputeEngine_MOPAC(void);

    void ParseOtherFlags(char *p);
    void DoComputation(void);
    unsigned long StackSize(void);
};
