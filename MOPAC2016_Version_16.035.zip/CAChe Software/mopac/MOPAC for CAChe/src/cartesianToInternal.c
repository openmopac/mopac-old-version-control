#include <compat.h>
#include <math.h>
#include <cmu.h>
#include "MOPACDriver.h"

int cartesianToInternal(double xyz[][3], long numat, Zmatrix geo[],
					long numberBonds, long (*bondList)[2],
					long atomLocation[], long numDummyAtoms)
{
/***********************************************************************
*
* cartesianToInternal works out the internal coordinates of a molecule.
*        the "rules" for the connectivity are as follows:
*        atom i is defined as being at a distance from the nearest
*        atom j, atom j already having been defined.
*        atom i makes an angle with atom j and the atom k, which has
*        already been defined, and is the nearest atom to j
*        atom i makes a dihedral angle with atoms j, k, and l. l having
*        been defined and is the nearest atom to j (or if none is
*        unique then the nearest to k), and j, k and l
*        have a contained angle in the range 15 to 165 degrees,
*        if possible.
*
*        if geo[1].atomA == -1 then the original connectivity is used.
*
*        note that geo and xyz must not be the same in the call.
*
*   on input xyz    = cartesian array of numat atoms
*
***********************************************************************/
	long i, j, k, l;
	double xdiff, ydiff, zdiff, sum, r, min_distance;
	char errs[256];

	if (numDummyAtoms > 0) {
		xyz[1][1] = xyz[0][1]; /* align Y value of first dummy with first atom */
		xyz[1][2] = xyz[0][2]; /* Z coordinate the same as the first real atom */
		xyz[2][2] = xyz[0][2];
	}

    if (geo[1].atomA == -1) {
        geo[1].atomA = 0;
        for (i=1; i < numat; i++) {
			/* check for correct assignments */
			if (i == 1 && i <= geo[i].atomA) {
				sprintf(errs,
					   "cartesianToInternal: received bad attachments to atom %d: %d %d %d",
					   i, geo[i].atomA, geo[i].atomB, geo[i].atomC);
				alert_user(errs);
			}
			if (i == 2 && (i <= geo[i].atomA || i <= geo[i].atomB ||
				geo[i].atomA == geo[i].atomB)) {
				sprintf(errs,
					   "cartesianToInternal: received bad attachments to atom %d: %d %d %d",
					   i, geo[i].atomA, geo[i].atomB, geo[i].atomC);
				alert_user(errs);
			}
			if (i > 2 && (i <= geo[i].atomA || i <= geo[i].atomB || i <= geo[i].atomC ||
				geo[i].atomA == geo[i].atomB || geo[i].atomB == geo[i].atomC ||
				geo[i].atomA == geo[i].atomC)) {
				sprintf(errs,
					   "cartesianToInternal: received bad attachments to atom %d: %d %d %d",
					   i, geo[i].atomA, geo[i].atomB, geo[i].atomC);
				alert_user(errs);
			}
            j=geo[i].atomA;
            k=geo[i].atomB;
            l=geo[i].atomC;
            if(i > 2) geo[i].dihedral = dihedral(xyz, i, j, k, l);
            if(i > 1) geo[i].angle = atomAngle(xyz, i, j, k);
			xdiff = xyz[i][0] - xyz[j][0];
			ydiff = xyz[i][1] - xyz[j][1];
			zdiff = xyz[i][2] - xyz[j][2];
            geo[i].distance = sqrt(xdiff*xdiff +
               					   ydiff*ydiff + zdiff*zdiff);
		}
	} else {
	  long nLinear, bond, ldx;
	  long atom1, atom2;
	  long *bondListPointer;
 	  CharH bondDefined = NULL;
	  
	  /* build an triangular logical array indicating which atoms are bonded */
	  nLinear = (numat*(numat+1))/2;
	  if ((bondDefined = (CharH) NewHandle(nLinear*sizeof(char))) == NULL) {
		sprintf (errs,"cartesianToInternal: bondDefined memory request %ld too large\n",
				 nLinear*sizeof(char));
		alert_user(errs);
		return (MOPACerrors);	 
	  }
	  HLock((Handle) bondDefined);
	  for (i = 0; i < nLinear; i++) (GetPtr(bondDefined))[i] = false;
		
		/*
		   Mark the bondDefined array to indicate that the bond exists.
		*/
		for (bond=0; bond<numberBonds; bond++) {
		  bondListPointer = bondList[bond];
		  atom1 = whichAtomIndex(bondListPointer[0], numat, atomLocation);
		  if (atom1 >= 0) {
			 atom2 = whichAtomIndex(bondListPointer[1], numat, atomLocation);
			 if (atom2 < 0) {
			 	sprintf(errs,"cartesianToInternal: atom %d is not in this molecule.", bondListPointer[1]);
			 	alert_user(errs);
			 } else {
			 	ldx = (atom1>atom2) ? ((atom1*(atom1+1))/2 + atom2) : ((atom2*(atom2+1))/2 + atom1);			
			 	(GetPtr(bondDefined))[ldx] = true; /* indicate that this bond order is already updated */
			 }
		  }
		}
		
		 geo[0].atomA = 1;
		 geo[0].atomB = 2;
		 geo[0].atomC = 3;
		 geo[1].atomB = 2;
		 geo[1].atomC = 3;
		 geo[2].atomC = 3;

		 /* 
		  * The second atom HAS to be attached to the first.
		  * However, don't change the attachment if this atom
		  * is the moving atom in a label, since its attachements
		  * are determined from the label.
		  */

		 if (geo[1].varyDistance != -1 && geo[1].varyAngle != -1 &&
			  geo[1].varyDihedral != -1)
		 	geo[1].atomA = 0; 
         /* The first two atoms are completely determined */
		 for (i=2; i<numat; i++) { 
		    /* if this atom is moving, then its connectivity is already
			   defined by the search label */
		  if (geo[i].varyDistance != -1 && geo[i].varyAngle != -1 &&
			  geo[i].varyDihedral != -1) {
		    long kB, kA;
			double sumB;
			
            /* if you can't figure a connection out, use these atoms.  Note:
			   some of these will be reset later because atom 0, 1, 2 
			   have special requirements. */

			geo[i].atomA = 1;
			geo[i].atomB = 2;
			geo[i].atomC = 3;
			kA = -1;
            sum=1.e30;
			min_distance=0.1; /* minimum distance for nearest non-bonded atom */
			kB = -1;
            sumB=1.e30;
			
              for (j=0; j < i; j++) {
			    xdiff = xyz[i][0] - xyz[j][0];
			    ydiff = xyz[i][1] - xyz[j][1];
			    zdiff = xyz[i][2] - xyz[j][2];
                r = sqrt(xdiff*xdiff + ydiff*ydiff + zdiff*zdiff);
				  if ((r>min_distance) && (r < sum)) {
				  	/* find the atom which is closest but not too close */
					  sum = r;
					  kA = j;
				  }
				  if (r < sumB) {
				     /* are i and j bonded? */
			 		  ldx = (i > j) ? ((i*(i+1))/2 + j) : ((j*(j+1))/2 + i);
					  if ((GetPtr(bondDefined))[ldx]) {
						 sumB = r;
						 kB = j;
					  }
				  }
              }

              k=kA;
/* If nothing is closest, assign k to the first atom */
			  if (kA == -1) k = 0;
/* if there is a bonded atom, take the closest bonded atom */
			  if (kB != -1) k = kB;

/*
    atom k is either the nearest bonded atom, or if there are no bonded
	atoms, then it is the nearest atom to atom i which has an atom number
	less than i.
*/
			  geo[i].atomA = k;

			  geo[i].atomB = geo[k].atomA; /* note that if k is 0 then geo[0].atomA is 1.
			  								     this also implies that if i were 1 then
											     k would be 0 so geo[1].atomB would be set 
												 to 1, which causes problems later.
											  */
			/* 
				Fixup for atoms that are bonded to the same atom as a moving atom in
			  	a dihedral search label.  Look through previous atoms and see if there
				are any that are bonded to the same atomA that have a dihedral search 
				set.  If so, and if the atom under consideration is NOT in the previous
				atom's label, set the connectivity to be the same atomB as the moving
				atom in the dihedral search label, and atomC to be the moving atom
				in the dihedral search label.
			*/
		
			  l = -1;
			
			  if (i > 3) {
			  	for (j = i-1; j >= 3; j--) { /* loop over previous atoms that have dihedrals*/
				  /* 
				  	Exclude dummy atoms from consideration if there are
					dummy atoms and if the atom uder consideration (i) is
					more than two beyond the dummy atoms.
				  */
				  
				  if ((numDummyAtoms > 0) && (i > numDummyAtoms + 2) 
				  	&& ((j <= numDummyAtoms) && (j != 0)))
						continue;
						
				  /* possible candidates:  same atomA, and is a dihedral search */
				  if ((geo[j].atomA == geo[i].atomA) 
				  	&& (geo[j].varyDihedral == -1)) {
				  
				  	/* Do not use this connectivity if the atom under consideration
					   is atomB or atomC */
				  	if ((i != geo[j].atomB) && (i != geo[j].atomC)) {
						geo[i].atomB = geo[j].atomB;
						geo[i].atomC =j;
						l = geo[k].atomC;
					}
				  }
				}
			  }

			  if ((i > 2) && (l == -1)) { /* do not assign atomC if set previously */	
				l = -1;
				/* Find another atom attached to geo[i].atomA which has
				   an atom number smaller than i, which is not
				   already used to describe i's position and which
				   is either not involved in a label with geo[i].atomA or
				   if it is involved with at label, then it is bonded.
				 */
				for (j = i-1; j >= 0; j--) {

				  if ((geo[j].atomA == geo[i].atomA) && (j != geo[i].atomB)) {
				    if (geo[j].varyDihedral != -1 && geo[j].varyDistance != -1
					    && geo[j].varyAngle != -1) {
					   l = j;
					   break;
					} else {
					   if (geo[j].varyDihedral == -1) {
					      int  a1, a2;
						  long ldx;
					      a1 = geo[j].atomA;
						  a2 = geo[a1].atomA;
						  ldx = (a1 > a2) ? ((a1*(a1+1))/2 +a2) : ((a2*(a2+1))/2 + a1);
						  if ((GetPtr(bondDefined))[ldx]) {					   
							  l=j;
							  break;
						  }
					   }
					}
				  }
				}
				if (l >= 0) geo[i].atomC = l;
				else geo[i].atomC = geo[geo[i].atomA].atomB; /* note that if geo[i].atomA is
															    0 then geo[0].atomB is 2
					 											if geo[i].atomA is 1 then
																geo[1].atomB is 2  because 
																of the intialization! */
			  }
			/* check for correct assignments */
			  if (i == 2) {
			  	if (i <= geo[i].atomA || i <= geo[i].atomB || 
				  geo[i].atomA == geo[i].atomB ) {
					sprintf(errs,
						"cartesianToInternal: error in attachments to "
						"atom %d: %d %d",
						 i, geo[i].atomA, geo[i].atomB);
					alert_user(errs);
				}
			  } else if (i <= geo[i].atomA || i <= geo[i].atomB || i <= geo[i].atomC ||
				  geo[i].atomA == geo[i].atomB || geo[i].atomB == geo[i].atomC ||
				  geo[i].atomA == geo[i].atomC) {
				 sprintf(errs,
					"cartesianToInternal: error in attachments to atom %d: %d %d %d",
					 i, geo[i].atomA, geo[i].atomB, geo[i].atomC);
				 alert_user(errs);
			  }
   			}
		}
		if (bondDefined != NULL) {
			HUnlock((Handle) bondDefined);
			DisposHandle((Handle) bondDefined);
		}  
  }

/* Cleanup from the initialization */
  geo[0].atomA = -1;
  geo[0].atomB = -1;
  geo[0].atomC = -1;
  geo[1].atomB = -1;
  geo[1].atomC = -1;
  geo[2].atomC = -1;
  xyzgeo(xyz,numat,geo);

  return 0;

}

void xyzgeo(double xyz[][3], int numat, Zmatrix geo[])
/***********************************************************************
*
*   xyzgeo converts coordinates from cartesian to internal.
*
*     on input xyz  = array of cartesian coordinates
*              numat= number of atoms
*
*    on output geo  = internal coordinates in angstroms, radians,
*                     and radians
*
***********************************************************************/
{
   int i, j, k, l, i1;
   double angle, tol, sum, r, min_distance;
   double xdiff, ydiff, zdiff;
   
     for (i=1; i<numat; i++) {
         j=geo[i].atomA;
         k=geo[i].atomB;
         l=geo[i].atomC;
         if (i > 1) {
			/*
    		   make sure angle is meaninglful for following dihedrals  SJC 10/19/91
			   only do this for atom 3 onwards, so that atomC is defined SJC 2/28/92
			*/
             angle = atomAngle(xyz,i,j,k);
			 tol=0.087266;        /* 5� */
             if (i > 2 && ((angle > PI - tol) || (angle < tol))) {
				/*
   				  angle is unsatisfactory, let's try inverting the
				  order of atomB and atomC. 
				*/
				double angle1, angle2;
				angle1 = atomAngle(xyz,i,j,l); /* these two angles make the dihedral */
				angle2 = atomAngle(xyz,j,l,k); /* only use them if the dihedral will be 
												defined after the switch */
				if (geo[i].varyAngle != -1) { /* Do not use locked angles */
					if (((angle1 < (PI - tol)) && (angle1 > tol)) && 
							(angle2 < (PI - tol)) && (angle2 > tol)) {
						geo[i].atomB = l;
						geo[i].atomC = k;
						k = geo[i].atomB;
						l = geo[i].atomC;
						angle = atomAngle(xyz,i,j,k);
					}
				}
       	   }
           geo[i].angle = atomAngle(xyz, i, j, k) * RadianToDegree;
           if (i > 2) {
			/*
    		   make sure dihedral is meaninglful
			*/
             angle = atomAngle(xyz,j,k,l);
             /* tol=0.2617994;     15�  */
			 tol=0.087266;        /* 5� */
             if ((angle > PI - tol) || (angle < tol)) {
				/*
   				  angle is unsatisfactory, let's search for another 
   				  atom for defining the dihedral. 
				*/
newTolerance:
                sum=100.;
				min_distance = 0.01;
				for (i1=0; i1 < i; i1++) {
			       xdiff = xyz[i1][0] - xyz[k][0];
			       ydiff = xyz[i1][1] - xyz[k][1];
			       zdiff = xyz[i1][2] - xyz[k][2];
                   r = xdiff*xdiff + ydiff*ydiff + zdiff*zdiff;
                   if ((r < sum) && (r > min_distance) && (i1 != j) && (i1 != k)) {
                      angle = atomAngle(xyz,j,k,i1);
                      if ((angle < (PI - tol)) && 
					     (angle > tol)) {
                            sum=r;
                            l=i1;
                            geo[i].atomC = l;
                      }
                   }
                }
            if (sum > 99. && tol > 0.1) {
/*
  anything within 3 degrees?
*/
               tol=0.05236;
               goto newTolerance;
            }
         }
         geo[i].dihedral = dihedral(xyz, i, j, k, l) * RadianToDegree;		 
	    }
	  }
	  xdiff = xyz[i][0] - xyz[j][0];
	  ydiff = xyz[i][1] - xyz[j][1];
	  zdiff = xyz[i][2] - xyz[j][2];
      geo[i].distance = sqrt(xdiff*xdiff + ydiff*ydiff + zdiff*zdiff);
	}
	geo[0].distance = 0.;
	geo[0].angle = 0.;
	geo[0].dihedral = 0.;
	geo[1].angle = 0.;
	geo[1].dihedral = 0.;
	geo[2].dihedral = 0.;
}

double atomAngle(xyz,i,j,k)
double xyz[][3];
int	   i, j, k;
/*********************************************************************
* atomAngle calculates the angle between atoms i,j, and k. the
*        cartesian coordinates are in xyz.
*********************************************************************/
{
	double xdiff, ydiff, zdiff;
	double d2ij, d2jk, d2ik;
	double temp, angle;
	
	  xdiff = xyz[i][0] - xyz[j][0];
	  ydiff = xyz[i][1] - xyz[j][1];
	  zdiff = xyz[i][2] - xyz[j][2];
      d2ij = xdiff*xdiff + ydiff*ydiff + zdiff*zdiff;
	  
	  xdiff = xyz[j][0] - xyz[k][0];
	  ydiff = xyz[j][1] - xyz[k][1];
	  zdiff = xyz[j][2] - xyz[k][2];
      d2jk = xdiff*xdiff + ydiff*ydiff + zdiff*zdiff;

	  xdiff = xyz[i][0] - xyz[k][0];
	  ydiff = xyz[i][1] - xyz[k][1];
	  zdiff = xyz[i][2] - xyz[k][2];
      d2ik = xdiff*xdiff + ydiff*ydiff + zdiff*zdiff;

      temp = sqrt(d2ij*d2jk);
      temp = 0.5 * (d2ij + d2jk - d2ik) / temp;
      if (temp > 1.0) temp=1.0;
      if (temp < -1.0) temp=-1.0;
      angle = acos(temp);
	  return (angle);
}

double dihedral(xyz,i,j,k,l)
double xyz[][3];
int i, j, k, l;
/*********************************************************************
*
*      dihedral calculates the dihedral angle between atoms i, j, k,
*            and l.  the cartesian coordinates of these atoms
*            are in array xyz.
*
*      dihedral has been tested against the MOPAC function DIHED.
*      The results are the same, except that accuracy of
*      dihedral is better than DIHED.
*
*********************************************************************/
{
	double angle;

      /* This function has been extensively tested against the MOPAC
	     function DIHED using a test harness and the results
		 are identical to 1.e-11 except when atoms are in the yz plane.
		 In that case, the MOPAC results are in error by 0.0004 radians.
		 Consequently, this changed function is more robust.
	  */
      angle = cmu_DiheAngle(&xyz[i][0],&xyz[j][0],&xyz[k][0],&xyz[l][0]);
      if (angle < 0.) angle = 4.0*asin(1.0) + angle;
	  /* if angle is greater than 2� return 0. */
	  if (angle > 4.*asin(1.0)) angle = 0.;

	  return (angle);
}
