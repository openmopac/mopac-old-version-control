#if defined(_WIN32)
#include <windows.h>
#endif

#include <string.h>
#include <errno.h>
#include <signal.h>
#include <time.h>

#include <compat.h>
#include <cul.h>
#include <CACheVersion.h>

#define LOCAL_STRING_LENGTH  128

cul_CPMsgChannel msgChannel1;
cul_CPMsgChannel msgChannel2;
cul_CPMsgChannel msgChannel3;
cul_CPMsgChannel msgChannel4;

static time_t time_since_message = 0;
static time_t current_clock;

#if defined(_WIN32)
#define MESSAGE_RETRIES  1
#else
#define MESSAGE_RETRIES  10
#endif

#define MESSAGE_ONE   1
#define MESSAGE_TWO   2
#define MESSAGE_THREE 4
#define MESSAGE_FOUR  8

#if defined(cache_irix)
#define MOPAC_EXE        mopac_
#define SETMSGBUFC       setmsgbufc_
#define SHUTDOWNC        shutdownc_
#define FORTRANEXITC     fortranexitc_
#define DBGBREAK         dbgbreak_
#define GETCACHEVERSION  getcacheversionc_
#elif defined(cache_bsd)
#define MOPAC_EXE        MOPAC
#define SETMSGBUFC       SETMSGBUFC
#define SHUTDOWNC        SHUTDOWNC
#define FORTRANEXITC     FORTRANEXITC
#define DBGBREAK         dbgbreak
#define GETCACHEVERSION  GETCACHEVERSION
#else
#define MOPAC_EXE        mopac
#define SETMSGBUFC       setmsgbufc
#define SHUTDOWNC        shutdownc
#define FORTRANEXITC     fortranexitc
#define DBGBREAK         dbgbreak
#define GETCACHEVERSION  getcacheversionc
#endif

void MOPAC_EXE();
void SETMSGBUFC(long *length, char *string, long *number);
long SHUTDOWNC(long *i);

#if defined(cache_aix) || defined(cache_bsd) || defined(cache_irix)
void stopHandler(int signalNumber);
void waitforrunflag(long *m);
#endif

FILE *debug_stream;

#if defined(cache_aix) || defined(cache_bsd) || defined(cache_irix)
int commIn, commOut;
struct sigaction signalAction;
sigset_t signalSet;
long shutdownflag = 0;
#endif

#define MOPACerrors        -2800 /* base number for CAChe reporting of MOPAC errors. */
#define MOPAC_SHMEM_ATTACH MOPACerrors - 1
#define MOPAC_SHMEM_ENV    MOPACerrors - 2
#define NEXT_ARG(xp) (((xp) - argv + 1) < argc ? (xp) + 1 : NULL) 

#if defined(cache_aix) || defined(cache_bsd) || defined(cache_irix)
main( int argc, char *argv[] )
#else
#error "machine not specified"
#endif
{
    char tbuf[64], buf[256];
    long length, channel_number;
    double t0 = 0.0, t1 = 0.0;

#if defined(cache_aix) || defined(cache_bsd) || defined(cache_irix)
    char **p;
    int processOutputFile; 
    int msgOut1, msgOut2, msgOut3, msgOut4, got_fds;

    if (isatty(fileno(stderr)))
        debug_stream = stderr;
    else if ((debug_stream = fopen("mopacComputeEngine_log","w")) == NULL)
        exit(1);

    /* Get information from argument list & set up communication channels */
    commIn = 0;
    commOut = 1;
    msgOut1 = msgOut2 = msgOut3 = msgOut4 = 2; /* stderr */
    processOutputFile = 0;
    got_fds = 0;

    p = NEXT_ARG(argv);

    while(p)
    {
        if ( strncmp(*p, "-`", 2) == 0 )
        {
            char *fdstring = NULL;

            if (got_fds) {
                got_fds = 0;
                break;
            }

            if ( (*p)[2] )
                fdstring = *p + 2;
            else if (p = NEXT_ARG(p))
                fdstring = *p;

            if ( (fdstring != NULL) && 
                 (sscanf(fdstring, "%d,%d,%d,%d,%d,%d,%d", &commOut, &commIn, 
                         &msgOut1, &msgOut2, &msgOut3, &msgOut4, &processOutputFile) == 7) )
            {
                fprintf(debug_stream, "%s: commOut: %d, commIn: %d\n", argv[0], commOut, commIn);
                fprintf(debug_stream, "msgOut1: %d, msgOut2: %d, msgOut3: %d, msgOut4: %d\n", 
                                       msgOut1, msgOut2, msgOut3, msgOut4);
                fprintf(debug_stream, "processOutputFile: %d\n", processOutputFile);
                fflush(debug_stream);
                got_fds = 1;
            } else
                break;

        } else {

            /* Arguments not correct for file descriptors */
            got_fds = 0;
            break;
        }

        p = NEXT_ARG(p);
    }

    if ( !got_fds )
    {
        fprintf(debug_stream, "usage: %s -` commOut,commIn,fd1,fd2,fd3,fd4,processOutputFile\n", argv[0]);
        fflush(debug_stream);
        fclose(debug_stream);
        exit(1);
    }

    // Initialize the message channel

    cul_attachCPMessageChannel(&msgChannel1, -1, msgOut1, 1);
    cul_attachCPMessageChannel(&msgChannel2, -1, msgOut2, 1);
    cul_attachCPMessageChannel(&msgChannel3, -1, msgOut3, 1);
    cul_attachCPMessageChannel(&msgChannel4, -1, msgOut4, 1);

    /*
    ** Signals are blocked on entry. Cause the SIGTERM signal
    ** to immediately terminate the application, and the
    ** SIGINT signal to set the 'stop' flag. Unblock
    ** all other signals.
    */

    signalAction.sa_handler = SIG_DFL;
    sigemptyset(&signalAction.sa_mask);
    signalAction.sa_flags = 0;

    if ( sigaction(SIGTERM, &signalAction, 0) == -1 )
    {
        fprintf(debug_stream, "%s: Unable to set default SIGTERM handling, errno = %d\n", argv[0], errno);
        fflush(debug_stream);
    }

    signalAction.sa_handler = stopHandler;
    sigemptyset(&signalAction.sa_mask);
    signalAction.sa_flags = 0;

    if ( sigaction(SIGINT, &signalAction, 0) == -1 )
    {
        fprintf(debug_stream, "%s: Unable to set default SIGINT handling, errno = %d\n", argv[0], errno);
        fflush(debug_stream);
    }

    sigfillset(&signalSet); // Unblock all signals

    if ( sigprocmask(SIG_UNBLOCK, &signalSet, 0) == -1 )
    {
        fprintf(debug_stream, "%s: Unable to block signals, errno = %d\n", argv[0], errno);
        fflush(debug_stream);
    }

    // Wait for the application request server to start up.

    waitforrunflag(0);

    // Send the application version to the scrolling status region.

    strcpy(buf, argv[0]);
    strcat(buf, " " CACHE_VERSION " " __DATE__ " " __TIME__ "\n");
    length = strlen(buf);
    channel_number = MESSAGE_ONE;
    SETMSGBUFC(&length, buf, &channel_number);
#endif
    
    // Check to see if processing an output file.

    if ( processOutputFile != 0 )
    {
        // Tell the ApplReqServer to process output.
        sprintf(buf, "Calculation done.");
        length = strlen(buf);
        channel_number = MESSAGE_FOUR;
        SETMSGBUFC(&length, buf, &channel_number);

        sprintf(buf,"All done");
        length = strlen(buf);
        channel_number = MESSAGE_TWO;
        SETMSGBUFC(&length, buf, &channel_number);

    } else {

        t0 = cul_seconds();
        MOPAC_EXE();
        t1 = cul_seconds();

        cul_elapsedtime(t0,t1,tbuf);

        sprintf(buf, "Computation time: %s\n", tbuf);
        length = strlen(buf);
        channel_number = MESSAGE_ONE;
        SETMSGBUFC(&length, buf, &channel_number);
    }
    
    fflush(debug_stream);
    fclose(debug_stream);
}


void SETMSGBUFC(long *length, char *string, long *number)
{
    char buf[LOCAL_STRING_LENGTH];
    short n;
    
   // Fortran strings are not necessarily NULL terminated so copy and then null
   // terminate the new string.  Add a line feeds to string as well.

    if ( *length < LOCAL_STRING_LENGTH - 2 )
    {
        memcpy(buf, string, *length);
        buf[(*length)  ] = '\n';
        buf[(*length)+1] = 0;

    } else {

        memcpy(buf, string, LOCAL_STRING_LENGTH - 2);
        buf[LOCAL_STRING_LENGTH - 2] = '\n';
        buf[LOCAL_STRING_LENGTH - 1] = 0;
    }

    // Put the message into the appropriate message buffer:

    // MESSAGE_ONE   goes to the scrolling status
    // MESSAGE_TWO   goes to the Current operation area of the MOPAC Status dialog
    // MESSAGE_THREE goes to the Current calculation area of the MOPAC Status dialog
    // MESSAGE_FOUR  goes to the scrolling status AND signals the application request
    //               server that the output file is to be processed

    switch (*number)
    {
        case MESSAGE_ONE:

            for ( n = 0 ; n < MESSAGE_RETRIES; n++ )
                if ( cul_sendCPMessageWait(&msgChannel1, buf, 0) == CUL_MSGS_SENT )
                    break;

            break;

        case MESSAGE_TWO:

            // This is the least critical message.  OK to drop on the floor. 
            // NOTE!!! Only send at most one message per second.

            current_clock = time(NULL);

            if ( difftime(current_clock,time_since_message) >= 1.0 ) // More than a second has elapsed.
            {
                cul_sendCPMessage(&msgChannel2, buf);
                time_since_message = time(NULL);
            }

            break;

        case MESSAGE_THREE:

            for ( n = 0 ; n < MESSAGE_RETRIES; n++ )
                if ( cul_sendCPMessageWait(&msgChannel3, buf, 0) == CUL_MSGS_SENT )
                    break;

            break;

        case MESSAGE_FOUR:

            // This is a critical message.

            // Wait for the server to set the 'ready' flag to be sure that the
            // server will see the message.

            // Put the message into the scrolling status channel and into the
            // "Calculation done" channel.

            for ( n = 0 ; n < MESSAGE_RETRIES; n++ )
                if ( cul_sendCPMessageWait(&msgChannel1, buf, 0) == CUL_MSGS_SENT )
                    break;

            for ( n = 0 ; n < MESSAGE_RETRIES; n++ )
                if ( cul_sendCPMessageWait(&msgChannel4, buf, 0) == CUL_MSGS_SENT )
                    break;

            // Pass the runFlag token to the manager.
            if ( write(commOut, "x", 1) != 1 )
            {
            } else {
            }

            // Wait for the server to indicate that it is ready and then set the
            // client flag to 'ready'.

            waitforrunflag(0);

            break;
    }
}


void GETCACHEVERSION(char *string, unsigned int length)
{
    strncpy(string, CACHE_VERSION, length-1);
    string[length-1] = '\0';
}


long SHUTDOWNC(long *i)
{  
    return (shutdownflag);
}


void FORTRANEXITC(long *m)
{
    exit(*m);
}


//void DBGBREAK()
//{
//    DebugBreak();
//}


#if defined(cache_aix) || defined(cache_bsd) || defined(cache_irix)
void stopHandler(int signalNumber)
{
    shutdownflag = 1; // Set the shutdown flag
}


void waitforrunflag(long *m) // FORTRAN requires an argument
{
    char buf[LOCAL_STRING_LENGTH];

    // Wait for the runFlag token.

    buf[1] = 0;

    if ( read(commIn, buf, 1) != 1 )
        exit(1);
}
#endif
