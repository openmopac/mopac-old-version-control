#define		RadianToDegree			57.2957795131
#define		DegreeToRadian			0.017453292

/* Prototypes for routines shared with other applications */
#ifdef __cplusplus	/* For type-safe linkage */
extern "C" {		/* Specify "C"-style linkage */
#endif
void 	alert_user_watch(char *errs);
double 	atomAngle(double xyz[][3],int i,int j,int k);
long 	atomicNumber(char *symbol);
void 	enterBusyState();
int		cancelOrProceedDialog(char *string, char *OKText, char *cancelText);
int		cartesianToInternal(double xyz[][3], long numat, Zmatrix geo[],
					long numberBonds, long (*bondList)[2],
					long atomLocation[], long numDummyAtoms);
long 	cleanUpZmatrix(
			long	NAtom,
			long numDummyAtoms,
			long numLockedAtoms,
			long *lockedAtoms,
			long numSearchLabels,
			SearchLabel *searchLabels,
			long numLockedLabels,
			LockedLabel *lockedLabels,
			Zmatrix *zMatrix,
			double (*coords)[3],
			long *atomLocation,
			long numberBonds,
			long (*bondList)[2]
		);
long	findAtom(long k, long atomLocation[], long NAtom);
void	getLockedAtoms(MolStruct *molStruct, long lockedAtoms[], 
		long NAtom);
void	getLockedLabels(MolStruct *molStruct, LockedLabel lockedLabels[]);
long 	getMolecularFormula(MolStruct *molStruct, char *formula, int maxLength);
long	getNumberDummyAtoms(MolStruct *molStruct, int NAtom);
long	getNumberLockedAtoms(MolStruct *molStruct, int NAtom);
long	getNumberLockedLabels(MolStruct *molStruct);
int		getSearchLabels(MolStruct *molStruct,
		SearchLabel searchLabels[], int max_num_labels);
void	inform_user_watch(char *errs);
void	instruct_user_watch(char *errs);
int		internalToCartesian (double  xyz[], int natoms,
        Zmatrix geo[], int labels[]);
void 	leaveBusyState();
int		lockedAdjust(MolStruct *wp, ObjectID atom_list[], 
		ObjclsID objclsID, double *LockVal);
short 	moleculeNetCharge(MolStruct *molStruct);
void	note_user(char *s);
void 	renumberSearchLabels(SearchLabel searchLabels[], long numSearchLabels,
		long NAtom, long atomLocation[]);
void 	renumberLockedLabels(LockedLabel lockedLabels[], long numLockedLabels,
		long NAtom, long atomLocation[]);
void 	renumberForFirstAtom(int i, LockedLabel lockedLabels[], long numLockedLabels,
		long NAtom, long atomLocation[], double coords[][3], long numDummyAtoms);
void 	renumberForMovingAtom(int i, SearchLabel searchLabels[], long numSearchLabels,
		long NAtom, long atomLocation[], double coords[][3], long numDummyAtoms);
int 	reorderForLockedAtoms(double coords[][3], long NAtom, 
				long atomLocation[],
				long lockedAtoms[], long numLockedAtoms,
				SearchLabel searchLabels[], long numSearchLabels,
	 			LockedLabel lockedLabels[], long numLockedLabels,
				long numDummyAtoms);
long 	reorderForLockedLabels(double coords[][3],long NAtom, long atomLocation[],
	 			 LockedLabel lockedLabels[], long numLockedLabels,
				 long numDummyAtoms);
void 	reorderForLabels(double coords[][3],long NAtom,long atomLocation[],
	 			 SearchLabel searchLabels[], long numSearchLabels,
				 long numDummyAtoms);
int		reorderMovingAtomsInLabels(SearchLabel searchLabels[], 
					Boolean switchedSearchLabel[]);
void 	replaceBlanks(char *s, char c);
int 	resolveLockedLabelConflicts(long *atomID, char (*atsymbol)[2],
				long lockedAtoms[], LockedLabel lockedLabels[],
				SearchLabel searchLabels[], long *numLockedAtoms, 
				long *numLockedLabels, long numSearchLabels,
				Boolean switchedSearchLabel[]);
void 	reverseLabelOrder(LockedLabel lockedLabels[], int m);
void 	reverseSearchOrder(SearchLabel searchLabels[], int m);
void 	slideAtoms(long k, long next, double coords[][3],
         		long atomLocation[], long numDummyAtoms);
void	slideAtomForward(long k, long next, double coords[][3],
         		long atomLocation[], long numDummyAtoms);
void 	swapAtoms(long k, long next, double coords[][3],
          long atomLocation[], long numDummyAtoms);

#ifdef __cplusplus	/* For type-safe linkage */
}		/* Specify "C"-style linkage */
#endif
