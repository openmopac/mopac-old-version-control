// cel.h -- defines CAChe error return codes
#ifndef _CEL_
#define _CEL_
typedef long CelErr;
#endif
