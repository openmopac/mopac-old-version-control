#include "compat.h"

#include "ZINDODriver.h"

int getMolecularCharge(int *mol_charge)
{
	FILE *input = NULL;
	char aString[255];

	*mol_charge = 0;

	if (!(input = fopen("OUTPUT file", "r"))) {
		sprintf(aString,"getMolecularCharge: "
				"The ZINDO Output file cannot be opened.\n");
		alert_user(aString);
		return -1;
	} else {
		for (;;) {
			if (fgets(aString, sizeof(aString), input) == 0) 
				break;
			if (strncmp(aString, " NET CHARGE =", 13) == 0) {
				sscanf(&aString[13], "%d", mol_charge);
				break;
			}
		}
		fclose(input);
	}
	return 0;
}
