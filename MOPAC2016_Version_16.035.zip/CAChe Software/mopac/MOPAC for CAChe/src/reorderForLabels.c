#include "compat.h"
#include "csu.h"
#include "MOPACDriver.h"

void reorderForLabels(double coords[][3],long NAtom,long atomLocation[],
	 			 SearchLabel searchLabels[], long numSearchLabels,
				 long numDummyAtoms)
/*
	SearchLabels defined in the Molecule Editor are used to vary internal
	coordinates in a molecule during a reaction coordinate or grid calculation.
	So that MOPAC can implement search labels, the driven internal coordinates 
	must be defined in the z-matrix.  Defining a z-matrix with specific internal
	coordinates may require renumbering the atoms in the molecule.  This 
	function does that renumbering.
*/
{
	long next, j, k, l;
	long	moving[2];
	long limit;

	if (numSearchLabels > 0) {
	/*
	   Assume that only one label can have the moving
	   atom of the other label as one of its non moving
	   atoms.  Make that label the second label.
	*/
		moving[0] = searchLabels[0].atomList[1];
		moving[1] = searchLabels[1].atomList[1];

		if (numSearchLabels == 2) {
			/*
			   Look through the atoms in search label 0 to findout
			   whether it contains the moving atom from in search
			   label 1.  If it does, switch the two labels so that
			   search label 0 becomes search label 1 and vice versa.
			   Then quit. 
			*/
			/* atomList[0] is the number of atoms in the label */
			for (j=searchLabels[0].atomList[0]; j > 0; j--) {
				k = searchLabels[0].atomList[j];
				if (k == moving[1]) {
					SearchLabel temp;
					temp = searchLabels[0];
					searchLabels[0] = searchLabels[1];
					searchLabels[1] = temp;
					l = moving[1];
					moving[1] = moving[0];
					moving[0] = l;
					break;
				}
			}
		}

		/* 
		  Now move all of the atoms mentioned in search label 0
		  to the first positions in the z-matrix.
		*/
		next = 0;
		if (moving[0] == moving[1] && numSearchLabels == 2) limit = 1;
		else limit = 0;
		for (j=searchLabels[0].atomList[0]; j > limit; j--) {
			k = findAtom(searchLabels[0].atomList[j],
						 atomLocation, NAtom);
			slideAtoms(k, next, coords, atomLocation, numDummyAtoms);
			next++;
			if (next <= numDummyAtoms)
				next = numDummyAtoms+1; 
		}
		
		if (numSearchLabels == 2) {
			/* 
			  Now move all of the atoms mentioned in search label 1
			  to the first positions in the z-matrix not taken by
			  the search atoms in search label 0.
			*/
			for (j=searchLabels[1].atomList[0]; j > 0; j--) {
				k = findAtom(searchLabels[1].atomList[j],
							 atomLocation, NAtom);
				if (k >= next) {
					slideAtoms(k, next, coords, atomLocation, numDummyAtoms);
					next++;
					if (next <= numDummyAtoms)
						next = numDummyAtoms+1; 
				}
			}
		}		
		
	 }
}

long findAtom(long k, long atomLocation[], long NAtom)
/*
    findAtom returns the position of atom k in the atomLocation
		array.
*/
{
	long j;
	
	if (k < 0 || k >= NAtom) return (-1);
	for (j=0; j<NAtom; j++) 
	   if (k == atomLocation[j]) return(j);

	return (-1);
}

void swapAtoms(long k, long next, double coords[][3],
          long atomLocation[], long numDummyAtoms)
{
   long l;
   double x;
   
	for (l=0; l < 3; l++) {
		x = coords[next][l];
		coords[next][l] = coords[k][l];
		coords[k][l] = x;
	}
	l = atomLocation[next];
	atomLocation[next] = atomLocation[k];
	atomLocation[k] = l;
	
	if (numDummyAtoms > 0) { /* fix up Y and Z coordinates on dummy atoms */
		if (k == 0) {
			coords[1][1] = coords[k][1];
			for (l=0; l < numDummyAtoms; l++)
				coords[l+1][2] = coords[k][2];
		} else if (next == 0) {
			coords[1][1] = coords[next][1];
			for (l=0; l < numDummyAtoms; l++)
				coords[l+1][2] = coords[next][2];
		}
	}
}

void slideAtoms(long k, long next, double coords[][3],
         		long atomLocation[], long numDummyAtoms)
{
   long l, i, j;
   double x, y, z;
  

	if (k > next) { /* don't do this if k == next or k < next */   
		x = coords[k][0];
		y = coords[k][1];
		z = coords[k][2];
		j = atomLocation[k];
	
		if ((next == 0) && (numDummyAtoms > 0)) {
		/* slide atom k to the "0" position, but leave dummy atoms immediatly
		   after the "0" position */
			for (i = k-1; i >numDummyAtoms; i--) {
				for (l=0; l < 3; l++) coords[i+1][l] = coords[i][l];
				atomLocation[i+1] = atomLocation[i];
			}
			/* move atom in "0" position to follow the dummy atoms */
			for (l=0; l < 3; l++) coords[numDummyAtoms+1][l] = coords[next][l];
			atomLocation[numDummyAtoms+1] = atomLocation[next];
			
		} else {
			for (i = k-1; i >= next; i--) {
				for (l=0; l < 3; l++) coords[i+1][l] = coords[i][l];
				atomLocation[i+1] = atomLocation[i];
			}
		}
	
		coords[next][0] = x;
		coords[next][1] = y;
		coords[next][2] = z;
		atomLocation[next] = j;
		
		/* if a new atom was placed in the "0" position, reset the Y coordinate
		   on the first dummy atom, and the Z coordinate on all the dummy atoms */
		   
		if ((next == 0) && (numDummyAtoms > 0)) {
			coords[1][1] = coords[next][1];
			for (i=0; i < numDummyAtoms; i++)
				coords[i+1][2] = coords[next][2];
		}
	}
}
