#include "compat.h"
#include "cpu.h"

long getNumberLockedAtoms(MolStruct *molStruct, int NAtom)
{
	BitH	XYZLockH;
	long 	numLockedAtoms;
	long	i;
	
	csu_GetPropArrays(molStruct, AtomID, XYZID, &XYZLockH, NULL, NULL);
	for (i=0, numLockedAtoms=0; i<NAtom; i++) {
		if (csu_GetBit(XYZLockH, i)) 
			/* value of lockedAtoms is true if the atom has locked 
			   Cartesian coordinates */
			numLockedAtoms++;
	}
	return (numLockedAtoms);
}
