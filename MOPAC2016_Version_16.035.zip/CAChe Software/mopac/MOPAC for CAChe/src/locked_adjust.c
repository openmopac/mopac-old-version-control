#include "compat.h"
#include "cpu.h"

int lockedAdjust(MolStruct *wp, ObjectID atom_list[], ObjclsID objclsID, double *LockVal)
{

/*  atom_list contains shorts that define the atom indices, the first element in the
**	array is the number of atoms to come, the calling routine must open this array
**	to its appropriate size -- (number of atoms + 1).
**	This routine then returns an int which indicates whether the interaction defined
**	by the atom list is locked or not -- negative values means the interaction is 
**	NOT locked.									
**	
**	This code furnished courtesy of Andy Spencer.			8/2/89		*/


	ConnProps conn_props;
	ShortH objcls1H, objcls2H; /* connector prop values */
	LongH obj1H, obj2H;
	DoubleH lockvalueH;		/*  a pointer to the locked values  */
	BitH obj_lockH, conn_validH;
	long num_valloc, a, i, j;
	ObjectID object_id;
	ObjclsID  atomN, objclsN;
	Boolean found_fw; // found in forward or reverse direction (found_rv variable not currently declared)
	
	if (objclsID < 0 || atom_list[0] < 1)
		return(-1);
	if (objclsID == Atom_distID) {
		if (atom_list[0] != 2)
			return -1;
		if (csu_GetPropArrays(wp, objclsID, DistanceID, &obj_lockH, NULL, (ValueH *)&lockvalueH) < 1)
			return -1;
	}
	else {
		if (objclsID == Bond_angID) {
			if (atom_list[0] != 3)
				return -1;
		}
		else if (atom_list[0] != 4) /* ImproperTorsionID or DihedralID */
			return -1;
		if (csu_GetPropArrays(wp, objclsID, AngleID, &obj_lockH, NULL, (ValueH *)&lockvalueH) < 1)
			return -1;
	}

	if (cpu_GetConnProps(wp, &conn_props) < 0)
		return(-1);
	num_valloc = conn_props.num_valloc;
	objcls1H = conn_props.objcls1H;
	objcls2H = conn_props.objcls2H;
	obj1H = conn_props.obj1H;
	obj2H = conn_props.obj2H;
	conn_validH = conn_props.validH;
	
	atomN = (GetPtr(DataDict.objclsdictH)+AtomID)->objclsN;
	objclsN = (GetPtr(DataDict.objclsdictH)+objclsID)->objclsN;
	
	/* find the adjust object class in the connector list */
	for (i = 0; i < num_valloc; ) {
		if (*(GetPtr(objcls2H) + i) != objclsN
		 || !csu_GetBit(conn_validH, i)
		 || *(GetPtr(objcls1H) + i) != atomN
		 || (object_id = *(GetPtr(obj2H) + i)) < 0) {
			i++;
			continue;
		}
			
		/* Found matching adjust object class now see if atom numbers match list. */
		a = atom_list[0]; /* number of atoms in list */
		j = i; /* connector index */
		found_fw = false; // found_rv = false;
		if (!csu_GetBit(obj_lockH, object_id)) /* label is not locked */
			a = 0;
		else if (objclsID == ImproperTorsionID) {
			/* find the four atoms in order 1,2,3,4 or 1,2,4,3 */
			if (*(GetPtr(obj1H) + i) != atom_list[1])
				j = num_valloc;
			a = 1;
			/* first atom found, find others */
			while (++j < num_valloc) {
				if (*(GetPtr(obj2H) + j) != object_id
				 || !csu_GetBit(conn_validH, j)
				 || *(GetPtr(objcls2H) + j) != objclsN)
					continue;
				if (*(GetPtr(objcls1H) + j) != atomN)
					break;
				a++;
				if (a == 2) {
					if (*(GetPtr(obj1H) + j) != atom_list[2])
						break;
				}
				else { /* 3 or 4 */
					if (*(GetPtr(obj1H) + j) != atom_list[3]
					 && *(GetPtr(obj1H) + j) != atom_list[4])
						break;
					if (a == 4) {
						*LockVal = GetPtr(lockvalueH)[object_id];
						return ((int)object_id); /* found match */
					}
				}
			}
			a = 0; /* no match */
		}
		else if (*(GetPtr(obj1H) + i) == atom_list[1])
			found_fw = true;
		else if (*(GetPtr(obj1H) + i) == atom_list[a])
			;
//			found_rv = true;
		else
			a = 0; /* does not match start or end atom */

		--a; /* decrement for first match */
		/* find remaining atoms */
		while (a > 0 && ++j < num_valloc) {
			if (*(GetPtr(obj2H) + j) != object_id
			 || !csu_GetBit(conn_validH, j)
			 || *(GetPtr(objcls2H) + j) != objclsN)
				continue;
			if (*(GetPtr(objcls1H) + j) != atomN)
				break;
			if (found_fw) {
				if (*(GetPtr(obj1H) + j) != atom_list[1 + atom_list[0] - a])
					break;
			}
			else { /* found_rv */
				if (*(GetPtr(obj1H) + j) != atom_list[a])
					break;
			}
			--a;
		}
		/* if a < 0, first atom was not in atom_list */
		/* if a > 0, some atoms in atom_list were not found */
		if (a == 0) {	/* found all atoms in atom_list */
			*LockVal = GetPtr(lockvalueH)[object_id];
			return ((int)object_id);
		}

		/* otherwise, go to next adjust object */
		while (++i < num_valloc)
			if (*(GetPtr(obj2H) + i) != object_id
			 && *(GetPtr(objcls2H) + i) == objclsN
			 && csu_GetBit(conn_validH, i))
				break;
	}
	return(-1);
}

