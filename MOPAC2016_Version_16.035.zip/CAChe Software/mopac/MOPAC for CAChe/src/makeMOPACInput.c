#if defined(_WIN32)
#include <windows.h>
#endif
#include <compat.h>
#include <math.h>
#include <ctype.h>
#include <CACheFileLib.h>
#include <CACheFileTypes.h>
#include <cpu.h>
#include "MOPACDriver.h"

#define MAX_KEYWORD_LENGTH 236

int makeMOPACInput(MolStruct *molStruct, MolStruct *productMolStruct, 
		MOPACControl *origControlPanel, MoleculeInfo *moleculeInfo, 
		short inputCalcNumber, Boolean appendedToMaintainOrientation)
{

	MOPACControl	control;
	FILE		*file = NULL;
	char		outputfile[256];
	char		string[256], keywords[256];
    char        *pkeys = NULL, *p = NULL;
	int			i, j, k, m, n, max_num_labels, nelectrons;
	Zmatrix		*zMatrix = NULL;
	char		errs[256];
 	long	 	numberBonds, (*bondList)[2] = NULL;
	short		*atomicNumber = NULL;
	Boolean		switchedSearchLabel[2];
	LockedLabel *lockedLabels = NULL;
	long		*lockedAtoms = NULL;
	Boolean		*isAtomCappedBond = NULL;

	char 		atsym2, atsym1;
	char		(*atsymbol)[2] = NULL;
	double  	(*tmpcoord)[3] = NULL, (*coords)[3] = NULL;
	short		*tmp_element = NULL; 
	short		Xe = 1, Po = 1, Rn = 1, At = 1;
	long		*atomID = NULL;
	ObjclsID	offset;
	long		NAtom, numDummyAtoms;
	int			rtn_code;
	Boolean		setControl = false, haveSparkles = false;
	double		high_x_value, high_y_value;

	/* Copy the control panel so that its settings will not be altered */
	control = *origControlPanel;
	
	/*      Write input file  	*/
	outputfile[0] = 0; /* null-terminate string */

    strcat(outputfile, "MOPAC Append");
	if (!(file = fopen(outputfile, "w"))) {
		alert_user_watch("The file 'MOPAC Append' cannot be opened because "
				   "the file may be locked, or it may be in use by"
				   " another application, or the disk may be full.");
		goto cantOpenReturn;
	}

	enterBusyState();
	/* 
	 * Some settings in the control panel may be inconsistent.  The settings
	 * from the front panel -- the calculation type, in particular -- override
	 * settings found in sub-dialogs (e.g., whether THERMO information is generated)
	 *
	 */
	if (control.calculate != forceMN)
		control.detailsThermo = false; /* THERMO calculations ONLY for Vib. spectra */
	
	if (control.calculate == transitionStateMN)
		control.detailsUseXYZ = true; /* XYZ always present for SADDLE calculations */

	if ((control.multiplicity == SPINMULT_TRIPLETUHF) ||
		(control.multiplicity == SPINMULT_BIRADICAL) ||
		(control.multiplicity == SPINMULT_UHF)) {
	/*	control.CIlevel = 1; */
	}

	/* Make sure that the extra keywords string is clean. Strip non printable characters */
	for (i=0; control.extraKeyWords[i] != 0; i++) 
		if (control.extraKeyWords[i] < 32 || 
		    control.extraKeyWords[i] > 126) control.extraKeyWords[i] = ' ';

	/* Make sure that the extra keywords string is upper case. */
	for (i=0; control.extraKeyWords[i] != 0; i++)  
		control.extraKeyWords[i] = toupper(control.extraKeyWords[i]);

	for (i=0; i<256; i++) {
		keywords[i] = 0;	
		string[i] = 0;
	}
	
	/* Get molecule information here, since it is needed later for checking on reordering
	   labels */
	 
   /*
    *  Find out how many of each object class there are.
    */
   	if (csu_ExistsObjclsID (molStruct, AtomID, &offset))
		NAtom = (long) ((GetPtr(molStruct->objclsH) + offset)->num_objs);
	else {
		alert_user_watch("makeMOPACInput: Unable to locate AtomID index.");
		goto errorReturn;
	}

	if ((rtn_code = csu_GrabVal (molStruct, AtomID, AnumID, (char **)&atomicNumber)) < 0) {
	  sprintf (errs," makeMOPACInput : csu_GrabVal AnumID, errno %d", rtn_code);
	  alert_user_watch(errs);
	  goto errorReturn;
	}

	/*
	 *  Set the array pointers for the atomic coordinates, atomic numbers,
     *  and atom symbols. Determine the net molecular charge.
    */
    
	if ((rtn_code = csu_GrabVal (molStruct, AtomID, ID_ID, (char **)&(atomID))) < 0) {
		sprintf (errs,"makeMOPACInput: csu_GrabVal ID, errno %d", rtn_code);
		alert_user_watch(errs);
		goto errorReturn;
	}

	if ((rtn_code = csu_GrabVal (molStruct, AtomID, XYZID, (char **)&(tmpcoord))) < 0) {
 		sprintf (errs,"makeMOPACInput: csu_GrabVal XYZ, errno %d", rtn_code);
		alert_user_watch(errs);
		goto errorReturn;
	}
      
	if ((rtn_code = csu_GrabVal (molStruct, AtomID, AnumID, (char **)&tmp_element)) < 0) {
		sprintf (errs,"makeMOPACInput: csu_GrabVal Anum, errno %d", rtn_code);
		alert_user_watch(errs);
		goto errorReturn;
	}

	if ((rtn_code = csu_GrabVal (molStruct, AtomID, SymID, (char **)&atsymbol)) < 0) {
 		sprintf (errs,"makeMOPACInput: csu_GrabVal Sym, errno %d", rtn_code);
		alert_user_watch(errs);
		goto errorReturn;
	}


	/* 
	* Check for the presence of capped bond atoms.
	* If there are capped bonds present, internal coordinates must be used.
	* Use XYZ must be turned off, as this is inconsistent with not optimizing
	* all degrees of freedom.
	*/
	for (i=0; i<NAtom; i++) {
	  if (strncmp(atsymbol[i],"Rn",2) == 0 || strncmp(atsymbol[i],"Am",2) == 0) {
		  control.detailsGeoType = INTERNAL_COORD;
		  control.detailsUseXYZ = false;
		  break;
	  }
	}

	/* build the list of bonds */
	numberBonds = cpu_getBondList(molStruct, &bondList);
  
	/* Get locked atoms from molstruct */
	
	/* create an array that could hold all the atoms; lockedAtoms[i] is true if
		atom i is locked, false otherwise */
	lockedAtoms = (long *) malloc(sizeof(long)*(NAtom));
	if (lockedAtoms == NULL) {
		alert_user_watch("Unable to allocate enough memory for locked atoms.  "
					"Increase the memory size for your MOPAC application using the "
				   	"Get Info command");
		goto errorReturn;
	}

	/* and then get the list of locked atoms */
	getLockedAtoms(molStruct, lockedAtoms, NAtom);
	
	/* Initialize number of search labels */
	moleculeInfo->numSearchLabels = 0;
	switchedSearchLabel[0] = switchedSearchLabel[1] = false;

	if ((control.calculate == CALCTYPE_RIGIDSRCH) || 
		(control.calculate == CALCTYPE_OPTSRCH)) {
		if (control.searchType == SRCHTYPE_RXN)
			max_num_labels = 1;
		else if (control.searchType == SRCHTYPE_GRID)
			max_num_labels = 2;
		else
			max_num_labels = 0;
	} else
		max_num_labels = 0;

	if (max_num_labels > 0)
		moleculeInfo->numSearchLabels = 
			getSearchLabels(molStruct, moleculeInfo->searchLabels, max_num_labels);
	
	/*
	 * Count the number of electrons in the molecule and check for
	 * consistency with the multiplicity.  If the multiplicity is not
	 * appropriate, suggest a reasonable value and fail.
	 *
	 * Return a MOPAC_INPUT_CHANGEMULT code to indicate to the application
	 * manager that it is OK to continue, but that it's not OK for
	 * the user interface to continue.
	 *
	 * Note: instruct_user_watch and inform_user_watch have different
	 * functions depending on whether the calling program is interactive
	 * or not.  For interactive (user interface) programs, 
	 * instruct_user_watch passes the message to the user, 
	 * inform_user_watch does nothing, and thecalling routine should 
	 * report an error for positive error codes.
	 * For detached (application manager, e.g.) programs, instruct_user_watch
	 * does nothing, inform_user_watch passes the message on to the
	 * user, and the calling routine should ignore positive error codes.
	 */
	for (i = 0, nelectrons = 0; i < NAtom; i++) {
		/* Filter capped bonds and dummy atoms */
		if (atomicNumber[i] == 86) {
			nelectrons++; /* Capped bond */
		} else if (atomicNumber[i] != 54) { /* do not count dummy atoms */
			nelectrons += atomicNumber[i];
		}
	}
	nelectrons -= moleculeInfo->netCharge;

	if ((nelectrons % 2) == 0) {
		/* even number of electrons */
		if ((strstr(control.extraKeyWords,"SINGLET") == NULL) &&
			(strstr(control.extraKeyWords,"DOUBLET") == NULL) &&
			(strstr(control.extraKeyWords,"TRIPLET") == NULL) &&
			(strstr(control.extraKeyWords,"QUARTET") == NULL) &&
			(strstr(control.extraKeyWords,"QUINTET") == NULL) &&
			(strstr(control.extraKeyWords,"SEXTET") == NULL) &&
			(strstr(control.extraKeyWords,"SEPTET") == NULL) &&
			(strstr(control.extraKeyWords,"OCTET") == NULL) &&
			(strstr(control.extraKeyWords,"NONET") == NULL) &&
			(strstr(control.extraKeyWords,"EXCITED") == NULL) &&
			(strstr(control.extraKeyWords,"BIRAD") == NULL) &&
			(strstr(control.extraKeyWords,"UHF") == NULL)) {

				if (control.multiplicity == SPINMULT_DOUBLET) {
					instruct_user_watch("You must change the multiplicity to be "
						"consistent with the number of electrons in your molecule.  "
						"Singlet multiplicity would be appropriate.");
					inform_user_watch("This calculation is being run as a singlet "
						"in order to be consistent with the number of electrons in your "
						"molecule.");
					control.multiplicity = SPINMULT_SINGLET;
					setControl = true;
				} else if (control.multiplicity == SPINMULT_QUARTET) {
					instruct_user_watch("You must change the multiplicity to be "
						"consistent with the number of electrons in your molecule.  "
						"Triplet multiplicity would be appropriate.");
					inform_user_watch("This calculation is being run as a triplet "
						"in order to be consistent with the number of electrons in your "
						"molecule.");
					control.multiplicity = SPINMULT_TRIPLET;
					setControl = true;
				} else if (control.multiplicity == SPINMULT_SEXTET) {
					instruct_user_watch("You must change the multiplicity to be "
						"consistent with the number of electrons in your molecule.  "
						"Quintet multiplicity would be appropriate.");
					inform_user_watch("This calculation is being run as a quintet "
						"in order to be consistent with the number of electrons in your "
						"molecule.");
					control.multiplicity = SPINMULT_QUINTET;
					setControl = true;
				} else if (control.multiplicity == SPINMULT_OCTET) {
					instruct_user_watch("You must change the multiplicity to be "
						"consistent with the number of electrons in your molecule.  "
						"Septet multiplicity would be appropriate.");
					inform_user_watch("This calculation is being run as a septet "
						"in order to be consistent with the number of electrons in your "
						"molecule.");
					control.multiplicity = SPINMULT_SEPTET;
					setControl = true;
				}
		}
	} else {
		/* odd number of electrons */
		if ((strstr(control.extraKeyWords,"SINGLET") == NULL) &&
			(strstr(control.extraKeyWords,"DOUBLET") == NULL) &&
			(strstr(control.extraKeyWords,"TRIPLET") == NULL) &&
			(strstr(control.extraKeyWords,"QUARTET") == NULL) &&
			(strstr(control.extraKeyWords,"QUINTET") == NULL) &&
			(strstr(control.extraKeyWords,"SEXTET") == NULL) &&
			(strstr(control.extraKeyWords,"SEPTET") == NULL) &&
			(strstr(control.extraKeyWords,"OCTET") == NULL) &&
			(strstr(control.extraKeyWords,"NONET") == NULL) &&
			(strstr(control.extraKeyWords,"EXCITED") == NULL) &&
			(strstr(control.extraKeyWords,"BIRAD") == NULL) &&
			(strstr(control.extraKeyWords,"UHF") == NULL)) {
				if (control.multiplicity == SPINMULT_SINGLET) {
					instruct_user_watch("You must change the multiplicity to be "
						"consistent with the number of electrons in your molecule.  "
						"Doublet multiplicity would be appropriate.");
					inform_user_watch("This calculation is being run as a doublet "
						"in order to be consistent with the number of electrons in your "
						"molecule.");
					control.multiplicity = SPINMULT_DOUBLET;
					setControl = true;
				} else if (control.multiplicity == SPINMULT_EXCSINGLET) {
					instruct_user_watch("You must change the multiplicity to be "
						"consistent with the number of electrons in your molecule.  "
						"Doublet multiplicity would be appropriate.");
					inform_user_watch("This calculation is being run as a doublet "
						"in order to be consistent with the number of electrons in your "
						"molecule.");
					control.multiplicity = SPINMULT_DOUBLET;
					setControl = true;
				} else if (control.multiplicity == SPINMULT_BIRADICAL) {
					instruct_user_watch("You must change the multiplicity to be "
						"consistent with the number of electrons in your molecule.  "
						"Doublet multiplicity would be appropriate.");
					inform_user_watch("This calculation is being run as a doublet "
						"in order to be consistent with the number of electrons in your "
						"molecule.");
					control.multiplicity = SPINMULT_DOUBLET;
					setControl = true;
				} else if (control.multiplicity == SPINMULT_TRIPLET) {
					instruct_user_watch("You must change the multiplicity to be "
						"consistent with the number of electrons in your molecule.  "
						"Quartet multiplicity would be appropriate.");
					inform_user_watch("This calculation is being run as a quartet "
						"in order to be consistent with the number of electrons in your "
						"molecule.");
					control.multiplicity = SPINMULT_QUARTET;
					setControl = true;
				} else if (control.multiplicity == SPINMULT_TRIPLETUHF) {
					instruct_user_watch("You must change the multiplicity to be "
						"consistent with the number of electrons in your molecule.  "
						"Quartet multiplicity would be appropriate.");
					inform_user_watch("This calculation is being run as a quartet "
						"in order to be consistent with the number of electrons in your "
						"molecule.");
					control.multiplicity = SPINMULT_QUARTET;
					setControl = true;
				} else if (control.multiplicity == SPINMULT_QUINTET) {
					instruct_user_watch("You must change the multiplicity to be "
						"consistent with the number of electrons in your molecule.  "
						"Sextet multiplicity would be appropriate.");
					inform_user_watch("This calculation is being run as a sextet "
						"in order to be consistent with the number of electrons in your "
						"molecule.");
					control.multiplicity = SPINMULT_SEXTET;
					setControl = true;
				} else if (control.multiplicity == SPINMULT_SEPTET) {
					instruct_user_watch("You must change the multiplicity to be "
						"consistent with the number of electrons in your molecule.  "
						"Octet multiplicity would be appropriate.");
					inform_user_watch("This calculation is being run as a octet "
						"in order to be consistent with the number of electrons in your "
						"molecule.");
					control.multiplicity = SPINMULT_OCTET;
					setControl = true;
				} else if (control.multiplicity == SPINMULT_NONET) {
					instruct_user_watch("You must change the multiplicity to be "
						"consistent with the number of electrons in your molecule.  "
						"Octet multiplicity would be appropriate.");
					inform_user_watch("This calculation is being run as a octet "
						"in order to be consistent with the number of electrons in your "
						"molecule.");
					control.multiplicity = SPINMULT_OCTET;
					setControl = true;
				}
		}
	}
	
	/* Analytical gradients cannot be used for C.I. calculations */
	if (control.CIlevel > 1 || (strstr(control.extraKeyWords,"C.I.") != NULL)) {
		if (control.detailsAnalytGrad) {
			instruct_user_watch("Analytical gradients are not available for "
				"calculations with a C.I. level other than Default.  "
				"Either uncheck Analytical gradients or set the C.I. "
				"level to Default.");
			inform_user_watch("This calculation is being run without analytical "
				"gradients in order to be consistent with the C.I. level "
				"selected.");
			control.detailsAnalytGrad = 0;
			setControl = true;
		}
	}
	
	/* 
		Analytical gradients are not available for elements beyond Xe.
	*/
	if (control.detailsAnalytGrad)  {
		Boolean haveHg = FALSE;
		Boolean haveTl = FALSE;
		Boolean havePb = FALSE;
		Boolean haveBi = FALSE;
		for (i=0; i<NAtom; i++) {
			switch (tmp_element[i]) {
				case 80:
					haveHg = TRUE;
					break;
				case 81:
					haveTl = TRUE;
					break;
				case 82:
					havePb = TRUE;
					break;
				case 83:
					haveBi = TRUE;
					break;
			}
		}
		
		if (haveHg || haveTl || havePb || haveBi) {
			sprintf(errs,"Analytical gradients are not availble for "
						"the following elements:");
			if (haveHg)
				strcat(errs,"  Hg");	
			if (haveTl)
				strcat(errs,"  Tl");	
			if (havePb)
				strcat(errs,"  Pb");	
			if (haveBi)
				strcat(errs,"  Bi");

			leaveBusyState();
			rtn_code = cancelOrProceedDialog(errs, 
				"Press OK to proceed with the calculation without analytical "
				"gradients.", 
				"Press Cancel if you do not wish to run the calculation.");
	
			enterBusyState();
	
			if (rtn_code < 0)
				goto errorReturn;
			else if (rtn_code == 1)
				goto cancelReturn;
				
			/* User chose to proceed with the calculation; turn analytical
				gradients off. */
			control.detailsAnalytGrad = FALSE;
		}

	}

	/* 
		Do not consider locked labels for SCF Energy calculations, since
		no geometry optimization will be done.
	*/
	
	if (control.calculate == scfEnergyMN)
		moleculeInfo->numLockedLabels = 0;
	
	/* 
		Locked atoms and locked labels will not work with FORCE calculations, and make
		no sense for this type of calculation since the gradient is not likely to be 
		zero.  Give the user the option of cancelling out of the calculation.
	*/
	if ((control.calculate == forceMN) 
		&& ((moleculeInfo->numLockedAtoms > 0) || 
			(moleculeInfo->numLockedLabels > 0))) {
		
		sprintf(errs,"FORCE calculations do not honor locked atoms or locked labels.");

		leaveBusyState();
		rtn_code = cancelOrProceedDialog(errs, 
			"Press OK to proceed with the calculation.", 
			"Press Cancel if you do not wish to run the calculation.");

		enterBusyState();

		if (rtn_code < 0)
			goto errorReturn;
		else if (rtn_code == 1)
			goto cancelReturn;
			
		/* User chose to proceed with the calculation; set the number of locked
		   atoms and labels to zero. */
		moleculeInfo->numLockedAtoms = 0;
		for (i=0; i<NAtom; i++)
			lockedAtoms[i] = false;
		moleculeInfo->numLockedLabels = 0;
	}

	/* 
		Maintain orientation does not work with vibrational spectra calculations.
	*/
	if (control.calculate == forceMN && control.detailsKeepOrient) {
		
		sprintf(errs,"Maintain orientation is not honored for vibrational spectra calculations.");

		leaveBusyState();
		rtn_code = cancelOrProceedDialog(errs, 
			"Press OK to proceed with the calculation.", 
			"Press Cancel if you do not wish to run the calculation.");

		enterBusyState();

		if (rtn_code < 0)
			goto errorReturn;
		else if (rtn_code == 1)
			goto cancelReturn;
	}
		
	/* 
		Locked atoms require that internal coordinates be used without Use XYZ.
		set the "Maintain orientation" checkbox for locked atoms 
	*/
	if (moleculeInfo->numLockedAtoms > 0 ) {
		control.detailsKeepOrient = true;
		control.detailsUseXYZ = false;
		control.detailsGeoType = INTERNAL_COORD;
	}
	
	if (moleculeInfo->numLockedLabels > 0) {
		lockedLabels = 
			(LockedLabel *) malloc(sizeof(LockedLabel)*(moleculeInfo->numLockedLabels));
		if (lockedLabels == NULL) {
			alert_user_watch("Unable to allocate enough memory for locked labels.  "
						"Increase the memory size for your MOPAC application using the "
				   		"Get Info command");
			goto errorReturn;
		}

		/* initialize the complete locked label */
		for (i=0; i<moleculeInfo->numLockedLabels; i++) {
			lockedLabels[i].value = 0.0;
			lockedLabels[i].atomList[0] = 0;
			for (j=1; j<5; j++) 
				lockedLabels[i].atomList[j] = -1;
		}
		getLockedLabels(molStruct, lockedLabels);

		/* Locked labels require using internal coordinates */
		control.detailsUseXYZ = false;
		control.detailsGeoType = INTERNAL_COORD;
	}

	/* If this input is in Cartesian coordinates, and there are locked atoms, there will
	   atoms that do not have coordinates optimized.  J. Stewart says that in this case
	   the XYZ keyword must be specified */
	if ((control.detailsGeoType == CARTESIAN_COORD) && 
		(moleculeInfo->numLockedAtoms > 0)) 
		control.detailsUseXYZ = true;
	
	
	/* also set up initial z-matrix information in case labels are reordered */

	/* add places for 2 dummy atoms at +X axis and positive X-Y quadrant*/
	if (control.detailsKeepOrient)
		numDummyAtoms = 2;
	else
		numDummyAtoms = 0;
	
	/* 
	 * SADDLE, IRC or DRC calculations that are appended to previous calculations
	 * with "Maintian orientation" checked will not work.
	 */
	if (control.calculate == transitionStateMN && inputCalcNumber > 0) {
		alert_user_watch("SADDLE calculations can only be first in a set of "
						"back-to-back calculations.");
		goto errorReturn;
	}
	
	if (control.calculate == ircMN && appendedToMaintainOrientation) {
		alert_user_watch("IRC calculations that are appended to calculations "
						"with 'Maintain orientation' checked do not work.  "
						"Uncheck 'Maintain orientation' in the Details dialog "
						"for the first of the back-to-back calculations.");
		goto errorReturn;
	}
	
	if (control.calculate == drcMN && appendedToMaintainOrientation) {
		alert_user_watch("DRC calculations that are appended to calculations "
						"with 'Maintain orientation' checked do not work.  "
						"Uncheck 'Maintain orientation' in the Details dialog "
						"for the first of the back-to-back calculations.");
		goto errorReturn;
	}
	
	/* Do not use dummy atoms if it is a DRC, IRC or SADDLE calculation */
	if ((control.calculate == transitionStateMN) || 
		(control.calculate == ircMN) || (control.calculate == drcMN)) {

		numDummyAtoms = 0;
	
		if (moleculeInfo->numUserDummyAtoms > 0) {
		/* User-defined dummy (Pu) atoms will cause IRC, DRC & SADDLE not to work */
			if (control.calculate == ircMN) 
				sprintf(errs,"IRC calculations do not work with dummy (Pu) atoms, and "
						"will produce unexpected molecular geometries in the map file.  "
						"It is recommended that you remove the Pu atoms from your "
						"molecule before carrying out this calculation.");
			else if (control.calculate == drcMN)
				sprintf(errs,"DRC calculations do not work with dummy (Pu) atoms, and "
						"will produce unexpected molecular geometries in the map file.  "
						"It is recommended that you remove the Pu atoms from your "
						"molecule before carrying out this calculation.");

			else 
				sprintf(errs,"SADDLE calculations do not work with dummy (Pu) atoms, and "
						"may produce unexpected molecular geometries.  "
						"It is recommended that you remove the Pu atoms from your "
						"molecule before carrying out this calculation.");

			leaveBusyState();
			rtn_code = cancelOrProceedDialog(errs, 
				"Press OK to proceed with the calculation.", 
				"Press Cancel if you do not wish to run the calculation.");
			enterBusyState();
			if (rtn_code < 0)
				goto errorReturn;
			else if (rtn_code == 1)
				goto cancelReturn;
		}

		if (moleculeInfo->numLockedLabels > 0 || moleculeInfo->numLockedAtoms > 0) {
		/* Locked labels and locked atoms do not make any sense in IRC, DRC & SADDLE */
			if (control.calculate == ircMN) 
				sprintf(errs,"Your molecule contains locked labels and locked atoms.  "
						"IRC calculations may produce unexpected molecular geometries "
						"in the map file.");
			else if (control.calculate == drcMN)
				sprintf(errs,"Your molecule contains locked labels and locked atoms.  "
						"DRC calculations may produce unexpected molecular geometries "
						"in the map file.");

			else 
				sprintf(errs,"Your molecule contains locked labels and locked atoms.  "
						"SADDLE calculations may produce unexpected molecular geometries "
						"when locked labels are present.");


			leaveBusyState();
			rtn_code = cancelOrProceedDialog(errs, 
				"Press OK to proceed with the calculation with locked "
				"labels, but without locked atoms.", 
				"Press Cancel if you do not wish to run the calculation.");

			enterBusyState();
			if (rtn_code < 0)
				goto errorReturn;
			else if (rtn_code == 1)
				goto cancelReturn;

			moleculeInfo->numLockedAtoms = 0;
			for (i=0; i<NAtom; i++)
				lockedAtoms[i] = false;
		} else if (moleculeInfo->numLockedLabels > 0) {
		/* Locked labels do not make any sense in IRC, DRC & SADDLE */
			if (control.calculate == ircMN) 
				sprintf(errs,"Your molecule contains locked labels.  "
						"IRC calculations may produce unexpected molecular geometries "
						"in the map file.");
			else if (control.calculate == drcMN)
				sprintf(errs,"Your molecule contains locked labels.  "
						"DRC calculations may produce unexpected molecular geometries "
						"in the map file.");

			else 
				sprintf(errs,"Your molecule contains locked labels.  "
						"SADDLE calculations may produce unexpected molecular geometries "
						"when locked labels are present.");

			leaveBusyState();
			rtn_code = cancelOrProceedDialog(errs, 
				"Press OK to proceed with the calculation with locked labels.", 
				"Press Cancel if you do not wish to run the calculation.");
			enterBusyState();
			if (rtn_code < 0)
				goto errorReturn;
			else if (rtn_code == 1)
				goto cancelReturn;
		} else if (moleculeInfo->numLockedAtoms > 0) {
		/* Locked cannot be used in IRC, DRC & SADDLE because they require dummy atoms */
			if (control.calculate == ircMN) 
				sprintf(errs,"Your molecule contains locked atoms.  "
						"The coordinates of these atoms will not be locked in an "
						"IRC calculation.");
			else if (control.calculate == drcMN)
				sprintf(errs,"Your molecule contains locked atoms.  "
						"The coordinates of these atoms will not be locked in a "
						"DRC calculation.");

			else 
				sprintf(errs,"Your molecule contains locked atoms.  "
						"The coordinates of these atoms will not be locked in a "
						"SADDLE calculation.");

			leaveBusyState();
			rtn_code = cancelOrProceedDialog(errs, 
				"Press OK to proceed with the calculation without locked atoms.", 
				"Press Cancel if you do not wish to run the calculation.");

			enterBusyState();
			if (rtn_code < 0)
				goto errorReturn;
			else if (rtn_code == 1)
				goto cancelReturn;
			moleculeInfo->numLockedAtoms = 0;
			for (i=0; i<NAtom; i++)
				lockedAtoms[i] = false;
		}

	} else if ((moleculeInfo->numLockedAtoms > 0) && (numDummyAtoms == 0)) {
		sprintf(errs,"Your molecule contains locked atoms but you have not checked "
			"the Maintain orientation checkbox in the Details dialog.  "
			"Therefore, the position of the locked atoms in your molecule will change.");

		leaveBusyState();
		rtn_code = cancelOrProceedDialog(errs, 
			"Press OK to proceed with the calculation.", 
			"Press Cancel if you do not wish to run the calculation.");

		enterBusyState();
		if (rtn_code < 0)
			goto errorReturn;
		else if (rtn_code == 1)
			goto cancelReturn;
	}

	if ((control.calculate == optimizeGeometryMN ||
		 control.calculate == optSearchMN) && 
				(control.geometrySearch == EFgeoOptMethodMN) &&
				(numDummyAtoms > 0 || moleculeInfo->numUserDummyAtoms > 0)) {
		if ((numDummyAtoms > 0 || moleculeInfo->numUserDummyAtoms > 0) && 
			(control.detailsUseXYZ) &&
			(!(strstr(control.extraKeyWords,"GEO-OK")))) {
			sprintf(errs,"It is necessary to add the GEO-OK Extra Keyword for a " 
				"calculation that uses eigenvector following (EF) geometry "
				"optimization with the options you have checked.");
	
			leaveBusyState();
//			rtn_code = cancelOrProceedDialog(errs, 
//				"Press OK to add the GEO-OK Extra Keyword and proceed with the calculation.", 
//				"Press Cancel if you do not wish to run the calculation.");

			rtn_code = 0;
			enterBusyState();
			if (rtn_code < 0)
				goto errorReturn;
			else if (rtn_code == 1)
				goto cancelReturn;
			else 
				sprintf(keywords,"%s GEO-OK",keywords);
		} else if ((numDummyAtoms > 0 || moleculeInfo->numUserDummyAtoms > 0) && 
			((!control.detailsUseXYZ) ||
			(control.detailsUseXYZ &&
			strstr(control.extraKeyWords,"GEO-OK")))) {

			if (moleculeInfo->numUserDummyAtoms > 0 && numDummyAtoms > 0) {
				if (moleculeInfo->numLockedAtoms > 0) {
					sprintf(errs,"Calculations with dummy atoms and locked atoms "
						"may not be successful " 
						"when using the eigenvector following (EF) geometry "
						"optimization method.");
				} else { /* dummy atoms added to maintain orientation */
					sprintf(errs,"Calculations with dummy atoms and the option "
						"to maintain the molecular orientation may not work " 
						"when using the eigenvector following (EF) geometry "
						"optimization method.");
				}
			} else if (numDummyAtoms > 0) {
				if (moleculeInfo->numLockedAtoms > 0) {
					sprintf(errs,"Calculations with locked atoms "
						"may not be successful " 
						"when using the eigenvector following (EF) geometry "
						"optimization method.");
				} else { /* dummy atoms added to maintain orientation */
					sprintf(errs,"Calculations with the option "
						"to maintain the molecular orientation may not work " 
						"when using the eigenvector following (EF) geometry "
						"optimization method.");
				}
			} else if (moleculeInfo->numUserDummyAtoms > 0) 
				sprintf(errs,"Calculations with dummy atoms may not be successful " 
					"when using the eigenvector following (EF) geometry "
					"optimization method.");
	
			leaveBusyState();
//			rtn_code = cancelOrProceedDialog(errs, 
//				"Press OK to proceed with the calculation.", 
//				"Press Cancel if you do not wish to run the calculation.");
			rtn_code =0;	
			enterBusyState();
			if (rtn_code < 0)
				goto errorReturn;
			else if (rtn_code == 1)
				goto cancelReturn;
		}
	} else if ((control.calculate == transitionStateMN) && 
				(control.geometrySearch == EFgeoOptMethodMN) &&
				(numDummyAtoms > 0 || moleculeInfo->numUserDummyAtoms > 0)) {
		if ((numDummyAtoms > 0 || moleculeInfo->numUserDummyAtoms > 0) && 
			(!(strstr(control.extraKeyWords,"GEO-OK")))) {
			sprintf(errs,"It is necessary to add the GEO-OK Extra Keyword for a " 
				"calculation that uses eigenvector following (EF) geometry "
				"optimization with the options you have checked.");
	
			leaveBusyState();
//			rtn_code = cancelOrProceedDialog(errs, 
//				"Press OK to add the GEO-OK Extra Keyword and proceed with the calculation.", 
//				"Press Cancel if you do not wish to run the calculation.");
			rtn_code =0;	
	
			enterBusyState();
			if (rtn_code < 0)
				goto errorReturn;
			else if (rtn_code == 1)
				goto cancelReturn;
			else 
				sprintf(keywords,"%s GEO-OK",keywords);
		} else if ((numDummyAtoms > 0 || moleculeInfo->numUserDummyAtoms > 0) && 
					(strstr(control.extraKeyWords,"GEO-OK"))) {

			if (moleculeInfo->numUserDummyAtoms > 0 && numDummyAtoms > 0) {
				if (moleculeInfo->numLockedAtoms > 0) {
					sprintf(errs,"Calculations with dummy atoms and locked atoms "
						"may not be successful " 
						"when using the eigenvector following (EF) geometry "
						"optimization method.");
				} else { /* dummy atoms added to maintain orientation */
					sprintf(errs,"Calculations with dummy atoms and the option "
						"to maintain the molecular orientation may not work " 
						"when using the eigenvector following (EF) geometry "
						"optimization method.");
				}
			} else if (numDummyAtoms > 0) {
				if (moleculeInfo->numLockedAtoms > 0) {
					sprintf(errs,"Calculations with locked atoms "
						"may not be successful " 
						"when using the eigenvector following (EF) geometry "
						"optimization method.");
				} else { /* dummy atoms added to maintain orientation */
					sprintf(errs,"Calculations with the option "
						"to maintain the molecular orientation may not work " 
						"when using the eigenvector following (EF) geometry "
						"optimization method.");
				}
			} else if (moleculeInfo->numUserDummyAtoms > 0) 
				sprintf(errs,"Calculations with dummy atoms may not be successful " 
					"when using the eigenvector following (EF) geometry "
					"optimization method.");
	
			leaveBusyState();
//			rtn_code = cancelOrProceedDialog(errs, 
//				"Press OK to proceed with the calculation.", 
//				"Press Cancel if you do not wish to run the calculation.");
			rtn_code =0;	
	
			enterBusyState();
			if (rtn_code < 0)
				goto errorReturn;
			else if (rtn_code == 1)
				goto cancelReturn;
		}
	} else if ((control.calculate == minimizeGradientMN) && 
				(control.minimizeGradient == EFgradMinMethodMN)&&
				(numDummyAtoms > 0 || moleculeInfo->numUserDummyAtoms > 0)) {
		if ((numDummyAtoms > 0 || moleculeInfo->numUserDummyAtoms > 0) && 
			(control.detailsUseXYZ) &&
			(!(strstr(control.extraKeyWords,"GEO-OK")))) {
			sprintf(errs,"It is necessary to add the GEO-OK Extra Keyword for a " 
				"calculation that uses eigenvector following (EF) gradient "
				"minimization with the options you have checked.");
	
			leaveBusyState();
//			rtn_code = cancelOrProceedDialog(errs, 
//				"Press OK to add the GEO-OK Extra Keyword and proceed with the calculation.", 
//				"Press Cancel if you do not wish to run the calculation.");
			rtn_code =0;	
	
			enterBusyState();
			if (rtn_code < 0)
				goto errorReturn;
			else if (rtn_code == 1)
				goto cancelReturn;
			else 
				sprintf(keywords,"%s GEO-OK",keywords);
		} else if ((numDummyAtoms > 0 || moleculeInfo->numUserDummyAtoms > 0) && 
			((!control.detailsUseXYZ) ||
			(control.detailsUseXYZ &&
			strstr(control.extraKeyWords,"GEO-OK")))) {

			if (moleculeInfo->numUserDummyAtoms > 0 && numDummyAtoms > 0) {
				if (moleculeInfo->numLockedAtoms > 0) {
					sprintf(errs,"Calculations with dummy atoms and locked atoms "
						"may not be successful " 
						"when using the eigenvector following (EF) gradient "
						"minimization method.");
				} else { /* dummy atoms added to maintain orientation */
					sprintf(errs,"Calculations with dummy atoms and the option "
						"to maintain the molecular orientation may not work " 
						"when using the eigenvector following (EF) gradient "
						"minimization method.");
				}
			} else if (numDummyAtoms > 0) {
				if (moleculeInfo->numLockedAtoms > 0) {
					sprintf(errs,"Calculations with locked atoms "
						"may not be successful " 
						"when using the eigenvector following (EF) gradient "
						"minimization method.");
				} else { /* dummy atoms added to maintain orientation */
					sprintf(errs,"Calculations with the option "
						"to maintain the molecular orientation may not work " 
						"when using the eigenvector following (EF) gradient "
						"minimization method.");
				}
			} else if (moleculeInfo->numUserDummyAtoms > 0) 
				sprintf(errs,"Calculations with dummy atoms may not be successful " 
					"when using the eigenvector following (EF) gradient "
					"minimization method.");
	
			leaveBusyState();
//			rtn_code = cancelOrProceedDialog(errs, 
//				"Press OK to proceed with the calculation.", 
//				"Press Cancel if you do not wish to run the calculation.");
			rtn_code =0;	
	
			enterBusyState();
			if (rtn_code < 0)
				goto errorReturn;
			else if (rtn_code == 1)
				goto cancelReturn;
		}
	}
	
	
	if ((coords = (double (*)[3]) 
			malloc(sizeof(double)*3*(NAtom+numDummyAtoms))) == NULL) {
		alert_user_watch("makeMOPACInput: Unable to allocate coords array.  "
					"Increase the memory size for your MOPAC application using the "
				   	"Get Info command");
		goto errorReturn;
	}

	if ((zMatrix = (Zmatrix (*)) 
			malloc(sizeof(Zmatrix)*MOPAC_MAX(3,NAtom+numDummyAtoms))) == NULL) {
		alert_user_watch("makeMOPACInput: Unable to allocate zMatrix array.  "
					"Increase the memory size for your MOPAC application using the "
				   	"Get Info command");
		goto errorReturn;
	}

	if (control.calculate == rigidSearchMN) 
		k=0;
	else 
		k=1;
	for (i=0; i < NAtom+numDummyAtoms; i++) {
     	zMatrix[i].atomA = 1;
     	zMatrix[i].atomB = 2;
     	zMatrix[i].atomC = 3;
     	zMatrix[i].varyDistance = k;
     	zMatrix[i].varyAngle = k;
     	zMatrix[i].varyDihedral = k;
     	zMatrix[i].distance = 0.0;
     	zMatrix[i].angle = 0.0;
     	zMatrix[i].dihedral = 0.0;
	}
	zMatrix[0].varyDistance = 0;
	zMatrix[0].varyAngle = 0;
	zMatrix[0].varyDihedral = 0;
	zMatrix[1].varyAngle = 0;
	zMatrix[1].varyDihedral = 0;
	zMatrix[2].varyDihedral = 0;

	/* Keep the first atom in place */
	for (j=0; j < 3; j++) 
		coords[0][j] = tmpcoord[0][j];
	moleculeInfo->atomLocation[0] = 0;
	high_x_value = coords[0][0];
	high_y_value = coords[0][1];
	
	for (i=1; i < NAtom; i++) {
		if (tmpcoord[i][0] > high_x_value)
			high_x_value = tmpcoord[i][0];
		if (tmpcoord[i][1] > high_y_value)
		high_y_value = tmpcoord[i][1];
		/* put the rest of the atoms after the dummy atoms */
		for (j=0; j < 3; j++) 
			coords[i+numDummyAtoms][j] = tmpcoord[i][j];
		/* leave room for the dummy atoms */
		moleculeInfo->atomLocation[i+numDummyAtoms] = i;
	}
	/* 
		put dummy atoms X axis at the same Y value as the 1st atom, and in the 1st 
		quadrant of the X-Y plane.  Both dummmy atoms have the same Z coordinate
		value as the first atom in the list.
		Put these atoms outside the positions of the atoms in the molecule.
		The dummy atoms are ALWAYS at the beginning of the z-matrix, but must
		go at the END of the atom list (since they are not included in the
		initial molstruct or in the MOPAC Graphics file or cartesian coordinate
		lists in MOPAC Output.
	*/
	if (numDummyAtoms > 0) {
		for (i=0; i < numDummyAtoms; i++) {
			moleculeInfo->atomLocation[i+1] = i+NAtom;
			for (j=0; j < 3; j++)
				coords[i+1][j] = 0.0;
		}
		coords[1][0] = high_x_value + 0.5;
		coords[1][1] = coords[0][1]; /* align Y value for first dummy with first real atom */
		coords[1][2] = coords[0][2]; /* Z coordinate the same as first real atom */
		coords[2][0] = high_x_value + 0.5;
		coords[2][1] = high_y_value + 0.5;
		coords[2][2] = coords[0][2];
	}
	i = buildKeywords(keywords, &control, moleculeInfo);
    if (i == -1) goto noLabelsReturn;
    if (i == -2) goto errorReturn;
        if(strstr(control.extraKeyWords,"RUN") != NULL)
        {
/*
 *  The CSF does not contain a comment, therefore the path name does not exist.
 */
          if ((rtn_code = csu_GrabVal (molStruct, NoteID,CommentID, (char **)&pkeys)) < 0) {
	      sprintf (errs," 'RUN EXTERNAL DATA SET' requested, but the CSF does not contain a name."
                "  Remove 'RUN EXTERNAL DATA SET', and either use the other option" 
                " 'DATA=<filename with path>', or run the CSF directly");
	      alert_user_watch(errs);
	      goto errorReturn;
	}
		  for (i = 0; pkeys[i]; i++)
			  if (pkeys[i] == '?') pkeys[i] =' ';
          strcpy(keywords,pkeys);
          p = keywords;
          while (*p)
          {
              *p = toupper(*p);
              p++;
          }
          if (strstr(keywords,".MOP") == NULL && strstr(keywords,".DAT") == NULL &&
              strstr(keywords,".ARC") == NULL && strstr(keywords,".INP") == NULL)
          {
              sprintf (errs," 'RUN EXTERNAL DATA SET' requested, but the CSF does not contain a name."
                "  Remove 'RUN EXTERNAL DATA SET', and either use the other option" 
                " 'DATA=<filename with path>', or run the CSF directly");
	      alert_user_watch(errs);
	      goto errorReturn;
          }

            strcpy(keywords," data=");
            strcat(keywords,pkeys);
        }


	/* resolve conflicts with locked labels */
    if (moleculeInfo->numLockedLabels > 0) {
		leaveBusyState();
		rtn_code = resolveLockedLabelConflicts(atomID, atsymbol, lockedAtoms, 
			lockedLabels, moleculeInfo->searchLabels, &moleculeInfo->numLockedAtoms, 
			&moleculeInfo->numLockedLabels, moleculeInfo->numSearchLabels,
			switchedSearchLabel);
		enterBusyState();
		if (rtn_code < 0)
			goto errorReturn;
		else if (rtn_code == 1) /* User canceled out of label conflict dialog */
			goto cancelReturn;

	 }
	 
	 /* reorder atoms for search labels */
	 if (moleculeInfo->numSearchLabels == 2) { 
		if (reorderMovingAtomsInLabels(moleculeInfo->searchLabels, 
			switchedSearchLabel) < 0)
				goto errorReturn;
	}
	
	 reorderForLabels(coords, NAtom+numDummyAtoms, moleculeInfo->atomLocation,
	 			 	  moleculeInfo->searchLabels, moleculeInfo->numSearchLabels,
					  numDummyAtoms);

		
	/* reorder atoms for locked labels */
    if (moleculeInfo->numLockedLabels > 0) {
		if (reorderForLockedLabels(coords, NAtom+numDummyAtoms, 
			moleculeInfo->atomLocation, lockedLabels, 
			moleculeInfo->numLockedLabels, numDummyAtoms) < 0)
				goto errorReturn;
	}		
		
	if (moleculeInfo->numLockedAtoms > 0) {
		if (reorderForLockedAtoms(coords, NAtom, moleculeInfo->atomLocation,
				lockedAtoms, moleculeInfo->numLockedAtoms,
				moleculeInfo->searchLabels, moleculeInfo->numSearchLabels,
	 			lockedLabels, moleculeInfo->numLockedLabels, numDummyAtoms) < 0)
					goto errorReturn;
	}				
	
	/* renumber the labels */
	renumberSearchLabels(moleculeInfo->searchLabels, moleculeInfo->numSearchLabels,
		   NAtom+numDummyAtoms, moleculeInfo->atomLocation);
	renumberLockedLabels(lockedLabels, moleculeInfo->numLockedLabels, 
			NAtom+numDummyAtoms, moleculeInfo->atomLocation);

	/* Finish processing the Z-matrix stuff so that all changes in search labels will
	   be done before printing out the STEP1 and STEP2 keywords */

	if ((NAtom + numDummyAtoms) <= 3  || 
		control.detailsGeoType != CARTESIAN_COORD) {	
		rtn_code = cleanUpZmatrix(NAtom, numDummyAtoms, 
			moleculeInfo->numLockedAtoms, lockedAtoms, 
			moleculeInfo->numSearchLabels, moleculeInfo->searchLabels, 
			moleculeInfo->numLockedLabels, lockedLabels, 
			zMatrix, coords, moleculeInfo->atomLocation, 
			numberBonds, bondList);
		if (rtn_code < 0)
			goto errorReturn;
	}
	
	if ((moleculeInfo->numSearchLabels == 2) && 
		((control.calculate == rigidSearchMN) || 
			(control.calculate == optSearchMN))) {
		/* Different moving atoms in the two labels */

		if (moleculeInfo->searchLabels[0].atomList[1] != 
			moleculeInfo->searchLabels[1].atomList[1]) {
			
			/* Different moving atoms in the two labels */
	  	 	double increment;
			if(moleculeInfo->searchLabels[0].numSteps>NumberOfGridSteps)
				moleculeInfo->searchLabels[0].numSteps = NumberOfGridSteps;
			increment = (moleculeInfo->searchLabels[0].highValue 
	   			    - moleculeInfo->searchLabels[0].lowValue) / 
					moleculeInfo->searchLabels[0].numSteps;	
			sprintf(keywords,"%s STEP1=%lf POINT1=%d", keywords,
				increment,moleculeInfo->searchLabels[0].numSteps+1);
			if(moleculeInfo->searchLabels[1].numSteps>NumberOfGridSteps)
				moleculeInfo->searchLabels[1].numSteps = NumberOfGridSteps;
	   		increment = (moleculeInfo->searchLabels[1].highValue 
	   			    - moleculeInfo->searchLabels[1].lowValue) / 
					moleculeInfo->searchLabels[1].numSteps;
			sprintf(keywords,"%s STEP2=%lf POINT2=%d", keywords,
				increment,moleculeInfo->searchLabels[1].numSteps+1);

		} else { /* the moving atom for both labels is the same */
			if (moleculeInfo->searchLabels[1].atomList[0] > 
				moleculeInfo->searchLabels[0].atomList[0]) {
			
				/* The first label comes first because it is smaller 
			   		(distance before angle, e.g.) */
	  	 		double increment;
				if(moleculeInfo->searchLabels[0].numSteps>NumberOfGridSteps)
					moleculeInfo->searchLabels[0].numSteps = NumberOfGridSteps;
				increment = (moleculeInfo->searchLabels[0].highValue 
	   			    - moleculeInfo->searchLabels[0].lowValue) / 
					moleculeInfo->searchLabels[0].numSteps;	
				sprintf(keywords,"%s STEP1=%lf POINT1=%d", keywords,
					increment,moleculeInfo->searchLabels[0].numSteps+1);
				if(moleculeInfo->searchLabels[1].numSteps>NumberOfGridSteps)
					moleculeInfo->searchLabels[1].numSteps = NumberOfGridSteps;
	   			increment = (moleculeInfo->searchLabels[1].highValue 
	   			    - moleculeInfo->searchLabels[1].lowValue) / 
					moleculeInfo->searchLabels[1].numSteps;
				sprintf(keywords,"%s STEP2=%lf POINT2=%d", keywords,
					increment,moleculeInfo->searchLabels[1].numSteps+1);

			} else { 
					/* The second label comes first because it is smaller 
			   		(distance before angle, e.g.) */
	  	 		double increment;
				if(moleculeInfo->searchLabels[1].numSteps>NumberOfGridSteps)
					moleculeInfo->searchLabels[1].numSteps = NumberOfGridSteps;
				increment = (moleculeInfo->searchLabels[1].highValue 
	   			    - moleculeInfo->searchLabels[1].lowValue) / 
					moleculeInfo->searchLabels[1].numSteps;	
				sprintf(keywords,"%s STEP1=%lf POINT1=%d", keywords,
					increment,moleculeInfo->searchLabels[1].numSteps+1);
				if(moleculeInfo->searchLabels[0].numSteps>NumberOfGridSteps)
					moleculeInfo->searchLabels[0].numSteps = NumberOfGridSteps;
	   			increment = (moleculeInfo->searchLabels[0].highValue 
	   			    - moleculeInfo->searchLabels[0].lowValue) / 
					moleculeInfo->searchLabels[0].numSteps;
				sprintf(keywords,"%s STEP2=%lf POINT2=%d", keywords,
					increment,moleculeInfo->searchLabels[0].numSteps+1);
			}
		}
	}
	if (!(control.timeLimit == 3600 && control.timeLimitUnits == 1)
	    && control.timeLimit != 0) {
		if (strstr(control.extraKeyWords," T=") == 0 && strncmp(control.extraKeyWords,"T=",2) != 0) {
			/* limit the time units so that they will not overflow a 32-bit word */
			long timeLimitTemp;
			timeLimitTemp = control.timeLimitUnits;

			if (timeLimitTemp == TIMELIM_MIN) {
				string[0] = 'M';
				string[1] = 0;
			} else if (timeLimitTemp == TIMELIM_HOUR) {
				string[0] = 'H';
				string[1] = 0;
			} else if (timeLimitTemp == TIMELIM_DAY) {
				string[0] = 'D';
				string[1] = 0;
			} else
				string[0] = 0;
			timeLimitTemp = control.timeLimit;
			if (timeLimitTemp < 0)
				timeLimitTemp = 0;
			if (strncmp(string,"D",1)) {
				if (timeLimitTemp > 240000L) 
					timeLimitTemp = 240000L;
			}
			else if (strncmp(string,"H",1)) {
				if (timeLimitTemp > 5900000L) 
					timeLimitTemp = 5900000L;
			}
			else if (strncmp(string,"M",1)) {
				if (timeLimitTemp > 70000000L) 
					timeLimitTemp = 70000000L;
			}
			else if (timeLimitTemp > 2000000000L) /* seconds */
					timeLimitTemp = 2000000000L;
			sprintf(keywords,"%s T=%d%s", keywords, timeLimitTemp,string);
		}
	}
		
	if (moleculeInfo->netCharge != 0 && (strstr(control.extraKeyWords,"CHARGE=") == 0)) 
		sprintf(keywords,"%s CHARGE=%d",keywords, moleculeInfo->netCharge);
		
	/* Dummy atom in the first position will require GEO-OK for EF and XYZ calculations */
	k = moleculeInfo->atomLocation[0];
 	if (strncmp(atsymbol[k],"Xe",2) == 0 || strncmp(atsymbol[k],"Pu",2) == 0) {
		if ((control.calculate == optimizeGeometryMN ||
		 	 control.calculate == optSearchMN) && 
					(control.geometrySearch == EFgeoOptMethodMN) &&
					(control.detailsUseXYZ) &&
					(!(strstr(control.extraKeyWords,"GEO-OK")))) {
			sprintf(errs,"It is necessary to add the GEO-OK Extra Keyword for a" 
				"calculation that uses eigenvector following (EF) geometry "
				"optimization with the options you have checked.");

			leaveBusyState();
			rtn_code = cancelOrProceedDialog(errs, 
				"Press OK to add the GEO-OK Extra Keyword and proceed with the calculation.", 
				"Press Cancel if you do not wish to run the calculation.");

			enterBusyState();
			if (rtn_code < 0)
				goto errorReturn;
			else if (rtn_code == 1)
				goto cancelReturn;
			else 
				sprintf(keywords,"%s GEO-OK",keywords);
		} else if ((control.calculate == transitionStateMN) && 
					(control.geometrySearch == EFgeoOptMethodMN) &&
					(!(strstr(control.extraKeyWords,"GEO-OK")))) {
			sprintf(errs,"It is necessary to add the GEO-OK Extra Keyword for a" 
				"calculation that uses eigenvector following (EF) geometry "
				"optimization with the options you have checked.");

			leaveBusyState();
			rtn_code = cancelOrProceedDialog(errs, 
				"Press OK to add the GEO-OK Extra Keyword and proceed with the calculation.", 
				"Press Cancel if you do not wish to run the calculation.");

			enterBusyState();
			if (rtn_code < 0)
				goto errorReturn;
			else if (rtn_code == 1)
				goto cancelReturn;
			else 
				sprintf(keywords,"%s GEO-OK",keywords);
		} else if ((control.calculate == minimizeGradientMN) && 
					(control.minimizeGradient == EFgradMinMethodMN)&&
					(control.detailsUseXYZ) &&
					(!(strstr(control.extraKeyWords,"GEO-OK")))) {
			sprintf(errs,"It is necessary to add the GEO-OK Extra Keyword for a" 
				"calculation that uses eigenvector following (EF) gradient "
				"minimization with the options you have checked.");

			leaveBusyState();
			rtn_code = cancelOrProceedDialog(errs, 
				"Press OK to add the GEO-OK Extra Keyword and proceed with the calculation.", 
				"Press Cancel if you do not wish to run the calculation.");

			enterBusyState();
			if (rtn_code < 0)
				goto errorReturn;
			else if (rtn_code == 1)
				goto cancelReturn;
			else 
				sprintf(keywords,"%s GEO-OK",keywords);
		}
	}
	if (numDummyAtoms == 0) {
		for (i=1; i < MOPAC_MIN(3,NAtom); i++) {
			k = moleculeInfo->atomLocation[i];
			if (strncmp(atsymbol[k],"Xe",2) == 0 || strncmp(atsymbol[k],"Pu",2) == 0) {
				if ((control.calculate == optimizeGeometryMN ||
		 	 		 control.calculate == optSearchMN) && 
							(control.geometrySearch == EFgeoOptMethodMN) &&
							(control.detailsUseXYZ) &&
							(!(strstr(control.extraKeyWords,"GEO-OK")))) {
					sprintf(errs,"It is necessary to add the GEO-OK Extra Keyword for a " 
						"calculation that uses eigenvector following (EF) geometry "
						"optimization with the options you have checked.");

					leaveBusyState();
					rtn_code = cancelOrProceedDialog(errs, 
						"Press OK to add the GEO-OK Extra Keyword and proceed with the calculation.", 
						"Press Cancel if you do not wish to run the calculation.");

					enterBusyState();
					if (rtn_code < 0)
						goto errorReturn;
					else if (rtn_code == 1)
						goto cancelReturn;
					else 
						sprintf(keywords,"%s GEO-OK",keywords);
				} else if ((control.calculate == transitionStateMN) && 
							(control.geometrySearch == EFgeoOptMethodMN) &&
							(!(strstr(control.extraKeyWords,"GEO-OK")))) {
					sprintf(errs,"It is necessary to add the GEO-OK Extra Keyword for a " 
						"calculation that uses eigenvector following (EF) geometry "
						"optimization with the options you have checked.");

					leaveBusyState();
					rtn_code = cancelOrProceedDialog(errs, 
						"Press OK to add the GEO-OK Extra Keyword and proceed with the calculation.", 
						"Press Cancel if you do not wish to run the calculation.");

					enterBusyState();
					if (rtn_code < 0)
						goto errorReturn;
					else if (rtn_code == 1)
						goto cancelReturn;
					else 
						sprintf(keywords,"%s GEO-OK",keywords);
				} else if ((control.calculate == minimizeGradientMN) && 
							(control.minimizeGradient == EFgradMinMethodMN)&&
							(control.detailsUseXYZ) &&
							(!(strstr(control.extraKeyWords,"GEO-OK")))) {
					sprintf(errs,"It is necessary to add the GEO-OK Extra Keyword for a " 
						"calculation that uses eigenvector following (EF) gradient "
						"minimization with the options you have checked.");

					leaveBusyState();
					rtn_code = cancelOrProceedDialog(errs, 
						"Press OK to add the GEO-OK Extra Keyword and proceed with the calculation.", 
						"Press Cancel if you do not wish to run the calculation.");

					enterBusyState();
					if (rtn_code < 0)
						goto errorReturn;
					else if (rtn_code == 1)
						goto cancelReturn;
					else 
						sprintf(keywords,"%s GEO-OK",keywords);
				}
			}
		}
	}

	/* Create an atomLocation array without dummy atoms */
	for (i = 0; i < NAtom+numDummyAtoms; i++)
		moleculeInfo->locationWithoutDummies[i] = -1;
	for (i = 0, j = 0; i < NAtom+numDummyAtoms; i++) {
		if (numDummyAtoms == 2 && (i == 1 || i == 2))
			continue;
		k = moleculeInfo->atomLocation[i];
		if (strncmp(atsymbol[k],"Xe",2) != 0 && strncmp(atsymbol[k],"Pu",2) != 0) {
			moleculeInfo->locationWithoutDummies[j] = 
				moleculeInfo->atomLocation[i];
			j++;
		}
	}
	
	/* Add OLDGEO keyword for calculations after the first one */
	if ((inputCalcNumber > 0) && !(strstr(control.extraKeyWords,"OLDGEO"))) {
		if ((strlen(keywords)+7) < MAX_KEYWORD_LENGTH)
			strcat(keywords," OLDGEO");
		else {	/* MAX_KEYWORD_LENGTH because " +" will have to be added to the first two lines */ 
	   sprintf(errs,"Options you have selected define MOPAC "
	                "keywords using more than %d characters."
	                "  Check fewer options on the Details dialog.",MAX_KEYWORD_LENGTH);
		alert_user_watch(errs);
	   
		/* keywords with initial part of message can overrun the errs string. 2/25/91 SJC
		Put in initial part of message*/
		sprintf(errs,"The MOPAC keywords you defined are: ");
		/* Then add the part of keywords that will fit */
		strncat(errs, keywords, sizeof(errs) - 1 - strlen(errs));
		/* And finally make sure that errs is still null-terminated */
		errs[255] = 0;
		alert_user_watch(errs);
		goto noSplitReturn;
	
		}
	}

	/* Make sure the extra keywords will fit in the keywords */
	if (control.extraKeyWords[0] != 0) {
		if (strlen(control.extraKeyWords) <=
			(MAX_KEYWORD_LENGTH - 1 - strlen(keywords))) {
			strcat(keywords," ");
			strncat(keywords, control.extraKeyWords, 
				MAX_KEYWORD_LENGTH - strlen(keywords));
		} else {
			sprintf(errs,"The MOPAC keywords generated by the options you have "
		   					"selected and your extra keywords will not fit.  "
							"Please reduce the number of extra keywords and try again.");
			alert_user_watch(errs);
			goto errorReturn;
		}
	}

	/* Make sure the keywords are null-terminated */
	keywords[MAX_KEYWORD_LENGTH] = 0;

    /* Check to be sure that the keywords line is less than or equal
	   to MAX_KEYWORD_LENGTH characters in length.  If it is too long, notify the user that
	   fewer options must be selected. */
	if (strlen(keywords) > MAX_KEYWORD_LENGTH) {	/* MAX_KEYWORD_LENGTH because " +" will have to be added to the first two lines */ 
	   sprintf(errs,"Options you have selected define MOPAC "
	                "keywords using more than %d characters."
	                "  Check fewer options on the Details dialog.",MAX_KEYWORD_LENGTH);
		alert_user_watch(errs);
	   
		/* keywords with initial part of message can overrun the errs string. 2/25/91 SJC
		Put in initial part of message*/
		sprintf(errs,"The MOPAC keywords you defined are: ");
		/* Then add the part of keywords that will fit */
		strncat(errs, keywords, sizeof(errs) - 1 - strlen(errs));
		/* And finally make sure that errs is still null-terminated */
		errs[255] = 0;
		alert_user_watch(errs);
		goto noSplitReturn;
	}
	/* Split keywords into up to three lines as required
	 * Title lines must be conserved for other uses
	 */
		
	if (strlen(keywords) <= 80) {						/* Just one line */
		fprintf(file,"%s\n",keywords); 
	} else {											/* Two or three lines */
		/* find the first blank starting from the 78th character */
		int lastblank1;
		int lastblank2;
		char	line80[81];
		char	line78[79];
		lastblank1 = 0;
		lastblank2 = 0;
		for (i = 0; i < 79 ; i++) line78[i] = 0;
		for (i = 0; i < 81 ; i++) line80[i] = 0;
		strncpy(line78,keywords,78);
		lastblank1 = findLastBlank(line78,78);
		if (lastblank1 == 0 ) {
			sprintf(errs,"Unable to break input keywords into multiple lines.  "
					"Be sure to place spaces between keywords entered in the "
					"Extra Keywords dialog of the Details dialog.");
			alert_user_watch(errs);
			sprintf(errs,"The line contains the keywords: %s.",line78);
			alert_user_watch(errs);
			goto noSplitReturn;
		}
		strncpy(line80,line78,lastblank1);
		strncpy(line80+lastblank1," +",2);
		fprintf(file,"%s\n",line80);

		/* now see if the rest of the keyword line will fit on the second line */

		if (strlen(keywords+lastblank1) <= 80) { /* It fits on the second line */
			fprintf(file,"%s\n",keywords+lastblank1);
		} else { 	/* put what will fit on the second line and then print a third line */
			for (i = 0; i < 79 ; i++) line78[i] = 0;
			for (i = 0; i < 81 ; i++) line80[i] = 0;
			strncpy (line78,keywords+lastblank1,78);
			lastblank2 = findLastBlank(line78,78);
			if (lastblank2 == 0 ) {
				sprintf(errs,"Unable to break input keywords into multiple lines.  "
					"Be sure to place spaces between keywords entered in the "
					"Extra Keywords dialog of the Details dialog.");
				alert_user_watch(errs);
				sprintf(errs,"The line contains the keywords: %s.",line78);
				alert_user_watch(errs);
				goto noSplitReturn;
			}
			strncpy(line80,line78,lastblank2);
			strncpy(line80+lastblank2," +",2);
			fprintf(file,"%s\n",line80);
			/* see if the rest of the keyword line will fit on the third line */
			
			if (strlen(keywords+lastblank1+lastblank2) <= 80) { /* it fits */
				fprintf(file,"%s\n",keywords+lastblank1+lastblank2);
			} else { /* keywords won't fit on three lines.  Tell the user and quit */
				sprintf(errs,"The MOPAC keywords generated by the options you have "
								"selected and your extra keywords will not fit.  "
								"Please reduce the number of extra keywords and try again.");
				alert_user_watch(errs);
	  			sprintf(errs,"The MOPAC keywords you defined are: ");
				strncat(errs, keywords, sizeof(errs) - 2 - strlen(errs));
				strcat(errs, ".");
				errs[255] = 0;
				alert_user_watch(errs);
	  			goto noSplitReturn;
			}
		}
			
	}

    /* Keywords line is complete */
	
	for (i=0; control.title[i] != 0; i++) 
		if (control.title[i] < 32) control.title[i] = ' ';
	strncpy(string, control.title, 72);
	string[72] = '\0';
	fprintf(file,"%s\n", string);
	if (numDummyAtoms == 0)
		fprintf(file,"%s\n",&(control.title[72]));
	else
	/* use the second title line to store the (x,y,z) coordinates of the first atom */
		fprintf(file,"CAChe_MOPAC_coordinate_shift: %14.6lf  %14.6lf  %14.6lf\n",
			coords[0][0],coords[0][1],coords[0][2]);

  /* 
   * Only the first calculation will have input geometry; 
   * subsequent calculations will have OLDGEO 
   */
  if (inputCalcNumber == 0) {

  if ((NAtom+numDummyAtoms) > 3  && 
  		(control.detailsGeoType == CARTESIAN_COORD)) {
    /* 
		This block of code is used when input in cartesian coordinates
	   	is required. 
	 */
 	/* put first real atom first */
	k = moleculeInfo->atomLocation[0];
	atsym2 = atsymbol[k][1];
	atsym1 = atsymbol[k][0];
	if (atsym2 < 32 || atsym2 > 126) {
		atsym2 = ' ';
	} else if (atsym2 == '_') atsym2 = ' ';

/* Assign sparkles, dummy atoms and capped bonds to special atoms */
	            if (strncmp(atsymbol[k],"Pu",2) == 0) {  // Z = 94
		   atsym1='X';
		   atsym2='X';
        } else 	if (strncmp(atsymbol[k],"Xe",2) == 0) {  // Z = 54 (Obsolete)
		   atsym1='X';
		   atsym2='X';
		   if (Xe) alert_user("Use Pu instead of Xe for dummy atoms.");
		   if (Xe) alert_user("Future versions of CAChe will not support Xe.");
		   Xe = 0;
	    } else 	if (strncmp(atsymbol[k],"Am",2) == 0) {  // Z = 95
		   atsym1='C';
		   atsym2='b';
        } else 	if (strncmp(atsymbol[k],"Rn",2) == 0) {  // Z = 86 (Obsolete)
		   atsym1='C';
		   atsym2='b';
		   if (Rn) alert_user("Use Am instead of Rn for capped bonds");
		   if (Rn) alert_user("Future versions of CAChe will not support Rn.");
		   Rn = 0;
	    } else 	if (strncmp(atsymbol[k],"Cm",2) == 0) {  // Z = 96
		   atsym1='+';
		   atsym2='3';
	    } else 	if (strncmp(atsymbol[k],"Bk",2) == 0) {  // Z = 97
		   atsym1='+';
	 	   atsym2='+';
	    } else 	if (strncmp(atsymbol[k],"Cf",2) == 0) {  // Z = 98
		   atsym1='+';
		   atsym2=' ';
	    } else 	if (strncmp(atsymbol[k],"Es",2) == 0) {  // Z = 99
		   atsym1='F';
		   atsym2='r';
	    } else 	if (strncmp(atsymbol[k],"Fm",2) == 0) {  // Z = 100
		   atsym1='A';
		   atsym2='t';
	    } else 	if (strncmp(atsymbol[k],"Md",2) == 0) {  // Z = 101
		   atsym1='-';
		   atsym2=' ';
        } else 	if (strncmp(atsymbol[k],"At",2) == 0) {  // Z = 85 (Obsolete)
		   atsym1='-';
		   atsym2=' ';
		   if (At) alert_user("Use Md instead of At for -1 sparkles.");
		   if (At) alert_user("Future versions of CAChe will not support At.");
		   At = 0;
	    } else 	if (strncmp(atsymbol[k],"No",2) == 0) {  // Z = 102
		   atsym1='-';
		   atsym2='-';	
        } else 	if (strncmp(atsymbol[k],"Po",2) == 0) {  // Z = 84 (Obsolete)
		   atsym1='-';
		   atsym2='-';	
		   if (Po) alert_user("Use No instead of Po for -2 sparkles.");
		   if (Po) alert_user("Future versions of CAChe will not support Po.");
		   Po = 0;
	    } else 	if (strncmp(atsymbol[k],"Lr",2) == 0) {  // Z = 103
		   atsym1='-';
		   atsym2='3';
		}
	fprintf(file,"%c%c(%3d) ", atsym1, atsym2, atomID[k]);
	
	if (lockedAtoms[k])
		/* flag locked atoms differently */
		fprintf(file,"%14.6lf  0  %14.6lf  0  %14.6lf  0\n", 
			 coords[0][0], coords[0][1], coords[0][2]);
	else
		fprintf(file,"%14.6lf  1  %14.6lf  1  %14.6lf  1\n", 
			coords[0][0], coords[0][1], coords[0][2]);

	/* put in dummy atoms next */
	/* sanity check on having assigned the proper Y and Z values to the
	   dummy atoms */
	if (numDummyAtoms > 0) {
		if ((coords[1][1] != coords[0][1]) || (coords[1][2] != coords[0][2]) ||
			(coords[2][2] != coords[0][2])) {
			alert_user_watch("makeMOPACInput: Error in coordinates for dummy atoms.");
			goto errorReturn;
		}
	}
    for (i=1; i < numDummyAtoms+1; i++) {
		fprintf(file,"XX(   ) ");
		/* only flag atoms as not being optimized if the XYZ keyword is used */
		if (control.detailsUseXYZ)
		   fprintf(file,"%14.6lf  0  %14.6lf  0  %14.6lf  0\n", 
		        coords[i][0], coords[i][1], coords[i][2]);
		else
		   fprintf(file,"%14.6lf  1  %14.6lf  1  %14.6lf  1\n", 
		        coords[i][0], coords[i][1], coords[i][2]);
	}
	/* and then the rest of the atoms */
 	for (i=numDummyAtoms+1; i<NAtom+numDummyAtoms; i++) {
		k = moleculeInfo->atomLocation[i];
		atsym2 = atsymbol[k][1];
		atsym1 = atsymbol[k][0];
		if (atsym2 < 32 || atsym2 > 126) {
		    atsym2 = ' ';
		} else if (atsym2 == '_') atsym2 = ' ';

    /* Assign sparkles, dummy atoms and capped bonds to special atoms */
	            if (strncmp(atsymbol[k],"Pu",2) == 0) {  // Z = 94
		   atsym1='X';
		   atsym2='X';
        } else 	if (strncmp(atsymbol[k],"Xe",2) == 0) {  // Z = 54 (Obsolete)
		   atsym1='X';
		   atsym2='X';
		   if (Xe) alert_user("Use Pu instead of Xe for dummy atoms.");
		   if (Xe) alert_user("Future versions of CAChe will not support Xe.");
		   Xe = 0;
	    } else 	if (strncmp(atsymbol[k],"Am",2) == 0) {  // Z = 95
		   atsym1='C';
		   atsym2='b';
        } else 	if (strncmp(atsymbol[k],"Rn",2) == 0) {  // Z = 86 (Obsolete)
		   atsym1='C';
		   atsym2='b';
		   if (Rn) alert_user("Use Am instead of Rn for capped bonds");
		   if (Rn) alert_user("Future versions of CAChe will not support Rn.");
		   Rn = 0;
	    } else 	if (strncmp(atsymbol[k],"Cm",2) == 0) {  // Z = 96
		   atsym1='+';
		   atsym2='3';
	    } else 	if (strncmp(atsymbol[k],"Bk",2) == 0) {  // Z = 97
		   atsym1='+';
	 	   atsym2='+';
	    } else 	if (strncmp(atsymbol[k],"Cf",2) == 0) {  // Z = 98
		   atsym1='+';
		   atsym2=' ';
	    } else 	if (strncmp(atsymbol[k],"Es",2) == 0) {  // Z = 99
		   atsym1='F';
		   atsym2='r';
	    } else 	if (strncmp(atsymbol[k],"Fm",2) == 0) {  // Z = 100
		   atsym1='A';
		   atsym2='t';
	    } else 	if (strncmp(atsymbol[k],"Md",2) == 0) {  // Z = 101
		   atsym1='-';
		   atsym2=' ';
        } else 	if (strncmp(atsymbol[k],"At",2) == 0) {  // Z = 85 (Obsolete)
		   atsym1='-';
		   atsym2=' ';
		   if (At) alert_user("Use Md instead of At for -1 sparkles.");
		   if (At) alert_user("Future versions of CAChe will not support At.");
		   At = 0;
	    } else 	if (strncmp(atsymbol[k],"No",2) == 0) {  // Z = 102
		   atsym1='-';
		   atsym2='-';	
        } else 	if (strncmp(atsymbol[k],"Po",2) == 0) {  // Z = 84 (Obsolete)
		   atsym1='-';
		   atsym2='-';	
		   if (Po) alert_user("Use No instead of Po for -2 sparkles.");
		   if (Po) alert_user("Future versions of CAChe will not support Po.");
		   Po = 0;
	    } else 	if (strncmp(atsymbol[k],"Lr",2) == 0) {  // Z = 103
		   atsym1='-';
		   atsym2='3';
		}

		
		fprintf(file,"%c%c(%3d) ", atsym1, atsym2, atomID[k]);
		
		if (lockedAtoms[k])
			/* flag locked atoms differently */
			fprintf(file,"%14.6lf  0  %14.6lf  0  %14.6lf  0\n", 
		       	 coords[i][0], coords[i][1], coords[i][2]);
		else
			fprintf(file,"%14.6lf  1  %14.6lf  1  %14.6lf  1\n", 
		        coords[i][0], coords[i][1], coords[i][2]);

 	}	
  } else {

/* 
  Use internal coordinates.
*/

	if ((isAtomCappedBond = (Boolean (*)) 
			malloc(sizeof(Boolean)*MOPAC_MAX(3,NAtom+numDummyAtoms))) == NULL) {
		alert_user_watch("makeMOPACInput: Unable to allocate isAtomCappedBond array.  "
					"Increase the memory size for your MOPAC application using the "
					"Get Info command");
		goto errorReturn;
	} else {
		for (i = 0; i < NAtom + numDummyAtoms; i++)
			isAtomCappedBond[i] = FALSE;
	}
		
	/* put first real atom first */
	i = 0;
	k = moleculeInfo->atomLocation[i];
	atsym1 = atsymbol[k][0];
	atsym2 = atsymbol[k][1];
	if (atsym2 < 32 || atsym2 > 126) {
		atsym2 = ' ';
	} else if (atsym2 == '_') atsym2 = ' ';

/* Assign sparkles, dummy atoms and capped bonds to special atoms */
	                if (strncmp(atsymbol[k],"Pu",2) == 0) {  // Z = 94
		   atsym1='X';
		   atsym2='X';
        } else 	if (strncmp(atsymbol[k],"Xe",2) == 0) {  // Z = 54 (Obsolete)
		   atsym1='X';
		   atsym2='X';
		   if (Xe) alert_user("Use Pu instead of Xe for dummy atoms.");
		   if (Xe) alert_user("Future versions of CAChe will not support Xe.");
		   Xe = 0;
	    } else 	if (strncmp(atsymbol[k],"Am",2) == 0) {  // Z = 95
	       isAtomCappedBond[i] = TRUE;
		   atsym1='C';
		   atsym2='b';
        } else 	if (strncmp(atsymbol[k],"Rn",2) == 0) {  // Z = 86 (Obsolete)
		   isAtomCappedBond[i] = TRUE;
		   atsym1='C';
		   atsym2='b';
		   if (Rn) alert_user("Use Am instead of Rn for capped bonds");
		   if (Rn) alert_user("Future versions of CAChe will not support Rn.");
		   Rn = 0;
	    } else 	if (strncmp(atsymbol[k],"Cm",2) == 0) {  // Z = 96
		   atsym1='+';
		   atsym2='3';
	    } else 	if (strncmp(atsymbol[k],"Bk",2) == 0) {  // Z = 97
		   atsym1='+';
	 	   atsym2='+';
	    } else 	if (strncmp(atsymbol[k],"Cf",2) == 0) {  // Z = 98
		   atsym1='+';
		   atsym2=' ';
	    } else 	if (strncmp(atsymbol[k],"Es",2) == 0) {  // Z = 99
		   atsym1='F';
		   atsym2='r';
	    } else 	if (strncmp(atsymbol[k],"Fm",2) == 0) {  // Z = 100
		   atsym1='A';
		   atsym2='t';
	    } else 	if (strncmp(atsymbol[k],"Md",2) == 0) {  // Z = 101
		   atsym1='-';
		   atsym2=' ';
        } else 	if (strncmp(atsymbol[k],"At",2) == 0) {  // Z = 85 (Obsolete)
		   atsym1='-';
		   atsym2=' ';
		   if (At) alert_user("Use Md instead of At for -1 sparkles.");
		   if (At) alert_user("Future versions of CAChe will not support At.");
		   At = 0;
	    } else 	if (strncmp(atsymbol[k],"No",2) == 0) {  // Z = 102
		   atsym1='-';
		   atsym2='-';	
        } else 	if (strncmp(atsymbol[k],"Po",2) == 0) {  // Z = 84 (Obsolete)
		   atsym1='-';
		   atsym2='-';
		   if (Po) alert_user("Use No instead of Po for -2 sparkles.");
		   if (Po) alert_user("Future versions of CAChe will not support Po.");
		   Po = 0;
	    } else 	if (strncmp(atsymbol[k],"Lr",2) == 0) {  // Z = 103
		   atsym1='-';
		   atsym2='3';
		}
	
	
	fprintf(file,"%c%c(%3d) ", atsym1, atsym2,atomID[k]);
	fprintf(file,"%14.6lf %2d  %14.6lf %2d  %14.6lf %2d  %3d %3d %3d\n", 
			zMatrix[i].distance, zMatrix[i].varyDistance,
			zMatrix[i].angle, zMatrix[i].varyAngle,
			zMatrix[i].dihedral, zMatrix[i].varyDihedral,
			zMatrix[i].atomA + 1, zMatrix[i].atomB + 1,
			zMatrix[i].atomC + 1);

	/* and then the dummy atoms */
	/* sanity check on having assigned the proper Y and Z values to the
	   dummy atoms */
	if (numDummyAtoms > 0) {
		k = moleculeInfo->atomLocation[0];
		if ((coords[1][1] != coords[0][1]) || (coords[1][2] != coords[0][2]) ||
			(coords[2][2] != coords[0][2])) {
			alert_user_watch("makeMOPACInput: Error in coordinates for dummy atoms.");
			goto errorReturn;
		}
	}
 	for (i=1; i < numDummyAtoms+1; i++) {
		/* don't vary coordinates for dummy atoms */
		zMatrix[i].varyDistance = zMatrix[i].varyAngle = zMatrix[i].varyDihedral = 0;
		fprintf(file,"XX(   ) ");
		fprintf(file,"%14.6lf %2d  %14.6lf %2d  %14.6lf %2d  %3d %3d %3d\n", 
		        zMatrix[i].distance, zMatrix[i].varyDistance,
				zMatrix[i].angle, zMatrix[i].varyAngle,
				zMatrix[i].dihedral, zMatrix[i].varyDihedral,
				zMatrix[i].atomA + 1, zMatrix[i].atomB + 1,
				zMatrix[i].atomC + 1);
	 }
	 
	 /* and then the rest of the atoms */
 	 for (i=numDummyAtoms+1; i < NAtom+numDummyAtoms; i++) {
		k = moleculeInfo->atomLocation[i];
		atsym1 = atsymbol[k][0];
		atsym2 = atsymbol[k][1];
		if (atsym2 < 32 || atsym2 > 126) {
		    atsym2 = ' ';
		} else if (atsym2 == '_') atsym2 = ' ';
/* Assign sparkles, dummy atoms and capped bonds to special atoms */
	            if (strncmp(atsymbol[k],"Pu",2) == 0) {  // Z = 94
		   atsym1='X';
		   atsym2='X';
        } else 	if (strncmp(atsymbol[k],"Xe",2) == 0) {  // Z = 54 (Obsolete)
		   atsym1='X';
		   atsym2='X';
		   if (Xe) alert_user("Use Pu instead of Xe for dummy atoms.");
		   if (Xe) alert_user("Future versions of CAChe will not support Xe.");
		   Xe = 0;
	    } else 	if (strncmp(atsymbol[k],"Am",2) == 0) {  // Z = 95
	       isAtomCappedBond[i] = TRUE;
		   if (zMatrix[i].distance < 3.0) {
			   zMatrix[i].varyDistance = 0;
			   zMatrix[i].distance = 1.7;
		   }
		   atsym1='C';
		   atsym2='b';
        } else 	if (strncmp(atsymbol[k],"Rn",2) == 0) {  // Z = 86 (Obsolete)
		   isAtomCappedBond[i] = TRUE;
		   if (zMatrix[i].distance < 3.0) {
			   zMatrix[i].varyDistance = 0;
			   zMatrix[i].distance = 1.7;
		   }
		   atsym1='C';
		   atsym2='b';
		   if (Rn) alert_user("Use Am instead of Rn for capped bonds");
		   if (Rn) alert_user("Future versions of CAChe will not support Rn.");
		   Rn = 0;
	    } else 	if (strncmp(atsymbol[k],"Cm",2) == 0) {  // Z = 96
		   atsym1='+';
		   atsym2='3';
	    } else 	if (strncmp(atsymbol[k],"Bk",2) == 0) {  // Z = 97
		   atsym1='+';
	 	   atsym2='+';
	    } else 	if (strncmp(atsymbol[k],"Cf",2) == 0) {  // Z = 98
		   atsym1='+';
		   atsym2=' ';
	    } else 	if (strncmp(atsymbol[k],"Es",2) == 0) {  // Z = 99
		   atsym1='F';
		   atsym2='r';
	    } else 	if (strncmp(atsymbol[k],"Fm",2) == 0) {  // Z = 100
		   atsym1='A';
		   atsym2='t';
	    } else 	if (strncmp(atsymbol[k],"Md",2) == 0) {  // Z = 101
		   atsym1='-';
		   atsym2=' ';
        } else 	if (strncmp(atsymbol[k],"At",2) == 0) {  // Z = 85 (Obsolete)
		   atsym1='-';
		   atsym2=' ';
		   if (At) alert_user("Use Md instead of At for -1 sparkles.");
		   if (At) alert_user("Future versions of CAChe will not support At.");
		   At = 0;
	    } else 	if (strncmp(atsymbol[k],"No",2) == 0) {  // Z = 102
		   atsym1='-';
		   atsym2='-';	
        } else 	if (strncmp(atsymbol[k],"Po",2) == 0) {  // Z = 84 (Obsolete)
		   atsym1='-';
		   atsym2='-';	
		   if (Po) alert_user("Use No instead of Po for -2 sparkles.");
		   if (Po) alert_user("Future versions of CAChe will not support Po.");
		   Po = 0;
	    } else 	if (strncmp(atsymbol[k],"Lr",2) == 0) {  // Z = 103
		   atsym1='-';
		   atsym2='3';
		}
	
   
		/* 
		 * If atom is bonded to a capped bond, set the bond distance to
		 * 1.7 Angstrom and lock the distance.
		 */

		if (isAtomCappedBond[zMatrix[i].atomA]) {
			if (zMatrix[i].distance < 3.0) {
				zMatrix[i].varyDistance = 0;
				zMatrix[i].distance = 1.7;
 	 }
  }
  
		fprintf(file,"%c%c(%3d) ", atsym1, atsym2,atomID[k]);
		fprintf(file,"%14.6lf %2d  %14.6lf %2d  %14.6lf %2d  %3d %3d %3d\n", 
		        zMatrix[i].distance, zMatrix[i].varyDistance,
				zMatrix[i].angle, zMatrix[i].varyAngle,
				zMatrix[i].dihedral, zMatrix[i].varyDihedral,
				zMatrix[i].atomA + 1, zMatrix[i].atomB + 1,
				zMatrix[i].atomC + 1);
 	 }
  }
  
  if (coords != NULL) free(coords);
  coords = NULL;
  if (isAtomCappedBond != NULL) free(isAtomCappedBond);
  isAtomCappedBond = NULL;
  
	/* Indicate the end of coordinates with a zero line. */
	fprintf(file,"        %14.6lf  0  %14.6lf  0  %14.6lf  0\n", 0., 0., 0.);
	
    if ((rtn_code = csu_ReleaseVal (molStruct, AtomID, AnumID)) < 0) {
    	sprintf (errs,"makeMOPACInput: csu_ReleaseVal AnumID, errno %d", rtn_code);
    	alert_user_watch(errs);
    }
	
    if ((rtn_code = csu_ReleaseVal (molStruct, AtomID, SymID)) < 0) {
    	sprintf (errs, "makeMOPACInput: csu_ReleaseVal SymID, errno %d", rtn_code);
    	alert_user_watch(errs);
    }
	
    if ((rtn_code = csu_ReleaseVal (molStruct, AtomID, XYZID)) < 0) {
    	sprintf (errs, "makeMOPACInput: csu_ReleaseVal XYZID, errno %d", rtn_code);
    	alert_user_watch(errs);
    }

	/* Write the product geometry if the is a SADDLE calculation */
	
	if (control.calculate == transitionStateMN &&
		hasProductMolecule(&control))
	{
   /*
    *  Find out how many of each object class there are.
    */
        i = NAtom;
        if (csu_ExistsObjclsID (productMolStruct, AtomID, &offset))
		NAtom = (long) ((GetPtr(productMolStruct->objclsH) + offset)->num_objs);
	else {
		alert_user_watch("makeMOPACInput: Unable to locate AtomID index in product molecule.");
		goto errorReturn;
	}
        if (NAtom != i)
        {
            	alert_user_watch ("Number of atoms in reactants and products are different.");
            goto errorReturn;
        }

   /*
    *  Set the array pointers for the atomic coordinates, atomic numbers,
    *  and atom symbols. Determine the net molecular charge.
    */
    
   		if ((rtn_code = csu_GrabVal (productMolStruct, AtomID, XYZID, (char **)&(tmpcoord))) < 0) {
     		sprintf (errs,"makeMOPACInput: csu_GrabVal XYZID, errno %d", rtn_code);
      		alert_user_watch(errs);
   		}
      
  		if ((rtn_code = csu_GrabVal (productMolStruct, AtomID, AnumID, (char **)&tmp_element)) < 0) {
    		sprintf (errs,"makeMOPACInput: csu_GrabVal AnumID, errno %d", rtn_code);
      		alert_user_watch(errs);
  		}

  		if ((rtn_code = csu_GrabVal (productMolStruct, AtomID, SymID, (char **)&atsymbol)) < 0) {
   		 	sprintf (errs,"makeMOPACInput: csu_GrabVal SymID, errno %d", rtn_code);
      		alert_user_watch(errs);
  		}
 
		if (NAtom > 3 && (control.detailsGeoType == CARTESIAN_COORD)) {
			for (i=0; i<NAtom; i++) {
				k = moleculeInfo->atomLocation[i];
				atsym2 = atsymbol[k][1];
				atsym1 = atsymbol[k][0];
				if (atsym2 < 32 || atsym2 > 126) {
					atsym2 = ' ';
				} else if (atsym2 == '_') atsym2 = ' ';
			
	
/* Assign sparkles, dummy atoms and capped bonds to special atoms */
	            if (strncmp(atsymbol[k],"Pu",2) == 0) {  // Z = 94
		   atsym1='X';
		   atsym2='X';
        } else 	if (strncmp(atsymbol[k],"Xe",2) == 0) {  // Z = 54 (Obsolete)
		   atsym1='X';
		   atsym2='X';
		   if (Xe) alert_user("Use Pu instead of Xe for dummy atoms.");
		   if (Xe) alert_user("Future versions of CAChe will not support Xe.");
		   Xe = 0;
	    } else 	if (strncmp(atsymbol[k],"Am",2) == 0) {  // Z = 95
		   atsym1='C';
		   atsym2='b';
        } else 	if (strncmp(atsymbol[k],"Rn",2) == 0) {  // Z = 86 (Obsolete)
		   atsym1='C';
		   atsym2='b';
		   if (Rn) alert_user("Use Am instead of Rn for capped bonds");
		   if (Rn) alert_user("Future versions of CAChe will not support Rn.");
		   Rn = 0;
	    } else 	if (strncmp(atsymbol[k],"Cm",2) == 0) {  // Z = 96
		   atsym1='+';
		   atsym2='3';
	    } else 	if (strncmp(atsymbol[k],"Bk",2) == 0) {  // Z = 97
		   atsym1='+';
	 	   atsym2='+';
	    } else 	if (strncmp(atsymbol[k],"Cf",2) == 0) {  // Z = 98
		   atsym1='+';
		   atsym2=' ';
	    } else 	if (strncmp(atsymbol[k],"Es",2) == 0) {  // Z = 99
		   atsym1='F';
		   atsym2='r';
	    } else 	if (strncmp(atsymbol[k],"Fm",2) == 0) {  // Z = 100
		   atsym1='A';
		   atsym2='t';
	    } else 	if (strncmp(atsymbol[k],"Md",2) == 0) {  // Z = 101
		   atsym1='-';
		   atsym2=' ';
        } else 	if (strncmp(atsymbol[k],"At",2) == 0) {  // Z = 85 (Obsolete)
		   atsym1='-';
		   atsym2=' ';
		   if (At) alert_user("Use Md instead of At for -1 sparkles.");
		   if (At) alert_user("Future versions of CAChe will not support At.");
		   At = 0;
	    } else 	if (strncmp(atsymbol[k],"No",2) == 0) {  // Z = 102
		   atsym1='-';
		   atsym2='-';	
        } else 	if (strncmp(atsymbol[k],"Po",2) == 0) {  // Z = 84 (Obsolete)
		   atsym1='-';
		   atsym2='-';	
		   if (Po) alert_user("Use No instead of Po for -2 sparkles.");
		   if (Po) alert_user("Future versions of CAChe will not support Po.");
		   Po = 0;
	    } else 	if (strncmp(atsymbol[k],"Lr",2) == 0) {  // Z = 103
		   atsym1='-';
		   atsym2='3';
		}

				fprintf(file,"%c%c(%3d) ", atsym1, atsym2, atomID[k]);
				fprintf(file,"%14.6lf  1  %14.6lf  1  %14.6lf  1\n", 
						tmpcoord[i][0], tmpcoord[i][1], tmpcoord[i][2]);
			}
		 } else {
			/* 
			  Use internal coordinates.
			*/
				 zMatrix[1].atomA = 0;
    			 cartesianToInternal(tmpcoord, NAtom+numDummyAtoms, zMatrix,
				 					numberBonds, bondList, moleculeInfo->atomLocation,
									numDummyAtoms);
				 for (i=0; i < NAtom; i++) {
					zMatrix[i].varyDistance = 1;
					zMatrix[i].varyAngle = 1;
					zMatrix[i].varyDihedral = 1;
				 }
				 zMatrix[0].varyDistance = 0;
				 zMatrix[0].varyAngle = 0;
				 zMatrix[0].varyDihedral = 0;
				 zMatrix[1].varyAngle = 0;
				 zMatrix[1].varyDihedral = 0;
				 zMatrix[2].varyDihedral = 0;
				 for (i=0; i < NAtom; i++) {
					k = moleculeInfo->atomLocation[i];
					atsym2 = atsymbol[k][1];
					atsym1 = atsymbol[k][0];
					if (atsym2 < 32 || atsym2 > 126) {
						atsym2 = ' ';
					} else if (atsym2 == '_') atsym2 = ' ';
				
					/* Assign sparkles, dummy atoms and capped bonds to special atoms */
				

				
/* Assign sparkles, dummy atoms and capped bonds to special atoms */
	            if (strncmp(atsymbol[k],"Pu",2) == 0) {  // Z = 94
		   atsym1='X';
		   atsym2='X';
        } else 	if (strncmp(atsymbol[k],"Xe",2) == 0) {  // Z = 54 (Obsolete)
		   atsym1='X';
		   atsym2='X';
		   if (Xe) alert_user("Use Pu instead of Xe for dummy atoms.");
		   if (Xe) alert_user("Future versions of CAChe will not support Xe.");
		   Xe = 0;
	    } else 	if (strncmp(atsymbol[k],"Am",2) == 0) {  // Z = 95
		   atsym1='C';
		   atsym2='b';
        } else 	if (strncmp(atsymbol[k],"Rn",2) == 0) {  // Z = 86 (Obsolete)
		   atsym1='C';
		   atsym2='b';
		   if (Rn) alert_user("Use Am instead of Rn for capped bonds");
		   if (Rn) alert_user("Future versions of CAChe will not support Rn.");
		   Rn = 0;
	    } else 	if (strncmp(atsymbol[k],"Cm",2) == 0) {  // Z = 96
		   atsym1='+';
		   atsym2='3';
	    } else 	if (strncmp(atsymbol[k],"Bk",2) == 0) {  // Z = 97
		   atsym1='+';
	 	   atsym2='+';
	    } else 	if (strncmp(atsymbol[k],"Cf",2) == 0) {  // Z = 98
		   atsym1='+';
		   atsym2=' ';
	    } else 	if (strncmp(atsymbol[k],"Es",2) == 0) {  // Z = 99
		   atsym1='F';
		   atsym2='r';
	    } else 	if (strncmp(atsymbol[k],"Fm",2) == 0) {  // Z = 100
		   atsym1='A';
		   atsym2='t';
	    } else 	if (strncmp(atsymbol[k],"Md",2) == 0) {  // Z = 101
		   atsym1='-';
		   atsym2=' ';
        } else 	if (strncmp(atsymbol[k],"At",2) == 0) {  // Z = 85 (Obsolete)
		   atsym1='-';
		   atsym2=' ';
		   if (At) alert_user("Use Md instead of At for -1 sparkles.");
		   if (At) alert_user("Future versions of CAChe will not support At.");
		   At = 0;
	    } else 	if (strncmp(atsymbol[k],"No",2) == 0) {  // Z = 102
		   atsym1='-';
		   atsym2='-';	
        } else 	if (strncmp(atsymbol[k],"Po",2) == 0) {  // Z = 84 (Obsolete)
		   atsym1='-';
		   atsym2='-';	
		   if (Po) alert_user("Use No instead of Po for -2 sparkles.");
		   if (Po) alert_user("Future versions of CAChe will not support Po.");
		   Po = 0;
	    } else 	if (strncmp(atsymbol[k],"Lr",2) == 0) {  // Z = 103
		   atsym1='-';
		   atsym2='3';
		}

					fprintf(file,"%c%c(%3d) ", atsym1, atsym2, atomID[k]);
					fprintf(file,"%14.6lf %2d  %14.6lf %2d  %14.6lf %2d  %3d %3d %3d\n", 
							zMatrix[i].distance, zMatrix[i].varyDistance,
							zMatrix[i].angle, zMatrix[i].varyAngle,
							zMatrix[i].dihedral, zMatrix[i].varyDihedral,
							zMatrix[i].atomA + 1, zMatrix[i].atomB + 1,
							zMatrix[i].atomC + 1);
				}
				
		  }
		/* Indicate the end of coordinates with a zero line. */
		fprintf(file,"        %14.6lf  0  %14.6lf  0  %14.6lf  0\n", 0., 0., 0.);
	
    	if ((rtn_code = csu_ReleaseVal (molStruct, AtomID, AnumID)) < 0) {
       		sprintf (errs,"makeMOPACInput: csu_ReleaseVal AnumID, errno %d", rtn_code);
      		alert_user_watch(errs);
    	}
	
    	if ((rtn_code = csu_ReleaseVal (molStruct, AtomID, SymID)) < 0) {
       		sprintf (errs, "makeMOPACInput: csu_ReleaseVal SymID, errno %d", rtn_code);
      		alert_user_watch(errs);
    	}
	
    	if ((rtn_code = csu_ReleaseVal (molStruct, AtomID, XYZID)) < 0) {
       		sprintf (errs, "makeMOPACInput: csu_ReleaseVal XYZID, errno %d", rtn_code);
      		alert_user_watch(errs);
    	}
		
	} else if ((moleculeInfo->numSearchLabels == 1) && 
		((control.calculate == rigidSearchMN) || 
			(control.calculate == optSearchMN))) {
	   double increment;
	   increment = (moleculeInfo->searchLabels[0].highValue 
	   			    - moleculeInfo->searchLabels[0].lowValue) 
					/ MOPAC_MAX(1,moleculeInfo->searchLabels[0].numSteps);
	   for (i=1; i <= moleculeInfo->searchLabels[0].numSteps; i++) {
			if (i % 8 == 0) fprintf(file,"\n");
		    fprintf(file, " %9.4lf",
					moleculeInfo->searchLabels[0].lowValue + increment*i);
	   }
	   fprintf(file,"\n");
	   /* put in extra line feed so that back-to-back calculations won't pick
	      up the next line of keywords as part of the search coordinate specification */
	   fprintf(file,"\n");
	} 
 }
	if (lockedAtoms != NULL) free(lockedAtoms);
	lockedAtoms = NULL;
	if (lockedLabels != NULL) free(lockedLabels);
	lockedLabels = NULL;
	
	if (file != NULL) fclose(file);
	file = NULL;
  
	if (zMatrix != NULL) free(zMatrix);
	zMatrix = NULL;
  
	leaveBusyState();
	if (bondList != NULL) free(bondList);
	bondList = NULL;
	
	/*
		If there are Pu atoms put in as dummy atoms, move them to the end
		of the atom location list, since they will not appear in the MOPAC
		Graphics file or in the listing of Cartesian geometries in the MOPAC
		Output file
	*/
	/* Pu first */
	i = 0;
	k = moleculeInfo->atomLocation[i];
	/* Look for Pu atoms */
	if (strncmp(atsymbol[k],"Pu",2) == 0) {
		/* Interchange dummy atom with first non-dummy atom */
		for (j=numDummyAtoms+1; j<NAtom+numDummyAtoms; j++) {
			if (strncmp(atsymbol[moleculeInfo->atomLocation[j]],"Pu",2) != 0) {
				moleculeInfo->atomLocation[i] = moleculeInfo->atomLocation[j];
				moleculeInfo->atomLocation[j] = k;
				break;
			}
		} /* j loop */
	} /* First atom is Pu */


	i = numDummyAtoms + 1;
	for (m = numDummyAtoms, n = 1; m < (NAtom - 2); m++) {
		k = moleculeInfo->atomLocation[i];
		/* Look for Pu atoms */
		if (strncmp(atsymbol[k],"Pu",2) == 0) {
			/* slide atoms beyond Pu down, and put Pu at the end */
			for (j = i; j < NAtom+numDummyAtoms - n; j++)
				moleculeInfo->atomLocation[j] = moleculeInfo->atomLocation[j+1];
			moleculeInfo->atomLocation[NAtom+numDummyAtoms-n] = k;
			n++;
		} else
			i++;
	} /* m loop */

	/* If there are dummy atoms put in the initial molecule position, 
	   slide dummy atoms to end of atom location list so that the output files
	   can be processed correctly */
	
	if (numDummyAtoms > 0) {
		for (i=1; i < NAtom; i++)
			moleculeInfo->atomLocation[i] = 
				moleculeInfo->atomLocation[i+numDummyAtoms];
		for (i=0; i < numDummyAtoms; i++)
			moleculeInfo->atomLocation[NAtom+i] = NAtom+i;
	}
	if (setControl == false)
		return (MOPAC_INPUT_NOERR);
	else
		return (MOPAC_INPUT_CHANGEMULT);
	
cantOpenReturn:
	if (lockedAtoms != NULL) free(lockedAtoms);
	if (lockedLabels != NULL) free(lockedLabels);
	if (file != NULL) fclose(file);
	leaveBusyState();
	if (bondList != NULL) free(bondList);
	if (zMatrix != NULL) free(zMatrix); 
  	if (coords != NULL) free(coords);
  	if (isAtomCappedBond != NULL) free(isAtomCappedBond);

	return (MOPAC_INPUT_CANTOPEN);

noLabelsReturn:
	if (lockedAtoms != NULL) free(lockedAtoms);
	if (lockedLabels != NULL) free(lockedLabels);
	if (file != NULL) fclose(file);
	leaveBusyState();
	if (bondList != NULL) free(bondList);
	if (zMatrix != NULL) free(zMatrix); 
  	if (coords != NULL) free(coords);
  	if (isAtomCappedBond != NULL) free(isAtomCappedBond);

	return (MOPAC_INPUT_NOLABEL);

noSplitReturn:
	if (lockedAtoms != NULL) free(lockedAtoms);
	if (lockedLabels != NULL) free(lockedLabels);
	if (file != NULL) fclose(file);
	leaveBusyState();
	if (bondList != NULL) free(bondList);
	if (zMatrix != NULL) free(zMatrix); 
  	if (coords != NULL) free(coords);
  	if (isAtomCappedBond != NULL) free(isAtomCappedBond);

	return (MOPAC_INPUT_NOSPLIT);

errorReturn:
	if (lockedAtoms != NULL) free(lockedAtoms);
	if (lockedLabels != NULL) free(lockedLabels);
	if (file != NULL) fclose(file);
	leaveBusyState();
	if (bondList != NULL) free(bondList);
	if (zMatrix != NULL) free(zMatrix); 
  	if (coords != NULL) free(coords);
  	if (isAtomCappedBond != NULL) free(isAtomCappedBond);
	return (MOPAC_INPUT_ERROR);

cancelReturn:
	if (lockedAtoms != NULL) free(lockedAtoms);
	if (lockedLabels != NULL) free(lockedLabels);
	if (file != NULL) fclose(file);
	leaveBusyState();
	if (bondList != NULL) free(bondList);
	if (zMatrix != NULL) free(zMatrix); 
  	if (coords != NULL) free(coords);
  	if (isAtomCappedBond != NULL) free(isAtomCappedBond);

	return (MOPAC_INPUT_CANCEL);

}

int findLastBlank(char string[],int length)
{
	int i;
	for (i=length; i > 0; i--) {
		if (string[i] == ' ') break;
	}
	return (i);
}
