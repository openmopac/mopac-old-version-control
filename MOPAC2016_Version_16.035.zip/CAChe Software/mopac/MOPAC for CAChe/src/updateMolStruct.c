#include  <compat.h>
#include  <memory.h>
#include  <math.h>
#include  <ServerStepQueue.h>

#if defined(unix)
#include  <UnixAppMgr.h>
#endif

#include  <ZINDODriver.h>

/* The following should be in Linus.h -- change when other CAChe applications are
	ported to RS6000 */
#define SHOWHY		0x0100	/* draw hydrogen atoms */

#define sppc_MACHINENAME_STRING -16413 /* resource with machine name */


/***************************************************************************************
 *
 *  ZINDOdriver_Update_MolStruct		George D. Purvis III	8/27/89
 *
 *  This routine handles all the output of an ZINDO calculation to the MolStruct
 *  
 *
 *	parameters		:		molStruct		;pointer to MolStruct.
 *							Control		;pointer to ZINDOControl data structure.
 *
 *	calls			:
 *
 *	returns			:		nothing.
 *
 **************************************************************************************/
 
int  ZINDOupdateMolStruct (MolStruct *molStruct, ZINDOControl *Control)
{
	ObjclsID objcls_index;
	PropID   propi;
	ObjectID objectnum;
	PropID   numprops;
	short	 errorCode = 0;
	short	 max_charge, charge_left, itemp;
	ObjclsID offset;
	long     num_valloc;
	int		 mol_charge;
	long	 i, j, index_max, dummy;
	long	 nAtoms, nOrbitals, nElectrons, nLinear, nMOs;
	BitH	 XYZ_hasValueH;
	PropH	 propsH;
	char	 errs[256], keywords[256];
	FILE	 *graphicsFile;
	DoubleH	 coord = NULL;
	LongH	 numberOfShells = NULL;
	LongH	 NPQ = NULL;
	LongH	 orbitalAngularType = NULL;
	LongH	 nuclearNumber = NULL, pchrg_used = NULL;	 
	DoubleH	 exponents = NULL;
	DoubleH	 MOocc = NULL, eigenValues = NULL, partialCharge = NULL;
	DoubleH	 vector = NULL, bondOrders = NULL;
	double	 *MOlocation;
	double	 totalEnergy[2], dipoleVector[3], dipole;
	Boolean	 bondOrdersAvailable, partialChargeAvailable;
	Boolean	 totalEnergyAvailable, eigenValuesAvailable, vectorsAvailable;
	Boolean	 UHF, dipoleVectorAvailable;
	static	 char functionName[] = "ZINDOupdateMolstruct";
	NameNID	 debye, source, kcal_mol_angstrom;
	PropID	 dipoleVectorID, dipoleID, gradientID;
	CelErr	 rtn_code;
	
	/*
	 * ASSERTION:  7/13/92 SJC - mainsb NEVER writes out the coeficients 
	 * and vectors; it always writes out the back-transformed orbitals.
	 * It also does not write out the molecular weight.
	 */
	
	if ((rtn_code = csu_GetNameIndex("ZINDO",&source)) < 0) {
		sprintf (errs,"%s: csu_GetNameIndex ZINDO rtn_code %d\n",
				functionName, rtn_code);
		alert_user(errs);
		return (ZINDOerrors - 1);
	}
	
	if ((rtn_code = csu_GetNameIndex("debye",&debye)) < 0) {
		sprintf (errs,"%s: csu_GetNameIndex debye rtn_code %d\n",
				functionName, rtn_code);
		alert_user(errs);
		return (ZINDOerrors - 1);
	}

	if ((rtn_code = csu_GetNameIndex("Kcal/mol/angstrom",&kcal_mol_angstrom)) < 0) {
	  sprintf (errs,"%s: csu_GetNameIndex kcal_mol_angstrom rtn_code %d\n",
			  functionName, rtn_code);
	  alert_user(errs);
	  return (ZINDOerrors - 1);
	}
	
	if ((rtn_code = csu_GetPropertyID("dipoleVector",&dipoleVectorID)) < 0) {
		sprintf (errs,"%s: csu_GetPropertyID dipoleVector rtn_code %d\n",
				functionName, rtn_code);
		alert_user(errs);
		return (ZINDOerrors - 1);
	}
	if ((rtn_code = csu_GetPropertyID("dipole",&dipoleID)) < 0) {
		sprintf (errs,"%s: csu_GetPropertyID dipole rtn_code %d\n",
				functionName, rtn_code);
		alert_user(errs);
		return (ZINDOerrors - 1);
	}
	if ((rtn_code = csu_GetPropertyID("calc_gradient",&gradientID)) < 0) {
	  sprintf (errs,"%s: csu_GetPropertyID gradient rtn_code %d\n",
			  functionName, rtn_code);
	  alert_user(errs);
	  return (ZINDOerrors - 1);
	}

	/*
	 *	Open the "ZINDO Graphics" file
	 */
	if ((graphicsFile = fopen("ZINDO Graphics", "rb")) == NULL) {
		sprintf(errs, "Unable to open %s.", "ZINDO Graphics");
		alert_user(errs);
		return (-1);
	}

	/* 
	 * Since we don't move electrons during a geometry optimization,
	 * better invalidate the coordinates of the lone pairs now. 
	 */
	   
	if (csu_ExistsObjclsID (molStruct, OrbitalID, &offset)) {
		propsH   = (GetPtr(molStruct->objclsH) + offset)->propsH;
		numprops = (GetPtr(molStruct->objclsH) + offset)->num_props;
		num_valloc = (GetPtr(molStruct->objclsH) + offset)->num_valloc;
		if (csu_ExistsPropID(propsH, XYZID, numprops, &propi)) {
			XYZ_hasValueH  = (GetPtr(propsH) + propi)->has_valueH;
			for (i=0; i<num_valloc; i++) 
				csu_ClearBit (XYZ_hasValueH, i);/* now has a invalid value */
		}
	}

	/* 
	 * Delete Molecular Orbital object classes as they will be re-used.
	 * This is a fix for the aging problem 
	 */

	if (csu_ExistsObjclsID (molStruct, MolecOrbitalID, &objcls_index))
		ed_DeleteObjcls(molStruct, MolecOrbitalID, 2);
	if (csu_ExistsObjclsID (molStruct, STOBasisFxnID, &objcls_index))
		ed_DeleteObjcls(molStruct, STOBasisFxnID, 2);
	if (csu_ExistsObjclsID (molStruct, GTOBasisFxnID, &objcls_index))
		ed_DeleteObjcls(molStruct, GTOBasisFxnID, 2);

	/* RS6000  and Diab FORTRAN puts the record length at the beginning and end of each record */
	fread(&dummy, sizeof(dummy), 1, graphicsFile);
	if (fread(&nAtoms, sizeof(nAtoms), 1, graphicsFile) != 1) {
		fclose(graphicsFile);
		return (-1);
	}
	if (errorCode = csu_GetPropArrays(molStruct,AtomID,DflagID,NULL,NULL,NULL) > nAtoms) {
		fclose(graphicsFile);
		return (-1);
	}
	if (fread(&nOrbitals, sizeof(nOrbitals), 1, graphicsFile) != 1) {
		fclose(graphicsFile);
		return (-1);
	}
	if (fread(&nElectrons, sizeof(nElectrons), 1, graphicsFile) != 1) {
		fclose(graphicsFile);
		return (-1);
	}

    UHF = nElectrons < 0;
	if (UHF) {
		if (nElectrons == -999999) /* Use -999999 to flag case with no electrons*/
			nElectrons = 0;
		else
			nElectrons = -nElectrons;
	}

   if ((coord = (DoubleH) NewHandle(3*nAtoms*sizeof(double))) == NULL) {
	   sprintf (errs,"ZINDO: coord memory request %ld too large\n",
				3*nAtoms*sizeof(double));
	   alert_user(errs);
	   errorCode = ZINDOerrors - 1;
	   goto errorReturn1;
   }

    HLock((Handle) coord);
	if (fread(GetPtr(coord), sizeof(double)*3, (size_t)nAtoms, graphicsFile) != 
		(size_t)nAtoms) {
		errorCode = ZINDOerrors - 2;
    	goto errorReturn2;
	}

	/* Get total energy and gradient in a.u.'s */
	/* end of first FORTRAN record.  Read in the record length */
	fread(&dummy, sizeof(dummy), 1, graphicsFile);
	/* and for the beginning of the next record */
	fread(&dummy, sizeof(dummy), 1, graphicsFile);
    totalEnergyAvailable =
		(fread(&totalEnergy, sizeof(double), 2, graphicsFile) == 2);

   if ((nuclearNumber = (LongH) NewHandle(nAtoms*sizeof(long))) == NULL) {
	   sprintf (errs,"ZINDO: nuclearNumber memory request %ld too large\n",
				nAtoms*sizeof(long));
	   alert_user(errs);
	   errorCode = ZINDOerrors - 2;
	   goto errorReturn2;
   }

    HLock((Handle) nuclearNumber);
	/* end of FORTRAN record.  Read in the record length */
	fread(&dummy, sizeof(dummy), 1, graphicsFile);
	/* and for the beginning of the next record */
	fread(&dummy, sizeof(dummy), 1, graphicsFile);
	if (fread(GetPtr(nuclearNumber), sizeof(long), (size_t)nAtoms, graphicsFile) != (size_t)nAtoms) {
	    errorCode = ZINDOerrors - 3;
        goto errorReturn3;
	};

	nMOs = nOrbitals;
	if (UHF) nMOs = 2 * nMOs;
   
   /* 
    * Since vectors are read from the ZINDO Graphics file last, 
	* only allocate space for one vector.  Each vector is read
	* and immediatly placed in the molstruct.
	*/
	if ((vector = (DoubleH) NewHandle(nOrbitals*sizeof(double))) == NULL) {
		sprintf (errs,"ZINDO: vector memory request %ld too large\n",
				 nOrbitals*sizeof(double));
		alert_user(errs);
		errorCode = ZINDOerrors - 3;
		goto errorReturn3;
	}

	if ((MOocc = (DoubleH) NewHandle(nMOs*sizeof(double))) == NULL) {
		sprintf (errs,"ZINDO: MOocc memory request %ld too large\n",
				 nOrbitals*sizeof(double));
		alert_user(errs);
		errorCode = ZINDOerrors - 6;
		goto errorReturn6;
	}

	if ((eigenValues = (DoubleH) NewHandle(nMOs*sizeof(double))) == NULL) {
		sprintf (errs,"ZINDO: eigenValues memory request %ld too large\n",
				 nOrbitals*sizeof(double));
		alert_user(errs);
		errorCode = ZINDOerrors - 7;
		goto errorReturn7;
	}

	if ((partialCharge = (DoubleH) NewHandle(nAtoms*sizeof(double))) == NULL) {
		sprintf (errs,"ZINDO: partialCharge memory request %ld too large\n",
				 nAtoms*sizeof(double));
		alert_user(errs);
		errorCode = ZINDOerrors - 8;
		goto errorReturn8;
	}

	nLinear = (nAtoms*(nAtoms+1))/2;
	if ((bondOrders = (DoubleH) NewHandle(nLinear*sizeof(double))) == NULL) {
		sprintf (errs,"ZINDO: bondOrders memory request %ld too large\n",
				 nLinear*sizeof(double));
		alert_user(errs);
		errorCode = ZINDOerrors - 9;
		goto errorReturn9;
	}
      
	HLock((Handle) vector);
	HLock((Handle) MOocc);
	HLock((Handle) eigenValues);
	HLock((Handle) partialCharge);
	HLock((Handle) bondOrders);
   
	nLinear = (nAtoms*(nAtoms+1))/2;
	/* end of FORTRAN record.  Read in the record length */
	fread(&dummy, sizeof(dummy), 1, graphicsFile);
	/* and for the beginning of the next record */
	fread(&dummy, sizeof(dummy), 1, graphicsFile);
	bondOrdersAvailable =
	        ((fread(GetPtr(bondOrders), sizeof(double), (size_t)nLinear,
			       graphicsFile) == (size_t)nLinear));

	/* end of FORTRAN record.  Read in the record length */
	fread(&dummy, sizeof(dummy), 1, graphicsFile);
	/* and for the beginning of the next record */
	fread(&dummy, sizeof(dummy), 1, graphicsFile);
	dipoleVectorAvailable = 
		(fread(dipoleVector, sizeof(double), 3,graphicsFile) == 3);
	/* end of FORTRAN record.  Read in the record length */
	fread(&dummy, sizeof(dummy), 1, graphicsFile);
	/* and for the beginning of the next record */
	fread(&dummy, sizeof(dummy), 1, graphicsFile);
	partialChargeAvailable = 
		   ((fread(GetPtr(partialCharge), sizeof(double), (size_t)nAtoms, 
		   		  graphicsFile) == (size_t)nAtoms) && totalEnergyAvailable);

	if ((numberOfShells = (LongH) NewHandle(nAtoms*sizeof(long))) == NULL) {
		sprintf (errs,"ZINDO: numberOfShells memory request %ld too large\n",
				 nAtoms*sizeof(long));
		alert_user(errs);
		errorCode = ZINDOerrors - 10;
		goto errorReturn10;	 
	}
	HLock((Handle) numberOfShells);
	/* end of FORTRAN record.  Read in the record length */
	fread(&dummy, sizeof(dummy), 1, graphicsFile);
	/* and for the beginning of the next record */
	fread(&dummy, sizeof(dummy), 1, graphicsFile);
	fread(GetPtr(numberOfShells), sizeof(long), (size_t)nAtoms, graphicsFile);

	if ((orbitalAngularType = (LongH) NewHandle(nOrbitals*sizeof(long))) == NULL) {
		sprintf (errs,"ZINDO: orbitalAngularType memory request %ld too large\n",
				 nOrbitals*sizeof(long));
		alert_user(errs);
		errorCode = ZINDOerrors - 11;
		goto errorReturn11;	 
	}
	HLock((Handle) orbitalAngularType);
	/* end of FORTRAN record.  Read in the record length */
	fread(&dummy, sizeof(dummy), 1, graphicsFile);
	/* and for the beginning of the next record */
	fread(&dummy, sizeof(dummy), 1, graphicsFile);
	fread(GetPtr(orbitalAngularType), sizeof(long), (size_t)nOrbitals, graphicsFile);

	if ((NPQ = (LongH) NewHandle(nOrbitals*sizeof(long))) == NULL) {
		sprintf (errs,"ZINDO: NPQ memory request %ld too large\n",
				 nOrbitals*sizeof(long));
		alert_user(errs);
		errorCode = ZINDOerrors - 12;
		goto errorReturn12;	 
	}
	HLock((Handle) NPQ);
	/* end of FORTRAN record.  Read in the record length */
	fread(&dummy, sizeof(dummy), 1, graphicsFile);
	/* and for the beginning of the next record */
	fread(&dummy, sizeof(dummy), 1, graphicsFile);
	fread(GetPtr(NPQ), sizeof(long), (size_t)nOrbitals, graphicsFile);

	if ((exponents = (DoubleH) NewHandle(6*nOrbitals*sizeof(double))) == NULL) {
		sprintf (errs,"ZINDO: exponents memory request %ld too large\n",
				 nOrbitals*sizeof(double));
		alert_user(errs);
		errorCode = ZINDOerrors - 13;
		goto errorReturn13;	 
	}
	HLock((Handle) exponents);
	/* end of FORTRAN record.  Read in the record length */
	fread(&dummy, sizeof(dummy), 1, graphicsFile);
	/* and for the beginning of the next record */
	fread(&dummy, sizeof(dummy), 1, graphicsFile);
	fread(GetPtr(exponents), 6*sizeof(double), (size_t)nOrbitals, graphicsFile);

	/* end of FORTRAN record.  Read in the record length */
	fread(&dummy, sizeof(dummy), 1, graphicsFile);
	/* and for the beginning of the next record */
	fread(&dummy, sizeof(dummy), 1, graphicsFile);

	/* UHF eigenvalues are written out in two records */
	if (!UHF) {
		eigenValuesAvailable =
			   (fread(GetPtr(eigenValues), sizeof(double), (size_t)nMOs,
					  graphicsFile) == (size_t)nMOs);
	} else {
		/* read in alpha eigenvalues */
		fread(GetPtr(eigenValues), sizeof(double), nMOs/2, graphicsFile);
		/* end of alpha eigenvalue FORTRAN record.  Read in the record length */
		fread(&dummy, sizeof(dummy), 1, graphicsFile);
		/* and for the beginning of the next record */
		fread(&dummy, sizeof(dummy), 1, graphicsFile);
		eigenValuesAvailable =
			   (fread(&(GetPtr(eigenValues)[nMOs/2]), sizeof(double), (size_t)nMOs/2,
					  graphicsFile) == (size_t)nMOs/2);
	}

	/* end of FORTRAN record.  Read in the record length */
	fread(&dummy, sizeof(dummy), 1, graphicsFile);
	/* and for the beginning of the next record */
	fread(&dummy, sizeof(dummy), 1, graphicsFile);

	if (!UHF) {
		fread(GetPtr(MOocc), sizeof(double), (size_t)nMOs, graphicsFile);
	} else {
		/* Read in alph occupation numbers */
		fread(GetPtr(MOocc), sizeof(double), nMOs/2, graphicsFile);
		/* end of alpha eigenvalue FORTRAN record.  Read in the record length */
		fread(&dummy, sizeof(dummy), 1, graphicsFile);
		/* and for the beginning of the next record */
		fread(&dummy, sizeof(dummy), 1, graphicsFile);
		fread(&(GetPtr(MOocc)[nMOs/2]), sizeof(double), (size_t)nMOs/2, graphicsFile);
	}

	/* end of FORTRAN record.  Read in the record length */
	fread(&dummy, sizeof(dummy), 1, graphicsFile);
	/* and for the beginning of the next record */
	fread(&dummy, sizeof(dummy), 1, graphicsFile);

	/* Get the first vector */
	vectorsAvailable = 
	       (fread(GetPtr(vector), sizeof(double), (size_t)nOrbitals, graphicsFile) == (size_t)nOrbitals);

	if (!eigenValuesAvailable)
	 	for (i=0; i < nMOs; i++) (GetPtr(eigenValues))[i] = (double) i;

	/*
	 *  Get a unique ID for this calculation history entry.
	 */
	getUniqueID (molStruct, CalcHistID, &objectnum);
	
	/*
	 *  Update the calculation_history object class.
	 */
	if ((rtn_code = csu_AddObjVal(molStruct, CalcHistID,
					CalcSourceID, objectnum,
					source, CSU_NAME, 1, NoUnit, 0,
					(char*)&source, 0, BY_ID)) < 0) {
		sprintf (errs,"%s: csu_AddObjVal CalcHist rtn_code %d\n",
				functionName, rtn_code);
		alert_user(errs);
		errorCode = ZINDOerrors - 14;
		goto errorReturn;
	}
	
	if ((rtn_code = csu_AddObjVal(molStruct, CalcHistID, VersionID, objectnum,
					source, CSU_STRING, 10, NoUnit, 0,
					(char*)Control->version, 1, BY_ID)) < 0) {
		sprintf (errs,"%s: csu_AddObjVal Version rtn_code %d\n",
				functionName, rtn_code);
		alert_user(errs);
		errorCode = ZINDOerrors - 15;
		goto errorReturn;
	}
	
	if ((rtn_code = csu_AddObjVal(molStruct, CalcHistID, DateTimeID, objectnum,
					source, CSU_STRING, 25, NoUnit, 0,
					(char*)Control->datetime, 1, BY_ID)) < 0) {
		sprintf (errs,"%s: csu_AddObjVal DateTime rtn_code %d\n",
				functionName, rtn_code);
		alert_user(errs);
	}
	
	/* Add the machine and server to the calculation history */
	
	if ((rtn_code = csu_AddObjVal(molStruct, CalcHistID, CalcServerID, objectnum,
					source, CSU_STRING, 25, NoUnit, 0,
					(char*)Control->servername, 1, BY_ID)) < 0) {
		sprintf (errs,"%s: csu_AddObjVal CalcServer rtn_code %d\n",
				functionName, rtn_code);
		alert_user(errs);
	}
	
	errs[0] = 0;
	switch (Control->parameters) {
		case PARAMTYPE_IEH:
			strcpy(errs, "Iterative Extended Huckel");
			break;
		
		case PARAMTYPE_CNDO1:
			strcpy(errs, "CNDO/1");
			break;
	  
		case PARAMTYPE_CNDO2:
			strcpy(errs, "CNDO/2");
			break;
	  
		case PARAMTYPE_INDO1:
			strcpy(errs, "INDO/1");
			break;
	  
		case PARAMTYPE_INDO2:
			strcpy(errs, "INDO/2");
			break;
	}
	
	if (errs[0] == 0) strcpy(errs,"INDO/1");
	
	if ((rtn_code = csu_AddObjVal(molStruct, CalcHistID, ModelID, objectnum,
					source, CSU_STRING, 32, NoUnit, 0,
					(char*)errs, 1, BY_ID)) < 0) {
		sprintf (errs,"%s: csu_AddObjVal Model rtn_code %d\n",
				functionName, rtn_code);
		alert_user(errs);
	}
	
	if (totalEnergyAvailable) {
		double grad_in_kcal;
		/* Add energy */
		if ((rtn_code = csu_AddObjVal(molStruct, CalcHistID, CalcEnergyID, objectnum,
						source, CSU_FLOATING, 1, Energy_kcalPerMole, 6,
						(char*)&totalEnergy, 0, BY_ID)) < 0) {
			sprintf (errs,"%s: csu_AddObjVal CalcEnergy rtn_code %d\n",
					functionName, rtn_code);
			alert_user(errs);
		}
		/* Add calculated gradient - change to kcal/mol/angstrom first */
		grad_in_kcal = (1.118583E+3)*(totalEnergy[1]);
		if ((rtn_code = csu_AddObjVal(molStruct, CalcHistID, gradientID, objectnum,
						source, CSU_FLOATING, 1, kcal_mol_angstrom, 6,
						(char*)&grad_in_kcal, 0, BY_ID)) < 0) {
			sprintf (errs,"%s: csu_AddObjVal CalcGradient rtn_code %d\n",
					functionName, rtn_code);
			alert_user(errs);
		}
	}
	
	/* Make the calc. comment from the control settings */
	
	/* Strip non printable characters from the extra keywords */
	for (i=0; Control->extraKeyWords[i] != 0; i++)
		if (Control->extraKeyWords[i] < 32 ||
			Control->extraKeyWords[i] > 126) Control->extraKeyWords[i] = ' ';
	
	/* put information about the calculation into the keywords string so that it can
	   be added to the calculation history comment in the molstruct */
	
	keywords[0] = 0;
	
	/* add the calculation type */
	sprintf(keywords,"CalcType:");
	if (Control->calculate == CALCTYPE_OPT)
		strncat(keywords,"Optimize",8);
	else if (Control->calculate == CALCTYPE_ENERGY)
		strncat(keywords,"Energy",7);
	else if (Control->calculate == CALCTYPE_TS)
		strncat(keywords,"TS",2);
	else if (Control->calculate == CALCTYPE_CI)
		strncat(keywords,"CI",2);
		
	/* add the multiplicity */
	strncat(keywords," Mult:",6);
	if (Control->multiplicity == SINGLET)
		strncat(keywords,"1",1);
	else if (Control->multiplicity == DOUBLET)
		strncat(keywords,"2",1);
	else if (Control->multiplicity == TRIPLET)
		strncat(keywords,"3",1);
	else if (Control->multiplicity == QUARTET)
		strncat(keywords,"4",1);
	else if (Control->multiplicity == QUINTET)
		strncat(keywords,"5",1);
	else if (Control->multiplicity == SEXTET)
		strncat(keywords,"6",1);
		
	/* add parameter type */
	strncat(keywords," Params:",8);
	if (Control->parameters == PARAMTYPE_IEH)
		strncat(keywords,"IEH",3);
	else if (Control->parameters == PARAMTYPE_CNDO1)
		strncat(keywords,"CNDO/1",6);
	else if (Control->parameters == PARAMTYPE_CNDO2)
		strncat(keywords,"CNDO/2",6);
	else if (Control->parameters == PARAMTYPE_INDO1)
		strncat(keywords,"INDO/1",6);
	else if (Control->parameters == PARAMTYPE_INDO2)
		strncat(keywords,"INDO/2",6);
		
	/* add C.I. level */
	strncat(keywords," CILev:",7);
	sprintf(errs,"%d",Control->CIlevel);
	strncat(keywords,errs,strlen(errs));
	
	/* add SCF type */
	strncat(keywords," SCFTyp:",8);
	if (Control->SCFtype == RHFTYPE)
		strncat(keywords,"RHF",3);
	else if (Control->SCFtype == UHFTYPE)
		strncat(keywords,"UHF",3);
	else if (Control->SCFtype == ROHFTYPE)
		strncat(keywords,"ROHF",4);
		
	/* SCF cycles */
	sprintf(errs," SCFCyc:%d",Control->maxSCFiterations);
	strncat(keywords,errs,strlen(errs));
		
	/* add molecular net charge */
	strncat(keywords," Charge:",8);
	sprintf(errs,"%d",Control->netCharge);
	strncat(keywords,errs,strlen(errs));
	
	/* add info on whether geometry is saved in a map file */
	strncat(keywords," SavMap:",8);
	if (Control->detailsMap)
		strncat(keywords,"yes",3);
	else
		strncat(keywords,"no",2);
	
	/* geometry search type */
	strncat(keywords," SrchTyp:",9);
	if (Control->geometrySearch == SEARCHTYPE_NR)
		strncat(keywords,"NR",2);
	else if (Control->geometrySearch == SEARCHTYPE_AH)
		strncat(keywords,"AH",2);
	if (Control->geometrySearch == SEARCHTYPE_GN)
		strncat(keywords,"GN",2);
		
	/* geometry convergence */
	strncat(keywords," GeoConv:",9);
	if (Control->geometryConvergence == 1)
		strncat(keywords,"CG1E-3",6);
	else if (Control->geometryConvergence == 2)
		strncat(keywords,"CG5E-4",6);
	else if (Control->geometryConvergence == 3)
		strncat(keywords,"CG1E-4",6);
	else if (Control->geometryConvergence == 4)
		strncat(keywords,"CG1E-5",6);
	else if (Control->geometryConvergence == 5)
		strncat(keywords,"CG1E-6",6);
	else if (Control->geometryConvergence == 6)
		strncat(keywords,"SC1E-4",6);
	else if (Control->geometryConvergence == 7)
		strncat(keywords,"EC1E-7",6);
	else if (Control->geometryConvergence == 8)
		strncat(keywords,"GN1E-3",6);
	else if (Control->geometryConvergence == 9)
		strncat(keywords,"GN5E-4",6);
	else if (Control->geometryConvergence == 10)
		strncat(keywords,"GN1E-4",6);
	
	/* Self-consistent reaction field */
	if (Control->detailsSCRxnF) {
		if (Control->cavityRadiusMeaning == RADIUS_EXTEND) {
			sprintf(errs," SCFRxnF:yes CavRadExt:%lf Dielec:%lf RefInd:%lf",
				Control->cavityRadiusExtend,Control->dielectric,
				Control->refractiveIndex);
		} else {
			sprintf(errs," SCFRxnF:yes CavRadTot:%lf Dielec:%lf RefInd:%lf",
				Control->cavityRadiusTotal,Control->dielectric,
				Control->refractiveIndex);
		}
	} else
		sprintf(errs," SCFRxnF:no");
	if ((strlen(keywords)+strlen(errs)) < 255)
		strncat(keywords,errs,strlen(errs));
	
	
	/* SCF convergence */
	sprintf(errs," SCFConv:%d",Control->scfConvergence);
	if ((strlen(keywords)+strlen(errs)) < 255)
		strncat(keywords,errs,strlen(errs));
	
	/* Metal configuration mixing */
	if (Control->metalConfigMixing == CONFIGMIX_VB)
		sprintf(errs," ConfMix:VB");
	else if (Control->metalConfigMixing == CONFIGMIX_N1)
		sprintf(errs," ConfMix:[n-1]");
	else if (Control->metalConfigMixing == CONFIGMIX_N2)
		sprintf(errs," ConfMix:[n-2]");
	else if (Control->metalConfigMixing == CONFIGMIX_N)
		sprintf(errs," ConfMix:[n]");
	if ((strlen(keywords)+strlen(errs)) < 255)
		strncat(keywords,errs,strlen(errs));
	
	/* Print level */
	if (Control->printAmount == PRINT_MIN)
		sprintf(errs," Prnt:Min");
	if (Control->printAmount == PRINT_NORM)
		sprintf(errs," Prnt:Norm");
	if (Control->printAmount == PRINT_LRGE)
		sprintf(errs," Prnt:Lrge");
	if ((strlen(keywords)+strlen(errs)) < 255)
		strncat(keywords,errs,strlen(errs));
		
	/* Restart */
	if (Control->controlRestart)
		sprintf(errs," Restart:yes");
	else
		sprintf(errs," Restart:no");
	if ((strlen(keywords)+strlen(errs)) < 255)
		strncat(keywords,errs,strlen(errs));
		
	/* put in the extra control words last */
	if (Control->extraKeyWords[0] != 0) {
		strncat(keywords," ControlWords:",14);
		strncat(keywords, Control->extraKeyWords, 255-strlen(keywords));
	}
	  
	replaceBlanks(keywords, '_');
	if ((rtn_code = csu_AddObjVal(molStruct, CalcHistID, CalcCommentID, objectnum,
					source, CSU_STRING, (short)(strlen(keywords)+1),
					NoUnit, 0, (char*)keywords, 1, BY_ID)) < 0) {
	  sprintf (errs,"%s: csu_AddObjVal CalcComment rtn_code %d\n",
			  functionName, rtn_code);
	  alert_user(errs);
	}
	
	/*
	 *  Grab and update the coordinates.
	 */
   
	{
		int		rtn_code;
		int		i;
	
		if (!csu_ExistsObjclsID (molStruct, AtomID, &objcls_index)) {
			if ((rtn_code = csu_AddObjcls (molStruct, AtomID, &objcls_index,
					  (ObjclsID) (nAtoms))) < 0)	{
				sprintf (errs,"%s: csu_AddObjcls AtomID rtn_code %d\n", functionName, rtn_code);
				alert_user(errs);
				errorCode = ZINDOerrors - 16;
				goto errorReturn;
			} else {

				double min[3], max[3], scale, std_width, mol_width;
				
				if ((rtn_code = csu_InstProp(molStruct->objclsH, objcls_index, XYZID,
											 3, source, CSU_FLOATING, Angstrom_U, 6, &propi)) < 0) {
					sprintf (errs,"%s: csu_InstProp XYZ rtn_code %d\n", functionName, rtn_code);
					alert_user(errs);
					errorCode = ZINDOerrors - 17;
					goto errorReturn;
				}
				
				for (i=0; i < nAtoms; i++) {
				
					 char symbol[2];
				
					 /* Keep track of the smallest and largest values of coordinates for
						scaling the viewing transform */
					 if (i == 0) {
						 for (j=0; j<3; j++)
							 min[j] = max[j] = (GetPtr(coord))[i+nAtoms*j];
					 } else {
						 for (j=0; j<3; j++) {
							 if ((GetPtr(coord))[i+nAtoms*j] < min[j])
								 min[j] = (GetPtr(coord))[i+nAtoms*j];
							 if ((GetPtr(coord))[i+nAtoms*j] > max[j])
								 max[j] = (GetPtr(coord))[i+nAtoms*j];
						 }
					 }
				
					 if ((rtn_code = csu_AddObjVal(molStruct, AtomID, XYZID, (i+1),
												   source, CSU_FLOATING, 3, Angstrom_U, 6,
												   (char *) &((GetPtr(coord))[i]), nAtoms, BY_ID)) < 0) {
						 sprintf (errs,"%s: csu_AddObjVal XYZ rtn_code %d\n", functionName, rtn_code);
						 alert_user(errs);
						 errorCode = ZINDOerrors - 18;
						 goto errorReturn;
					 }
					 itemp = 0x7002;
					 if ((rtn_code = csu_AddObjVal(molStruct, AtomID, RflagID, (i+1),
												   source, CSU_HEX, 1, NoUnit, 0,
												   (char *) &itemp, 0, BY_ID)) < 0) {
						 sprintf (errs,"%s: csu_AddObjVal Rflag rtn_code %d\n", functionName, rtn_code);
						 alert_user(errs);
						 errorCode = ZINDOerrors - 19;
						 goto errorReturn;
					 }
						
					 itemp = (short)(GetPtr(nuclearNumber))[i];
					 if ((rtn_code = csu_AddObjVal(molStruct, AtomID, AnumID, (i+1),
												   source, CSU_INTEGER, 1, Unit, 0,
												   (char *) &itemp, 0, BY_ID)) < 0) {
						 sprintf (errs,"%s: csu_AddObjVal Anum rtn_code %d\n", functionName, rtn_code);
						 alert_user(errs);
						 errorCode = ZINDOerrors - 20;
						 goto errorReturn;
					 }
					 atomSymbol((GetPtr(nuclearNumber))[i], symbol);
					 if ((rtn_code = csu_AddObjVal(molStruct, AtomID, SymID, (i+1),
												   source, CSU_STRING, 2, NoUnit, 0,
												   &symbol[0], 1, BY_ID)) < 0) {
						 sprintf (errs,"%s: csu_AddObjVal Sym rtn_code %d\n", functionName, rtn_code);
						 alert_user(errs);
						 errorCode = ZINDOerrors - 21;
						 goto errorReturn;
					 }
					 /* set nuclear charge to 0 */
					 itemp = 0;
					 if ((rtn_code = csu_AddObjVal (molStruct, AtomID, ChrgID, 
													(i+1),
													source, CSU_FLOATING, 1, Charge_AU, 
													4, (char*)&itemp, 0,
													BY_ID)) < 0) {
						 sprintf (errs,"%s: csu_AddObjVal Chrg rtn_code %d\n", 
								   functionName, rtn_code);
						 alert_user(errs);
						 goto errorReturn;
					 }
				
				 }
				
				 /* set it so that hydrogens are displayed */
				 molStruct->flags |= SHOWHY;
				
				 /* Scale the viewing transform.  With thanks to Joel Damiano and Bill Hanks. 
				  * Most code borrowed from the CenterInWin.c routines in the translators.
				  */
				 mol_width = max[0] - min[0]; /* molecule width */
				 if ((max[1] - min[1]) > mol_width)
					 mol_width = max[1] - min[1];
				 if ((max[2] - min[2]) > mol_width)
					 mol_width = max[2] - min[2];
				
				 /* Assume the standard initial window size */
				 std_width = 0.55; /* window width is approx one-half of screen */
				
				 /* map molecule coordinates into normalized (-1 to +1) coordinates */
				 scale = std_width/mol_width;
				 scale *= 0.8;
				
				 for (j = 0; j < 3; j++) {
					 molStruct->lxform[j][j] = scale;
					 molStruct->lxform[3][j] = -0.5*scale*(max[j]+min[j]);
				 }
				
				 molStruct->lxform[3][3] = 1.;
				
				 /* Find the molecule's net charge from the output file */
				 
				 getMolecularCharge(&mol_charge);
				
				 /* Add formal charges if the molecule has a net charge */
				 
				 if (mol_charge != 0) {
				
					 if ((pchrg_used = (LongH) NewHandle(nAtoms*sizeof(long))) == NULL) {
					  sprintf (errs,"ZINDO: pchrg_used memory request %ld too large\n",
							   nAtoms*sizeof(long));
					  alert_user(errs);
					  errorCode = ZINDOerrors - 4;
					  goto errorReturn;
					 }
				
					 HLock((Handle) pchrg_used);
				
					 for (i = 0; i < nAtoms; i++)
						 (GetPtr(pchrg_used))[i] = 0;
					 
					 charge_left = mol_charge;
					 
					 for (j = 0; j < nAtoms; j++) {
				
						 /* Find the largest remaining formal charge */
						 for (i = 0, max_charge = 0, index_max = -1 ; i < nAtoms; i++) {
							 if ((GetPtr(pchrg_used))[i] == 0) {
								 /* round to nearest integer */
								 itemp = (short) floor(fabs((GetPtr(partialCharge))[i]) + 0.5); 
								 if ((GetPtr(partialCharge))[i] < 0.0) itemp = -itemp;
								 if (mol_charge > 0) {
									 if (itemp > max_charge) {
										 max_charge = itemp;
										 index_max = i;
									 }
								 } else {
									 if (itemp < max_charge) {
										 max_charge = itemp;
										 index_max = i;
									 }
								 }
							 }
						 }
						 
						 /* Add the formal charge */
						 if (index_max >= 0) {
							 if (((mol_charge > 0) && (max_charge > charge_left)) ||
								 ((mol_charge < 0) && (max_charge < charge_left)))
								 max_charge = charge_left; /* The maximum charge is large enough */
					 
							 if ((rtn_code = csu_AddObjVal (molStruct, AtomID, ChrgID, 
															(Control->atomLocation[index_max]),
															source, CSU_FLOATING, 1, Charge_AU, 
															4, (char*)&max_charge, 0,
															BY_INDEX)) < 0) {
								 sprintf (errs,"%s: csu_AddObjVal Chrg rtn_code %d\n", 
										   functionName, rtn_code);
								 alert_user(errs);
								 goto errorReturn;
							 }
				
							 /* reduce the charge left to account for */
							 charge_left -= max_charge;
							 /* mark this one as used */
							 (GetPtr(pchrg_used))[index_max] = 1;
					 
						 }
					 }
					 
					 /* 
					  * If there is still charge unaccounted for, assign it to the molecule
					  * with the largest partial charge of the correct sign.
					  */
					 if (charge_left != 0) {
					 
						 double current_charge, big_charge;
				
						 /* Find the largest remaining formal charge */
						 for (i = 0, big_charge = 0.0, index_max = -1 ; i < nAtoms; i++) {
							 if ((GetPtr(pchrg_used))[i] == 0) {
								 current_charge = (GetPtr(partialCharge))[i];
								 if (mol_charge > 0) {
									 if (current_charge > big_charge) {
										 big_charge = current_charge;
										 index_max = i;
									 }
								 } else {
									 if (current_charge < big_charge) {
										 big_charge = current_charge;
										 index_max = i;
									 }
								 }
							 }
						 }
						 
						 /* Add the formal charge */
						 if (index_max >= 0) {
							 if ((rtn_code = csu_AddObjVal (molStruct, AtomID, ChrgID, 
															(Control->atomLocation[index_max]),
															source, CSU_FLOATING, 1, Charge_AU, 
															4, (char*)&charge_left, 0,
															BY_INDEX)) < 0) {
								 sprintf (errs,"%s: csu_AddObjVal Chrg rtn_code %d\n", 
										   functionName, rtn_code);
								 alert_user(errs);
								 goto errorReturn;
							 }
				
							 /* reduce the charge left to account for */
							 charge_left = 0;
							 /* mark this one as used */
							 (GetPtr(pchrg_used))[index_max] = 1;
					 
						 }
					 }
					  
					 /* 
					  * If there is still charge unaccounted for, assign it to the first 
					  * atom that doesn't have a formal charge
					  */
					 if (charge_left != 0) {
				
						 for (i = 0; i < nAtoms; i++) {
							 if ((GetPtr(pchrg_used))[i] == 0) {
								 /* Add the formal charge */
								 if ((rtn_code = csu_AddObjVal (molStruct, AtomID, ChrgID, 
																(Control->atomLocation[i]),
																source, CSU_FLOATING, 1, Charge_AU, 
																4, (char*)&charge_left, 0,
																BY_INDEX)) < 0) {
									 sprintf (errs,"%s: csu_AddObjVal Chrg rtn_code %d\n", 
											   functionName, rtn_code);
									 alert_user(errs);
									 goto errorReturn;
								 }
				 
								 /* reduce the charge left to account for */
								 charge_left = 0;
								 /* mark this one as used */
								 (GetPtr(pchrg_used))[i] = 1;
							 
								 break;
							 }
						 }
						 
					 }
					 
					 if (charge_left != 0)
						 alert_user("ZINDOupdateMolStruct:  unable to obtain correct molecular "
							 "charge by assigning formal charges.  Use the Editor to review and"
							 "assign appropriate formal charges.");
				
					 if (pchrg_used != NULL) HUnlock((Handle) pchrg_used);
					 if (pchrg_used != NULL) DisposHandle((Handle) pchrg_used);
					 pchrg_used = NULL;
				
				 }
			}
		} else {
			
			propsH   = (GetPtr(molStruct->objclsH) + objcls_index)->propsH;
			numprops = (GetPtr(molStruct->objclsH) + objcls_index)->num_props;
			
			if (!csu_ExistsPropID(propsH, XYZID, numprops, &propi)) {
				if ((rtn_code = csu_InstProp(molStruct->objclsH, objcls_index, XYZID,
											 3, source, CSU_FLOATING, Angstrom_U, 6, &propi)) < 0) {
					sprintf (errs,"%s: csu_InstProp XYZ rtn_code %d\n", functionName, rtn_code);
					alert_user(errs);
					errorCode = ZINDOerrors - 22;
					goto errorReturn;
				}
			}
			
			/*
			 *  Update/Add atomic coordinates.
			 */
			 
			for (i=0; i < nAtoms; i++) {
				 if ((rtn_code = csu_AddObjVal(molStruct, AtomID, XYZID,
											   (Control->atomLocation[i]),
											   source, CSU_FLOATING, 3, Angstrom_U, 6,
											   (char *) &((GetPtr(coord))[i]), nAtoms, BY_INDEX)) < 0) {
					 sprintf (errs,"%s: csu_AddObjVal XYZ rtn_code %d"
								   " for ZINDO atom %d, molstruct atom %d.\n",
								   functionName, rtn_code, i, Control->atomLocation[i]);
					 alert_user(errs);
				 }
			}
		}
	}

	/* Update the dipole vector and dipole in the calculation history */
	if (dipoleVectorAvailable) {
		if ((rtn_code = csu_AddObjVal(molStruct, CalcHistID, dipoleVectorID, 
						  objectnum, source, CSU_FLOATING, 3, debye, 6,
						(char*)dipoleVector, 1, BY_ID)) < 0) {
			sprintf (errs,"%s: csu_AddObjVal dipoleVector rtn_code %d\n",
					functionName, rtn_code);
			alert_user(errs);
		}
	
		dipole = sqrt(dipoleVector[0]*dipoleVector[0] +
					  dipoleVector[1]*dipoleVector[1] +
					  dipoleVector[2]*dipoleVector[2]);
		if ((rtn_code = csu_AddObjVal(molStruct, CalcHistID, dipoleID, 
						  objectnum, source, CSU_FLOATING, 1, debye, 6,
						(char*)&dipole, 0, BY_ID)) < 0) {
			sprintf (errs,"%s: csu_AddObjVal dipole rtn_code %d\n",
					functionName, rtn_code);
			alert_user(errs);
		}
	}

	/*
	 *  Update the atomic partial charges in the atom object class.
	 */
	 
	if (partialChargeAvailable) {
		for (i=0; i < nAtoms; i++) {
			if ((rtn_code = csu_AddObjVal (molStruct, AtomID, PchrgID, 
										   (Control->atomLocation[i]),
										   source, CSU_FLOATING, 1, Charge_AU, 
										   4, (char*)&((GetPtr(partialCharge))[i]), 0,
										   BY_INDEX)) < 0) {
				sprintf (errs,"%s: csu_AddObjVal Pchrg rtn_code %d\n", functionName, rtn_code);
				alert_user(errs);
				errorCode = ZINDOerrors - 23;
				goto errorReturn;
			}
		}
	}
	
	HUnlock((Handle) partialCharge);
	DisposHandle((Handle) partialCharge);
	partialCharge = NULL;
	
	
	if (vectorsAvailable) {
		/*
		 *  Update the molecular orbital information in the mol_orbital
		 *  object class.
		 *
		 *  See if MO object class exists.  If not then instantiate it.
		 */
		
		if (!csu_ExistsObjclsID (molStruct, MolecOrbitalID, &objcls_index))	{
			if ((rtn_code = csu_AddObjcls (molStruct, MolecOrbitalID, &objcls_index,
						 (ObjclsID)(nMOs))) < 0)	{
				sprintf (errs,"%s: csu_AddObjcls MolecOrbital rtn_code %d\n", functionName, rtn_code);
				alert_user(errs);
				errorCode = ZINDOerrors - 24;
				goto errorReturn;
			}
		}
		
		/*
		 *  If the Molecular orbital property does not exist then instantiate it.
		 */
		
		propsH   = (GetPtr(molStruct->objclsH) + objcls_index)->propsH;
		numprops = (GetPtr(molStruct->objclsH) + objcls_index)->num_props;
		
		if (!csu_ExistsPropID(propsH, EigVecID, numprops, &propi)) {
			if ((rtn_code = csu_InstProp(molStruct->objclsH, objcls_index, EigVecID,
						  (short) nOrbitals, source, CSU_FLOATING, NoUnit, 6, &propi)) < 0) {
				sprintf (errs,"%s: csu_InstProp EigVec rtn_code %d\n", functionName, rtn_code);
				alert_user(errs);
				errorCode = ZINDOerrors - 25;
				goto errorReturn;
			}
		}
		
		propsH   = (GetPtr(molStruct->objclsH) + objcls_index)->propsH;
		numprops = (GetPtr(molStruct->objclsH) + objcls_index)->num_props;
		
		if (!csu_ExistsPropID(propsH, EigValID, numprops, &propi)) {
			if ((rtn_code = csu_InstProp(molStruct->objclsH, objcls_index, EigValID,
										 1, source, CSU_FLOATING, EV, 6, &propi)) < 0) {
				sprintf (errs,"%s: csu_InstProp EigVal rtn_code %d\n", functionName, rtn_code);
				alert_user(errs);
				errorCode = ZINDOerrors - 26;
				goto errorReturn;
			}
		}
		
		propsH   = (GetPtr(molStruct->objclsH) + objcls_index)->propsH;
		numprops = (GetPtr(molStruct->objclsH) + objcls_index)->num_props;
		
		if (!csu_ExistsPropID(propsH, OccNumID, numprops, &propi)) {
			if ((rtn_code = csu_InstProp(molStruct->objclsH, objcls_index, OccNumID,
										 1, source, CSU_FLOATING, NoUnit, 6, &propi)) < 0) {
				sprintf (errs,"%s: csu_InstProp OccNum rtn_code %d\n", functionName, rtn_code);
				alert_user(errs);
				errorCode = ZINDOerrors - 27;
				goto errorReturn;
			}
		}
		
		for (MOlocation = GetPtr(vector), i=0; i < nMOs; i++) {
			
			if ((rtn_code = csu_AddObjVal(molStruct, MolecOrbitalID, EigValID, (i+1),
										  source, CSU_FLOATING, 1, EV, 6,
										  (char*)&((GetPtr(eigenValues))[i]), 0, BY_ID)) < 0) {
				sprintf (errs,"%s: csu_AddObjVal EigVal rtn_code %d\n", functionName, rtn_code);
				alert_user(errs);
				errorCode = ZINDOerrors - 28;
				goto errorReturn;
			}
			
			if ((rtn_code = csu_AddObjVal(molStruct, MolecOrbitalID, OccNumID, (i+1),
										  source, CSU_FLOATING, 1, NoUnit, 8,
										  (char*)&((GetPtr(MOocc))[i]), 0, BY_ID)) < 0) {
				sprintf (errs,"%s: csu_AddObjVal OccNum rtn_code %d\n",functionName,  rtn_code);
				alert_user(errs);
				errorCode = ZINDOerrors - 29;
				goto errorReturn;
			}
			
			if (vectorsAvailable) {
				/* 
				 * See if some coefficients in this vector need reordering 
				 * because the Tabulator requires d-orbitals in a specific order
				 */
				for (j=0; j<nOrbitals; j++) {
					if ((GetPtr(orbitalAngularType))[j] == 4) {
						 double temp;
						 temp = MOlocation[j];
						 MOlocation[j] = MOlocation[j+1];
						 MOlocation[j+1] = temp;
					}
				}
				
				if ((rtn_code = csu_AddObjVal(molStruct, MolecOrbitalID, EigVecID, (i+1),
											  source, CSU_FLOATING, (short)nOrbitals, NoUnit, 6,
											  (char *) MOlocation, 1, BY_ID)) < 0) {
					sprintf (errs,"%s: csu_AddObjVal EigVec rtn_code %d\n",functionName,  rtn_code);
					alert_user(errs);
					errorCode = ZINDOerrors - 30;
					goto errorReturn;
				}
				/* Get the next vector */
				if (i < (nMOs - 1)) {
					if (UHF && (i == (nMOs/2 - 1))) {
						/* End of alpha coefficients */
						/* end of FORTRAN record.  Read in the record length */
						fread(&dummy, sizeof(dummy), 1, graphicsFile);
						/* and for the beginning of the next record */
						fread(&dummy, sizeof(dummy), 1, graphicsFile);
					}
					vectorsAvailable = 
						   (fread(GetPtr(vector), sizeof(double), (size_t)nOrbitals, graphicsFile) == (size_t)nOrbitals);
				}
			
				if (!vectorsAvailable) {
					sprintf (errs,"%s: Unable to get orbital %d and following.\n",
								functionName, i+1);
					alert_user(errs);
				}
			} /* end of vectorsAvailable */
		} /* i loop */
	}

	/* Done with the graphics file */
	fclose(graphicsFile);
	graphicsFile = NULL;
	  
	HUnlock((Handle) vector);
	DisposHandle((Handle) vector);
	vector = NULL;
	HUnlock((Handle) eigenValues);
	DisposHandle((Handle) eigenValues);
	eigenValues = NULL;
	HUnlock((Handle) MOocc);
	DisposHandle((Handle) MOocc);
	MOocc = NULL;
	
	/*
	 *  Update the bond orders in the bond object class.
	 */ 
	if (bondOrdersAvailable) 
		AddBondOrder (molStruct, bondOrders, nAtoms, Control->atomLocation, source);

	HUnlock((Handle) bondOrders);
	DisposHandle((Handle) bondOrders);
	bondOrders = NULL;
	
	if (vectorsAvailable) {  
		/*
		 * Connect the calculation history to the first molecular orbital.
		 */
		if ((rtn_code = csu_AddConnectorVal (molStruct,
								  CalcHistID, 
								  csu_ObjectIDtoIndex(molStruct, CalcHistID, objectnum),
								  MolecOrbitalID, 0,
								  csu_Delete2ifC)) < 0) {
			sprintf (errs,"updateMolstruct: csu_AddConnectorVal MolecOrbital rtn_code %d\n",
				 rtn_code);
			alert_user(errs);
			errorCode = ZINDOerrors - 31;
			goto errorReturn;
		}
	}
	/*
	 *  Update the basis functions in the sto_basis_fxn object class.
	 */

	ZINDOaddBasisSet (molStruct, GetPtr(exponents), nAtoms, 
			  Control->atomLocation, GetPtr(numberOfShells), 
			  GetPtr(NPQ), source);

errorReturn:
	 if (pchrg_used != NULL) HUnlock((Handle) pchrg_used);
     if (pchrg_used != NULL) DisposHandle((Handle) pchrg_used);
errorReturn13:
	 if (NPQ != NULL) HUnlock((Handle) NPQ);
     if (NPQ != NULL) DisposHandle((Handle) NPQ);
errorReturn12:
	 if (orbitalAngularType != NULL) HUnlock((Handle) orbitalAngularType);
     if (orbitalAngularType != NULL) DisposHandle((Handle) orbitalAngularType);
errorReturn11:
	 if (numberOfShells != NULL) HUnlock((Handle) numberOfShells);
     if (numberOfShells != NULL) DisposHandle((Handle) numberOfShells);
errorReturn10:
	 if (vector != NULL) HUnlock((Handle) vector);
	 if (MOocc != NULL) HUnlock((Handle) MOocc);
	 if (eigenValues != NULL) HUnlock((Handle) eigenValues);
	 if (partialCharge != NULL) HUnlock((Handle) partialCharge);
	 if (bondOrders != NULL) HUnlock((Handle) bondOrders);
     if (bondOrders != NULL) DisposHandle((Handle) bondOrders);
errorReturn9:
     if (partialCharge != NULL) DisposHandle((Handle) partialCharge);
errorReturn8:
     if (eigenValues != NULL) DisposHandle((Handle) eigenValues);
errorReturn7:
     if (MOocc != NULL) DisposHandle((Handle) MOocc);
errorReturn6:
     if (vector != NULL) DisposHandle((Handle) vector);
errorReturn3:
	 if (nuclearNumber != NULL) HUnlock((Handle) nuclearNumber); 
	 if (nuclearNumber != NULL) DisposHandle((Handle) nuclearNumber);
errorReturn2:
	 if (coord != NULL) HUnlock((Handle) coord); 
	 if (coord != NULL) DisposHandle((Handle) coord);
errorReturn1:
     if (graphicsFile != NULL) fclose(graphicsFile);
	 return (errorCode);
}
