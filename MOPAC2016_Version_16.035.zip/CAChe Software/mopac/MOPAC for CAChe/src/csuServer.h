/*
 *	Created 02/Aug/2000	Ingvar Lagerstedt
 *
 *	The functions collected here were found hiding in the TabulatorComputeEngine library
 *
 * csu_findConnectedIndices()
 * csu_findConnectedObject()
 * csu_getPropertySource()
 * csu_CountValidObjects()      moved here from MOPACLib and ZINDOLib 15-Mar-2001 MSS
 *
 * Note that the function csu_findConnectedObject is different from the function
 * csu_findConnectedObjects() found in csuintfc.c
 */
#ifdef __cplusplus	/* For type-safe linkage */
extern "C" {		/* Specify "C"-style linkage */
#endif

CelErr csu_findConnectedIndices( MolStruct *msPtr,
                                 ObjclsID objcls1ID,
                                 ObjectID obj1index,
                                 ObjclsID objcls2ID,
                                 ObjectID *obj2index,
                                 ObjectID list_length,
                                 ObjectID *numConnected );

CelErr csu_findConnectedObject( MolStruct *msPtr,
                                ObjclsID objcls1ID,
                                ObjectID obj1index,
                                ObjclsID objcls2ID,
                                ObjectID *obj2index );

CelErr csu_getPropertySource( MolStruct *msPtr,
                              ObjclsID objclsID,
                              PropID propertyID,
                              short *sourceName );

CelErr csu_CountValidObjects( MolStruct *msPtr,
                              ObjclsID objclsID );

#ifdef __cplusplus	/* For type-safe linkage */
}
#endif
