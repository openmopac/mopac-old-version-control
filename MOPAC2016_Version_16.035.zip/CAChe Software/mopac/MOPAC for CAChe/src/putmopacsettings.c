#include "compat.h"
#include "MOPACDriver.h"

int putmopacsettings(
FILE	*file,
MOPACControl controlPanel[], 
long initialNum,
long finalNum
)
{
	int		i;

	/* Write the general heading for a MOPAC Settings file */
	if (fprintf(file,"startSettings MOPAC 3.0\n") < 0) return (-1);
	
	/* Write the number of Controls found in this file */
	if (fprintf(file,"   numParamBlocks %d\n",
				finalNum - initialNum +1) < 0) return (-1);
	
	/* 
	 * Write accessory file information and molecular charge
	 * Only write the values for the final Control in the range 
	 */
    if (fprintf(file,"   accessoryDensity %d\n",
				controlPanel[finalNum].accessoryDensity) < 0) return (-1);

    if (fprintf(file,"   accessoryIsotope %d\n",
				controlPanel[finalNum].accessoryIsotope) < 0) return (-1);

    if (fprintf(file,"   accessoryLog %d\n",
				controlPanel[finalNum].accessoryLog) < 0) return (-1);

    if (fprintf(file,"   accessoryGraphics %d\n",
				controlPanel[finalNum].accessoryGraphics) < 0) return (-1);

    if (fprintf(file,"   accessoryInput %d\n",
				controlPanel[finalNum].accessoryInput) < 0) return (-1);

    if (fprintf(file,"   accessoryOutput %d\n",
				controlPanel[finalNum].accessoryOutput) < 0) return (-1);

    if (fprintf(file,"   accessoryRestart %d\n",
				controlPanel[finalNum].accessoryRestart) < 0) return (-1);

    if (fprintf(file,"   accessoryArchive %d\n",
				controlPanel[finalNum].accessoryArchive) < 0) return (-1);

    if (fprintf(file,"   molecularCharge %d\n",
				controlPanel[finalNum].molecularCharge) < 0) return (-1);

	/*
	 * Now write the control parameters other than accessory file info
	 * for the complete range of Controls.
	 */
	 
	 for (i=initialNum; i<= finalNum; i++)
	 	PutMOPACControlFile(file, &controlPanel[i]);

	if (fprintf(file,"endSettings MOPAC 3.0\n\n") < 0) return (-1);
	
	return (0);
}
