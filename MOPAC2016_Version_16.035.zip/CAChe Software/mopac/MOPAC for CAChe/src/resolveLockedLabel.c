#include "compat.h"
#include <stdlib.h>
#include "csu.h"
#include "MOPACDriver.h"

int resolveLockedLabelConflicts(long *atomID, char (*atsymbol)[2], long lockedAtoms[], 
				LockedLabel lockedLabels[], SearchLabel searchLabels[],
				long *numLockedAtoms, long *numLockedLabels, long numSearchLabels,
				Boolean switchedSearchLabel[])
/*
	LockedLabels defined in the Molecule Editor are used to mark certain internal
	coordinates in a molecule during an optimization so that they are not varied.
	So that MOPAC can implement search labels, the locked internal coordinates 
	must be defined in the z-matrix. 
	
	There are cases when locked labels will be in conflict with each other
	with regards to building a z-matrix.  For example, two locked angles may
	have the same first atom, but this atom will only be able to have an angle
	defined one way.  When possible, locked label orders will be switched in 
	order to satisfy locked labels using the z-matrix.
	
	There are cases in which locked labels will 
	contain locked atoms.  These are of two cases:  one or both ends of the locked 
	label are not locked atoms or both end atoms are locked.  This routine either
	changes the order of the atoms in the locked label or treats all atoms in the
	locked label as locked atoms to resolve the conflicts between locked atoms and
	labels.
	
	Returns 0 if successful, +1 if the user decides to cancel from a label conflict
	dialog.
*/
{
	LockedLabel tempLabel;
	long j, k, m, n;
	long rtn_code = 0;
	int *number_of_m_repeats = NULL;
	Boolean all_atoms_the_same, unlocked_atom, same_order, opposite_order, swap_m_and_j;
	Boolean *removedLabel = NULL;
	Boolean *switchedLabelOrder = NULL;
	Boolean atom_found[4];

  if (*numLockedLabels > 0) {
		if ((removedLabel = (Boolean *) 
			malloc(sizeof(Boolean)*(*numLockedLabels))) == NULL) {
			alert_user("Unable to allocate enough memory for ordering locked labels.  "
						"Increase the memory size for your application using the "
				   		"Get Info command");
			goto errorReturn;
		}
	
		if ((switchedLabelOrder = (Boolean *) 
			malloc(sizeof(Boolean)*(*numLockedLabels))) == NULL) {
			alert_user("Unable to allocate enough memory for ordering locked labels.  "
						"Increase the memory size for your application using the "
				   		"Get Info command");
			goto errorReturn;
		}
		
		if ((number_of_m_repeats = (int *) 
			malloc(sizeof(int)*(*numLockedLabels))) == NULL) {
			alert_user("Unable to allocate enough memory for ordering locked labels.  "
						"Increase the memory size for your application using the "
				   		"Get Info command");
			goto errorReturn;
		}
		
		for (m = 0; m < *numLockedLabels; m++) { /* initialize label flags */
			removedLabel[m] = false;
			switchedLabelOrder[m] = false;
		}

		/* 
		  Sort labels so that distances come first, angles second, and 
		  dihedrals last.
		*/
		for (m = 0; m < (*numLockedLabels)-1; m++) { /* Put all distance labels first */
			n = *numLockedLabels;
			if ((lockedLabels[m].atomList[0] == 4) || 
					(lockedLabels[m].atomList[0] == 3)) {
				n = m; /* mark position of angle or dihedral label */
				for (j=m+1; j < *numLockedLabels; j++) { /* go through remaining labels */
					if ((lockedLabels[j].atomList[0] == 2) && 
						(n < *numLockedLabels)) { 
						/* 
						   Found a diistance label and there is a previous label that
						   is not a distance label.  Switch the labels.
						*/
						tempLabel = lockedLabels[j];
						lockedLabels[j] = lockedLabels[n];
						lockedLabels[n] = tempLabel;
						n = j;
					}
				}
			}
		}

		for (m = 0; m < (*numLockedLabels)-1; m++) { /* Put all angle labels second */
			n = *numLockedLabels;
			if (lockedLabels[m].atomList[0] == 4) {
				n = m; /* mark position of dihedral label */
				for (j=m+1; j < *numLockedLabels; j++) { /* go through remaining labels */
					if ((lockedLabels[j].atomList[0] == 3) && 
						(n < *numLockedLabels)) { 
						/* 
						   Found an angle label and there is a previous label that
						   is a dihedral label.  Switch the labels.
						*/
						tempLabel = lockedLabels[j];
						lockedLabels[j] = lockedLabels[n];
						lockedLabels[n] = tempLabel;
						n = j;
					}
				}
			}
		}

		/* remove locked labels that consist entirely of locked atoms */
		if (*numLockedAtoms > 0) {
			for (m = 0; m < *numLockedLabels; m++) { /* process all the locked labels */
	
				unlocked_atom = false;
				for (n=lockedLabels[m].atomList[0]; n>0; n--) {
					if (!lockedAtoms[lockedLabels[m].atomList[n]])
						unlocked_atom = true; /* found an unlocked atom in the label */
				}
				if (!unlocked_atom) { 
					/* didn't find any unlocked atoms, so mark the label to be removed*/
					removedLabel[m] = true;
				}
			}

		/* resolve conflicts between locked labels and locked atoms */
			for (m = 0; m < *numLockedLabels; m++) { /* process all the locked labels */
			
				/* Check to see if the first atom in the label is a locked atom.  If
				   it is, change the order of the label if the last atom in the label
				   is not a locked atom */
		
				if (lockedAtoms[lockedLabels[m].atomList[1]]) {
					if (!lockedAtoms[lockedLabels[m].atomList[lockedLabels[m].atomList[0]]]) {
						/* 
							The opposite end of the label is not a locked atom,
							so switch the order of the label 
						*/
						if (!switchedLabelOrder[m]) {
							reverseLabelOrder(lockedLabels, m);
							switchedLabelOrder[m] = true; /* mark this label as switched to
															resolve conflict with locked atoms */
						} else { 
						/* can't switch the label because it's been switched once already*/
							/* Tell the user that the locked label will not be honored */
							rtn_code = warnAboutLockedLabel(atomID, 
											atsymbol, lockedLabels, m);
							if (rtn_code == 0)
								/* mark this label as being removed */
								removedLabel[m] = true;
							else if (rtn_code == 1)
								/* user canceled out of calculation */
								goto cancelReturn;
							else
								goto errorReturn;
						}
					} else {
						/* Tell the user that the locked label will not be honored */
							rtn_code = warnAboutLockedLabel(atomID, 
											atsymbol, lockedLabels, m);
							if (rtn_code == 0)
								/* mark this label as being removed */
								removedLabel[m] = true;
							else if (rtn_code == 1)
								/* user canceled out of calculation */
								goto cancelReturn;
							else
								goto errorReturn; 
					}
		
				} /* first atom in label is a locked atom */
				
			 } /* m loop */
		}
		
		if (numSearchLabels > 1) {
			for (m = 0; m < *numLockedLabels; m++) { /* process all the locked labels */
			
			/*
				If both the first and last atom of a locked label are the moving 
				atom in the search labels, the locked label will not be expressable
				in the z-matrix.  Attempt to switch the search label that has the
				same first atom as the moving atom in a search label.  If not,
				remove the locked label.
			*/
			
				j = lockedLabels[m].atomList[1];
				k = lockedLabels[m].atomList[lockedLabels[m].atomList[0]];
				
				if (((searchLabels[0].atomList[1] == j) &&
					 (searchLabels[1].atomList[1] == k)) ||
					((searchLabels[0].atomList[1] == k) &&
					 (searchLabels[1].atomList[1] == j))) {
					 
					 if ((searchLabels[0].atomList[1] == j) &&
					 	(!switchedSearchLabel[0])) { /* switch the first search label */
						reverseSearchOrder(searchLabels, 0);
						switchedSearchLabel[0] = true; 
					 } else if ((searchLabels[1].atomList[1] == j) &&
					 		(!switchedSearchLabel[1])) { /* switch the second search label */
						reverseSearchOrder(searchLabels, 1);
						switchedSearchLabel[1] = true; 
					 } else {
					 
						/* Tell the user that the locked label will not be honored */
							rtn_code = warnAboutLockedLabel(atomID, 
											atsymbol, lockedLabels, m);
							if (rtn_code == 0)
								/* mark this label as being removed */
								removedLabel[m] = true;
							else if (rtn_code == 1)
								/* user canceled out of calculation */
								goto cancelReturn;
							else
								goto errorReturn;
					}
				}
			}
		}
		
		for (j=0; j<numSearchLabels; j++) {

		  for (m = 0; m < *numLockedLabels; m++) { /* process all the locked labels */
			
			if (searchLabels[j].atomList[1] == lockedLabels[m].atomList[1]) {
			/* 
			   If the moving atom in a search label is the same as the first atom in
			   a locked label of the same length, the z-matrix will not be able to express
			   both the search and lock on this internal coordinate. Attempt to reverse the
			   locked label; if it's already been reversed, then remove it 
			*/				
				if (searchLabels[j].atomList[0] == lockedLabels[m].atomList[0]) {
					 
					if (!switchedLabelOrder[m]) {
						reverseLabelOrder(lockedLabels, m);
						switchedLabelOrder[m] = true; 
					} else {
						/* Tell the user that the locked label will not be honored */
							rtn_code = warnAboutLockedLabel(atomID, 
											atsymbol, lockedLabels, m);
							if (rtn_code == 0)
								/* mark this label as being removed */
								removedLabel[m] = true;
							else if (rtn_code == 1)
								/* user canceled out of calculation */
								goto cancelReturn;
							else
								goto errorReturn; 
					}
				}
			/* 
			   If the moving atom in a search label is the same as the first atom in
			   a locked label, the two labels have different lengths, but they do not 
			   have the same atoms, the labels will not be expressed in a z-matrix.
			   Attempt to reverse the locked label.  If it has already been reversed, 
			   remove the locked label.
			*/				
				if (searchLabels[j].atomList[0] != lockedLabels[m].atomList[0]) {
					 
					all_atoms_the_same = true;
					for (k = 2; 
						k <= MOPAC_MIN(searchLabels[j].atomList[0],
										lockedLabels[m].atomList[0]);
						k++) {
						if (searchLabels[j].atomList[k] != lockedLabels[m].atomList[k]) {
							all_atoms_the_same = false;
							break;
						}
					}
					
					if (!all_atoms_the_same) {
						if (!switchedLabelOrder[m]) { /* can switch the locked label */
							reverseLabelOrder(lockedLabels, m);
							switchedLabelOrder[m] = true;
					 	} else if (!switchedSearchLabel[j]) { /* can switch the second search label */
							reverseSearchOrder(searchLabels, j);
							switchedSearchLabel[j] = true; 
						} else {
							/* Tell the user that the locked label will not be honored */
								rtn_code = warnAboutLockedLabel(atomID, 
												atsymbol, lockedLabels, m);
								if (rtn_code == 0)
									/* mark this label as being removed */
									removedLabel[m] = true;
								else if (rtn_code == 1)
									/* user canceled out of calculation */
									goto cancelReturn;
								else
									goto errorReturn; 
						}
					}
				}
			}
		  }
		}


		/*  
			If the first atom of a search label appears after the first atom in a locked
			label, and the first atom of the locked label appears after the first atom
			in the search label, a Z-matrix will no be possible.  Attempt to swithc the
			locked label to resolve the conflict.
		*/

		for (j=0; j<numSearchLabels; j++) {

			Boolean needToSwitch;
			
			needToSwitch = FALSE;
			
			for (m = 0; m < *numLockedLabels; m++) { /* process all the locked labels */

				for (k = 2; k <= lockedLabels[m].atomList[0]; k++) {
					if (lockedLabels[m].atomList[k] == searchLabels[j].atomList[1]) {
					/* First atom in search label found in locked label; check for inverse */
						for (n = 2; n <= searchLabels[j].atomList[0]; n++) {
							if (searchLabels[j].atomList[n] == lockedLabels[m].atomList[1]) {
								needToSwitch = TRUE;
								break;
							}
						}
						if (needToSwitch)
							break;
					}
					if (needToSwitch)
						break;
				}
				
				if (needToSwitch) {
					/* Attempt to switch the locked label */
					if (!switchedLabelOrder[m]) { /* can switch the locked label */
						reverseLabelOrder(lockedLabels, m);
						switchedLabelOrder[m] = true;
					} else {
						/* Tell the user that the locked label will not be honored */
							rtn_code = warnAboutLockedLabel(atomID, 
											atsymbol, lockedLabels, m);
							if (rtn_code == 0)
								/* mark this label as being removed */
								removedLabel[m] = true;
							else if (rtn_code == 1)
								/* user canceled out of calculation */
								goto cancelReturn;
							else
								goto errorReturn; 
					}
				}

			} /* loop over locked labels */

		} /* loop over search labels */


		/*
			Locked labels of the same length that share the same atoms will
			also cause inconsistencies which cannot be resolved by a z-matrix
			formulation.
		*/
		for (m = 0; m < (*numLockedLabels)-1; m++) { /* process all the locked labels */
		  if (!removedLabel[m]) { /* don't bother with labels that are already gone! */
			for (j=m+1; j < *numLockedLabels; j++) {
			  if (!removedLabel[j]) { /* dont' bother with labels that are already gone! */
				if (lockedLabels[j].atomList[0] == lockedLabels[m].atomList[0]) {
					all_atoms_the_same = true;
					for (k = 1; k <= lockedLabels[m].atomList[0]; k++) {
						atom_found[k] = false;
						for (n = 1; n <= lockedLabels[j].atomList[0]; n++) {
							if (lockedLabels[j].atomList[n] == 
								lockedLabels[m].atomList[k]) {
								atom_found[k] = true;
								break;
							}
						} /* n loop */
						if (!atom_found[k]) {
							all_atoms_the_same = false;
							break;
						}
					} /* k loop */
					
					if (all_atoms_the_same) {
						/* the atoms are in the same order or reverse order */
						same_order = false;
						opposite_order = false;
						if (lockedLabels[m].atomList[0] == 2) {
							if ((lockedLabels[m].atomList[1] == lockedLabels[j].atomList[1]) &&
								(lockedLabels[m].atomList[2] == lockedLabels[j].atomList[2]))
								same_order = true;
							else if ((lockedLabels[m].atomList[1] == lockedLabels[j].atomList[2]) &&
								(lockedLabels[m].atomList[2] == lockedLabels[j].atomList[1]))
								opposite_order = true;
						} else if (lockedLabels[m].atomList[0] == 3) {
							if ((lockedLabels[m].atomList[1] == lockedLabels[j].atomList[1]) &&
								(lockedLabels[m].atomList[2] == lockedLabels[j].atomList[2]) &&
								(lockedLabels[m].atomList[3] == lockedLabels[j].atomList[3]))
								same_order = true;
							else if ((lockedLabels[m].atomList[1] == lockedLabels[j].atomList[3]) &&
								(lockedLabels[m].atomList[2] == lockedLabels[j].atomList[2]) &&
								(lockedLabels[m].atomList[3] == lockedLabels[j].atomList[1]))
								opposite_order = true;
						} else if (lockedLabels[m].atomList[0] == 4) {
							if ((lockedLabels[m].atomList[1] == lockedLabels[j].atomList[1]) &&
								(lockedLabels[m].atomList[2] == lockedLabels[j].atomList[2]) &&
								(lockedLabels[m].atomList[3] == lockedLabels[j].atomList[3]) &&
								(lockedLabels[m].atomList[4] == lockedLabels[j].atomList[4]))
								same_order = true;
							else if ((lockedLabels[m].atomList[1] == lockedLabels[j].atomList[4]) &&
								(lockedLabels[m].atomList[2] == lockedLabels[j].atomList[3]) &&
								(lockedLabels[m].atomList[3] == lockedLabels[j].atomList[2]) &&
								(lockedLabels[m].atomList[4] == lockedLabels[j].atomList[1]))
								opposite_order = true;
						}
						if (same_order || opposite_order) {
							if (switchedLabelOrder[m] && !switchedLabelOrder[j]) {
							/*
							  Mark the second label as removed since the first one
							  was switched to accomodate a conflict
							*/
								removedLabel[j] = true;
							} else {
							/*
							  Mark the second label as removed since the first one
							  was switched to accomodate a conflict
							*/
								removedLabel[m] = true;
								/* 
									no need to check further down the list because if
									label m contains all the same atoms as j & another
									label, then j will also coincide with the other
									label, and it will be caught later 
								*/
								break;
							}
						} else {
							if (switchedLabelOrder[m] && !switchedLabelOrder[j]) {
							/*
							  Mark the second label as removed since the first one
							  was switched to accomodate a conflict
							*/
								rtn_code = warnAboutLockedLabel(atomID, 
												atsymbol, lockedLabels, j);
								if (rtn_code == 0)
									/* mark this label as being removed */
									removedLabel[j] = true;
								else if (rtn_code == 1)
									/* user canceled out of calculation */
									goto cancelReturn;
								else
									goto errorReturn; 
							} else {
							/*
							  Mark the second label as removed since the first one
							  was switched to accomodate a conflict
							*/
								rtn_code = warnAboutLockedLabel(atomID, 
												atsymbol, lockedLabels, m);
								if (rtn_code == 0)
									/* mark this label as being removed */
									removedLabel[m] = true;
								else if (rtn_code == 1)
									/* user canceled out of calculation */
									goto cancelReturn;
								else
									goto errorReturn; 
								/* 
									no need to check further down the list because if
									label m contains all the same atoms as j & another
									label, then j will also coincide with the other
									label, and it will be caught later 
								*/
								break;
							}
						}
					}
				} /* same length */
			  } /* j not removed */
			} /* j loop */
		  } /* m not removed */
		} /* m loop */
		

		/* 
			Now go through and try to resolve conflicts between locked labels that
			have the same first atom
		*/
		for (m = 0; m < *numLockedLabels ; m++)
			number_of_m_repeats[m] = 0;
		for (m = 0; m < (*numLockedLabels)-1; m++) { /* process all the locked labels */
		  ++number_of_m_repeats[m];
		  if (!removedLabel[m]) { /* don't bother with labels that are already gone! */
			/* compare each label with those that follow it */
			for (j = m+1; j < *numLockedLabels; j++) {
			  
			  swap_m_and_j = false; /* flag for swapping m & j labels */
				
			  if (!removedLabel[j]) { /* don't bother with labels that are already gone! */
			  
				/* for each atom in the first label, see if it is first in a following label */
				if (lockedLabels[m].atomList[1] == lockedLabels[j].atomList[1]) {
					/* first atom in labels are the same */
				
					if (((lockedLabels[m].atomList[0] == 2) && 
						(lockedLabels[j].atomList[0] ==2)) ||
						((lockedLabels[m].atomList[0] == 3) && 
						(lockedLabels[j].atomList[0] ==3)) ||
						((lockedLabels[m].atomList[0] == 4) && 
						(lockedLabels[j].atomList[0] ==4))) {

						all_atoms_the_same = true;
						for (k = 2; k <= lockedLabels[m].atomList[0]; k++) {
							for (n = 2; n <= lockedLabels[j].atomList[0]; n++) {
								if (lockedLabels[m].atomList[k] != lockedLabels[j].atomList[n])
									all_atoms_the_same = false;
								
							} /* n loop */
						} /* k loop */
						if (!all_atoms_the_same) {
							/* two distance, angle or dihedral labels with the 
								same first atom:  switch the order of one of them */
							if (!switchedLabelOrder[j]) {
								reverseLabelOrder(lockedLabels, j);
								switchedLabelOrder[j] = true; 
							} else if (!switchedLabelOrder[m]) {
								reverseLabelOrder(lockedLabels, m);
								switchedLabelOrder[m] = true;
							} else { 
							/* can't switch the labels because they've 
							   both been switched once already.  Tell the 
							   user that the locked label will not be honored */
								rtn_code = warnAboutLockedLabel(atomID, 
												atsymbol, lockedLabels, j);
								if (rtn_code == 0) {
									/* mark this label as being removed */
									removedLabel[j] = true;
									goto jLabelRemoved;
								} else if (rtn_code == 1)
									/* user canceled out of calculation */
									goto cancelReturn;
								else
									goto errorReturn;
							}
						}
					} else if (((lockedLabels[m].atomList[0] == 2) &&
							   (lockedLabels[j].atomList[0] == 3)) ||
							   ((lockedLabels[m].atomList[0] == 3) &&
							   (lockedLabels[j].atomList[0] == 2))) {
						/* a distance and an angle */
						if (lockedLabels[m].atomList[0] == 2) {
							/* m label is the distance */
							if (lockedLabels[m].atomList[2] == 
									lockedLabels[j].atomList[2]) {
								/* put m label after j label */
								swap_m_and_j = true;
								goto swap_m_and_j_labels;
							} else if (lockedLabels[m].atomList[2] == 
									lockedLabels[j].atomList[3]) {
								/* can't handle this with a Z-matrix.  Tell the 
							   user that the angle label will not be honored */
								rtn_code = warnAboutLockedLabel(atomID, 
												atsymbol, lockedLabels, j);
								if (rtn_code == 0) {
									/* mark this label as being removed */
									removedLabel[j] = true;
									goto jLabelRemoved;
								} else if (rtn_code == 1)
									/* user canceled out of calculation */
									goto cancelReturn;
								else
									goto errorReturn;
							} else {
								/* Second atom in the distance label is not in the
								   angle label.  Reverse the order of one of the labels */
								if (!switchedLabelOrder[j]) {
									reverseLabelOrder(lockedLabels, j);
									switchedLabelOrder[j] = true; 
								} else if (!switchedLabelOrder[m]) {
									reverseLabelOrder(lockedLabels, m);
									switchedLabelOrder[m] = true;
								} else { 
								/* can't switch the labels because they've 
								   both been switched once already.  Tell the 
								   user that the locked label will not be honored */
									rtn_code = warnAboutLockedLabel(atomID, 
													atsymbol, lockedLabels, j);
									if (rtn_code == 0) {
										/* mark this label as being removed */
										removedLabel[j] = true;
										goto jLabelRemoved;
									} else if (rtn_code == 1)
										/* user canceled out of calculation */
										goto cancelReturn;
									else
										goto errorReturn;
								}
							}
							
						} else {
							/* j label is the distance */
							/* If the second atom in j is the second one in m,
							   no action is needed because j comes after m */
							if (lockedLabels[j].atomList[2] == 
									lockedLabels[m].atomList[3]) {
							/* can't handle this with a Z-matrix.  Tell the 
							   user that the angle label will not be honored */
								rtn_code = warnAboutLockedLabel(atomID, 
												atsymbol, lockedLabels, m);
								if (rtn_code == 0) {
									/* mark this label as being removed */
									removedLabel[m] = true;
									goto mLabelRemoved;
								} else if (rtn_code == 1)
									/* user canceled out of calculation */
									goto cancelReturn;
								else
									goto errorReturn;
							} else if (lockedLabels[j].atomList[2] != 
										lockedLabels[m].atomList[2]) {
								/* Second atom in the distance label is not in the
								   angle label.  Reverse the order of one of the labels */
								if (!switchedLabelOrder[j]) {
									reverseLabelOrder(lockedLabels, j);
									switchedLabelOrder[j] = true; 
								} else if (!switchedLabelOrder[m]) {
									reverseLabelOrder(lockedLabels, m);
									switchedLabelOrder[m] = true;
								} else { 
								/* can't switch the labels because they've 
								   both been switched once already.  Tell the 
								   user that the locked label will not be honored */
									rtn_code = warnAboutLockedLabel(atomID, 
													atsymbol, lockedLabels, j);
									if (rtn_code == 0) {
										/* mark this label as being removed */
										removedLabel[j] = true;
										goto jLabelRemoved;
									} else if (rtn_code == 1)
										/* user canceled out of calculation */
										goto cancelReturn;
									else
										goto errorReturn;
								}
							}
						}
					} else if (((lockedLabels[m].atomList[0] == 2) &&
							   (lockedLabels[j].atomList[0] == 4)) ||
							   ((lockedLabels[m].atomList[0] == 4) &&
							   (lockedLabels[j].atomList[0] == 2))) {
						/* a distance and a dihedral */
						if (lockedLabels[m].atomList[0] == 2) {
							/* m is the distance label */
							if ((lockedLabels[m].atomList[2] == 
								lockedLabels[j].atomList[4]) ||
								(lockedLabels[m].atomList[2] == 
								lockedLabels[j].atomList[3])) {
								/* second atom in the distance is the third or fourth atom 
									in the dihedral */
								rtn_code = warnAboutLockedLabel(atomID, 
												atsymbol, lockedLabels, j);
								if (rtn_code == 0) {
									/* mark this label as being removed */
									removedLabel[j] = true;
									goto jLabelRemoved;
								} else if (rtn_code == 1)
									/* user canceled out of calculation */
									goto cancelReturn;
								else
									goto errorReturn;
							} else if (!(lockedLabels[m].atomList[2] == 
										lockedLabels[j].atomList[2])) {
								/* no need to do anything is the second atom in the distance
								   is the second atom in the dihedral because m
								   comes before j */
								/* second atom in the distance label is not in the dihedral */
								if (!switchedLabelOrder[m]) {
									reverseLabelOrder(lockedLabels, m);
									switchedLabelOrder[m] = true; 
								} else if (!switchedLabelOrder[j]) {
									reverseLabelOrder(lockedLabels, j);
									switchedLabelOrder[j] = true;
								} else { 
								/* can't switch the labels because they've 
								   both been switched once already.  Tell the 
								   user that the locked label will not be honored */
									rtn_code = warnAboutLockedLabel(atomID, 
													atsymbol, lockedLabels, j);
									if (rtn_code == 0) {
										/* mark this label as being removed */
										removedLabel[j] = true;
										goto jLabelRemoved;
									} else if (rtn_code == 1)
										/* user canceled out of calculation */
										goto cancelReturn;
									else
										goto errorReturn;
								}
							}
						} else {
							/* j is the distance label */
							if ((lockedLabels[j].atomList[2] == 
								lockedLabels[m].atomList[4]) ||
								(lockedLabels[j].atomList[2] == 
								lockedLabels[m].atomList[3])) {
								/* second atom in the distance is the third or fourth atom 
									in the dihedral */
								rtn_code = warnAboutLockedLabel(atomID, 
												atsymbol, lockedLabels, m);
								if (rtn_code == 0) {
									/* mark this label as being removed */
									removedLabel[m] = true;
									goto mLabelRemoved;
								} else if (rtn_code == 1)
									/* user canceled out of calculation */
									goto cancelReturn;
								else
									goto errorReturn;
							} else if (lockedLabels[j].atomList[2] == 
										lockedLabels[m].atomList[2]) {
								/* second atom in the distance is the second atom 
									in the dihedral:  switch the order of m and j */
								swap_m_and_j = true;
								goto swap_m_and_j_labels;
							} else {
								/* second atom in the distance label is not in the dihedral */
								if (!switchedLabelOrder[j]) {
									reverseLabelOrder(lockedLabels, j);
									switchedLabelOrder[j] = true; 
								} else if (!switchedLabelOrder[m]) {
									reverseLabelOrder(lockedLabels, m);
									switchedLabelOrder[m] = true;
								} else { 
								/* can't switch the labels because they've 
								   both been switched once already.  Tell the 
								   user that the locked label will not be honored */
									rtn_code = warnAboutLockedLabel(atomID, 
													atsymbol, lockedLabels, m);
									if (rtn_code == 0) {
										/* mark this label as being removed */
										removedLabel[m] = true;
										goto mLabelRemoved;
									} else if (rtn_code == 1)
										/* user canceled out of calculation */
										goto cancelReturn;
									else
										goto errorReturn;
								}
							}
						}
					} else if (((lockedLabels[m].atomList[0] == 3) &&
							   (lockedLabels[j].atomList[0] == 4)) ||
							   ((lockedLabels[m].atomList[0] == 4) &&
							   (lockedLabels[j].atomList[0] == 3))) {
						/* an angle and a dihedral*/
						if (lockedLabels[m].atomList[0] == 3) {
							/* m is the angle label */
						all_atoms_the_same = true;
						for (k = 1; k <= lockedLabels[m].atomList[0]; k++) {
							atom_found[k] = false;
							for (n = 1; n <= lockedLabels[j].atomList[0]; n++) {
								if (lockedLabels[j].atomList[n] == 
									lockedLabels[m].atomList[k]) {
									atom_found[k] = true;
									break;
								}
							} /* n loop */
							if (!atom_found[k]) {
								all_atoms_the_same = false;
								break;
							}
						} /* k loop */
							
							if (all_atoms_the_same) {
								/* all atoms in the angle are also in the dihedral */
								if ((lockedLabels[m].atomList[2] == 
									lockedLabels[j].atomList[2]) &&
									(lockedLabels[m].atomList[3] == 
									lockedLabels[j].atomList[3])) {
									/* angle follows dihedral.  Put the angle label after the
									   dihedral */
									  swap_m_and_j = true;
									  goto swap_m_and_j_labels;
								} else if ((lockedLabels[m].atomList[2] == 
									lockedLabels[j].atomList[2]) &&
									(lockedLabels[m].atomList[3] == 
									lockedLabels[j].atomList[4])) {
									/* this case can't be handled by the z-matrix:  remove
									   the dihedral label */
									rtn_code = warnAboutLockedLabel(atomID, 
													atsymbol, lockedLabels, j);
									if (rtn_code == 0) {
										/* mark this label as being removed */
										removedLabel[j] = true;
										goto jLabelRemoved;
									} else if (rtn_code == 1)
										/* user canceled out of calculation */
										goto cancelReturn;
									else
										goto errorReturn;
								} else if ((lockedLabels[m].atomList[2] == 
									lockedLabels[j].atomList[3]) &&
									(lockedLabels[m].atomList[3] == 
									lockedLabels[j].atomList[4])) {
									/* this case can't be handled by the z-matrix:  remove
									   the dihedral label */
									rtn_code = warnAboutLockedLabel(atomID, 
													atsymbol, lockedLabels, j);
									if (rtn_code == 0) {
										/* mark this label as being removed */
										removedLabel[j] = true;
										goto jLabelRemoved;
									} else if (rtn_code == 1)
										/* user canceled out of calculation */
										goto cancelReturn;
									else
										goto errorReturn;
								} else if ((lockedLabels[m].atomList[2] == 
									lockedLabels[j].atomList[3]) &&
									(lockedLabels[m].atomList[3] == 
									lockedLabels[j].atomList[2])) {
									/* this case can't be handled by the z-matrix:  remove
									   the dihedral label */
									rtn_code = warnAboutLockedLabel(atomID, 
													atsymbol, lockedLabels, j);
									if (rtn_code == 0) {
										/* mark this label as being removed */
										removedLabel[j] = true;
										goto jLabelRemoved;
									} else if (rtn_code == 1)
										/* user canceled out of calculation */
										goto cancelReturn;
									else
										goto errorReturn;
								} else if ((lockedLabels[m].atomList[2] == 
									lockedLabels[j].atomList[4]) &&
									(lockedLabels[m].atomList[3] == 
									lockedLabels[j].atomList[2])) {
									/* this case can't be handled by the z-matrix:  remove
									   the dihedral label */
									rtn_code = warnAboutLockedLabel(atomID, 
													atsymbol, lockedLabels, j);
									if (rtn_code == 0) {
										/* mark this label as being removed */
										removedLabel[j] = true;
										goto jLabelRemoved;
									} else if (rtn_code == 1)
										/* user canceled out of calculation */
										goto cancelReturn;
									else
										goto errorReturn;
								} else if ((lockedLabels[m].atomList[2] == 
									lockedLabels[j].atomList[4]) &&
									(lockedLabels[m].atomList[3] == 
									lockedLabels[j].atomList[3])) {
									/* this case can't be handled by the z-matrix:  remove
									   the dihedral label */
									rtn_code = warnAboutLockedLabel(atomID, 
													atsymbol, lockedLabels, j);
									if (rtn_code == 0) {
										/* mark this label as being removed */
										removedLabel[j] = true;
										goto jLabelRemoved;
									} else if (rtn_code == 1)
										/* user canceled out of calculation */
										goto cancelReturn;
									else
										goto errorReturn;
								}
							} else {
								/* reverse the order of the angle label preferentially */
								if (!switchedLabelOrder[m]) {
									reverseLabelOrder(lockedLabels, m);
									switchedLabelOrder[m] = true; 
								} else if (!switchedLabelOrder[j]) {
									reverseLabelOrder(lockedLabels, j);
									switchedLabelOrder[j] = true;
								} else { 
								/* can't switch the labels because they've 
								   both been switched once already.  Tell the 
								   user that the locked label will not be honored */
									rtn_code = warnAboutLockedLabel(atomID, 
													atsymbol, lockedLabels, j);
									if (rtn_code == 0) {
										/* mark this label as being removed */
										removedLabel[j] = true;
										goto jLabelRemoved;
									} else if (rtn_code == 1)
										/* user canceled out of calculation */
										goto cancelReturn;
									else
										goto errorReturn;
								}
							}
						} else {
							/* j is the angle label */
							all_atoms_the_same = true;
							for (k = 1; k <= lockedLabels[j].atomList[0]; k++) {
								atom_found[k] = false;
								for (n = 1; n <= lockedLabels[m].atomList[0]; n++) {
									if (lockedLabels[m].atomList[n] == 
										lockedLabels[j].atomList[k]) {
										atom_found[k] = true;
										break;
									}
								} /* n loop */
								if (!atom_found[k]) {
									all_atoms_the_same = false;
									break;
								}
							} /* k loop */
							
							if (all_atoms_the_same) {
								/* all atoms in the angle are also in the dihedral */
								/* if the angle atoms are those of the dihedral, don't
								   do anything since the labels are already in the correct
								   order */
								if ((lockedLabels[j].atomList[2] == 
									lockedLabels[m].atomList[2]) &&
									(lockedLabels[j].atomList[3] == 
									lockedLabels[m].atomList[4])) {
									/* this case can't be handled by the z-matrix:  remove
									   the dihedral label */
									rtn_code = warnAboutLockedLabel(atomID, 
													atsymbol, lockedLabels, j);
									if (rtn_code == 0) {
										/* mark this label as being removed */
										removedLabel[j] = true;
										goto jLabelRemoved;
									} else if (rtn_code == 1)
										/* user canceled out of calculation */
										goto cancelReturn;
									else
										goto errorReturn;
								} else if ((lockedLabels[j].atomList[2] == 
									lockedLabels[m].atomList[3]) &&
									(lockedLabels[j].atomList[3] == 
									lockedLabels[m].atomList[4])) {
									/* this case can't be handled by the z-matrix:  remove
									   the dihedral label */
									rtn_code = warnAboutLockedLabel(atomID, 
													atsymbol, lockedLabels, j);
									if (rtn_code == 0) {
										/* mark this label as being removed */
										removedLabel[j] = true;
										goto jLabelRemoved;
									} else if (rtn_code == 1)
										/* user canceled out of calculation */
										goto cancelReturn;
									else
										goto errorReturn;
								} else if ((lockedLabels[j].atomList[2] == 
									lockedLabels[j].atomList[3]) &&
									(lockedLabels[m].atomList[3] == 
									lockedLabels[j].atomList[2])) {
									/* this case can't be handled by the z-matrix:  remove
									   the dihedral label */
									rtn_code = warnAboutLockedLabel(atomID, 
													atsymbol, lockedLabels, j);
									if (rtn_code == 0) {
										/* mark this label as being removed */
										removedLabel[j] = true;
										goto jLabelRemoved;
									} else if (rtn_code == 1)
										/* user canceled out of calculation */
										goto cancelReturn;
									else
										goto errorReturn;
								} else if ((lockedLabels[m].atomList[2] == 
									lockedLabels[j].atomList[4]) &&
									(lockedLabels[m].atomList[3] == 
									lockedLabels[j].atomList[2])) {
									/* this case can't be handled by the z-matrix:  remove
									   the dihedral label */
									rtn_code = warnAboutLockedLabel(atomID, 
													atsymbol, lockedLabels, j);
									if (rtn_code == 0) {
										/* mark this label as being removed */
										removedLabel[j] = true;
										goto jLabelRemoved;
									} else if (rtn_code == 1)
										/* user canceled out of calculation */
										goto cancelReturn;
									else
										goto errorReturn;
								} else if ((lockedLabels[m].atomList[2] == 
									lockedLabels[j].atomList[4]) &&
									(lockedLabels[m].atomList[3] == 
									lockedLabels[j].atomList[3])) {
									/* this case can't be handled by the z-matrix:  remove
									   the dihedral label */
									rtn_code = warnAboutLockedLabel(atomID, 
													atsymbol, lockedLabels, j);
									if (rtn_code == 0) {
										/* mark this label as being removed */
										removedLabel[j] = true;
										goto jLabelRemoved;
									} else if (rtn_code == 1)
										/* user canceled out of calculation */
										goto cancelReturn;
									else
										goto errorReturn;
								}
							} else {
								/* reverse the order of the angle label preferentially */
								if (!switchedLabelOrder[m]) {
									reverseLabelOrder(lockedLabels, m);
									switchedLabelOrder[m] = true; 
								} else if (!switchedLabelOrder[j]) {
									reverseLabelOrder(lockedLabels, j);
									switchedLabelOrder[j] = true;
								} else { 
								/* can't switch the labels because they've 
								   both been switched once already.  Tell the 
								   user that the locked label will not be honored */
									rtn_code = warnAboutLockedLabel(atomID, 
													atsymbol, lockedLabels, j);
									if (rtn_code == 0) {
										/* mark this label as being removed */
										removedLabel[j] = true;
										goto jLabelRemoved;
									} else if (rtn_code == 1)
										/* user canceled out of calculation */
										goto cancelReturn;
									else
										goto errorReturn;
								}
							}
						}
					} else {
						/* not possible! */
						alert_user(" resolveLockedLabelConflicts: error in locked label processing.");
						goto errorReturn;
					}
				} /* 1st atom the same */
			  } /* j label removed */
			} /* j loop */
		  } /* m label removed */
			/* deal with swapping m & j */
jLabelRemoved:
			/* just marked j as being removed; no need to process more j's */
		 ;
mLabelRemoved:
			/* just marked m as being removed; no need to process more j's */
		 ;
swap_m_and_j_labels:
			if (swap_m_and_j) { /* need to interchange m and j labels, and then proceed
									from the original position of m */
				tempLabel = lockedLabels[j];
				lockedLabels[j] = lockedLabels[m];
				lockedLabels[m] = tempLabel;
				if (number_of_m_repeats[m] < 10)
					m--; /* decrement the m counter */
			}
		} /* m loop */


		/* 
			Now go through and try to resolve conflicts between locked labels that
			don't have the same first atom
		*/
		for (m = 0; m < *numLockedLabels ; m++)
			number_of_m_repeats[m] = 0;
		for (m = 0; m < (*numLockedLabels)-1; m++) { /* process all the locked labels */
		  ++number_of_m_repeats[m];
		  if (!removedLabel[m]) { /* don't bother with labels that are already gone! */
			/* compare each label with those that follow it */
			for (j = m+1; j < *numLockedLabels; j++) {
			  
			  swap_m_and_j = false; /* flag for swapping m & j labels */
				
			  if (!removedLabel[j]) { /* don't bother with labels that are already gone! */
			  
				/* for each atom in the first label, see if it is first in a following label */
				if (lockedLabels[m].atomList[1] == lockedLabels[j].atomList[1]) {
					/* Already took care of labels that have the same first atom */
					continue; 
				} else {
					Boolean m_has_j1, j_has_m1;
					/* see if m contains the first atom of j */
					m_has_j1 = false;
					for (k = 2; k <= lockedLabels[m].atomList[0]; k++) {
						if (lockedLabels[m].atomList[k] == lockedLabels[j].atomList[1]) {
							m_has_j1 = true;
							break;
						}
					}
					
					/* see if j contains the first atom of m */
					j_has_m1 = false;
					for (k = 2; k <= lockedLabels[j].atomList[0]; k++) {
						if (lockedLabels[j].atomList[k] == lockedLabels[m].atomList[1]) {
							j_has_m1 = true;
							break;
						}
					}
					
					if (((lockedLabels[m].atomList[0] == 2) &&
						(lockedLabels[j].atomList[0] == 2)) ||
						((lockedLabels[m].atomList[0] == 3) &&
						(lockedLabels[j].atomList[0] == 3)) || 
						((lockedLabels[m].atomList[0] == 4) &&
						(lockedLabels[j].atomList[0] == 4))) {
						/* two distances, two angles or two dihedrals */
						/* if j has m's first atom, no action is necessary, since 
						   j is after m in the list */
						if (m_has_j1 && j_has_m1 && (!(lockedLabels[m].atomList[0] == 2))
							&& (lockedLabels[m].atomList[1] != lockedLabels[j].atomList[1])) {
							/* each has the first of the other -- distances were already 
							taken care of by having the same atoms. 
							This can't be handled by the z-matrix formulation, so
							remove one label */
							
							rtn_code = warnAboutLockedLabel(atomID, 
											atsymbol, lockedLabels, j);
							if (rtn_code == 0) {
								/* mark this label as being removed */
								removedLabel[j] = true;
								goto jLabelRemoved2;
							} else if (rtn_code == 1)
								/* user canceled out of calculation */
								goto cancelReturn;
							else
								goto errorReturn;
						} else if (m_has_j1) {
							swap_m_and_j;
							goto swap_m_and_j_labels2;
						}
					} else if (((lockedLabels[m].atomList[0] == 2) &&
						(lockedLabels[j].atomList[0] == 3)) || 
						((lockedLabels[m].atomList[0] == 3) &&
						(lockedLabels[j].atomList[0] == 2))){
						/* one distance and one angle */
						if (m_has_j1 && j_has_m1 && (lockedLabels[m].atomList[1] !=
							lockedLabels[j].atomList[1])) {
							if (lockedLabels[m].atomList[0] == 2) {
								/* m is the distance label */
								if ((lockedLabels[m].atomList[1] == 
									lockedLabels[j].atomList[3]) &&
									(lockedLabels[m].atomList[2] == 
									lockedLabels[j].atomList[1])) {
									/* This can't be handled by the z-matrix formulation, so
										remove one label */
										
										rtn_code = warnAboutLockedLabel(atomID, 
														atsymbol, lockedLabels, j);
										if (rtn_code == 0) {
											/* mark this label as being removed */
											removedLabel[j] = true;
											goto jLabelRemoved2;
										} else if (rtn_code == 1)
											/* user canceled out of calculation */
											goto cancelReturn;
										else
											goto errorReturn;
								} else if ((lockedLabels[m].atomList[1] == 
										lockedLabels[j].atomList[2]) && 
										(lockedLabels[m].atomList[2] == 
										lockedLabels[j].atomList[1])) {
									/* reverse one of the labels and put the distance
									   label after the angle label */
									if (!switchedLabelOrder[j]) {
										reverseLabelOrder(lockedLabels, j);
										switchedLabelOrder[j] = true;
										swap_m_and_j = true;
										goto swap_m_and_j_labels2;
									} else if (!switchedLabelOrder[m]) {
										reverseLabelOrder(lockedLabels, m);
										switchedLabelOrder[m] = true;
										swap_m_and_j = true;
										goto swap_m_and_j_labels2;
									} else { 
									/* can't switch the labels because they've 
									   both been switched once already.  Tell the 
									   user that the locked label will not be honored */
										rtn_code = warnAboutLockedLabel(atomID, 
														atsymbol, lockedLabels, j);
										if (rtn_code == 0) {
											/* mark this label as being removed */
											removedLabel[j] = true;
											goto jLabelRemoved2;
										} else if (rtn_code == 1)
											/* user canceled out of calculation */
											goto cancelReturn;
										else
											goto errorReturn;
									}
								}
							} else {
								/* j is the distance label */
								if ((lockedLabels[j].atomList[1] == 
									lockedLabels[m].atomList[3]) &&
									(lockedLabels[j].atomList[2] == 
									lockedLabels[m].atomList[1])) {
									/* This can't be handled by the z-matrix formulation, so
										remove one label */
										
										rtn_code = warnAboutLockedLabel(atomID, 
														atsymbol, lockedLabels, m);
										if (rtn_code == 0) {
											/* mark this label as being removed */
											removedLabel[m] = true;
											goto mLabelRemoved2;
										} else if (rtn_code == 1)
											/* user canceled out of calculation */
											goto cancelReturn;
										else
											goto errorReturn;
								} else if ((lockedLabels[j].atomList[1] == 
										lockedLabels[m].atomList[2]) && 
										(lockedLabels[j].atomList[2] == 
										lockedLabels[m].atomList[1])) {
									/* reverse one of the labels and put the distance
									   label after the angle label */
									if (!switchedLabelOrder[m]) {
										reverseLabelOrder(lockedLabels, m);
										switchedLabelOrder[m] = true;
										swap_m_and_j = true;
										goto swap_m_and_j_labels2;
									} else if (!switchedLabelOrder[j]) {
										reverseLabelOrder(lockedLabels, j);
										switchedLabelOrder[j] = true;
										swap_m_and_j = true;
										goto swap_m_and_j_labels2;
									} else { 
									/* can't switch the labels because they've 
									   both been switched once already.  Tell the 
									   user that the locked label will not be honored */
										rtn_code = warnAboutLockedLabel(atomID, 
														atsymbol, lockedLabels, m);
										if (rtn_code == 0) {
											/* mark this label as being removed */
											removedLabel[m] = true;
											goto mLabelRemoved2;
										} else if (rtn_code == 1)
											/* user canceled out of calculation */
											goto cancelReturn;
										else
											goto errorReturn;
									}
								}
							
							}
						} else {
							if (lockedLabels[m].atomList[0] == 2) {
								/* m is the distance label */
								if (m_has_j1) {
									swap_m_and_j = true;
									goto swap_m_and_j_labels2;
								} else if (j_has_m1) {
									if ((lockedLabels[m].atomList[1] == 
										lockedLabels[j].atomList[3]) && 
										(lockedLabels[m].atomList[2] ==
										lockedLabels[j].atomList[2])) {
										if (!switchedLabelOrder[m]) {
											reverseLabelOrder(lockedLabels, m);
											switchedLabelOrder[m] = true;
											swap_m_and_j = true;
											goto swap_m_and_j_labels2;
										} else if (!switchedLabelOrder[j]) {
											reverseLabelOrder(lockedLabels, j);
											switchedLabelOrder[j] = true;
											swap_m_and_j = true;
											goto swap_m_and_j_labels2;
										} else {
											/* can't switch the labels because they've 
											   both been switched once already.  Tell the 
											   user that the locked label will not be honored */
												rtn_code = warnAboutLockedLabel(atomID, 
																atsymbol, lockedLabels, j);
												if (rtn_code == 0) {
													/* mark this label as being removed */
													removedLabel[j] = true;
													goto jLabelRemoved2;
												} else if (rtn_code == 1)
													/* user canceled out of calculation */
													goto cancelReturn;
												else
													goto errorReturn;
										}
									} 
								} 
							} else {
								/* j is the distance label */
								/* if j has the first atom of the angle, no action is needed,
								   because the j label already comes after the m label */
								if (j_has_m1) {
									if ((lockedLabels[j].atomList[1] == 
										lockedLabels[m].atomList[3]) && 
										(lockedLabels[j].atomList[2] ==
										lockedLabels[m].atomList[2])) {
										if (!switchedLabelOrder[j]) {
											reverseLabelOrder(lockedLabels, j);
											switchedLabelOrder[j] = true;
											swap_m_and_j = true;
											goto swap_m_and_j_labels2;
										} else if (!switchedLabelOrder[m]) {
											reverseLabelOrder(lockedLabels, m);
											switchedLabelOrder[m] = true;
											swap_m_and_j = true;
											goto swap_m_and_j_labels2;
										} else {
											/* can't switch the labels because they've 
											   both been switched once already.  Tell the 
											   user that the locked label will not be honored */
												rtn_code = warnAboutLockedLabel(atomID, 
																atsymbol, lockedLabels, m);
												if (rtn_code == 0) {
													/* mark this label as being removed */
													removedLabel[m] = true;
													goto mLabelRemoved2;
												} else if (rtn_code == 1)
													/* user canceled out of calculation */
													goto cancelReturn;
												else
													goto errorReturn;
										}
									}
								} 
							}
						}
					} else if (((lockedLabels[m].atomList[0] == 2) &&
						(lockedLabels[j].atomList[0] == 4)) || 
						((lockedLabels[m].atomList[0] == 4) &&
						(lockedLabels[j].atomList[0] == 2))){
						/* one distance and one dihedral */
						if (m_has_j1 && j_has_m1 && (lockedLabels[m].atomList[1] !=
							lockedLabels[j].atomList[1])) {
							if (lockedLabels[m].atomList[0] == 2) {
								/* m is the distance label */
								if ((lockedLabels[m].atomList[1] == 
									lockedLabels[j].atomList[4]) ||
									(lockedLabels[m].atomList[1] == 
									lockedLabels[j].atomList[3])){
									/* This can't be handled by the z-matrix formulation, so
										remove one label */
										
										rtn_code = warnAboutLockedLabel(atomID, 
														atsymbol, lockedLabels, j);
										if (rtn_code == 0) {
											/* mark this label as being removed */
											removedLabel[j] = true;
											goto jLabelRemoved2;
										} else if (rtn_code == 1)
											/* user canceled out of calculation */
											goto cancelReturn;
										else
											goto errorReturn;
								} else if (lockedLabels[m].atomList[2] == 
											lockedLabels[j].atomList[1]) {
									/* reverse the distance label and put the distance
									   label before the dihedral label */
									if (!switchedLabelOrder[m]) {
										reverseLabelOrder(lockedLabels, m);
										switchedLabelOrder[m] = true;
									} else { 
									/* can't switch the labels because they've 
									   both been switched once already.  Tell the 
									   user that the locked label will not be honored */
										rtn_code = warnAboutLockedLabel(atomID, 
														atsymbol, lockedLabels, j);
										if (rtn_code == 0) {
											/* mark this label as being removed */
											removedLabel[j] = true;
											goto jLabelRemoved2;
										} else if (rtn_code == 1)
											/* user canceled out of calculation */
											goto cancelReturn;
										else
											goto errorReturn;
									}
								}
							} else {
								/* j is the distance label */
								if ((lockedLabels[j].atomList[1] == 
									lockedLabels[m].atomList[4]) ||
									(lockedLabels[j].atomList[1] == 
									lockedLabels[m].atomList[3])) {
									/* This can't be handled by the z-matrix formulation, so
										remove one label */
										
										rtn_code = warnAboutLockedLabel(atomID, 
														atsymbol, lockedLabels, m);
										if (rtn_code == 0) {
											/* mark this label as being removed */
											removedLabel[m] = true;
											goto mLabelRemoved2;
										} else if (rtn_code == 1)
											/* user canceled out of calculation */
											goto cancelReturn;
										else
											goto errorReturn;
								} else if (lockedLabels[j].atomList[2] == 
											lockedLabels[m].atomList[1]) {
									/* reverse the distance label and put the distance
									   label before the angle label */
									if (!switchedLabelOrder[j]) {
										reverseLabelOrder(lockedLabels, j);
										switchedLabelOrder[j] = true;
										swap_m_and_j = true;
										goto swap_m_and_j_labels2;
									} else { 
									/* can't switch the labels because they've 
									   both been switched once already.  Tell the 
									   user that the locked label will not be honored */
										rtn_code = warnAboutLockedLabel(atomID, 
														atsymbol, lockedLabels, m);
										if (rtn_code == 0) {
											/* mark this label as being removed */
											removedLabel[m] = true;
											goto mLabelRemoved2;
										} else if (rtn_code == 1)
											/* user canceled out of calculation */
											goto cancelReturn;
										else
											goto errorReturn;
									}
								}
							
							}
						} else {
							if (lockedLabels[m].atomList[0] == 2) {
								/* m is the distance label */
								if (m_has_j1) {
									swap_m_and_j = true;
									goto swap_m_and_j_labels2;
								} else if (j_has_m1) {
									if (lockedLabels[m].atomList[1] == 
										lockedLabels[j].atomList[4]) {
										/* reverse the distance label */
										if (!switchedLabelOrder[m]) {
											reverseLabelOrder(lockedLabels, m);
											switchedLabelOrder[m] = true;
										} else if (!switchedLabelOrder[j]) {
											reverseLabelOrder(lockedLabels, j);
											switchedLabelOrder[j] = true;
										} else { 
										/* can't switch the labels because they've 
										   both been switched once already.  Tell the 
										   user that the locked label will not be honored */
											rtn_code = warnAboutLockedLabel(atomID, 
															atsymbol, lockedLabels, j);
											if (rtn_code == 0) {
												/* mark this label as being removed */
												removedLabel[j] = true;
												goto jLabelRemoved2;
											} else if (rtn_code == 1)
												/* user canceled out of calculation */
												goto cancelReturn;
											else
												goto errorReturn;
										}
									}
								} 
							} else {
								/* j is the distance label */
								if (j_has_m1) {
									swap_m_and_j = true;
									goto swap_m_and_j_labels2;
								} else if (m_has_j1) {
									if (lockedLabels[j].atomList[1] == 
										lockedLabels[m].atomList[2]) {
										swap_m_and_j = true;
										goto swap_m_and_j_labels2;
									} else if (lockedLabels[j].atomList[1] == 
										lockedLabels[m].atomList[3]) {
										swap_m_and_j = true;
										goto swap_m_and_j_labels2;
									} else if (lockedLabels[j].atomList[1] == 
										lockedLabels[m].atomList[4]) {
										if (lockedLabels[j].atomList[2] ==
											lockedLabels[m].atomList[3]) {
											if (!switchedLabelOrder[j]) {
												reverseLabelOrder(lockedLabels, j);
												switchedLabelOrder[j] = true;
												swap_m_and_j = true;
												goto swap_m_and_j_labels2;
											} else if (!switchedLabelOrder[m]) {
												reverseLabelOrder(lockedLabels, m);
												swap_m_and_j = true;
												goto swap_m_and_j_labels2;
											} else { 
											/* can't switch the labels because they've 
											   both been switched once already.  Tell the 
											   user that the locked label will not be honored */
												rtn_code = warnAboutLockedLabel(atomID, 
																atsymbol, lockedLabels, m);
												if (rtn_code == 0) {
													/* mark this label as being removed */
													removedLabel[m] = true;
													goto mLabelRemoved2;
												} else if (rtn_code == 1)
													/* user canceled out of calculation */
													goto cancelReturn;
												else
													goto errorReturn;
											}
										} else if (lockedLabels[j].atomList[2] ==
											lockedLabels[m].atomList[2]) {
											swap_m_and_j = true;
											goto swap_m_and_j_labels2;
										}
									}
								}
							}
						}
					} else if (((lockedLabels[m].atomList[0] == 3) &&
						(lockedLabels[j].atomList[0] == 4)) || 
						((lockedLabels[m].atomList[0] == 4) &&
						(lockedLabels[j].atomList[0] == 3))){
						/* one angle and one dihedral */
						if (m_has_j1 && j_has_m1 && 
							(lockedLabels[m].atomList[1] != lockedLabels[j].atomList[1])){
							if (lockedLabels[m].atomList[0] == 3) {
								/* m is the angle label */
								all_atoms_the_same = true;
								for (k = 1; k <= lockedLabels[m].atomList[0]; k++) {
									atom_found[k] = false;
									for (n = 1; n <= lockedLabels[j].atomList[0]; n++) {
										if (lockedLabels[j].atomList[n] == 
											lockedLabels[m].atomList[k]) {
											atom_found[k] = true;
											break;
										}
									} /* n loop */
									if (!atom_found[k]) {
										all_atoms_the_same = false;
										break;
									}
								} /* k loop */

								if (lockedLabels[m].atomList[1] == 
									lockedLabels[j].atomList[2]) {
									if ((lockedLabels[m].atomList[2] == 
										lockedLabels[j].atomList[3]) &&
										(lockedLabels[m].atomList[3] ==
										lockedLabels[j].atomList[4])) {
										swap_m_and_j = true;
										goto swap_m_and_j_labels2;
									} else if ((lockedLabels[m].atomList[2] ==
												lockedLabels[j].atomList[4]) &&
												(lockedLabels[m].atomList[3] ==
												lockedLabels[j].atomList[3])) {
										swap_m_and_j = true;
										goto swap_m_and_j_labels2;
									} else if ((lockedLabels[m].atomList[2] ==
												lockedLabels[j].atomList[1]) &&
												(lockedLabels[m].atomList[3] ==
												lockedLabels[j].atomList[3])) {
										/* This case can't be handled by the z-matrix.
										Tell the user that the locked label will 
										not be honored */
										rtn_code = warnAboutLockedLabel(atomID, 
														atsymbol, lockedLabels, j);
										if (rtn_code == 0) {
											/* mark this label as being removed */
											removedLabel[j] = true;
											goto jLabelRemoved2;
										} else if (rtn_code == 1)
											/* user canceled out of calculation */
											goto cancelReturn;
										else
											goto errorReturn;
									} else if ((lockedLabels[m].atomList[2] ==
												lockedLabels[j].atomList[1]) &&
												(lockedLabels[m].atomList[3] ==
												lockedLabels[j].atomList[4])) {
										/* This case can't be handled by the z-matrix.
										Tell the user that the locked label will 
										not be honored */
										rtn_code = warnAboutLockedLabel(atomID, 
														atsymbol, lockedLabels, j);
										if (rtn_code == 0) {
											/* mark this label as being removed */
											removedLabel[j] = true;
											goto jLabelRemoved2;
										} else if (rtn_code == 1)
											/* user canceled out of calculation */
											goto cancelReturn;
										else
											goto errorReturn;
									} else if (lockedLabels[m].atomList[2] ==
												lockedLabels[j].atomList[3]) {
										if (!switchedLabelOrder[m]) {
											reverseLabelOrder(lockedLabels, m);
											/* dihedral is second in list */
										} else {
											/* Can't reverse the label.
											Tell the user that the locked label will 
											not be honored */
											rtn_code = warnAboutLockedLabel(atomID, 
															atsymbol, lockedLabels, j);
											if (rtn_code == 0) {
												/* mark this label as being removed */
												removedLabel[j] = true;
												goto jLabelRemoved2;
											} else if (rtn_code == 1)
												/* user canceled out of calculation */
												goto cancelReturn;
											else
												goto errorReturn;
										}
									} else if (lockedLabels[m].atomList[3] ==
												lockedLabels[j].atomList[1]) {
										/* Case can't be handled by the z-matrix.
										Tell the user that the locked label will 
										not be honored */
										rtn_code = warnAboutLockedLabel(atomID, 
														atsymbol, lockedLabels, j);
										if (rtn_code == 0) {
											/* mark this label as being removed */
											removedLabel[j] = true;
											goto jLabelRemoved2;
										} else if (rtn_code == 1)
											/* user canceled out of calculation */
											goto cancelReturn;
										else
											goto errorReturn;
									}
								} else if (lockedLabels[m].atomList[1] ==
									lockedLabels[j].atomList[3]) {
									if (all_atoms_the_same) {
										/* This case can't be handled by the z-matrix.
										Tell the user that the locked label will 
										not be honored */
										rtn_code = warnAboutLockedLabel(atomID, 
														atsymbol, lockedLabels, j);
										if (rtn_code == 0) {
											/* mark this label as being removed */
											removedLabel[j] = true;
											goto jLabelRemoved2;
										} else if (rtn_code == 1)
											/* user canceled out of calculation */
											goto cancelReturn;
										else
											goto errorReturn;
									} else if (lockedLabels[m].atomList[2] ==
												lockedLabels[j].atomList[1]) {
										if (!switchedLabelOrder[m]) {
											reverseLabelOrder(lockedLabels, m);
											/* dihedral is second in list */
										} else {
											/* Can't reverse the label.
											Tell the user that the locked label will 
											not be honored */
											rtn_code = warnAboutLockedLabel(atomID, 
															atsymbol, lockedLabels, j);
											if (rtn_code == 0) {
												/* mark this label as being removed */
												removedLabel[j] = true;
												goto jLabelRemoved2;
											} else if (rtn_code == 1)
												/* user canceled out of calculation */
												goto cancelReturn;
											else
												goto errorReturn;
										}
									} else if (lockedLabels[m].atomList[3] ==
												lockedLabels[j].atomList[1]) {
										/* This case can't be handled by the z-matrix.
										Tell the user that the locked label will 
										not be honored */
										rtn_code = warnAboutLockedLabel(atomID, 
														atsymbol, lockedLabels, j);
										if (rtn_code == 0) {
											/* mark this label as being removed */
											removedLabel[j] = true;
											goto jLabelRemoved2;
										} else if (rtn_code == 1)
											/* user canceled out of calculation */
											goto cancelReturn;
										else
											goto errorReturn;
									}
								} else if (lockedLabels[m].atomList[1] ==
									lockedLabels[j].atomList[4]) {
									if (all_atoms_the_same) {
										/* This case can't be handled by the z-matrix.
										Tell the user that the locked label will 
										not be honored */
										rtn_code = warnAboutLockedLabel(atomID, 
														atsymbol, lockedLabels, j);
										if (rtn_code == 0) {
											/* mark this label as being removed */
											removedLabel[j] = true;
											goto jLabelRemoved2;
										} else if (rtn_code == 1)
											/* user canceled out of calculation */
											goto cancelReturn;
										else
											goto errorReturn;
									} else if (lockedLabels[m].atomList[2] ==
												lockedLabels[j].atomList[1]) {
										if (!switchedLabelOrder[m]) {
											reverseLabelOrder(lockedLabels, m);
											/* dihedral is second in list */
										} else {
											/* Can't reverse the label.
											Tell the user that the locked label will 
											not be honored */
											rtn_code = warnAboutLockedLabel(atomID, 
															atsymbol, lockedLabels, j);
											if (rtn_code == 0) {
												/* mark this label as being removed */
												removedLabel[j] = true;
												goto jLabelRemoved2;
											} else if (rtn_code == 1)
												/* user canceled out of calculation */
												goto cancelReturn;
											else
												goto errorReturn;
										}
									} else if (lockedLabels[m].atomList[3] ==
												lockedLabels[j].atomList[1]) {
										/* This case can't be handled by the z-matrix.
										Tell the user that the locked label will 
										not be honored */
										rtn_code = warnAboutLockedLabel(atomID, 
														atsymbol, lockedLabels, j);
										if (rtn_code == 0) {
											/* mark this label as being removed */
											removedLabel[j] = true;
											goto jLabelRemoved2;
										} else if (rtn_code == 1)
											/* user canceled out of calculation */
											goto cancelReturn;
										else
											goto errorReturn;
									}
								} 
							} else {
								/* j is the angle label */
								all_atoms_the_same = true;
								for (k = 1; k <= lockedLabels[j].atomList[0]; k++) {
									atom_found[k] = false;
									for (n = 1; n <= lockedLabels[m].atomList[0]; n++) {
										if (lockedLabels[m].atomList[n] == 
											lockedLabels[j].atomList[k]) {
											atom_found[k] = true;
											break;
										}
									} /* n loop */
									if (!atom_found[k]) {
										all_atoms_the_same = false;
										break;
									}
								} /* k loop */

								if (lockedLabels[j].atomList[1] == 
									lockedLabels[m].atomList[2]) {
									if ((lockedLabels[j].atomList[2] == 
										lockedLabels[m].atomList[3]) &&
										(lockedLabels[j].atomList[3] ==
										lockedLabels[m].atomList[4])) {
										swap_m_and_j = true;
										goto swap_m_and_j_labels2;
									} else if ((lockedLabels[j].atomList[2] ==
												lockedLabels[m].atomList[4]) &&
												(lockedLabels[j].atomList[3] ==
												lockedLabels[m].atomList[3])) {
										swap_m_and_j = true;
										goto swap_m_and_j_labels2;
									} else if ((lockedLabels[j].atomList[2] ==
												lockedLabels[m].atomList[1]) &&
												(lockedLabels[j].atomList[3] ==
												lockedLabels[m].atomList[3])) {
										/* This case can't be handled by the z-matrix.
										Tell the user that the locked label will 
										not be honored */
										rtn_code = warnAboutLockedLabel(atomID, 
														atsymbol, lockedLabels, m);
										if (rtn_code == 0) {
											/* mark this label as being removed */
											removedLabel[m] = true;
											goto mLabelRemoved2;
										} else if (rtn_code == 1)
											/* user canceled out of calculation */
											goto cancelReturn;
										else
											goto errorReturn;
									} else if ((lockedLabels[j].atomList[2] ==
												lockedLabels[m].atomList[1]) &&
												(lockedLabels[j].atomList[3] ==
												lockedLabels[m].atomList[4])) {
										/* This case can't be handled by the z-matrix.
										Tell the user that the locked label will 
										not be honored */
										rtn_code = warnAboutLockedLabel(atomID, 
														atsymbol, lockedLabels, m);
										if (rtn_code == 0) {
											/* mark this label as being removed */
											removedLabel[m] = true;
											goto mLabelRemoved2;
										} else if (rtn_code == 1)
											/* user canceled out of calculation */
											goto cancelReturn;
										else
											goto errorReturn;
									} else if (lockedLabels[j].atomList[2] ==
												lockedLabels[m].atomList[3]) {
										if (!switchedLabelOrder[j]) {
											reverseLabelOrder(lockedLabels, j);
											/* dihedral is second in list */
											swap_m_and_j = true;
											goto swap_m_and_j_labels2;
										} else {
											/* Can't reverse the label.
											Tell the user that the locked label will 
											not be honored */
											rtn_code = warnAboutLockedLabel(atomID, 
															atsymbol, lockedLabels, m);
											if (rtn_code == 0) {
												/* mark this label as being removed */
												removedLabel[m] = true;
												goto mLabelRemoved2;
											} else if (rtn_code == 1)
												/* user canceled out of calculation */
												goto cancelReturn;
											else
												goto errorReturn;
										}
									} else if (lockedLabels[j].atomList[3] ==
												lockedLabels[m].atomList[1]) {
										/* Case can't be handled by the z-matrix.
										Tell the user that the locked label will 
										not be honored */
										rtn_code = warnAboutLockedLabel(atomID, 
														atsymbol, lockedLabels, m);
										if (rtn_code == 0) {
											/* mark this label as being removed */
											removedLabel[m] = true;
											goto mLabelRemoved2;
										} else if (rtn_code == 1)
											/* user canceled out of calculation */
											goto cancelReturn;
										else
											goto errorReturn;
									}
								} else if (lockedLabels[j].atomList[1] ==
									lockedLabels[m].atomList[3]) {
									if (all_atoms_the_same) {
										/* This case can't be handled by the z-matrix.
										Tell the user that the locked label will 
										not be honored */
										rtn_code = warnAboutLockedLabel(atomID, 
														atsymbol, lockedLabels, m);
										if (rtn_code == 0) {
											/* mark this label as being removed */
											removedLabel[m] = true;
											goto mLabelRemoved2;
										} else if (rtn_code == 1)
											/* user canceled out of calculation */
											goto cancelReturn;
										else
											goto errorReturn;
									} else if (lockedLabels[j].atomList[2] ==
												lockedLabels[m].atomList[1]) {
										if (!switchedLabelOrder[j]) {
											reverseLabelOrder(lockedLabels, j);
											/* dihedral is second in list */
											swap_m_and_j = true;
											goto swap_m_and_j_labels2;
										} else {
											/* Can't reverse the label.
											Tell the user that the locked label will 
											not be honored */
											rtn_code = warnAboutLockedLabel(atomID, 
															atsymbol, lockedLabels, m);
											if (rtn_code == 0) {
												/* mark this label as being removed */
												removedLabel[m] = true;
												goto mLabelRemoved2;
											} else if (rtn_code == 1)
												/* user canceled out of calculation */
												goto cancelReturn;
											else
												goto errorReturn;
										}
									} else if (lockedLabels[j].atomList[3] ==
												lockedLabels[m].atomList[1]) {
										/* This case can't be handled by the z-matrix.
										Tell the user that the locked label will 
										not be honored */
										rtn_code = warnAboutLockedLabel(atomID, 
														atsymbol, lockedLabels, m);
										if (rtn_code == 0) {
											/* mark this label as being removed */
											removedLabel[m] = true;
											goto mLabelRemoved2;
										} else if (rtn_code == 1)
											/* user canceled out of calculation */
											goto cancelReturn;
										else
											goto errorReturn;
									}
								} else if (lockedLabels[j].atomList[1] ==
									lockedLabels[m].atomList[4]) {
									if (all_atoms_the_same) {
										/* This case can't be handled by the z-matrix.
										Tell the user that the locked label will 
										not be honored */
										rtn_code = warnAboutLockedLabel(atomID, 
														atsymbol, lockedLabels, m);
										if (rtn_code == 0) {
											/* mark this label as being removed */
											removedLabel[m] = true;
											goto mLabelRemoved2;
										} else if (rtn_code == 1)
											/* user canceled out of calculation */
											goto cancelReturn;
										else
											goto errorReturn;
									} else if (lockedLabels[j].atomList[2] ==
												lockedLabels[m].atomList[1]) {
										if (!switchedLabelOrder[j]) {
											reverseLabelOrder(lockedLabels, m);
											swap_m_and_j = true;
											goto swap_m_and_j_labels2;
											/* dihedral is second in list */
										} else {
											/* Can't reverse the label.
											Tell the user that the locked label will 
											not be honored */
											rtn_code = warnAboutLockedLabel(atomID, 
															atsymbol, lockedLabels, m);
											if (rtn_code == 0) {
												/* mark this label as being removed */
												removedLabel[m] = true;
												goto mLabelRemoved2;
											} else if (rtn_code == 1)
												/* user canceled out of calculation */
												goto cancelReturn;
											else
												goto errorReturn;
										}
									} else if (lockedLabels[j].atomList[3] ==
												lockedLabels[m].atomList[1]) { 
										/* This case can't be handled by the z-matrix.
										Tell the user that the locked label will 
										not be honored */
										rtn_code = warnAboutLockedLabel(atomID, 
														atsymbol, lockedLabels, m);
										if (rtn_code == 0) {
											/* mark this label as being removed */
											removedLabel[m] = true;
											goto mLabelRemoved2;
										} else if (rtn_code == 1)
											/* user canceled out of calculation */
											goto cancelReturn;
										else
											goto errorReturn;
									}
								} 
							}
						} else if (j_has_m1) {
							swap_m_and_j = true;
							goto swap_m_and_j_labels2;
						}
					}
				} /* 1st atom not the same */
			  } /* j label removed */
			} /* j loop */
		  } /* m label removed */
			/* deal with swapping m & j */
jLabelRemoved2:
			/* just marked j as being removed; no need to process more j's */
		 ;
mLabelRemoved2:
			/* just marked m as being removed; no need to process more j's */
		;
swap_m_and_j_labels2:
			if (swap_m_and_j) { /* need to interchange m and j labels, and then proceed
									from the original position of m */
				tempLabel = lockedLabels[j];
				lockedLabels[j] = lockedLabels[m];
				lockedLabels[m] = tempLabel;
				if (number_of_m_repeats[m] < 10)
					m--; /* decrement the m counter */
			}
		} /* m loop */

		/* 
			Go through and removed all locked labels that were marked to be 
			turned into locked atoms 
		*/
		for (m = 0, n = *numLockedLabels; m < *numLockedLabels; m++) { 
			if (removedLabel[m]) {
				/* remove this label from the list of locked labels */
				for (k=m; k<(*numLockedLabels)-1; k++) 
					lockedLabels[k] = lockedLabels[k+1];
				n--; /* decrement the number of locked labels */
			}
	
		 } /* m loop */
	  	*numLockedLabels = n; /* set new value of number of locked labels */
	
	  }
  
  if (removedLabel != NULL) free(removedLabel);
  if (switchedLabelOrder != NULL) free(switchedLabelOrder);
  if (number_of_m_repeats != NULL) free(number_of_m_repeats);
  return (0);
 
errorReturn:
  if (removedLabel != NULL) free(removedLabel);
  if (switchedLabelOrder != NULL) free(switchedLabelOrder);
  if (number_of_m_repeats != NULL) free(number_of_m_repeats);
  return (-1);

cancelReturn:
  if (removedLabel != NULL) free(removedLabel);
  if (switchedLabelOrder != NULL) free(switchedLabelOrder);
  if (number_of_m_repeats != NULL) free(number_of_m_repeats);
  return (1);
 
}

void reverseSearchOrder(SearchLabel searchLabels[], int m)
{
	int j;
	SearchLabel tempLabel;

	tempLabel = searchLabels[m];
	for (j=1; j <= searchLabels[m].atomList[0]; j++) {
		searchLabels[m].atomList[j] = 
			tempLabel.atomList[searchLabels[m].atomList[0]-j+1];
	}
}

void reverseLabelOrder(LockedLabel lockedLabels[], int m)
{
	int j;
	LockedLabel tempLabel;

	tempLabel = lockedLabels[m];
	for (j=1; j <= lockedLabels[m].atomList[0]; j++) {
		lockedLabels[m].atomList[j] = 
			tempLabel.atomList[lockedLabels[m].atomList[0]-j+1];
	}
}

int	warnAboutLockedLabel(long *atomID, char (*atsymbol)[2], 
							LockedLabel lockedLabels[], int m)
{
	int i, j;
	char atsym2, atsym1;
	char string[255], string2[255];


	sprintf(string, "A locked label in the molecule cannot be maintained in "
					"this calculation because it conflicts with "
					"other locked labels or with atoms with locked coordinates.  "
					"The label contains the following atoms:\n  ");
	for (i=1; i < lockedLabels[m].atomList[0]; i++) {
		j = lockedLabels[m].atomList[i];
		atsym2 = atsymbol[j][1];
		atsym1 = atsymbol[j][0];
		if (atsym2 < 32 || atsym2 > 126) {
		    atsym2 = ' ';
		} else if (atsym2 == '_') atsym2 = ' ';
		sprintf(string2,"%c%c(%d), ", atsym1, atsym2, atomID[j]);
		if ((strlen(string)+strlen(string2)) < 255)
			strncat(string,string2,strlen(string2));
	}
	i = lockedLabels[m].atomList[0];
	j = lockedLabels[m].atomList[i];
	atsym2 = atsymbol[j][1];
	atsym1 = atsymbol[j][0];
	if (atsym2 < 32 || atsym2 > 126) {
		atsym2 = ' ';
	} else if (atsym2 == '_') atsym2 = ' ';
	sprintf(string2,"%c%c(%d)  ", atsym1, atsym2, atomID[j]);
	if ((strlen(string)+strlen(string2)) < 255)
		strncat(string,string2,strlen(string2));

	
	return(cancelOrProceedDialog(string, "Press OK to proceed with the calculation.", 
								"Press Cancel if you do not wish to run the calculation.")); 
}
