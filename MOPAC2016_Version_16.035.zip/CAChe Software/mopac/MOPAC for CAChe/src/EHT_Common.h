/*
** MODULE:
**	EHT_Common.h
**
** DESCRIPTION:
**	Definitions for Extended Huckel defines, structures and prototypes.
**	It is intended to be used in UI, application manager and application.
**
** NOTES:
**
** HISTORY:
**	06/09/92 - JJS - Created.
*/

/* Duplicate header file lock */
#ifndef __EHTCOMMON__
#define __EHTCOMMON__

#include <cul.h>
#include <SSQFileTypes.h>
#include <CACheFileLib.h>

#ifndef TRUE
#define TRUE			(1)
#endif
#ifndef FALSE
#define FALSE			(0)
#endif

/* Things that are R/W from settings file. */

/*
** Values for molRangeFlag which specifies which radio button is set for
** calculating eht print values.
*/
#define HOMO_AND_LUMO	1
#define ALL_MOLS		2
#define NO_MOLS			3
#define HOMO_TO_LUMO	4

#define	EHT				1			/* what type of Hamiltonian do we want to solve, 'normal' */
#define	CHGEHT			2			/* ... or charge iterative.  */

#define	MINCONTRACTIONLEN 3			/* minimum contraction length is STO-3G */
#define	MAXCONTRACTIONLEN 6			/* maximum contraction length is STO-6G */

/*
 *  Integral flags  :  extracted from Argus 6/12/90  MT.
 *
 *  Type flags for integrals.  These flags each control the
 *  calculation of one predefined type of integral.  The 
 *  same type number may mean different things in the
 *  electron-nuclear and two-electron integrals routines,
 *  for example.
 *
 *  Currently 3 Categories of integrals are classified,
 *  each having possible TYPES.
 *
 *  1.  One-electron ints.    : overlap, dipole, kinetic energy, etc.
 *  2.  Nuclear-electron      : nuclear-electron integrals (i|1/r|j)
 *  3.  Two-electron  
 *
 *  I've only put in the one-ele. #defines below.
 */ 
#define     TYPE1		0x0001
#define     TYPE2       0x0002

#define     PROP_ONE_CENTER    (TYPE1)
#define     PROP_ALL_CENTER	   (TYPE1 | TYPE2)

/*
** File types that are put in file lists telling what file is used for.
*/
enum EHT_file_type
{
	EHT_PARAMETERS_FILE = ssq_file_custom,
	EHT_DEFAULT_PARAMS_FILE,
	EHT_OUTPUT_FILE,
	EHT_LOG_FILE,
	EHT_DUMMY_FILE = ssq_file_dummy
};

/*
** Mol/map (data) file, optional EHT accessory file and optional log
** file are output files.
**
** Even though the 'Extended Huckel Output' file and the log file aren't
** always generated data areas are always allocated in the output file
** list structure.
*/
#define EHT_NUM_OUTPUT_FILES	3

/*
** Bit defines for accessory files that can be created from application.
** This info is stored in the accessoryOutput item in EHTControl structure and the
** settings file.
*/
#define EHT_OUTPUT_FILE_BIT		1
#define EHT_LOG_FILE_BIT		2

/*
** Define things that are used with file names and file lists.
*/
#define EHT_MAX_FNAME_SIZE		CFL_PATH_MAX		/* Char size of file name buffers */

/* max size of the servername passed from unix manager to unix compute engine */
#define ServerNameSize 32 /* should match ssq_ServerNameSize */

/* Settings, parameters, mol/map file, data dictionary, default parameters */
#define SETTINGS_FLIST_INDEX		0
#define PARAMS_FLIST_INDEX			1
#define DATA_FLIST_INDEX			2
#define DEFAULT_PARAMS_FLIST_INDEX	3
#define DATADICT_FLIST_INDEX		4 /* This file does not get transferred.
									   * Data dictionary needs to go at the end of the list 
									   * because we can't have gaps in the input list */

/* This number needs to include the data dictionary name */ 
#define EHT_NUM_INPUT_FILES			5

#define SETTINGS_FNAME_INDEX		(EHT_MAX_FNAME_SIZE * SETTINGS_FLIST_INDEX)
#define PARAMS_FNAME_INDEX			(EHT_MAX_FNAME_SIZE * PARAMS_FLIST_INDEX)
#define DATA_FNAME_INDEX			(EHT_MAX_FNAME_SIZE * DATA_FLIST_INDEX)
#define DEFAULT_PARAMS_FNAME_INDEX 	(EHT_MAX_FNAME_SIZE * DEFAULT_PARAMS_FLIST_INDEX)
#define DATADICT_FNAME_INDEX 		(EHT_MAX_FNAME_SIZE * DATADICT_FLIST_INDEX)


#define EHT_OUTPUT_NAME			"Extended Huckel Output"
#define EHT_LOG_NAME			"Extended Huckel Log"
#define DATADICT_NAME			"Data Dictionary"
/* Don't change name to ExtendedHuckel with umlaut, can't access data dictionary with that name */
#define EHT_DATADICT_APPL_NAME	"ExtendedHuckel"

/*
** Define number of channels and message channels IDs.
*/
#define	EHT_NUM_CHANNELS		3		/* Number of channels used */
#define EHT_MSG_BUFFER_SIZE		256		/* Chars in channel message buffer */

/*
** Defines for message channels that write info in status box.
**
** NOTE:  These numbers should agree with those in ServerStepQueue.h
**
*/
#define EHT_SCROLL_MSG_CHAN		0		/* Scroll area in sts dialog chan num */
#define EHT_CURRENT_CALC_CHAN	1		/* Current calc in sts dialog box. */
#define EHT_CURRENT_OP_CHAN		2		/* Current operation in sts dialog chan num */

/*
** Define error code for ReadParamFile
*/
#define EHunableToReadParamFile -1

/*
** Bits in runFlag which is shared between application and application
** manager EHT_88KDriverParam structure.
*/
#define EHT_RUNNING				1		/* 68K tells 88K to start calc */
#define EHT_STOPPED				2		/* 68K tells 88K to stop calc */
#define EHT_WAITING				4		/* 88K is waiting for 68K */
#define EHT_QUITTING			8		/* 88K quits application */
#define EHT_ERROR_EXIT			128		/* Error in application code. */

/*
** This structure contains the number of input files and a buffer that holds
** the settings file, parameters file and mol/map file names. The indexs for
** these are defined above.
*/
struct EHT_InputFileList {
	long		numFiles;
	long		transferFormat[EHT_NUM_INPUT_FILES];
	char		fileName[EHT_MAX_FNAME_SIZE * EHT_NUM_INPUT_FILES];
};
typedef struct EHT_InputFileList EHT_InputFileList;
typedef struct EHT_InputFileList* EHT_InputFileListPtr;

/*
** This structure contains a file name and folder type that is returned
** by the application to the application manager to build a output file
** transfer list.
*/
struct EHT_OutputFileInfo {
	unsigned long		validFile;
	unsigned long		outputFileType;
	unsigned long		outputFolderType;
	unsigned long		fileFormat;
	char				fileName[EHT_MAX_FNAME_SIZE];
};
typedef struct EHT_OutputFileInfo EHT_OutputFileInfo;
typedef struct EHT_OutputFileInfo* EHT_OutputFileInfoPtr;

/*
** The structure below contains data for the output files. There is always one
** output file and that is a modified mol/map file.
**
** There is an optional 'Extended Huckel Output' file that will be used
** if the numFiles is 2. The 'Extended Huckel Output' file will be put in
** the mol/map sub-folder by using folder types when the application is
** done and the application manager builds the output file list.
*/
struct EHT_OutputFileList {
	long				numFiles;
	EHT_OutputFileInfo	fileInfo[EHT_NUM_OUTPUT_FILES];
};
typedef struct EHT_OutputFileList EHT_OutputFileList;
typedef struct EHT_OutputFileList* EHT_OutputFileListPtr;

struct EHT_88kDriverParam {
	EHT_InputFileListPtr	inputFileListPtr;
	EHT_OutputFileListPtr	outputFileListPtr;
	cul_CPMsgChannel		*msgChannelPtr;
	char					*applicationVersionPtr;
	char					*serverNamePtr;
	char					*dateTimePtr;
	char					validStructure;		/* true - structure inited */
	char					runFlag;			/* 0 - halted, !0 - running */
};
typedef struct EHT_88kDriverParam EHT_88kDriverParam;
typedef struct EHT_88kDriverParam* EHT_88kDriverParamPtr;

/*
** Here data for the lists and communication area for the 88K are keep for
** the EHT application manager.
*/ 
struct EHT_Settings {
	void					*sharedMemAddr;
	cul_CPMsgChannel		*msgChannelPtr;
	EHT_InputFileList		inputFileList;
	EHT_OutputFileListPtr	outputFileListPtr;
};
typedef struct EHT_Settings EHT_Settings;
typedef struct EHT_Settings* EHT_SettingsPtr;

/*
**  Data structure for holding parameters for an atomic orbital.
*/ 
 typedef struct {
   double		IP;				/* the ionization potential							     */
   double		STOexp[2];		/* default Slater's rules exponent, up to double zeta    */
   double		Coeff[2];       /* coefficients for STO's above, up to double zeta       */
   short        Nzeta;          /* 1 or 2 for single zeta or double zeta respectively    */
   short		atomicnumber;	/* the atomic number of the atoms this ao belongs to.    */
   short		Nquant;			/* the principal quantum number of this AO's shell	     */
   char			anglelabel;		/* the type of shell ie. "p"						     */
   char			dummy[1];       /* padding for the 88k */
 } AOdata;

/*
**  Data structure for EHT input control parameters
*/
#define	MAXperiodicOrbitals		412  /* Make sure that Erich.h has same value */
#define	SIZEPeriodicTable		103

 typedef struct  {
   double		Kfac;			/* the Hamiltonian K factor for off diag elements   */
   long			numPOrbs;		/* number of entries in  PeriodicOrbitals array		*/
   long			passBackFlags;	/* Bits for specifing things passed back to ui. */
   long			molRangeFlag;	/* For radio buttons using lumoplus/homominus */
   long			lumoplus;		/* the input request for LUMO + inp_mohigh			*/
   long			homominus;		/* the input request for HOMO - inp_molow			*/
   long			mostart;		/* mostart and moend are the actual range ...		*/
   long			moend;			/* ...for printing of mos to MolStruct				*/
   short		EHTopt;			/* the type of EHT hamiltonian we'll solve			*/
   short		LContr;			/* the input contraction length for the STO-NG		*/
   long			CalcDipole;     /* will we calculate the dipole moment */
   unsigned     PropIntFlag;    /* bitflag for controlling property integrals.      */
   char			version[32];	/* the date/time of compilation of this version		*/
   char			datetime[32];	/* the date and time string for the calculation		*/
   char			molStructName[256];		/* the name of the molecule file */
   char			startupVolume[32];		/* the name of the startup Volume */
   char			SystemFolderPath[256];
   char			CACheSystemPath[256];
   char			defParamFileName[32];
   char			paramFileName[256];		/* From settings file. */
   char			realParamFileName[256];	/* From input file list. */
   char			settingFileName[256];	/* Settings file name */
   char			inpbuff[768];			/* holds contents of .inp file						*/
   long			atom_number;	/* Holds atom num used in parameters periodic table. */
   long			accessoryOutput;		/* Holds bits for output and log accessory files. */
   long  		S_Param_index[SIZEPeriodicTable]; /* holds indices for S parameters for per. table    */
   long  		P_Param_index[SIZEPeriodicTable]; /*                   P		*/
   long  		D_Param_index[SIZEPeriodicTable]; /*				   D		*/
   long  		F_Param_index[SIZEPeriodicTable]; /*				   F		*/
   long  		Num_shells[SIZEPeriodicTable];	       /* number of shells each atom in per. table			*/
   long  		Num_basis[SIZEPeriodicTable];		   /* number of basis fxns each atom in per. table		*/
   char         pad88K[4];    /* pad bytes to force double work alligmnent */
   AOdata		PeriodicOrbitals[MAXperiodicOrbitals]; /* array holds the parameters			*/
 } EHTControl;

/*
** Simplified Env structure for unix version -- The Env structure
** for the coprocessor and Mac versions can be found in Env.h
*/

typedef struct Environ {
	long	user[16];	/* uncommitted - for use by applications to pass flags */
} Environ, *EnvPtr;

extern volatile Environ *Env;

/***************************** Prototypes ***************************/
/* used by both the user interface and the application manager      */

#if	defined(__cplusplus)
extern "C" {
#endif

Boolean	CommonReadSettings(EHTControl *Control, char *inputfile, char *fileName);
Boolean HasExtHuckelParams (FILE *controlfile);
int		InitPeriodicIndexTables (EHTControl *Control, char *msg);
void	HandleSettingsMessage(char *errs);
int		ReadOrbitalParams (AOdata Orbitals[], char filename[], char *msg);

#if	defined(__cplusplus)
}
#endif

/************************** End of Prototypes ***********************/

#endif /* __EHTCOMMON__ */
