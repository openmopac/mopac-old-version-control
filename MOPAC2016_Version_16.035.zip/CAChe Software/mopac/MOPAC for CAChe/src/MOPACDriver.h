// Definitions for MOPACdriver

#include <ServerStepQueue.h>
#include "csu.h"

#define MOPAClimit 125000 /* internal MOPAC atom limit */

/* 
 * MOPAC licensed atom limits
 */

#define MOPAC_ATOM_LIMIT_UNDEFINED  -1
#define MOPAC_ATOM_LIMIT_NONE 0
#define MOPAC_ATOM_LIMIT1 300
#define MOPAC_ATOM_LIMIT2 1000


#include "appl_info.h"
#include "MoleculeInfo.h"
#include "Control.h"

#ifdef __cplusplus	/* For type-safe linkage */
extern "C" {		/* Specify "C"-style linkage */
#endif

#if defined(unix)
#define mam_SendStatus uam_SendStatus
#elif defined(_WIN32)
#define mam_SendStatus cem_SendStatus
#endif

#define MOP_YIELD()	/* do nothing */

#define		MOPACerrors			-2800 /* base number for CAChe reporting of MOPAC errors. */

/* MOPAC return codes */
#define MOPAC_SHMEM_ATTACH	MOPACerrors - 1
#define MOPAC_SHMEM_ENV		MOPACerrors - 2
#define MOPAC_ALLOC_OUTFILE	MOPACerrors - 3
#define MOPAC_MAX_CALCOUT	MOPACerrors - 4
#define MOPAC_DATA_DICT		MOPACerrors - 5
#define MOPAC_GET_PRODUCT	MOPACerrors - 6
#define MOPAC_OPEN_INPUT	MOPACerrors - 7
#define MOPAC_APPEND_INPUT	MOPACerrors - 8
#define MOPAC_MAKE_INPUT	MOPACerrors - 9
#define MOPAC_CACHE_PATH	MOPACerrors - 10
#define MOPAC_INIT_CHANNEL	MOPACerrors - 11
#define MOPAC_GET_MEMORY	MOPACerrors - 12
#define MOPAC_GET_LIMITS	MOPACerrors - 13
#define MOPAC_GET_INPUT		MOPACerrors - 14
#define MOPAC_OPEN_TMPFILE	MOPACerrors - 15
#define MOPAC_READ_TMPFILE	MOPACerrors - 16
#define MOPAC_SET_FILEATTR	MOPACerrors - 17
#define MOPAC_EMPTY_TMPFILE	MOPACerrors - 18

#define MOPAC_SETTINGS_ALLOCATE	MOPACerrors - 101	/* can't allocate control array */
#define MOPAC_SETTINGS_EMPTY	MOPACerrors - 102	/* empty settings file*/
#define MOPAC_SETTINGS_MOPACSET	MOPACerrors - 103	/* not a MOPAC settings file */

#define MOPAC_MOLECULE_READMS	MOPACerrors - 201	/* error reading MolStruct */
#define MOPAC_MOLECULE_NOATOMS	MOPACerrors - 202	/* no atoms in molstruct */
#define MOPAC_MOLECULE_DUMMIES	MOPACerrors - 203	/* error determining number of dummy atoms in molstruct */
#define MOPAC_MOLECULE_GRABVAL	MOPACerrors - 204	/* error getting value from molstruct */
#define MOPAC_MOLECULE_ATOMLIM	MOPACerrors - 205	/* error getting atom limits in molstruct */
#define MOPAC_MOLECULE_MOPACLIM	MOPACerrors - 206	/* too many atoms for atomList array */
#define MOPAC_MOLECULE_ASSEMBL	MOPACerrors - 207	/* assemblage file */
#define MOPAC_COMPENG_ERROR		MOPACerrors - 208	/* compute engine encountered error */
#define MOPAC_MOLECULE_TOOMANY	1L					/* too many atoms in molstruct */

#define MOPAC_INPUT_NOERR		0
#define MOPAC_INPUT_ERROR		-1
#define MOPAC_INPUT_CANCEL		1
#define MOPAC_INPUT_NOLABEL		2
#define MOPAC_INPUT_CANTOPEN	3
#define MOPAC_INPUT_NOSPLIT		4
#define MOPAC_INPUT_CHANGEMULT	5

#define MOPAC_TMPFILE_NAME "MOPACoutputFileList.tmp"

#define MOPAC_STATUS_CALC	ssq_CurrentCalcChannel
#define MOPAC_STATUS_OPER	ssq_CurrentOpChannel
#define MOPAC_STATUS_SCROLL	ssq_ScrollChannel

#define		NumberOfGridSteps	200	/* the number of steps MOPAC takes along
										each axis in a grid calculation */

#define		optimizeGeometryMN	1	/* the menu item number on the calculation
										type popup menu in the MOPAC control panel
										for optimizing geometries */
#define		checkInputMN		2	/* the menu item number on the calculation
										type popup menu in the MOPAC control panel
										for checking the input */
#define		scfEnergyMN			3	/* the menu item number on the calculation
										type popup menu in the MOPAC control panel
										for an SCF Energy calculation */
#define 	forceMN				5  	/* the menu item number on the calculation
									  type popup menu in the MOPAC control panel
									  for a vibrational spectra (force) calculation*/
#define 	rigidSearchMN		6  /* the menu item number on the calculation
							  		  type popup menu for a rigid search */
#define 	optSearchMN			7  /* the menu item number on the calculation
							  		  type popup menu for an optimized search */
#define 	transitionStateMN	8  /* the menu item number on the calculation
									  type popup menu in the MOPAC control panel
									  for a transition state (saddle) calculation*/
#define		minimizeGradientMN	9	/* the menu item number on the calculation
									   type popup menu in the MOPAC control panel
									   for a minimize gradient calculation*/
#define 	ircMN				10  /* the menu item number on the calculation
							  			type popup menu for an intrinsic reaction 
										coordinate */
#define 	drcMN				11  /* the menu item number on the calculation
							  			type popup menu for an dynamic reaction 
										coordinate */
#define		EFgeoOptMethodMN	5	/* the menu item number on the Optimize geometry 
										by popup menu in the Details dialog
										for using the eigenvector following method */
#define		EFgradMinMethodMN	3	/* the menu item number on the Minimize gradient 
										by popup menu in the Details dialog
										for using the eigenvector following method */

#define MOPC_FILE 0x4D4F5043L 	/* 'MOPC' settings file type */
#define CACH_FILE 0x43414348L 	/* 'CACH' file creator */

#define STGS_FILE 0x53544753L 	/* 'STGS' settings file type */
#define TEXT_FILE 0x54455854L 	/* 'TEXT' file type */
#define MOLS_FILE 0x4D4F4C53L 	/* 'MOLS' file type */
#define Binary_FILE 0x42494E41L /* 'BINA' file type */

#define MAX_OUT_FILES				57	/* Maximum number of output files
											to be shipped back to Mac */
#ifndef BOOLEAN
#define		BOOLEAN				int
#endif /* BOOLEAN */
#ifndef TRUE
#define		TRUE				1
#endif /* TRUE */
#ifndef FALSE
#define		FALSE				0
#endif /* FALSE */

#define		MOPAC_MAX(i,j)			(((i)>(j)) ? (i) : (j))
#define		MOPAC_MIN(i,j)		(((i)<(j)) ? (i) : (j))

#define		ExitToShell()		exit(0)

#define		TOOCLOSE		0.1			/* two atoms too close in Bohrs */
#define		TOOSMALL		1.0e-10		/* a number that's considered too small */
										/* to invert */
#define		DEGENERATE		1.0e-3		/* two MOs degenerate if this close together */									

/*
 *  Shell types used in the basis set structures below.
 */
 
#define		STO				0
#define		CGTO			1

#define		MOPAC_S 		0
#define		MOPAC_P			1
#define		MOPAC_D			2
#define		MOPAC_F			3

typedef struct {
	char 			fileName[256];
	unsigned long	macFileType;
	unsigned long	macFileCreator;
	unsigned long	CACheFileType;
	unsigned long	CACheFolderType;
	unsigned long	cacheTransferFormat;
} OutputFileAttributes;

typedef struct  {
 	double	distance;
	double	angle;
	double	dihedral;
	int		atomA;
	int		atomB;
	int		atomC;
	short	varyDistance;
	short	varyAngle;
	short	varyDihedral;
 } Zmatrix;

 typedef struct {
	double		value;
 	ObjclsID	objclsID;
	ObjectID	atomList[5];  /* atomList[0] is the number of atoms in this label */
 } LockedLabel;
 
 typedef struct {
 	long			numControls;
 	MoleculeInfo 	moleculeInfo;
	Appl_Info 		appl_info;
	MOPACControl	Control[1];
 } StepSettings;

#define CALLOC(n, x)	((x *) calloc(n, sizeof(x))
#define NIL(type) 		((type *)NULL)

#if !defined(_WIN32)
#define max(a,b) ((a)>(b)?(a):(b))
#define min(a,b) ((a)<(b)?(a):(b))
#endif

#define	SPLASH_DELAY (2 * 60L) 		/* minimum splash-panel display time */

/* CAChe file type definitions */
enum MOPAC_file_type {
	MOPAC_PRODUCT_FILE = ssq_file_custom,
	MOPAC_INPUT_FILE,
	MOPAC_OUTPUT_FILE,
	MOPAC_RESTART_FILE,
	MOPAC_DENSITY_FILE,
	MOPAC_GRAPHICS_FILE,
	MOPAC_ARCHIVE_FILE,
	MOPAC_PARAM_FILE,
	MOPAC_SETUP_FILE,
	MOPAC_DUMMY_FILE = ssq_file_dummy
};

extern char MOPACOutputFile[32];
extern char MOPACGraphicsFile[32];
extern char MOPACoutputFileList[32];
extern char mam_OrigInputFile[ssq_FileNameSize];
extern ObjectID calchist_objectnum;
extern FILE *mopacOutputFileList;

#include "MOPACLib_Protos.h" /* Stuff shared with other applications */
/***************************** Prototypes ***************************/
/* used by both the user interface and the application manager      */

int  	AddBondOrder(MolStruct *msPtr, DoubleH bondOrders, long nAtoms,
					  long atomLocation[], NameNID source);
int 	addCalcHistory(MolStruct *molStruct, Appl_Info *applInfo,
			ObjectID *objectnum, char *keyWords, short outputCalcNumber);
void 	addToOutputFileList(char *fileName, unsigned long macFileType,
			unsigned long macFileCreator, unsigned long CACheFileType,
			unsigned long CACheFolderType, 
			unsigned long cacheTransferFormat);
Boolean	advanceToNextKeywords(FILE *input, char *keywords, 
				char *formula, int maxLength, int numAmpersand,
				int *num_hydrogens, int *num_heavy);
void	alert_user(char *s);
int 	appendToFile(char *inputFile, char *outputFile, short outputCalcNumber);
void 	atomSymbol(long i,char aSymbol[2]);
int		bondOrbitals(short btype);
void buildFormula(int numberEach[], char *formula, int maxLength, 
				int TotalNumberElements);
int 	buildKeywords(char keywords[], MOPACControl *controlPanel, 
						MoleculeInfo *moleculeInfo);
int		cancelOrProceedDialog(char *string, char *OKText, char *cancelText);
int		cartesianToInternal(double xyz[][3], long numat, Zmatrix geo[],
					long numberBonds, long (*bondList)[2],
					long atomLocation[], long numDummyAtoms);
void	CheckControlPanel(MOPACControl *controlPanel);
int		confCheck(short n_lobes, short n_orbitals, long n_bonds, 
					short hi_btype, short conf);
void 	deleteInvalidMolstructObjs(MolStruct *molStruct);
int		dependentHeader(MolStruct *ms, ObjclsID objclsID, PropID propID,
			long v_bytes, long vec_len, long v_type, long unitN, 
			long num_IDs, long *ID_list);
int		determineAtomicNumber(char *aString);
double 	dihedral(double xyz[][3],int i,int j,int k,int l);
int		findLastBlank(char string[],int length);
void	GetDefaultParams (MOPACControl *Control); 
void	getLockedAtoms(MolStruct *molStruct, long lockedAtoms[], 
		long NAtom);
long	getKeywords (char *filename, char *keywords, double coord_shift[3], 
			Boolean *typeRXNCOORD, int *mol_charge, short outputCalcNumber);
int 	getKeywordsFromInput(FILE *input, char *keywords, int *numAmpersand);
void	getLockedLabels(MolStruct *molStruct, LockedLabel lockedLabels[]);
long 	getMolecularFormula(MolStruct *molStruct, char *formula, int maxLength);
long 	getMolecule(MolStruct *molStruct, MoleculeInfo *moleculeInfo);
Boolean GetMOPACParams (FILE *controlfile, MOPACControl *Control);
long	getmopacsettings(FILE *controlfile, MOPACControl **Control,
		long *numControls, long currentControl);
long 	getOutputMolecule(MolStruct *molStruct, MoleculeInfo *moleculeInfo);
long 	getProductMolecule(MolStruct *molStruct, MolStruct *productMolStruct,
						   MOPACControl *controlPanel);
void 	getProductMoleculeName(MOPACControl *controlPanel, char *name);
int		getSearchLabels(MolStruct *molStruct,
		SearchLabel searchLabels[], int max_num_labels);
Boolean hasProductMolecule(MOPACControl *controlPanel);
void	inform_user(char *s);
int		initOutputFileList();
int 	inputHasParams(Boolean *hasParams, char *fname);
int 	inputHasSetup(Boolean *hasSetup, char *setupfname);
void	instruct_user(char *s);
void 	invalidateProductMolecule(MOPACControl *controlPanel);
int 	isInputRestart(Boolean *isRestart);
int 	makeMOPACInput(MolStruct *molStruct, MolStruct *productMolStruct, 
				   	   MOPACControl *controlPanel, MoleculeInfo *moleculeInfo,
					   short inputCalcNumber, 
					   Boolean appendedToMaintainOrientation);
int		MOPAC_check_conf(MolStruct *msPtr);
void 	MOPACaddBasisSet (MolStruct *msPtr, double *exponents,
						long nAtoms, long orbitalRange[], long nuclearNumber[],
						long atomLocation[]);
int  MOPACupdateMolStruct (
	MolStruct *molStruct, 
	MOPACControl *Control, 
	Appl_Info *applInfo, 
	long locationWithoutDummies[],
	double coord_shift[], 
	Boolean ProcessMOPACoutput, 
	Boolean MapFile, 
	Boolean typeRXNCOORD, 
	Boolean typeGRID, 
	char *keyWords, 
	int mol_charge, 
	short outputCalcNumber
);
void 	mosToTransform(Boolean UHF, double degeneracy_criterion,
				double MOocc[], double eigenValues[], 
				int saveHOMO, int saveLUMO, int nOrbitals,
				int *startalpha, int *startbeta, int *vendalpha, int *vendbeta);
Boolean OKtoProcessOutput(char *buf, Boolean *timedOut,
		StepSettings stepSettings, short useControlNumber);
void 	processOutput(MOPACControl ControlPanel,
					Appl_Info applInfo, MoleculeInfo *moleculeInfo, 
					short outputCalcNumber, Boolean timedOut, 
					Boolean ProcessMOPACoutput, Boolean MOPACRunning);
int 	PutMOPACControlFile(FILE *file, MOPACControl *controlPanel);
int 	putmopacsettings(FILE *file, MOPACControl controlPanel[], 
		long initialNum, long finalNum);
CelErr	SetMOPACStdUnits(); /* Data dictionary must be loaded first */
void 	setOutputFileOwner(char	*fileName, long fileType, long fileCreator);
int 	startMovieHeader(MolStruct *ms, char *suffix, long fileType);
int		temperatureParens(char string[], int length, char newstring[]);
int		transferOutput(char *inputFile, char *outputFile);
int		warnAboutLockedLabel(long *atomID, char (*atsymbol)[2], 
						LockedLabel lockedLabels[], int m);
long 	whichAtomIndex(long atomNumber, long nAtoms, long atomLocation[]);
int 	writeEnergyTable(MolStruct *ms, MoleculeInfo *moleculeInfo,
					double coord_shift[], short outputCalcNumber, 
					char *keyWords, Boolean ProcessMOPACoutput);
int 	writeReactionCoord(MolStruct *molStruct, MoleculeInfo *moleculeInfo,
					int numSearchLabels, double coord_shift[], 
					short outputCalcNumber, Boolean ProcessMOPACoutput);
int 	writeDRC(MolStruct *molStruct, MoleculeInfo *moleculeInfo, 
					double coord_shift[], short drcIrcMode, 
					short outputCalcNumber, Boolean ProcessMOPACoutput);
int 	writeIRC(MolStruct *molStruct, MoleculeInfo *moleculeInfo, 
					double coord_shift[], short ircMode, 
					short outputCalcNumber, Boolean ProcessMOPACoutput);
int 	writeVibrationalSpectra(
	MolStruct *molStruct, 
	long locationWithoutDummies[]
);
void	xyzgeo(double xyz[][3], int numat, Zmatrix geo[]);

int		cem_SendStatus(const long channel, const char *const message);

#ifndef unix
	int getLicensedAtomLimit(int * mopacLicenseLimit);
#endif


#ifdef __cplusplus	/* For type-safe linkage */
}					/* Specify "C"-style linkage */
#endif
/************************** End of Prototypes ***********************/

