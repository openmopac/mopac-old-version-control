/* Definitions for ZINDO user interface and application manager */

#include <ServerStepQueue.h>
#include <csu.h>

#ifndef TRUE
#define TRUE  1
#endif
#ifndef FALSE
#define FALSE 0
#endif

#ifndef BOOLEN
#define BOOLEAN int
#endif

#ifdef __cplusplus	/* For type-safe linkage */
extern "C" {		/* Specify "C"-style linkage */
#endif

#if defined(unix)
#define mam_SendStatus uam_SendStatus
#elif defined(_WIN32)
#define mam_SendStatus cem_SendStatus
#endif

#define		RadianToDegree			57.2957795131

#define		ZINDOerrors			-3000 /* base number for CAChe reporting of ZINDO errors. */

/* ZINDO return codes */
#define ZINDO_SHMEM_ATTACH	ZINDOerrors - 1
#define ZINDO_SHMEM_ENV		ZINDOerrors - 2
#define ZINDO_ALLOC_OUTFILE	ZINDOerrors - 3
#define ZINDO_MAX_CALCOUT	ZINDOerrors - 4
#define ZINDO_DATA_DICT		ZINDOerrors - 5
#define ZINDO_GET_PRODUCT	ZINDOerrors - 6
#define ZINDO_OPEN_INPUT	ZINDOerrors - 7
#define ZINDO_APPEND_INPUT	ZINDOerrors - 8
#define ZINDO_MAKE_INPUT	ZINDOerrors - 9
#define ZINDO_CACHE_PATH	ZINDOerrors - 10
#define ZINDO_INIT_CHANNEL	ZINDOerrors - 11
#define ZINDO_GET_MEMORY	ZINDOerrors - 12
#define ZINDO_GET_LIMITS	ZINDOerrors - 13
#define ZINDO_GET_INPUT		ZINDOerrors - 14
#define ZINDO_GET_TITLE		ZINDOerrors - 15
#define ZINDO_OPEN_TMPFILE	ZINDOerrors - 16
#define ZINDO_READ_TMPFILE	ZINDOerrors - 17
#define ZINDO_SET_FILEATTR	ZINDOerrors - 18
#define ZINDO_EMPTY_TMPFILE	ZINDOerrors - 19

#define ZINDO_SETTINGS_ZINDOSET	ZINDOerrors - 101	/* not a ZINDO settings file */
#define ZINDO_SETTINGS_OPTION	ZINDOerrors - 102	/* unrecognized option */

#define ZINDO_MOLECULE_READMS	ZINDOerrors - 201	/* unable to read molstruct */
#define ZINDO_MOLECULE_NOATOMS	ZINDOerrors - 202	/* no atoms in molstruct */
#define ZINDO_MOLECULE_ATOMLIM	ZINDOerrors - 203	/* error getting atom limits in molstruct */
#define ZINDO_MOLECULE_TOOMANY	ZINDOerrors - 204	/* too many atoms in molstruct */
#define ZINDO_MOLECULE_ASSEMBL	ZINDOerrors - 205	/* assemblage file */
#define ZINDO_COMPENG_ERROR		ZINDOerrors - 206	/* Compute engine error */

#define ZINDO_TMPFILE_NAME "ZINDOoutputFileList.tmp"

#define ZINDO_STATUS_CALC	ssq_CurrentCalcChannel
#define ZINDO_STATUS_OPER	ssq_CurrentOpChannel
#define ZINDO_STATUS_SCROLL	ssq_ScrollChannel

#define	ZINDOlimit		   200 /* maximum number of atoms*/
#define	ZINDOciLimit	   700 /* maximum number of CI configurations */
							   /* 
								* Set limits in the UI getAtomLimits to
								* correspond to ZINDOlimit & ZINDOciLimit
								*/
#define ZIND_FILE 0x5A494E44L 	/* 'ZIND' settings file type */
#define CACH_FILE 0x43414348L 	/* 'CACH' file creator */

#define TEXT_FILE 0x54455854L 	/* 'TEXT' file type */
#define MOLS_FILE 0x4D4F4C53L 	/* 'MOLS' file type */
#define Binary_FILE 0x42494E41L /* 'BINA' file type */

#define Energy_kcalPerMole  51

#define RHFTYPE						1
#define UHFTYPE						2
#define ROHFTYPE					3

#define SINGLET						1
#define DOUBLET						2
#define TRIPLET						3
#define QUARTET						4
#define QUINTET						5
#define SEXTET						6

/* Parameter types */
enum paramType {
	PARAMTYPE_IEH=1,
	PARAMTYPE_CNDO1,
	PARAMTYPE_CNDO2,
	PARAMTYPE_INDO1,
	PARAMTYPE_INDO2,
	PARAMTYPE_DUMMY
};

/* Calculation types */
enum calcType {
	CALCTYPE_ENERGY=1,
	CALCTYPE_OPT,
	CALCTYPE_TS,
	CALCTYPE_CI,
	CALCTYPE_DUMMY
};

/* Geometry search types */
enum searchType {
	SEARCHTYPE_NR=1,
	SEARCHTYPE_AH,
	SEARCHTYPE_GN,
	SEARCHTYPE_DUMMY
};

/* Symmetry types */
enum symmetryType {
	SPACESYMMETRY_NONE=1,
	SPACESYMMETRY_C2V,
	SPACESYMMETRY_C2,
	SPACESYMMETRY_CI,
	SPACESYMMETRY_CH,
	SPACESYMMETRY_C2H,
	SPACESYMMETRY_D2,
	SPACESYMMETRY_D2H,
	SPACESYMMETRY_DUMMY
};

/* SCF convergence criterion */
enum scfConvergence {
	SCFCONVERGENCE_001=1,
	SCFCONVERGENCE_0001,
	SCFCONVERGENCE_00001,
	SCFCONVERGENCE_000001,
	SCFCONVERGENCE_0000001,
	SCFCONVERGENCE_00000001,
	SCFCONVERGENCE_000000001,
	SCFCONVERGENCE_DUMMY
};

/* Metal configuration mixing */
enum configMixing {
	CONFIGMIX_VB=1,
	CONFIGMIX_N1,
	CONFIGMIX_N2,
	CONFIGMIX_N,
	CONFIGMIX_DUMMY
};

/* Print amount */
enum printAmount {
	PRINT_MIN=-1,
	PRINT_NORM,
	PRINT_LRGE,
	PRINT_DUMMY
};

/* Basis types */
enum basisType {
	BASISTYPE_S=1,
	BASISTYPE_P,
	BASISTYPE_D,
	BASISTYPE_DNMINUS1,
	BASISTYPE_F,
	BASISTYPE_DUMMY
};

/* Radius selection */
#define		RADIUS_TOTAL 1
#define		RADIUS_EXTEND 2

#define		ZINDO_MAX(i,j)		((i>j) ? (i) : (j))
#define		ZINDO_MIN(i,j)		((i<j) ? (i) : (j))
#define		ExitToShell()		exit(0)

#define		TOOCLOSE		0.1			/* two atoms too close in Bohrs */
#define		TOOSMALL		1.0e-10		/* a number that's considered too small */
										/* to invert */
#define		DEGENERATE		1.0e-3		/* two MOs degenerate if this close together */									

/*
 *  Shell types used in the basis set structures below.
 */
 
#define		STO				0
#define		CGTO			1

#define		ZINDO_S 		0
#define		ZINDO_P			1
#define		ZINDO_D			2
#define		ZINDO_F			3

typedef struct {
	char 			fileName[256];
	unsigned long	macFileType;
	unsigned long	macFileCreator;
	unsigned long	CACheFileType;
	unsigned long	CACheFolderType;
	unsigned long	cacheTransferFormat;
} OutputFileAttributes;

/*
 *  Data structure for ZINDO input control parameters
 */

#if defined(powerc) || defined (__powerc)
#pragma options align=mac68k
#endif

 typedef struct  {
   double		dummy;				/* insure double word alignment */
   char			version[32];		/* the date/time of compilation of this version		*/
   char			datetime[32];		/* the date and time string for the calculation		*/
   char			servername[32];		/* the server that runs the calculation */
   char			molStructName[256]; /* the name of the molecule file */
   char			title[256];
   short		parameters;
   short		multiplicity;
   short		calculate;
   short		geometrySearch;
   short		geometryConvergence;
   short		spaceSymmetry;
   short		numberOfElectrons;
   short		netCharge;
   short		SCFtype;
   short		maxSCFiterations;
   Boolean		controlRestart;
   Boolean		detailsSCRxnF;
   Boolean		detailsMap;
   Boolean		saveBasis;
   Boolean		saveVectors;
   Boolean		saveGraphics;
   Boolean		saveInput;
   Boolean		saveOutput;
   Boolean		saveCon;
   Boolean		saveOpt;
   Boolean		saveSummary;
   Boolean		saveLog;
   char			extraKeyWords[256];
   short		scfConvergence;
   short		maxGeometrySteps;
   long 		CIlevel;
   long			printAmount;
   short		cavityRadiusMeaning;
   double 		cavityRadiusExtend;
   double 		cavityRadiusTotal;
   double		dielectric;
   double		refractiveIndex;
   double		spectraCutoff;
   long 		atomLocation[ZINDOlimit];
   short		metalConfigMixing;
 } ZINDOControl;

 typedef struct {
 	Boolean			ZINDOinputFile;
	ZINDOControl	Control;
 } StepSettings;
#if defined(powerc) || defined (__powerc)
#pragma options align=reset
#endif

#define MALLOC(x)   	((x *) malloc(sizeof(x)))
#define CALLOC(n, x)	((x *) calloc(n, sizeof(x))
#define NIL(type) 		((type *)NULL)

#ifndef max
#define max(a,b) ((a)>(b)?(a):(b))
#endif

#ifndef min
#define min(a,b) ((a)<(b)?(a):(b))
#endif

/* CAChe file type definitions */
enum ZINDO_file_type {
	ZINDO_INPUT_FILE = ssq_file_custom,
	ZINDO_OUTPUT_FILE,
	ZINDO_VECTOR_FILE,
	ZINDO_OPTIMPATH_FILE,
	ZINDO_GRAPHICS_FILE,
	ZINDO_RESTGEO_FILE,
	ZINDO_SUMMARY_FILE,
	ZINDO_DUMMY_FILE = ssq_file_dummy
};

extern char ZINDOOutputFile[32];
extern char ZINDOGraphicsFile[32];
extern char ZINDOLogFile[32];
extern char ZINDOSummaryFile[32];
extern char ZINDOBasisFile[32];
extern char mam_OrigInputFile[ssq_FileNameSize];
extern long AtomLimit;
extern long CiLimit;

/***************************** Prototypes ***************************/
/* used by both the user interface and the application manager      */
CelErr	SetZINDOStdUnits(); /* Data dictionary must be loaded first */
int  	AddBondOrder (MolStruct *msPtr, DoubleH bondOrders, long nAtoms,
					  long atomLocation[], short source);
void 	addToOutputFileList(char *fileName, 
			unsigned long macFileType,
			unsigned long macFileCreator,
			unsigned long CACheFileType,
			unsigned long CACheFolderType,
			unsigned long cacheTransferFormat);
void	alert_user(char *s);
void	alert_user_cilevel(char *s);
int		appendToFile(char *inputFile, char *outputFile);
void 	append_ZINDO_Status(char *s);
void 	atomSymbol(long i,char aSymbol[2]);
int 	CheckControlPanel(ZINDOControl *controlPanel);
int		countAtomsInInput(FILE *stream, int *num_atoms, 
			int *num_bfn, int *num_ci);
int		dependentHeader(MolStruct *ms, ObjclsID objclsID, PropID propID,
			long v_bytes, long vec_len, long v_type, long unitN, 
			long num_IDs, long *ID_list);
void	enterBusyState();
void	leaveBusyState();
int 	getAtomLimits(long *atomLimit, long *ciLimit);
short	getCalculationType();
int 	getMolecularCharge(int *mol_charge);
long 	getMolecule(MolStruct *molStruct, ZINDOControl *controlPanel);
long	getNumberLockedAtoms(MolStruct *molStruct, int NAtom);
int		getNumberLockedLabels(MolStruct *molStruct);
void 	GetZINDODefaults (ZINDOControl *Control);
long	GetZINDOParams (ZINDOControl *Control, FILE *controlfile);
void	inform_user(char *s);
int		initOutputFileList(ZINDOControl *Control);
void	instruct_user(char *s);
Boolean	isFileZINDOinput(char *inputFile, char *titleMol);
Boolean isZINDOInputRestart(char *inputFile);
void	makeCompoundName(char *base, char *suffix, char *compound);
int 	makeZINDOInput(MolStruct *molStruct, ZINDOControl *controlPanel, double *new_cutoff);
int 	makeZINDOInput1(MolStruct *molStruct, ZINDOControl *controlPanel, double *new_cutoff);
short 	moleculeNetCharge(MolStruct *molStruct);
int 	PutZINDOParams(ZINDOControl *controlPanel, FILE *file);
void	replaceBlanks(char *s, char c);
void 	setOutputFileOwner(char *fileName, long fileType, long fileCreator);
int 	startMovieHeader(MolStruct *ms, char *suffix, long fileType);
Boolean titleFromZINDOinput(char *inputFile, char *title);
int 	writeOptimizationPath(MolStruct *molStruct, long atomLocation[],
                          char *molStructName, Boolean ZINDOinputFile);
int		writeUVSpectra(MolStruct *molStruct, double energy_cutoff);
void 	ZINDOaddBasisSet(MolStruct *msPtr, double *exponents,
					   long nAtoms, long atomLocation[],
					   long valenceType[], long NPQ[], short source);
int  	ZINDOupdateMolStruct (MolStruct *molStruct, ZINDOControl *Control);

int		cem_SendStatus(const long channel, const char *const message);

#ifdef __cplusplus	/* For type-safe linkage */
}					/* Specify "C"-style linkage */
#endif
