#ifndef _CACHE_Version_
#define _CACHE_Version_

#ifdef APSTUDIO_INVOKED

#define CACHE_VERSION    "CACHE_VERSION"
#define CACHE_COPYRIGHT  "CACHE_COPYRIGHT"
#define CACHE_COMPANY    "CACHE_COMPANY"

#else

#if !defined(CACHE_VERS)
#define CACHE_VERS 11-12-2006
#endif

#if !defined(CACHE_COMP)
#define CACHE_COMP Fujitsu Limited
#endif

#if !defined(CACHE_YEAR)
#define CACHE_YEAR 2004
#endif

#define MAKE_STRING(v) #v
#define EVAL_MACRO(a) MAKE_STRING(a)

#define CACHE_VERSION    EVAL_MACRO(CACHE_VERS)
#define CACHE_COPYRIGHT  "� 2000-" EVAL_MACRO(CACHE_YEAR) " " EVAL_MACRO(CACHE_COMP) ", " \
                         "� 1989-2000 Oxford Molecular Ltd." 
#define CACHE_COMPANY    EVAL_MACRO(CACHE_COMP)

#endif

#endif
