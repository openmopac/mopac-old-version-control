#include "compat.h"
#include "ZINDODriver.h"

short moleculeNetCharge(MolStruct *molStruct)
{
	short 	 moleculeCharge;
	long	 NAtom;
	ObjclsID offset;
	long 	 i, rtn_code;
	short   *atchg;
	char	 errs[256];

   	if (csu_ExistsObjclsID (molStruct, AtomID, &offset))
     	NAtom = ((GetPtr(molStruct->objclsH) + offset)->num_objs);
   	else {
     	return (0);
   	}

	if ((rtn_code = csu_GrabVal (molStruct, AtomID, ChrgID, (char **)&atchg)) < 0)
     	return (0);
  	else {
     	for (i=0, moleculeCharge=0; i < NAtom; i++)
       			moleculeCharge += atchg[i];
       
     	if ((rtn_code = csu_ReleaseVal (molStruct, AtomID, ChrgID)) < 0) {
       		sprintf (errs," moleculeNetCharge : csu_ReleaseVal ChrgID, errno %d", rtn_code);
	   		alert_user(errs);
     	}
 	}

	return (moleculeCharge);
}
