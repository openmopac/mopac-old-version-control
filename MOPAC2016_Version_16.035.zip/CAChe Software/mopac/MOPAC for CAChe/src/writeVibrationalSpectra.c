#if defined(_WIN32)
#include <windows.h>
#endif

#include <compat.h>
#include <math.h>
#include <csu.h>
#include <CACheFileLib.h>
#include "MOPACDriver.h"

typedef struct  {
	short	pair[4][2];
	float	perCent[4];
} AtomPairs;

int writeVibrationalSpectra
(
	MolStruct *molStruct, 
	long locationWithoutDummies[]
)
{
	FILE		*MOPACoutput = NULL, *ForceData;
	ObjclsID	offset;
	int		i, ii, NAtoms, NAtoms_in_output, nVibrations, ndata;
	CelErr		err;
	char		string[256], errs[256], dummy[256],
				functionName[] = "writeVibrationalSpectra";
	double		*vibration = NULL, *dipole = NULL, temp,
				cmToKcal, cmToKcalOffset, coord[3],
				temperature, heat_of_formation, enthalpy, 
				heat_capacity, entropy, free_energy, *mode = NULL,
				*modeWithDummies = NULL, calToKcal, calToKcalOffset;
	AtomPairs	*atomPairs = NULL;
	PropID		energyID, transitionDipoleID, transitionMomentID,
				normalModeID, temperatureID, enthalpyID,
				heat_of_formationID, heat_capacityID,
				entropyID, free_energyID;
	NameNID		energy_auID, dipole_auID, cmM1ID, debyeID, noUnit,
				kelvinID, cal_kelvin_molID, cal_molID, kcal_molID;
	ObjclsID	vibrational_levelID, thermodynamic_infoID;

    int   j, k, kk, vibID, atomA, atomB, vibIndex;
    float freqValue, transDipole;
    float percent;

    int getNumVibrations(FILE*);
    int getVibMode(FILE*, int*, float*, float*);
    int getAtomContrib(FILE*, int*, int*, int*, float*);
	MOP_YIELD();
	/*
     *  Find out how many atoms there are.
     */
	if (csu_ExistsObjclsID (molStruct, AtomID, &offset))
		NAtoms = (long) ((GetPtr(molStruct->objclsH) + offset)->num_objs);
	else {
		sprintf(errs, "%s: Unable to locate AtomID index.", functionName);
		alert_user(errs);
		return (MOPACerrors - 2);
	}
	/* Get Property ID's */
	if ((err = csu_GetPropertyID("transitionDipole", &transitionDipoleID)) < 0) {
		sprintf (errs,"%s: csu_GetPropertyID transitionDipole err code %d\n",
            functionName, err);
		alert_user(errs);
		return (MOPACerrors - 1);
	}

	if ((err = csu_GetPropertyID("transitionMoment", &transitionMomentID)) < 0) {
		sprintf (errs,"%s: csu_GetPropertyID transitionMoment err code %d\n",
            functionName, err);
		alert_user(errs);
		return (MOPACerrors - 1);
	}
	if ((err = csu_GetPropertyID("Energy", &energyID)) < 0) {
		sprintf (errs,"%s: csu_GetPropertyID Energy err code %d\n",
            functionName, err);
		alert_user(errs);
		return (MOPACerrors - 1);
	}
	if ((err = csu_GetPropertyID("normalMode", &normalModeID)) < 0) {
		sprintf (errs,"%s: csu_GetPropertyID normalMode err code %d\n",
            functionName, err);
		alert_user(errs);
		return (MOPACerrors - 1);
	}
	if ((err = csu_GetPropertyID("temperature", &temperatureID)) < 0) {
		sprintf (errs,"%s: csu_GetPropertyID temperature err code %d\n",
            functionName, err);
		alert_user(errs);
		return (MOPACerrors - 1);
	}
	if ((err = csu_GetPropertyID("enthalpy", &enthalpyID)) < 0) {
		sprintf (errs,"%s: csu_GetPropertyID enthalpy err code %d\n",
            functionName, err);
		alert_user(errs);
		return (MOPACerrors - 1);
	}
	if ((err = csu_GetPropertyID("heat_of_formation", 
										&heat_of_formationID)) < 0) {
		sprintf (errs,"%s: csu_GetPropertyID normalMode err code %d\n",
            functionName, err);
		alert_user(errs);
		return (MOPACerrors - 1);
	}
	if ((err = csu_GetPropertyID("heat_capacity", &heat_capacityID)) < 0) {
		sprintf (errs,"%s: csu_GetPropertyID heat_capacity err code %d\n",
            functionName, err);
		alert_user(errs);
		return (MOPACerrors - 1);
	}
	if ((err = csu_GetPropertyID("entropy", &entropyID)) < 0) {
		sprintf (errs,"%s: csu_GetPropertyID entropy err code %d\n",
            functionName, err);
		alert_user(errs);
		return (MOPACerrors - 1);
	}
	if ((err = csu_GetPropertyID("free_energy", &free_energyID)) < 0) {
		sprintf (errs,"%s: csu_GetPropertyID free_energy err code %d\n",
            functionName, err);
		alert_user(errs);
		return (MOPACerrors - 1);
	}
	/* Get unit name indices */
	if ((err = csu_GetNameIndex("noUnit", &noUnit)) < 0) {
		sprintf (errs,"%s: csu_GetNameIndex noUnit err code %d\n",
				functionName, err);
		alert_user(errs);
		return (MOPACerrors - 1);
	}
	if ((err = csu_GetNameIndex("cm-1", &cmM1ID)) < 0) {
		sprintf (errs,"%s: csu_GetNameIndex cm-1 err code %d\n",
				functionName, err);
		alert_user(errs);
		return (MOPACerrors - 1);
	}
	if ((err = csu_GetNameIndex("dipole_au", &dipole_auID)) < 0) {
		sprintf (errs,"%s: csu_GetNameIndex dipole_au err code %d\n",
				functionName, err);
		alert_user(errs);
		return (MOPACerrors - 1);
	}
	if ((err = csu_GetNameIndex("debye", &debyeID)) < 0) {
		sprintf (errs,"%s: csu_GetNameIndex debye err code %d\n",
				functionName, err);
		alert_user(errs);
		return (MOPACerrors - 1);
	}
	if ((err = csu_GetNameIndex("energy_au",&energy_auID)) < 0) {
		sprintf (errs,"%s: csu_GetNameIndex energy_au err code %d\n",
				functionName, err);
		alert_user(errs);
		return (MOPACerrors - 1);
	}
	if ((err = csu_GetNameIndex("Kelvin", &kelvinID)) < 0) {
		sprintf (errs,"%s: csu_GetNameIndex Kelvin err code %d\n",
				functionName, err);
		alert_user(errs);
		return (MOPACerrors - 1);
	}
	if ((err = csu_GetNameIndex("cal/mol/Kelvin", &cal_kelvin_molID)) < 0) {
		sprintf (errs,"%s: csu_GetNameIndex kcal/mol/Kelvin err code %d\n",
				functionName, err);
		alert_user(errs);
		return (MOPACerrors - 1);
	}
	if ((err = csu_GetNameIndex("Kcal/mol", &kcal_molID)) < 0) {
		sprintf (errs,"%s: csu_GetNameIndex Kcal/mol err code %d\n",
				functionName, err);
		alert_user(errs);
		return (MOPACerrors - 1);
	}
	if ((err = csu_GetNameIndex("cal/mol", &cal_molID)) < 0) {
		sprintf (errs,"%s: csu_GetNameIndex cal/mol err code %d\n",
				functionName, err);
		alert_user(errs);
		return (MOPACerrors - 1);
	}
	/* Get object class indices */
	if ((err = csu_GetObjectClassID("vibrational_level",&vibrational_levelID)) < 0) {
		sprintf (errs,"%s: csu_GetObjectClassID vibrational_level err code %d\n",
				functionName, err);
		alert_user(errs);
		return (MOPACerrors - 1);
	}
	if ((err = csu_GetObjectClassID("thermodynamic_info",
								  &thermodynamic_infoID)) < 0) {
		sprintf (errs,"%s: csu_GetObjectClassID thermodynamic_info err code %d\n",
				functionName, err);
		alert_user(errs);
		return (MOPACerrors - 1);
	}
	
	/* Get conversion factors */
	if (csu_GetUnitConv((short) cmM1ID, (short) kcal_molID, 
				&cmToKcal, &cmToKcalOffset) != 0) {
	}

	if (csu_GetUnitConv((short) cal_molID, (short) kcal_molID, 
				&calToKcal, &calToKcalOffset) != 0) {
	}

	/* Starting analysis of MOPAC output file */

	if ((MOPACoutput = fopen(MOPACOutputFile, "r")) == NULL) {
		sprintf(errs, "%s: Unable to open MOPAC Output.", functionName);
		alert_user(errs);
		return (MOPACerrors - 3);
	}

	/* 
	 * Update the molecule coordinates to agree with the ones used for
	 * normal modes.
	 */
	while (TRUE) {
		if (cfl_fgets(string, sizeof(string), MOPACoutput) == 0)
			goto endOfFile;
		if (strncmp(string,"          ORIENTATION OF MOLECULE IN FORCE CALCULATION", 54) == 0) {
			/* Skip 3 lines */
			if (cfl_fgets(string, sizeof(string), MOPACoutput) == 0)
				goto endOfFile;
			if (cfl_fgets(string, sizeof(string), MOPACoutput) == 0)
				goto endOfFile;
			if (cfl_fgets(string, sizeof(string), MOPACoutput) == 0)
				goto endOfFile;
			break;
		}
	}

	i = 0;
	while(TRUE) {
		if (cfl_fgets(string, sizeof(string), MOPACoutput) == 0)
				goto endOfFile;
        if (strlen(string) <= 20) 
			break;
		
		sscanf(&string[20], "%lf %lf %lf", &coord[0], &coord[1], &coord[2]);
		if ((err = csu_AddObjVal(molStruct, AtomID, XYZID, (locationWithoutDummies[i]), MOPAC_SRC,
                                         CSU_FLOATING, 3, Angstrom_U, 6, (char *) coord, 1, BY_INDEX)) < 0)
		{
			sprintf (errs,"%s: csu_AddObjVal XYZ err code %d\n", functionName, err);
			alert_user(errs);
			goto errorReturn;
		}
		i++;
		NAtoms_in_output=i;
	}
		
    /* Determine the number of points calculated */

    nVibrations = 0;

    if ((ForceData = fopen("ForceData", "r")) == NULL)
    {
        sprintf(errs, "%s: Unable to open ForceData.", functionName);
        alert_user(errs);
        return (MOPACerrors - 3);
    }

    nVibrations = getNumVibrations(ForceData);

   /* If the vibrational calculation wasn't carried out, return */

   if (nVibrations <= 0 || nVibrations > 60000)
   {
      sprintf(errs, "%s:  error reading Number of Vibrations.", functionName);
      alert_user(errs);
      goto errorReturn;
   }

   MOP_YIELD();

	/* acquire spectral frequencies */
	vibration = (double *) mlalloc((nVibrations+8) * sizeof(double));
	if (vibration == NULL) {
		sprintf (errs,"%s: vibration memory request %ld too large\n",
			functionName, (nVibrations+8) * sizeof(double));
		alert_user(errs);
		goto errorReturn;
	}
	for (i = 0; i < nVibrations + 8; i++) 
		vibration[i] = 0.0;
	
	atomPairs = (AtomPairs *) mlalloc((nVibrations+8) * sizeof(AtomPairs));
	if (atomPairs == NULL) {
		sprintf (errs,"%s: atomPairs memory request %ld too large\n",
				 functionName, (nVibrations+8) * sizeof(AtomPairs));
		alert_user(errs);
		goto errorReturn;
	}
	for (i = 0; i < nVibrations + 8; i++) 
		atomPairs[i].pair[0][0] = 0;

	mode = (double *) mlalloc((NAtoms_in_output*3*8) * sizeof(double));
	modeWithDummies = (double *) mlalloc((NAtoms*3) * sizeof(double));
	if (mode == NULL || modeWithDummies == NULL) {
		sprintf (errs,"%s: unable to allocate memory for normal modes.",
			functionName);
		alert_user(errs);
		goto errorReturn;
	}

	dipole = (double *) mlalloc((nVibrations+8) * sizeof(double));
	for (i = 0; i < nVibrations + 8; i++) 
		dipole[i] = 0.0;

	/* find a block of normal coordinates */
	fseek(MOPACoutput,0,0);
	while (TRUE) {
		if (cfl_fgets(string, sizeof(string), MOPACoutput) == 0) 
			goto endOfFile;
	//	if (strncmp(string,"           NORMAL COORDINATE ANALYSIS", 37) == 0)
		if (strncmp(string,"           MASS-WEIGHTED COORDINATE ANALYSIS", 44) == 0)
		{
			/* Skip 2 lines */
			if (cfl_fgets(string, sizeof(string), MOPACoutput) == 0) goto endOfFile;
			if (cfl_fgets(string, sizeof(string), MOPACoutput) == 0) goto endOfFile;
			break;
		}
	}

    // Delete existing object classes.

    if ( csu_ExistsObjclsID( molStruct, vibrational_levelID, &offset ) )
        ed_DeleteObjcls( molStruct, vibrational_levelID, 2 );

    for ( i = 0; i < nVibrations; i += 8 )
    {
        while (TRUE)
        {
            if ( cfl_fgets( string, sizeof(string), MOPACoutput ) == 0 ) goto endOfFile;
            if ( sscanf( string, " Root No. %s", dummy ) == 1 ) break;
        }

        // Skip a blank line, the symmetry information, and another blank line.

        if ( cfl_fgets( string, sizeof(string), MOPACoutput ) == 0 ) goto endOfFile;
        if ( cfl_fgets( string, sizeof(string), MOPACoutput ) == 0 ) goto endOfFile;
        if ( cfl_fgets( string, sizeof(string), MOPACoutput ) == 0 ) goto endOfFile;

        // Read the frequencies.

        if ( cfl_fgets( string, sizeof(string), MOPACoutput ) == 0 ) goto endOfFile;

        sscanf( string, "%lf %lf %lf %lf %lf %lf %lf %lf", (vibration+i),   (vibration+i)+1,
                                                           (vibration+i)+2, (vibration+i)+3,
                                                           (vibration+i)+4, (vibration+i)+5,
                                                           (vibration+i)+6, (vibration+i)+7  );

        // Skip a blank line.

        if ( cfl_fgets( string, sizeof(string), MOPACoutput ) == 0 ) goto endOfFile;

        // Read the normal mode coefficients.

        for ( j = 0; j < 24*NAtoms_in_output; j++ ) *(mode+j) = 0.0;

        for ( j = 0; j < NAtoms_in_output*3; j++ )
        {
            if ( cfl_fgets( string, sizeof(string), MOPACoutput ) == 0 ) goto endOfFile;

            // The first part of this line is either formatted as
            // "Cartesian_coordinate_index" or "[xyz] atomic_symbol atom_number".

            ndata = sscanf( string, "%*d %lf %lf %lf %lf %lf %lf %lf %lf",
                            (mode+j),                       (mode+j) +  3*NAtoms_in_output, 
                            (mode+j) +  6*NAtoms_in_output, (mode+j) +  9*NAtoms_in_output,
                            (mode+j) + 12*NAtoms_in_output, (mode+j) + 15*NAtoms_in_output,
                            (mode+j) + 18*NAtoms_in_output, (mode+j) + 21*NAtoms_in_output  );

            if ( ndata < 1 )
            {
                sscanf( string, "%*s %*s %*d %lf %lf %lf %lf %lf %lf %lf %lf",
                        (mode+j),                       (mode+j) +  3*NAtoms_in_output, 
                        (mode+j) +  6*NAtoms_in_output, (mode+j) +  9*NAtoms_in_output,
                        (mode+j) + 12*NAtoms_in_output, (mode+j) + 15*NAtoms_in_output,
                        (mode+j) + 18*NAtoms_in_output, (mode+j) + 21*NAtoms_in_output  );
            }
        }

        // Assign zero modes to dummy atoms (converting to CAChe sequence of atoms).

        for ( ii = i, j = 0; ii < MOPAC_MIN(i+8,nVibrations); ii++, j += 3*NAtoms_in_output )
        {
            for ( k = 0; k < 3*NAtoms; k++ ) *(modeWithDummies+k) = 0.0;

            for ( k = 0; k < NAtoms_in_output; k++ )
            {
                kk = locationWithoutDummies[k];
                modeWithDummies[3*kk]     = mode[j + 3*k];
                modeWithDummies[3*kk + 1] = mode[j + 3*k + 1];
                modeWithDummies[3*kk + 2] = mode[j + 3*k + 2];
            }

            if ( (err = csu_AddObjVal( molStruct, vibrational_levelID, normalModeID, ii+1,
                                       MOPAC_SRC, CSU_FLOATING, (short)NAtoms*3, noUnit, 6,
                                       (char *) (modeWithDummies), 1, BY_ID )) < 0 )
            {
                sprintf( errs, "%s: csu_AddObjVal normalModeID err code %d for MOPAC vibration %d.\n",
                         functionName, err, i);
                alert_user(errs);
            }
        }
    }

    for ( i = 0; i < nVibrations; i++ )
    {
        // Read vibration ID, frequency value, and transition dipole.

        if ( !getVibMode( ForceData, &vibID, &freqValue, &transDipole ) ) 
            goto vibsFound;

        if ( vibID < 1 || vibID > nVibrations )
        {
            sprintf(errs,"%s: vibration number %d out of range.", functionName, vibID);
            alert_user(errs);
            goto vibsFound;
        }

        vibration[vibID-1] = freqValue;
        dipole[vibID-1]    = transDipole;
		
        // Read atomic contributions to this mode.

        for ( j = 0; j < 4; j++ )
        {
            atomPairs[vibID-1].pair[j][0] = 0;
            atomPairs[vibID-1].pair[j][1] = 0;
            atomPairs[vibID-1].perCent[j] = 0.0;
        }

        j = 0;

        while( getAtomContrib( ForceData, &vibIndex, &atomA, &atomB, &percent ) != 0 )
        {
            if ( vibIndex == 0 && j == 0 )
            {
                sprintf(errs, "%s:  error reading vibration modes", functionName);
                alert_user(errs);
                goto errorReturn;
            }

            if ( j < 4 ) // CAChe uses no more than first four records
            {
                atomPairs[vibID-1].pair[j][0] = atomA; 
                atomPairs[vibID-1].pair[j][1] = atomB;
                atomPairs[vibID-1].perCent[j] = percent;
                j++;
            }
        }

        // Fill in data for degenerate levels.
	
        for ( ; i < vibID-1; i++ )
        {
            vibration[i] = vibration[vibID-1];
            dipole[i]    = dipole[vibID-1];

            for ( j = 0; j < 4; j++ )
            {
                atomPairs[i].pair[j][0] = atomPairs[vibID-1].pair[j][0];
                atomPairs[i].pair[j][1] = atomPairs[vibID-1].pair[j][1];
                atomPairs[i].perCent[j] = atomPairs[vibID-1].perCent[j];
            }
        }
    }

vibsFound:

    for ( i = 0; i < nVibrations; i++ )
    {
        // Add vibrational frequencies & intensities to chemical sample.

        temp = vibration[i]*cmToKcal + cmToKcalOffset;

        if ( (err = csu_AddObjVal( molStruct, vibrational_levelID, energyID, i+1, MOPAC_SRC,
                                   CSU_FLOATING, 1, cmM1ID, 2, (char *) &(temp), 0, BY_ID )) < 0 )
        {
            sprintf( errs, "%s: csu_AddObjVal EnergyID err code %d for MOPAC vibration %d.\n",
                     functionName, err, i );
            alert_user(errs);
        }

        if ( (err = csu_AddObjVal( molStruct, vibrational_levelID, transitionDipoleID, i+1, MOPAC_SRC,
                                   CSU_FLOATING, 1, debyeID, 4, (char *) &(dipole[i]), 0, BY_ID )) < 0)
        {
            sprintf( errs, "%s: csu_AddObjVal transitionDipoleID err code %d for MOPAC vibration %d.\n",
                     functionName, err, i );
            alert_user(errs);
        }

        // Connect the vibrational levels to the active atoms.

        if ( atomPairs[i].pair[0][0] > 0 )
        {
            for ( ii = 0; ii < 4; ii++ )
            {
                if ( atomPairs[i].pair[ii][0] == 0 ) continue;

                if ( fabs( atomPairs[i].perCent[ii] - atomPairs[i].perCent[0] ) >
                     fabs( 0.05*atomPairs[i].perCent[0] ) ) continue;

                if ( (j = locationWithoutDummies[atomPairs[i].pair[ii][0] - 1]) < 0 || j >= NAtoms )
                {
                    sprintf( errs, "%s: locationWithoutDummies[%d:0] = %d out of range; i=%d ii=%d",
                             functionName, atomPairs[i].pair[ii][0], j, i, ii );
                    alert_user(errs);
                }

                if ( (err = csu_AddConnectorVal( molStruct, AtomID, j, vibrational_levelID, i,
                                                 csu_Delete2ifC )) < 0 )
                {
                    sprintf( errs, "%s: csu_AddConnectorVal vibrational_levelID err code %d\n",
                             functionName, err );
                    alert_user(errs);
                }

                if ( (j = locationWithoutDummies[atomPairs[i].pair[ii][1] - 1]) < 0 || j >= NAtoms )
                {
                    sprintf( errs, "%s: locationWithoutDummies[%d:1] = %d out of range; i=%d ii=%d",
                             functionName, atomPairs[i].pair[ii][1], j, i, ii );
                    alert_user(errs);
                }

                if ((err = csu_AddConnectorVal( molStruct, AtomID, j, vibrational_levelID, i,
                                                csu_Delete2ifC )) < 0 )
                {
                    sprintf (errs,"%s: csu_AddConnectorVal vibrational_levelID err code %d\n",
                            functionName, err );
                    alert_user(errs);
                }
            }
        }
    }

    // Thermodynamic Properties

    while ( cfl_fgets( string, sizeof(string), MOPACoutput ) )
    {
        // Search for thermodynamic data in the MOPAC output file.

        if ( sscanf( string, " TEMP. (K) PARTITION FUNCTION %s", dummy ) != 1 )
            continue;

        // Delete thermodynamic data previously recorded in the chemical sample.

        if ( csu_ExistsObjclsID( molStruct, thermodynamic_infoID, &offset ) )
            ed_DeleteObjcls( molStruct, thermodynamic_infoID, 2 );

        i = 0;

        while ( cfl_fgets( string, sizeof(string), MOPACoutput ) )
        {
            // Search for a temperature data point.

            if ( sscanf( string, "%lf VIB. %s", &temperature, dummy ) < 2 )
                continue;

            i++;

            // Add data point to chemical sample.

            if ( (err = csu_AddObjVal( molStruct, thermodynamic_infoID, temperatureID,
                                       i, MOPAC_SRC, CSU_FLOATING, 1, kelvinID, 1,
                                       (char *) &(temperature), 0, BY_ID )) < 0 )
            {
                sprintf( errs, "%s: csu_AddObjVal thermodynamic_infoID err code %d "
                               "for MOPAC temperature %d.\n", functionName, err, i );
                alert_user(errs);
            }

            // Connect the calculation history to this temperature data point.

            if ( (err = csu_ConnectObjects( molStruct, CalcHistID, calchist_objectnum,
                                                       thermodynamic_infoID, i, csu_Delete2ifC )) < 0 )
            {
                sprintf( errs, "%s: csu_AddConnectorVal temperature i=%d err code %d\n",
                               functionName, i, err );
                alert_user(errs);
            }

            // Skip the data listed for the various degrees of freedom.

            if ( cfl_fgets( string, sizeof(string), MOPACoutput ) == 0 ) goto allDone;
            if ( cfl_fgets( string, sizeof(string), MOPACoutput ) == 0 ) goto allDone;
            if ( cfl_fgets( string, sizeof(string), MOPACoutput ) == 0 ) goto allDone;

            // Read the total heat of formation, enthalpy, heat capacity, and entropy.

            if ( cfl_fgets( string, sizeof(string), MOPACoutput ) == 0 ) goto allDone;

            ndata = sscanf( string, " TOT. %lf %lf %lf %lf", &heat_of_formation,
                                                             &enthalpy,
                                                             &heat_capacity,
                                                             &entropy );

            if ( ndata < 1 ) continue;

            if ( (err = csu_AddObjVal( molStruct, thermodynamic_infoID, heat_of_formationID,
                                       i, MOPAC_SRC, CSU_FLOATING, 1, kcal_molID, 3,
                                       (char *) &(heat_of_formation), 0, BY_ID )) < 0 )
            {
                sprintf( errs, "%s: csu_AddObjVal thermodynamic_infoID err code %d "
                               "for MOPAC heat of formation %d.\n", functionName, err, i );
                alert_user(errs);
            }

            if ( ndata < 2 ) continue;

            temp = enthalpy*calToKcal + calToKcalOffset;

            if ( (err = csu_AddObjVal( molStruct, thermodynamic_infoID, enthalpyID,
                                       i, MOPAC_SRC, CSU_FLOATING, 1, cal_molID, 3,
                                       (char *) &(temp), 0, BY_ID )) < 0 )
            {
                sprintf( errs, "%s: csu_AddObjVal thermodynamic_infoID err code %d "
                               "for MOPAC enthalpy %d.\n", functionName, err, i );
                alert_user(errs);
            }

            if ( ndata < 3 ) continue;

            if ( (err = csu_AddObjVal( molStruct, thermodynamic_infoID, heat_capacityID,
                                       i, MOPAC_SRC, CSU_FLOATING, 1, cal_kelvin_molID, 3,
                                       (char *) &(heat_capacity), 0, BY_ID )) < 0 )
            {
                sprintf( errs, "%s: csu_AddObjVal thermodynamic_infoID err code %d "
                               "for MOPAC heat capacity %d.\n", functionName, err, i );
                alert_user(errs);
            }

            if ( ndata < 4 ) continue;

            if ( (err = csu_AddObjVal( molStruct, thermodynamic_infoID, entropyID,
                                       i, MOPAC_SRC, CSU_FLOATING, 1, cal_kelvin_molID, 3,
                                       (char *) &(entropy), 0, BY_ID )) < 0 )
            {
                sprintf( errs, "%s: csu_AddObjVal thermodynamic_infoID err code %d "
                               "for MOPAC entropy %d.\n", functionName, err, i );
                alert_user(errs);
            }

            free_energy = heat_of_formation - 0.001*temperature*entropy;

            if ( (err = csu_AddObjVal( molStruct, thermodynamic_infoID, free_energyID,
                                       i, MOPAC_SRC, CSU_FLOATING, 1, kcal_molID, 3,
                                       (char *) &(free_energy), 0, BY_ID )) < 0 )
            {
                sprintf( errs, "%s: csu_AddObjVal thermodynamic_infoID err code %d "
                               "for MOPAC free energy %d.\n", functionName, err, i );
                alert_user(errs);
            }
	}
    }
  
allDone:
	if (vibration != NULL) 
		free(vibration);
	if (dipole != NULL) 
		free(dipole);
	if (mode != NULL)
		free(mode);
	if (modeWithDummies != NULL)
		free(modeWithDummies);
	if (atomPairs != NULL)
		free(atomPairs);
	if (MOPACoutput != NULL) 
		fclose(MOPACoutput);
	if (ForceData != NULL)
		fclose(ForceData);
	return(0);
	
endOfFile:
	if (ForceData != NULL)
		fclose(ForceData);
	sprintf(errs, "%s: Unexpected end of file on MOPAC Output.", functionName);
	alert_user(errs);
	goto allDone;

errorReturn:
	if (vibration != NULL) 
		free(vibration);
	if (dipole != NULL) 
		free(dipole);
	if (mode != NULL)
		free(mode);
	if (modeWithDummies != NULL)
		free(modeWithDummies);
	if (atomPairs != NULL)
		free(atomPairs);
	if (MOPACoutput != NULL) 
		fclose(MOPACoutput);
	if (ForceData != NULL)
		fclose(ForceData);
    return (MOPACerrors - 1);
	
}


int getNumVibrations(FILE *inputStream)
{
    int  Value = 0;
    char string[80];

    while ( cfl_fgets(string, sizeof(string), inputStream) != 0 )
    {
        if ( strlen(string) == 0 ) return 0;

        if ( *string != '#' )
        {
            sscanf(&string[0],"%d", &Value); 
            return Value;
        }
    }

    return 0;
}


int getVibMode(FILE *inputStream, int *ID, float *freqValue, float *transDipole)
{
    char string[80];

    while ( cfl_fgets(string, sizeof(string), inputStream) != 0 )
    {
        if ( strlen(string) == 0 ) return 0;

        if ( *string != '#' )
        {
            sscanf( string,"%d %f %f", ID, freqValue, transDipole );
            return 1;
        }
    }

    return 0;
}


int getAtomContrib(FILE *inputStream, int *ID, int *atomA, int *atomB, float *percent)
{
    char string[80];

    while ( cfl_fgets(string, sizeof(string), inputStream) != 0 )
    {
        if ( strlen(string) == 0 ) return 0;

        if ( *string != '#' )
        {
            sscanf( string, "%d %d %d %f", ID, atomA, atomB, percent );
            return *ID;
        }
    }

    return 0;
}
