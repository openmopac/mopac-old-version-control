/*
 *	27/Jun/2000 Ingvar Lagerstedt, Oxford Molecular
 *		Renamed EnergyID to energyID to avoid name conflict with updated csu.h
 */

#include <compat.h>
#include <cpu.h>
#include <ZINDODriver.h>
#include <CACheFileLib.h>

#define cmToAU 4.556335e-6

typedef struct  {
	long	pair[4][1];
	double  coefficient[4];
} ExcitationPair;

int writeUVSpectra(MolStruct *molStruct, double energy_cutoff_nm)
{
	int i, rtn_code;
	long nConfigurations, nStates, state;
	FILE *ZINDOoutput = NULL;
	char string[256];
	double *absorptions = NULL, *dipole = NULL, temp, *tDipole = NULL;
	double energy_cutoff = 0.0;
	long nAbsorptions, transition;
	ObjclsID offset;
	Boolean list_abbreviated = FALSE;
 	char functionName[] = "writeUVSpectra";
	ExcitationPair	*excitationPair = NULL;
  
	PropID energyID, transitionDipoleID, transitionMomentID,
		   normalModeID;
	NameNID energy_auID, dipole_auID, cmM1ID, debyeID, noUnit, ZINDO_SOURCE;
	ObjclsID electronic_stateID, mol_orbitalID;

	char errs[256];
	
	/* Control panel energy cutoff is in nanometers; energies in ZINDO Output are in cm-1 */
	if (energy_cutoff_nm > 0.0)
		energy_cutoff = 10000000.0/energy_cutoff_nm;
	
	if ((rtn_code = csu_GetPropertyID("transitionDipole",&transitionDipoleID)) < 0) {
		sprintf (errs,"%s: csu_GetPropertyID transitionDipole rtn_code %d\n",
				functionName, rtn_code);
		alert_user(errs);
		return (ZINDOerrors - 1);
	}
	
	if ((rtn_code = csu_GetPropertyID("transitionMoment",&transitionMomentID)) < 0) {
		sprintf (errs,"%s: csu_GetPropertyID transitionMoment rtn_code %d\n",
				functionName, rtn_code);
		alert_user(errs);
		return (ZINDOerrors - 1);
	}
	if ((rtn_code = csu_GetPropertyID("Energy",&energyID)) < 0) {
		sprintf (errs,"%s: csu_GetPropertyID Energy rtn_code %d\n",
				functionName, rtn_code);
		alert_user(errs);
		return (ZINDOerrors - 1);
	}
	if ((rtn_code = csu_GetPropertyID("normalMode",&normalModeID)) < 0) {
		sprintf (errs,"%s: csu_GetPropertyID normalMode rtn_code %d\n",
				functionName, rtn_code);
		alert_user(errs);
		return (ZINDOerrors - 1);
	}
	if ((rtn_code = csu_GetNameIndex("noUnit",&noUnit)) < 0) {
		sprintf (errs,"%s: csu_GetNameIndex noUnit rtn_code %d\n",
				functionName, rtn_code);
		alert_user(errs);
		return (ZINDOerrors - 1);
	}
	if ((rtn_code = csu_GetNameIndex("ZINDO",&ZINDO_SOURCE)) < 0) {
		sprintf (errs,"%s: csu_GetNameIndex ZINDO_SOURCE rtn_code %d\n",
				functionName, rtn_code);
		alert_user(errs);
		return (ZINDOerrors - 1);
	}
	if ((rtn_code = csu_GetNameIndex("cm-1", &cmM1ID)) < 0) {
		sprintf (errs,"%s: csu_GetNameIndex cm-1 rtn_code %d\n",
				functionName, rtn_code);
		alert_user(errs);
		return (ZINDOerrors - 1);
	}
	if ((rtn_code = csu_GetNameIndex("dipole_au", &dipole_auID)) < 0) {
		sprintf (errs,"%s: csu_GetNameIndex dipole_au rtn_code %d\n",
				functionName, rtn_code);
		alert_user(errs);
		return (ZINDOerrors - 1);
	}
	if ((rtn_code = csu_GetNameIndex("debye", &debyeID)) < 0) {
		sprintf (errs,"%s: csu_GetNameIndex debye rtn_code %d\n",
				functionName, rtn_code);
		alert_user(errs);
		return (ZINDOerrors - 1);
	}
	if ((rtn_code = csu_GetNameIndex("energy_au", &energy_auID)) < 0) {
		sprintf (errs,"%s: csu_GetNameIndex energy_au rtn_code %d\n",
				functionName, rtn_code);
		alert_user(errs);
		return (ZINDOerrors - 1);
	}
	if ((rtn_code = csu_GetObjectClassID("electronic_state", &electronic_stateID)) < 0) {
		sprintf (errs,"%s: csu_GetObjectClassID electronic_state rtn_code %d\n",
				functionName, rtn_code);
		alert_user(errs);
		return (ZINDOerrors - 1);
	}
	if ((rtn_code = csu_GetObjectClassID("mol_orbital", &mol_orbitalID)) < 0) {
		sprintf (errs,"%s: csu_GetObjectClassID mol_orbital rtn_code %d\n",
				functionName, rtn_code);
		alert_user(errs);
		return (ZINDOerrors - 1);
	}


   /*
    *  Find out how many atoms there are.
    */
    
   if ( !csu_ExistsObjclsID (molStruct, AtomID, &offset) )
       alert_user(" Error attempting to locate AtomID index.");
	
	if ((ZINDOoutput = fopen("OUTPUT file","r")) == NULL) {
	   alert_user("Unable to process ZINDO Output.");
	   goto endOfFile;
	};

	for (;;) {
		if (cfl_fgets(string, sizeof(string), ZINDOoutput) == 0) {
			alert_user("Spectra information cannot be added to your molecule for this type of C.I.");
			goto allDone;
		}
		if (strncmp(string," EXCITED STATES, PURE CONFIGURATIONS", 32) == 0) break;
	}

	/* 
	 * Sometimes there are ZIO End-of-file warning messages after the 
	 * "EXCITED STATES, PURE CONFIGURATIONS" line appears.   SJC, 2/4/91 
	 */
   
	for (;;) {
	
		if (cfl_fgets(string, sizeof(string), ZINDOoutput) == 0) goto endOfFile;

		/* 
		 * Some C.I. calculations abbreviate the C.I. list.
		 * In this case, look for the second set of configurations to get a configuration
		 * count. SJC 6/28/95
		 */
		if (strncmp(string, "LIST BEFORE ABBREVIATION", 24) == 0)
			list_abbreviated = TRUE;

		if (strncmp(string, "                                   (CM-1)", 41) == 0) {
			if (!list_abbreviated)
				break;
			else
				/* Get a second incidence of (CM-1) */
				list_abbreviated = FALSE;
		}
	}

    for (i=0;; i++) {
	    int itemp;
		if (cfl_fgets(string, sizeof(string), ZINDOoutput) == 0) goto endOfFile;
		itemp = 0;
		sscanf(string,"%d", &itemp);	
		if (itemp == 0) break;
		nConfigurations = itemp;
	}

    if (nConfigurations <= 0) goto allDone;
	
	if (nConfigurations == 1) { /* C.I. has no excited configurations */
		alert_user("Only one configuration present.  Specify C.I. level larger than 'None.'");
		goto allDone;
	}
	
	/* Determine the dominant orbitals in each excitation. */
	for (;;) {
		if (cfl_fgets(string, sizeof(string), ZINDOoutput) == 0) goto endOfFile;
		if (strncmp(string," GROUND STATE DEPRESSION", 24) == 0) break;
	}
	for (;;) {
		if (cfl_fgets(string, sizeof(string), ZINDOoutput) == 0) goto endOfFile;
		if (strncmp(string," EIGENVALUES", 12) == 0) break;
	}

	if (cfl_fgets(string, sizeof(string), ZINDOoutput) == 0) goto endOfFile;
    for (i=0, nStates=0;; i++) {
	    int itemp[5], j;
		
		if (cfl_fgets(string, sizeof(string), ZINDOoutput) == 0) goto endOfFile;
		for (j=0; j<5; j++) itemp[j] = 0;
		
		sscanf(string,"%d %*s %d %*s %d %*s %d %*s %d %*s ", &itemp[0], &itemp[1], &itemp[2], &itemp[3], &itemp[4]);	
		for (j=0; j<5; j++, nStates++) if (itemp[j] == 0) goto gotnStates;
	}

gotnStates:
	
	excitationPair = (ExcitationPair *) mlalloc((nStates + 5) * sizeof(ExcitationPair));
	if (excitationPair == NULL) {
	  sprintf (errs,"ZINDO: Excitation Pair memory request %ld too large\n",
			   (nStates + 5) * sizeof(ExcitationPair));
	  alert_user(errs);
	  goto errorReturn;
	}


	absorptions = (double *) mlalloc((nStates+5) * sizeof(double));
	if (absorptions == NULL) {
	  sprintf (errs,"ZINDO: absorptions memory request %ld too large\n",
			   (nStates+5) * sizeof(double));
	  alert_user(errs);
	  goto errorReturn;	  
	}

	dipole = (double *) mlalloc((nStates+5) * sizeof(double));
	if (dipole == NULL) {
	  sprintf (errs,"ZINDO: dipole memory request %ld too large\n",
			   (nStates+5) * sizeof(double));
	  alert_user(errs);
	  goto errorReturn;
	}

	tDipole = (double *) mlalloc(3 * (nStates+5) * sizeof(double));
	if (tDipole == NULL) {
	  sprintf (errs,"ZINDO: tDipole memory request %ld too large\n",
			   3 * (nStates+5) * sizeof(double));
	  alert_user(errs);
	  goto errorReturn;
	}

    for (state = 0; state < nStates; state += 5) {
	   int jj, j, l;

	   for (jj=0; jj<5; jj++) {
	      for (l=0; l<4; l++) {
		   excitationPair[state+jj].pair[l][0] = 0;
		   excitationPair[state+jj].pair[l][1] = 0;
		   excitationPair[state+jj].coefficient[l] = 0.0;
		  }
	   }

	   for (;;) {
		   if (cfl_fgets(string, sizeof(string), ZINDOoutput) == 0) goto endOfFile;
		   if (strncmp(string," CONFIGURATIONS:        ", 24) == 0) break;
	   }

	   for (j = 0; j < nConfigurations; j++) {
		 long orb1, orb2;
	     double coeff[5];

		 /* get line with coefficients */
		 if (cfl_fgets(string, sizeof(string), ZINDOoutput) == 0) goto endOfFile;

		 orb1 = 0;
		 orb2 = 0;
		 sscanf(&string[5],"%d->%d", &orb1, &orb2);
		 
         for (jj=0; jj<5; jj++) coeff[jj] = 0;
		 sscanf(&string[25],"%10lf%10lf%10lf%10lf%10lf",
				&coeff[0], &coeff[1], &coeff[2], &coeff[3], &coeff[4]);
		 for (jj=0; jj<5; jj++) {
		     /* save only the configuration which contributes the most to this state */
			 if (fabs(coeff[jj]) > fabs(excitationPair[state+jj].coefficient[0])) {
				 excitationPair[state+jj].pair[0][0] = orb1;
				 excitationPair[state+jj].pair[0][1] = orb2;
				 excitationPair[state+jj].coefficient[0] = coeff[jj];
			 }
		 }
	   }
	}
			
	/* Determine the number of excited states calculated */
	for (;;) {
		if (cfl_fgets(string, sizeof(string), ZINDOoutput) == 0) goto endOfFile;
		if (strncmp(string," TRANSITION MOMENTS AND OSCILLATOR", 32) == 0) break;
	}
	for (i=0; i<6; i++) {
		if (cfl_fgets(string, sizeof(string), ZINDOoutput) == 0) goto endOfFile;
	}

	/* acquire spectral frequencies */

	for (i=0;;) {
	    double oscillatorStrength, this_abs, this_dip[3];
		
		/* absorptions */
		if (cfl_fgets(string, sizeof(string), ZINDOoutput) == 0) goto endOfFile;
		if (strncmp(string,"(", 1) != 0) break;
		
		sscanf(&string[14],"%10lf%10lf%10lf", 
				&this_dip[0], &this_dip[1], &this_dip[2]);
		sscanf(&string[55],"%10lf%10lf", &this_abs, &oscillatorStrength);
		
		if (this_abs <= energy_cutoff || energy_cutoff == 0.0) {
			absorptions[i] = this_abs;
			tDipole[i*3] = this_dip[0];
			tDipole[i*3 + 1] = this_dip[1];
			tDipole[i*3 + 2] = this_dip[2];
		
		dipole[i] = sqrt(tDipole[i*3]*tDipole[i*3] + tDipole[i*3+1]*tDipole[i*3+1]
		                +tDipole[i*3+2]*tDipole[i*3+2]);
		i++;
		} else
			break;
	}
    nAbsorptions = i;

#if defined (_DEBUG)
    sprintf(errs,"nAbs: %d   abs[0]: %lf    abs[nAbs]: %lf", nAbsorptions,
            absorptions[0],absorptions[nAbsorptions]);
	alert_user(errs);
#endif
	
	/* start writing the spectrum information */

   if (csu_ExistsObjclsID (molStruct, electronic_stateID, &offset))
     		ed_DeleteObjcls(molStruct, electronic_stateID, 2);
	
	/* Calculate 
	   Refer to Quantum Chemistry by R. Daudel, G. Lerory, D. Peeters, and
	   M. Sana, John Wiley & Sons, Chichester, 1983.
	 */
	 
		for (i = 0, transition = 0; i < nAbsorptions; i++) {
			/* Skip the first transition if its energy is zero SJC June 1999 */
			if (i == 0 && absorptions[i] == 0.0)
				continue;
			temp=absorptions[i]*cmToAU;
			if ((rtn_code = csu_AddObjVal(molStruct, electronic_stateID, energyID, transition + 1,
										  ZINDO_SOURCE, CSU_FLOATING, 1, cmM1ID, 1,
										  (char *) &(temp), 0, BY_ID)) < 0) {
			  sprintf (errs,"%s: csu_AddObjVal EnergyID rtn_code %d"
							" for energy level %d.\n", functionName, rtn_code, i);
			  alert_user(errs);
			}

			if ((rtn_code = csu_AddObjVal(molStruct, electronic_stateID, transitionDipoleID, transition + 1,
										  ZINDO_SOURCE, CSU_FLOATING, 1, debyeID, 4,
										  (char *) &(dipole[i]), 0, BY_ID)) < 0) {
			  sprintf (errs,"%s: csu_AddObjVal transitionDipoleID rtn_code %d"
							" for energy level %d.\n", functionName, rtn_code, i);
			  alert_user(errs);
			}

			if ((rtn_code = csu_AddObjVal(molStruct, electronic_stateID, transitionMomentID, transition + 1,
										  ZINDO_SOURCE, CSU_FLOATING, 3, debyeID, 4,
										  (char *) &(tDipole[3*i]), 1, BY_ID)) < 0) {
			  sprintf (errs,"%s: csu_AddObjVal transitionMomentID rtn_code %d"
							" for energy level %d.\n", functionName, rtn_code, i);
			  alert_user(errs);
			}
		  /*
		   * Connect the electronic_stateID to the active atoms.
		   */

			if (excitationPair[i].pair[0][0] > 0) {
			   int j, ii;
			   for (ii=0; ii < 1; ii++) {
				 if (excitationPair[i].pair[ii][0] > 0) {
					if ((j = csu_ObjectIDtoIndex(molStruct, mol_orbitalID,
												 excitationPair[i].pair[ii][0])) < 0) {
						sprintf (errs,"writeUVSpectra: csu_ObjectIDtoIndex mol_orbitalID rtn_code %d\n",
								 j);
						alert_user(errs);
					}
					
#if defined (_DEBUG)
					sprintf(errs,"connecting: %d->%d to %d", j,
							excitationPair[i].pair[ii][1], i);
					alert_user(errs);
#endif

					if ((rtn_code = csu_AddConnectorVal (molStruct,
												mol_orbitalID, j,
												electronic_stateID, transition,
												csu_Delete2ifC)) < 0) {
						sprintf (errs,"writeUVSpectra: csu_AddConnectorVal electronic_state rtn_code %d\n",
							 rtn_code);
						alert_user(errs);
					}
  
					if ((j = csu_ObjectIDtoIndex(molStruct, mol_orbitalID,
												 excitationPair[i].pair[ii][1])) < 0) {
						sprintf (errs,"writeUVSpectra: csu_ObjectIDtoIndex mol_orbitalID rtn_code %d\n",
								 j);
						alert_user(errs);
					}
					if ((rtn_code = csu_AddConnectorVal (molStruct, mol_orbitalID, j,
														  electronic_stateID, transition,
														  csu_Delete2ifC)) < 0) {
						sprintf (errs,"writeUVSpectra: csu_AddConnectorVal electronic_stateID rtn_code %d\n",
								 rtn_code);
						alert_user(errs);
					}
				 }
			   }
			}
			transition++;
		}

allDone:

	if (excitationPair != NULL) free(excitationPair);
	if (absorptions != NULL) free(absorptions);
	if (dipole != NULL) free(dipole);	
	if (ZINDOoutput != NULL) fclose(ZINDOoutput);
	return (0);
	
endOfFile:
	alert_user("Unexpected end of file on ZINDO output.");
	goto allDone;
	
errorReturn:

	if (excitationPair != NULL) free(excitationPair);
	if (absorptions != NULL) free(absorptions);
	if (dipole != NULL) free(dipole);	
	if (ZINDOoutput != NULL) fclose(ZINDOoutput);
    return (ZINDOerrors - 1);
	
}
