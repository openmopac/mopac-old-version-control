/*
 * QChkPt.h
 */

#ifndef __QChkPt__
#define __QChkPt__

#include <ServerStepQueue.h>

#define qcp_HeaderSize	256												/* Total size of header */
#define qcp_FileIDSize	32												/* Size of FileID field */
#define qcp_PadSize		qcp_HeaderSize - qcp_FileIDSize - sizeof(long)	/* Size of Pad field */

#define	qcp_CURRENTVERSIONNUMBER	1		/* Version number for CAChe 3.5 */
#define qcp_CHKPTHEADERID			"CAChe ChkPtFile"

/******************************************************
 * Version structure located at front of ChkPt file
 ******************************************************/
 
 struct	qcp_ChkPtHeader
 {
 	char			fileID[qcp_FileIDSize];
	unsigned long	versionNumber;
	char			pad[qcp_PadSize];
};

typedef struct qcp_ChkPtHeader qcp_ChkPtHeader;
typedef struct qcp_ChkPtHeader* qcp_ChkPtHeaderPtr;

/******************************************************
 *
 *		QChkPt Prototypes
 *
 ******************************************************/

/*************************************************************************************
 ***************	The following routines are located in QChkPt.c	**************
 *************************************************************************************/

	
/*************************************************************************************
 *	This routine creates and writes a Checkpoint File.
 *************************************************************************************/
ssq_Err		qcp_CreateChkPtFile (
	char*			tempFilename,
	char*			chkptFilename,
	ssq_QueuePtr	queue);
	
/*************************************************************************************
 *	This routine creates and writes a Checkpoint File.
 *************************************************************************************/
ssq_Err		qcp_ReadChkPtFile (
	char*			chkptFilename,
	ssq_QueuePtr	queue);
	
#endif
