/*
** Tab_Common.h
*/

#ifndef _TAB_COMMON_H_
#define _TAB_COMMON_H_

#include <compat.h>

#include <stddef.h>

#include <cul.h>
#include <SSQFileTypes.h>
#include <TabFileTypes.h>
#include <CACheFileLib.h>

/*
** Note: The max filename size must be 256 because this list
** is used to pass the *full path* of the data dictionary to
** the calculational code.
*/

#define TAB_MAX_FILENAME_SIZE CFL_PATH_MAX	/* size of filename buffers */

#define ALL_MOs 10000

/*
** Structure passed via settings file between manager and appl.
**
** If changed, keep in mind the differences in structure padding
** between compilers/architectures!
*/
#define MAX_NUMBER_ISOVALUES 1

/*
   THE FOLLOWING SURFACE CONTROL STRUCTURES MUST HAVE A LENGTH
   WHICH IS A MULTIPLE OF 8.
 */
typedef struct {
	double			value[MAX_NUMBER_ISOVALUES];
	double			frontierWeight;
	double			reagentEnergy;
	long		    lumoplus; 		/* the input request for LUMO + inp_mohigh			*/
	long			homominus; 		/* the input request for HOMO - inp_molow			*/
	long			colorBy;					/*
													DENSITY_GRADIENT_COLOR
													ELECTROSTATIC_COLOR
													ISOVALUE_COLOR
													HOMO_COLOR
													LUMO_COLOR
													FRONTIER_DENSITY_COLOR
													SUPERDELOC_COLOR
												 */
	long			frontierDensityType;		/*
												   ELECTROPHILIC_TYPE
												   NUCLEOPHILIC_TYPE
												   RADICAL_TYPE
												 */
	long			superdelocType; 	/*
												   ELECTROPHILIC_TYPE
												   NUCLEOPHILIC_TYPE
												   RADICAL_TYPE
												 */
	long			padding;					/* dummy entry to assure length is
												   multiple of 8 bytes */
} Density_surface_control;

typedef struct {
	double			value[MAX_NUMBER_ISOVALUES];
	long		    lumoplus; 		/* the input request for LUMO + inp_mohigh			*/
	long			homominus; 		/* the input request for HOMO - inp_molow			*/
} MO_surface_control;

typedef struct {
	double			value[MAX_NUMBER_ISOVALUES];
	long		    lumoplus; 		/* the input request for LUMO + inp_mohigh			*/
	long			homominus; 		/* the input request for HOMO - inp_molow			*/
	long			contrLength;	/*
										DEFAULT_CONTRACTION
										STO_1G
										STO_2G
										STO_3G
										STO_4G
										STO_5G
										STO_6G
									*/
	long			method;	/*
												POINTCHARGE_METHOD,
												MULTIPOLE_METHOD,
												ANALYTICAL_METHOD
											*/
} Electrostatic_surface_control;

typedef struct {
	double			value[MAX_NUMBER_ISOVALUES];
	double			reagentEnergy;
	long		    lumoplus; 		/* the input request for LUMO + inp_mohigh			*/
	long			homominus; 		/* the input request for HOMO - inp_molow			*/
} Superdeloc_surface_control;

typedef struct {
	double			value[MAX_NUMBER_ISOVALUES];
	double			from;
	double			to;
	double			threshold;
} tAmplitude_surface_control;

typedef struct
{
	double			preferedIntervalDistance;
/*
   THE FOLLOWING SURFACE CONTROL STRUCTURES MUST BE ALIGNED ON A DOUBLE
   WORD BOUNDARY.
 */
	Density_surface_control			density;
	MO_surface_control				MOs;
	Electrostatic_surface_control	electrostatic;
	Superdeloc_surface_control		superdeloc;
	tAmplitude_surface_control		tAmplitude;

	long			surfaceType;	/*
									   density_STYPE -> total electron density is evaluated
									   MOs_STYPE -> molecular orbitals are evaluated
									   electrostatic_STYPE -> total electrostatic potential is evaluated
									   superdeloc_STYPE -> superdelocalizability is evaluated
									   tAmplitude_STYPE -> transition Amplitude is evaluated
									 */

	long			maxGridIntervals;
	long			saveGrid;		/* = TRUE, a 3D grid in map file format is saved */
	long			savePlane;		/* = TRUE, surface files are generated for
											   xy, yz, and xz planes */
	long			mostart;		/* mostart and moend are the actual range  			*/
	long			moend;			/* for printing of mos to MolStruct					*/
	long			returnTabulatorOutput; /* return Tabulator Output to the user */
	long			padding;		/* dummy spare variable to ensure 8 byte alignment */
	char			version[32];	/* the date/time of compilation of this version		*/
	char			datetime[32];	/* the date and time string for the calculation		*/
	char			molStructName[TAB_MAX_FILENAME_SIZE]; /* the name of the molecule file */
} TabulatorControl;

enum Tab_reaction_type {
	TOO_LOW_RTYPE = 0,
	ELECTROPHILIC_RTYPE,
	NUCLEOPHILIC_RTYPE,
	RADICAL_RTYPE,
	TOO_HIGH_RTYPE
};

enum Tab_electrostatic_Method {
	TOO_LOW_ES_METHOD = 0,
	POINTCHARGE_ES_METHOD,
	MULTIPOLE_ES_METHOD,
	ANALYTICAL_ES_METHOD,
	TOO_HIGH_ES_METHOD
};

enum Tab_surface_type {
	TOO_LOW_STYPE = 0,
	density_STYPE,
	MOs_STYPE,
	electrostatic_STYPE,
	superdeloc_STYPE,
	tAmplitude_STYPE,
	TOO_HIGH_STYPE
};

enum Tab_electrostatic_contraction_length {
	TOO_LOW_CONTR_LEN = -1,
	DEFAULT_CONTRACTION,
	STO_1G,
	STO_2G,
	STO_3G,
	STO_4G,
	STO_5G,
	STO_6G,
	TOO_HIGH_CONTR_LEN
};

enum Tab_density_ColorBy {
	TOO_LOW_COLOR = 0,
	DENSITY_GRADIENT_COLOR,
	ELECTROSTATIC_COLOR,
	ISOVALUE_COLOR,
	HOMO_COLOR,
	LUMO_COLOR,
	FRONTIER_DENSITY_COLOR,
	SUPERDELOC_COLOR,
	TOO_HIGH_COLOR
};

typedef TabulatorControl *TabulatorControlP, **TabulatorControlH;


typedef long Tab_file_type;
typedef long Tab_folder_type;
typedef long Tab_transfer_format;

/* File name communication structures */

#define TAB_MAX_NUM_INPUT_FILES 4
#define TAB_OUTPUT_FILES_INCREMENTS 16
#define TAB_MAX_OUTPUT_FILES 4096	/* Does not apply to all architectures */

struct tab_InputFileSpec
{
	long entryIsValid;	/* Boolean: indicates whether this entry is valid */
	char name[TAB_MAX_FILENAME_SIZE];
};

typedef struct tab_InputFileSpec tab_InputFileSpec, *tab_InputFileSpecPtr;

struct tab_InputFileList
{
	unsigned int maxNumEntries;
	tab_InputFileSpec inputFileSpec[TAB_MAX_NUM_INPUT_FILES];
};

typedef struct tab_InputFileList tab_InputFileList, *tab_InputFileListPtr;

/* Defines of files in above list */

#define TAB_IL_SETTINGS		0		/* settings (control panel) file */
#define TAB_IL_CCLIST		1		/* calculation parameters file */
#define TAB_IL_MOLSTRUCT	2		/* file on which to work */
#define TAB_IL_DATADICT		3		/* path of data dictionary */

struct tab_OutputFileSpec
{
	Tab_file_type outputFileCode;
	Tab_folder_type outputFolderCode;
	Tab_transfer_format fileFormat;
	long entryIsValid;	/* Boolean: indicates whether this entry is valid */
	char name[TAB_MAX_FILENAME_SIZE];
};

typedef struct tab_OutputFileSpec tab_OutputFileSpec,
	*tab_OutputFileSpecPtr;

struct tab_OutputFileList
{
	unsigned long bytesAllocated;
	unsigned short maxNumEntries;
	unsigned short numEntriesUsed;
	tab_OutputFileSpec outputFileSpec[1];	/* Actual # varies */
};

typedef struct tab_OutputFileList tab_OutputFileList,
	*tab_OutputFileListPtr;

/* Definition of the calculation history information structure */

#define ServerNameSize 32 /* should match ssq_ServerNameSize */
typedef struct {
	char serverName[ServerNameSize];
} CalcHistInfo, *CalcHistInfoPtr;

/* Definition of the interprocess(or) Env user structure. */

#if	defined(unix) || defined(_WIN32)
/* volatile struct members caused a problem for unix C compiler */
typedef volatile struct TabulatorDriver88kParam {
	long applFlags;		/* written by application */
	long mgrFlags;			/* written by manager */
	cul_CPMsgChannel *msgChannelP;
	tab_InputFileListPtr inputfileListP;
	tab_OutputFileListPtr outputfileListP;	/* not valid on copr. */
	CalcHistInfoPtr calcHistInfoP;
	char 	*applicationVersionPtr;
	long structureIsValid;
} TabulatorDriverParam88k;
#else
typedef struct TabulatorDriver88kParam {
	volatile long applFlags;		/* written by application */
	volatile long mgrFlags;			/* written by manager */
	volatile cul_CPMsgChannel *msgChannelP;
	volatile tab_InputFileListPtr inputfileListP;
	volatile tab_OutputFileListPtr outputfileListP;	/* not valid on copr. */
	volatile CalcHistInfoPtr calcHistInfoP;
	volatile char 	*applicationVersionPtr;
	volatile long structureIsValid;
} TabulatorDriverParam88k;
#endif

/* application-manager message channel defines */
#define TAB_NUM_MSG_CHANNELS 4	/* # of message channels */
#define TAB_MSG_BUFFER_SIZE 256	/* size of msg buffers in bytes */

typedef TabulatorDriverParam88k *TabulatorDrvrParam88kPtr;

/* applFlags */

#define TAB_APPL_READY		1
#define TAB_APPL_RUNNING	2
#define TAB_APPL_DONE		4

/* mgrFlags */

#define TAB_MGR_START		1
#define TAB_MGR_QUIT		2

#if	defined(unix) || defined(_WIN32)

/*
** Simplified Env structure for unix version -- The Env structure
** for the coprocessor and Mac versions can be found in Env.h
*/

typedef struct Environ {
	long	user[16];	/* uncommitted - for use by applications to pass flags */
} Environ, *EnvPtr;

extern volatile Environ *Env;

/* specify name for file to store output file list */
#define TAB_OFL_FNAME "TAB_OutputFileList.tmp"

#endif

/* Prototypes */

Boolean
CheckControlPanel(TabulatorControl *controlPanel);

void
GetDefaultParams(TabulatorControl *Control);

Boolean
HasTabulatorParams(FILE *controlfile);

Boolean
GetTabulatorParams(FILE *controlfile, TabulatorControl *Control);

Boolean
GetTabulatorParamsV2(FILE *controlfile, TabulatorControl *Control);

Boolean
GetTabulatorParamsV3(FILE *controlfile, TabulatorControl *Control);

int PutTabulatorControlFile(
	FILE *file,
	TabulatorControl *Control,
	Boolean all_settings	/* if true, save settings for all surface
							   types, not just the current one */
);

#endif /* _TAB_COMMON_H_ */
