#include <compat.h>
#include <ctype.h>
#include <cpu.h>
#include <MOPACDriver.h>
#include <CACheFileLib.h>

#define KEYWORD_LEN 255
#define	TOTAL_NUM_ELEMS	104

int isInputRestart(Boolean *isRestart)
{
	FILE *input = NULL;
	size_t 	j;
	Boolean	havePlusOrAmpersand = FALSE;
	char 	aString[255];

	*isRestart = FALSE;

	if (!(input = fopen("MOPAC Input","r"))) {
		sprintf(aString,"isInputRestart: "
			"The MOPAC Input file cannot be opened.");
		alert_user(aString);
		return -1;
	} else {
		if (cfl_fgets(aString, sizeof(aString), input) == 0) {
			sprintf(aString,"isInputRestart: "
				"The MOPAC Input file is empty.");
			alert_user(aString);
			fclose(input);
			return -1;
		}
		
		/* Uppercase the string */
		for (j=0; j< strlen(aString); j++) {
			aString[j] = ToUpper(aString[j]);
		}

		/* See if "RESTART" occurs in the first line */
		if (strstr(aString, "RESTART")) {
			*isRestart = TRUE;
			fclose(input);
			return 0;
		}

		/* See if the string has a + or a & character at the end */
		havePlusOrAmpersand = false;
		
		for (j=0; j< strlen(aString); j++) {
			if ((aString[j] == '+') || (aString[j] == '&')) {
				havePlusOrAmpersand = true;
				break;
			}
		}

		if (havePlusOrAmpersand) { /* get the second line */
			havePlusOrAmpersand = false;

			if (cfl_fgets(aString, sizeof(aString), input) == 0) {
				sprintf(aString,"isInputRestart: "
					"MOPAC Input file does not have a second line.");
				alert_user(aString);
				fclose(input);
				return -1;
			}

			/* Uppercase the string */
			for (j=0; j< strlen(aString); j++) {
				aString[j] = ToUpper(aString[j]);
			}

			/* See if "RESTART" occurs in the second line */
			if (strstr(aString, "RESTART")) {
				*isRestart = TRUE;
				fclose(input);
				return 0;
			}

			/* Look for ampersand in second line */
			for (j=0; j< strlen(aString); j++) {
				if ((aString[j] == '+') || (aString[j] == '&')) {
					havePlusOrAmpersand = true;
					break;
				}
			}
		}
		if (havePlusOrAmpersand) { /* get the third line */
			havePlusOrAmpersand = false;

			if (cfl_fgets(aString, sizeof(aString), input) == 0) {
				sprintf(aString,"isInputRestart: "
					"MOPAC Input file does not have a third line.");
				alert_user(aString);
				fclose(input);
				return -1;
			}

			/* Uppercase the string */
			for (j=0; j< strlen(aString); j++) {
				aString[j] = ToUpper(aString[j]);
			}

			/* See if "RESTART" occurs in the third line */
			if (strstr(aString, "RESTART")) {
				*isRestart = TRUE;
				fclose(input);
				return 0;
			}

		}
		fclose(input);
		return 0;
	}
				
}

int inputHasParams(Boolean *hasParams, char *fname)
{
	FILE *input = NULL;
	int  	numAmpersand, dummy1, dummy2, j;
	Boolean	haveInput = TRUE;
	char 	keywords[256], bString[256];
	char	*cptr;

	*hasParams = FALSE;

	if (!(input = fopen("MOPAC Input","r"))) {
		alert_user("inputHasParams: "
			"The MOPAC Input file cannot be opened.\n");
		return -1;
	} else {
		/*
		 * Read through MOPAC Input file.  Look for occurrence
		 * of EXTERNAL keyword in the various back-to-back
		 * data sets.
		 */
		while (haveInput) {
			if (getKeywordsFromInput(input, keywords, &numAmpersand) !=0 ) {
				alert_user("inputHasParams: "
					"Unable to get keywords from MOPAC Input.\n");
				fclose(input);
				return -1;
			}
			
			/* See if "EXTERNAL=" occurs in the keywords */
			if (cptr = strstr(keywords, "EXTERNAL=")) {

				if (strncmp(cptr, "EXTERNAL=", 9)) {
					alert_user("inputHasParams: strstr failed.\n");
					fclose(input);
					return -1;
				}
				cptr += 9;
				if ((sscanf(cptr, "%s", bString) == 1) &&
					bString[0] && (strlen(bString) <= 31)) {
					/* Only one EXTERNAL parameter file is permitted */
					if (*hasParams &&
						(strncmp(fname, bString, strlen(bString)) != 0)) {
						alert_user("Your MOPAC Input file requires "
							"(at least) two different EXTERNAL parameter "
							"files.  Please run this calculation as "
							"separate calculations that require only "
							"one distinct EXTERNAL parameter file each.");
						fclose(input);
						return -1;
					}
					/* Upper-case the parameter file name, since
					 * MOPAC will upper-case the keywords and then
					 * try to open the file with an all upper-case name
					 * (this will be a problem on UNIX machines)
					 */
					for (j=0; j< strlen(bString); j++) {
						bString[j] = ToUpper(bString[j]);
					}
					strcpy(fname, bString);
					*hasParams = TRUE;
				} else {
					alert_user("inputHasParams: External parameter file "
						"name is invalid.");
					fclose(input);
					return -1;
				}
			}
			
			/* Scan through input file to next keyword line */
			haveInput = 
				advanceToNextKeywords(input, keywords, NULL, 
						0, numAmpersand, &dummy1, &dummy2);
		}

		fclose(input);
		return 0;
	}
				
}

int inputHasSetup(Boolean *hasSetup, char *setupfname)
{
	FILE *input = NULL;
	int  	numAmpersand, dummy1, dummy2, j;
	Boolean	haveInput = TRUE;
	char 	keywords[256], bString[256];
	char	*cptr;

	*hasSetup = FALSE;

	if (!(input = fopen("MOPAC Input","r"))) {
		alert_user("inputHasSetup: "
			"The MOPAC Input file cannot be opened.\n");
		return -1;
	} else {
		/*
		 * Read through MOPAC Input file.  Look for occurrence
		 * of SETUP keyword in the various back-to-back
		 * data sets.
		 */
		while (haveInput) {
			if (getKeywordsFromInput(input, keywords, &numAmpersand) !=0 ) {
				alert_user("inputHasSetup: "
					"Unable to get keywords from MOPAC Input.\n");
				fclose(input);
				return -1;
			}
			
			/* See if "SETUP=" occurs in the keywords */
			if (cptr = strstr(keywords, "SETUP=")) {

				if (strncmp(cptr, "SETUP=", 6)) {
					alert_user("inputHasSetup: strstr failed.\n");
					fclose(input);
					return -1;
				}
				cptr += 6;
				if ((sscanf(cptr, "%s", bString) == 1) &&
					bString[0] && (strlen(bString) <= 31)) {
					/* Only one SETUP file is permitted */
					if (*hasSetup &&
						(strncmp(setupfname, bString, strlen(bString)) != 0)) {
						alert_user("Your MOPAC Input file requires "
							"(at least) two different SETUP files.  "
							"Please run this calculation as "
							"separate calculations that require only "
							"one distinct SETUP file each.");
						fclose(input);
						return -1;
					}
					/* 
					 * Upper-case the setup file name since MOPAC will
					 * upper-case the keywords, and then try to open
					 * the file with an all upper-case name (this will
					 * create a problem on UNIX machines)
					 */
					for (j=0; j< strlen(bString); j++) {
						bString[j] = ToUpper(bString[j]);
					}
					strcpy(setupfname, bString);
					*hasSetup = TRUE;
				} else {
					alert_user("inputHasSetup: External setup file "
						"name is invalid.");
					fclose(input);
					return -1;
				}
			}
			
			/* Scan through input file to next keyword line */
			haveInput = 
				advanceToNextKeywords(input, keywords, NULL, 
							0, numAmpersand, &dummy1, &dummy2);
		}

		fclose(input);
		return 0;
	}
				
}

int getKeywordsFromInput(FILE *input, char *keywords, int *numAmpersand)
{
	/*
	 * Utility function to extract keywords from a MOPAC Input
	 * or MOPAC Output file starting at the current line.
	 * The input file must be positioned at the begining of
	 * the keywords of a back-to-back input file.
	 * "keywords" must be long enough to contain the complete
	 * keyword string (255 characters is sufficient)
	 *
	 * "file" is positioned immediatly after the keywords on return.
	 */
	 
	int  	len, j, position;
	Boolean	havePlusOrAmpersand = false;
	Boolean precedingSpace = false;
	Boolean followingSpace = false;
	char aString[256], tmpkeywords[KEYWORD_LEN + 1];
	 
	*numAmpersand = 0;
	tmpkeywords[0] = 0;
	strncpy(keywords, tmpkeywords, KEYWORD_LEN);
	 
	if (cfl_fgets(aString, sizeof(aString), input) == 0) {
	 	alert_user("getKeywordsFromInput: Unable to get first line "
			"of keywords.\n");
	 	return -1;
	}
		
	len = strlen(aString);

	/* Uppercase the string */
	for (j=0; j< len; j++) {
		aString[j] = ToUpper(aString[j]);
	}

	for (j = 0, position = 0; j < len; j++) {

		/* See if there is a preceding space */
		if (j > 0 && aString[j-1] != ' ')
			precedingSpace = false;
		else
			precedingSpace = true;

		/* See if there is a following space */
		if (j < len - 1 && aString[j+1] != ' ' && aString[j+1] != '\n')
			followingSpace = false;
		else
			followingSpace = true;

		if (aString[j] == '\n') {
			if (position < KEYWORD_LEN - 1)
				tmpkeywords[position++] = ' ';

			break; /* Quit if at a newline */

		} else if (aString[j] == ' ') {
			if (precedingSpace)
				continue;
			else {
				if (position < KEYWORD_LEN - 1)
					tmpkeywords[position++] = aString[j];
				else
					break;
			}
		} else if (aString[j] == '+') {
			if (precedingSpace && followingSpace)
				havePlusOrAmpersand = true;
			else {
				if (position < KEYWORD_LEN - 1)
					tmpkeywords[position++] = aString[j];
				else
					break;
			}
		} else if (aString[j] == '&') {
			(*numAmpersand)++;
			if (precedingSpace && followingSpace) {
				havePlusOrAmpersand = true;
			} else
				continue;
		} else {
			if (position < KEYWORD_LEN - 1)
				tmpkeywords[position++] = aString[j];
			else
				break;
		}
	}

	/* If there is a SETUP file, read the next line as keywords */
	if (!havePlusOrAmpersand) {
		if (strstr(aString, "SETUP=") != NULL)
			havePlusOrAmpersand = TRUE;
	}

	if (havePlusOrAmpersand) { /* get the second line */
		havePlusOrAmpersand = false;
		if (cfl_fgets(aString, sizeof(aString), input) == 0) {
			alert_user("getKeywordsFromInput: Unable to get the second "
				"line of keywords.\n");
			return -1;
		}

		len = strlen(aString);

		/* Uppercase the string */
		for (j=0; j< len; j++) {
			aString[j] = ToUpper(aString[j]);
		}

		for (j = 0; j < len; j++) {

			/* See if there is a preceding space */
			if (j > 0 && aString[j-1] != ' ')
				precedingSpace = false;
			else
				precedingSpace = true;

			/* See if there is a following space */
			if (j < len - 1 && aString[j+1] != ' ' && aString[j+1] != '\n')
				followingSpace = false;
			else
				followingSpace = true;

			if (aString[j] == '\n') {
				if (position < KEYWORD_LEN - 1)
					tmpkeywords[position++] = ' ';

				break; /* Quit if at a newline */

			} else if (aString[j] == ' ') {
				if (precedingSpace)
					continue;
				else {
					if (position < KEYWORD_LEN - 1)
						tmpkeywords[position++] = aString[j];
					else
						break;
				}
			} else if (aString[j] == '+') {
				if (precedingSpace && followingSpace)
					havePlusOrAmpersand = true;
				else {
					if (position < KEYWORD_LEN - 1)
						tmpkeywords[position++] = aString[j];
					else
						break;
				}
			} else if (aString[j] == '&') {
				(*numAmpersand)++;
				if (precedingSpace && followingSpace) {
					havePlusOrAmpersand = true;
				} else
					continue;
			} else {
				if (position < KEYWORD_LEN - 1)
					tmpkeywords[position++] = aString[j];
				else
					break;
			}
		}
	}

	/* If there is a SETUP file, read the next line as keywords */
	if (!havePlusOrAmpersand) {
		if (strstr(aString, "SETUP=") != NULL)
			havePlusOrAmpersand = TRUE;
	}

	if (havePlusOrAmpersand) { /* get the third line */
		havePlusOrAmpersand = false;
		if (cfl_fgets(aString, sizeof(aString), input) == 0) {
			alert_user("getKeywordsFromInput: Unable to get the "
				"third line of keywords.\n");
			return -1;
		}

		len = strlen(aString);

		/* Uppercase the string */
		for (j=0; j< len; j++) {
			aString[j] = ToUpper(aString[j]);
		}

		for (j = 0; j < len; j++) {

			/* See if there is a preceding space */
			if (j > 0 && aString[j-1] != ' ')
				precedingSpace = false;
			else
				precedingSpace = true;

			/* See if there is a following space */
			if (j < len - 1 && aString[j+1] != ' ' && aString[j+1] != '\n')
				followingSpace = false;
			else
				followingSpace = true;

			if (aString[j] == '\n') {
				if (position < KEYWORD_LEN - 1)
					tmpkeywords[position++] = ' ';

				break; /* Quit if at a newline */

			} else if (aString[j] == ' ') {
				if (precedingSpace)
					continue;
				else {
					if (position < KEYWORD_LEN - 1)
						tmpkeywords[position++] = aString[j];
					else
						break;
				}
			} else if (aString[j] == '+') {
				if (precedingSpace && followingSpace)
					havePlusOrAmpersand = true;
				else {
					if (position < KEYWORD_LEN - 1)
						tmpkeywords[position++] = aString[j];
					else
						break;
				}
			} else if (aString[j] == '&') {
				if (precedingSpace && followingSpace) {
					havePlusOrAmpersand = true;
				} else
					continue;
			} else {
				if (position < KEYWORD_LEN - 1)
					tmpkeywords[position++] = aString[j];
				else
					break;
			}
		}
	}

	/* Null-terminate the keyword line */
	tmpkeywords[position] = 0;
	strncpy(keywords, tmpkeywords, KEYWORD_LEN);
	return 0;
	
}

Boolean advanceToNextKeywords(
	FILE *input, 
	char *keywords,
	char *formula,
	int maxLength,
	int numAmpersand,
	int *num_hydrogens, 
	int *num_heavy

)
{
	/*
	 * Utility routine to scan through a MOPAC Input file from
	 * the present position until the next set of keywords are
	 * located.  Assumes that "input" is positioned just past
	 * the keywords, and that "keywords" contains the keywords
	 * for the current back-to-back calculation.
	 *
	 * If maxLength > 0, the molecular formula is returned in
	 * "formula."  This formula is constructed the same way
	 * as getMolecularFormula does for molStructs.
	 */
	
	int 	i, linecount, optvar1, optvar2, optvar3;
	int		numberEach[TOTAL_NUM_ELEMS];
	long	file_position;
	float	geovar1, geovar2, geovar3;
	char 	aString[256];
	char	*cptr;
	char	firstchar, secondchar;
	Boolean	haveSteps = FALSE;
	Boolean haveAlphaChar, haveDigitChar;
	
	*num_hydrogens = *num_heavy = 0;

	if (maxLength > 0)
		for (i=0; i < TOTAL_NUM_ELEMS; i++)
			numberEach[i] = 0;

	/* Skip over title lines */
	for (i=numAmpersand; i<2; i++) {
		if (cfl_fgets(aString, sizeof(aString), input) == 0) {
			alert_user("advanceToNextKeywords: Unable to get the "
				"title lines.\n");
			return FALSE;
		}
	}
	
	if (strstr(keywords, "OLDGEO" ) == NULL) {
		/* Read in geometry */
		for (linecount = 0; ; linecount++) {
			if (cfl_fgets(aString, sizeof(aString), input) == 0) {
				alert_user("advanceToNextKeywords: Unable to read "
					"atom coordinate line.\n");
				return FALSE;
			}
			/*
			 * If this is a coordinate line, there will be at least
			 * one alphabetical character, plus or minus (for sparkles)
			 * in it.
			 */
			for (i = 0, haveAlphaChar = FALSE; i < strlen(aString); i++) {
				if(isalpha(aString[i])) {
					haveAlphaChar = TRUE;
					break;
				} else if (aString[i] == '+') {
					haveAlphaChar = TRUE;
					break;
				} else if (aString[i] == '-') {
					haveAlphaChar = TRUE;
					break;
				}
			}
			
			if (!haveAlphaChar)
				break;
			
			if (maxLength > 0) {
				/* 
				 * Get the atom's symbol and add to 
				 * molecular formula list 
				 */
				
				firstchar = ToUpper(aString[i]);
				secondchar = ToUpper(aString[i+1]);
				
				if (firstchar == 'H') {
					if (!isalpha(secondchar))
						numberEach[0]++; /* Hydrogen */
					else if (secondchar == 'E')
						numberEach[1]++; /* Helium */
					else if (secondchar == 'F')
						numberEach[71]++; /* Hafnium */
					else if (secondchar == 'O')
						numberEach[66]++; /* Holmium */
					else if (secondchar == 'G')
						numberEach[79]++; /* Mercury */
				} else if (firstchar == 'D') {
					if (!isalpha(secondchar))
						numberEach[0]++; /* Deuterium */
					else if (secondchar == 'Y')
						numberEach[65]++; /* Dysprosium */
				} else if (firstchar == 'L') {
					if (secondchar == 'I')
						numberEach[2]++; /* Lithium */
					else if (secondchar == 'A')
						numberEach[56]++; /* Lanthanum */
					else if (secondchar == 'U')
						numberEach[70]++; /* Lutetium */
					else if (secondchar == 'R')
						numberEach[102]++; /* Lawrencium */
				} else if (firstchar == 'B') {
					if (!isalpha(secondchar))
						numberEach[4]++; /* Boron */
					else if (secondchar == 'E')
						numberEach[3]++; /* Beryllium */
					else if (secondchar == 'R')
						numberEach[34]++; /* Bromine */
					else if (secondchar == 'A')
						numberEach[55]++; /* Barium */
					else if (secondchar == 'I')
						numberEach[82]++; /* Bismuth */
					else if (secondchar == 'K')
						numberEach[96]++; /* Berkelium */
				} else if (firstchar == 'C') {
					if (!isalpha(secondchar))
						numberEach[5]++; /* Carbon */
					else if (secondchar == 'L')
						numberEach[16]++; /* Chlorine */
					else if (secondchar == 'A')
						numberEach[19]++; /* Calcium */
					else if (secondchar == 'R')
						numberEach[23]++; /* Chromium */
					else if (secondchar == 'O')
						numberEach[26]++; /* Cobalt */
					else if (secondchar == 'U')
						numberEach[28]++; /* Copper */
					else if (secondchar == 'D')
						numberEach[47]++; /* Cadmium */
					else if (secondchar == 'S')
						numberEach[54]++; /* Cesium */
					else if (secondchar == 'E')
						numberEach[57]++; /* Cerium */
					else if (secondchar == 'M')
						numberEach[95]++; /* Curium */
					else if (secondchar == 'F')
						numberEach[97]++; /* Californium */
				} else if (firstchar == 'N') {
					if (!isalpha(secondchar))
						numberEach[6]++; /* Nitrogen */
					else if (secondchar == 'E')
						numberEach[9]++; /* Neon */
					else if (secondchar == 'A')
						numberEach[10]++; /* Sodium */
					else if (secondchar == 'B')
						numberEach[40]++; /* Niobium */
					else if (secondchar == 'I')
						numberEach[27]++; /* Nickel */
					else if (secondchar == 'D')
						numberEach[59]++; /* Neodymium */
					else if (secondchar == 'P')
						numberEach[92]++; /* Neptunium */
					else if (secondchar == 'O')
						numberEach[101]++; /* Nobelium */
				} else if (firstchar == 'O') {
					if (!isalpha(secondchar))
						numberEach[7]++; /* Oxygen */
					else if (secondchar == 'S')
						numberEach[75]++; /* Osmium */
				} else if (firstchar == 'F') {
					if (!isalpha(secondchar))
						numberEach[8]++; /* Fluorine */
					else if (secondchar == 'E')
						numberEach[25]++; /* Iron */
					else if (secondchar == 'R')
						numberEach[86]++; /* Francium */
					else if (secondchar == 'M')
						numberEach[99]++; /* Fermium */
				} else if (firstchar == 'M') {
					if (secondchar == 'G')
						numberEach[11]++; /* Magnesium */
					else if (secondchar == 'N')
						numberEach[24]++; /* Manganese */
					else if (secondchar == 'O')
						numberEach[41]++; /* Molybdenum */
					else if (secondchar == 'D')
						numberEach[100]++; /* Mendelevium */
				} else if (firstchar == 'A') {
					if (secondchar == 'L')
						numberEach[12]++; /* Aluminum */
					else if (secondchar == 'R')
						numberEach[17]++; /* Argon */
					else if (secondchar == 'S')
						numberEach[32]++; /* Arsenic */
					else if (secondchar == 'G')
						numberEach[46]++; /* Silver */
					else if (secondchar == 'U')
						numberEach[78]++; /* Gold */
					else if (secondchar == 'T')
						numberEach[84]++; /* Astatine */
					else if (secondchar == 'C')
						numberEach[88]++; /* Actinium */
					else if (secondchar == 'M')
						numberEach[94]++; /* Americium */
				} else if (firstchar == 'S') {
					if (!isalpha(secondchar))
						numberEach[15]++; /* Sulfur */
					else if (secondchar == 'I')
						numberEach[13]++; /* Silicon */
					else if (secondchar == 'C')
						numberEach[20]++; /* Scandium */
					else if (secondchar == 'E')
						numberEach[33]++; /* Selenium */
					else if (secondchar == 'R')
						numberEach[37]++; /* Strontium */
					else if (secondchar == 'N')
						numberEach[49]++; /* Tin */
					else if (secondchar == 'B')
						numberEach[50]++; /* Antimony */
					else if (secondchar == 'M')
						numberEach[61]++; /* Samarium */
				} else if (firstchar == 'P') {
					if (!isalpha(secondchar))
						numberEach[14]++; /* Phosphorus */
					else if (secondchar == 'D')
						numberEach[45]++; /* Palladium */
					else if (secondchar == 'R')
						numberEach[58]++; /* Praseodymium */
					else if (secondchar == 'M')
						numberEach[60]++; /* Promethium */
					else if (secondchar == 'T')
						numberEach[77]++; /* Platinum */
					else if (secondchar == 'B')
						numberEach[81]++; /* Lead */
					else if (secondchar == 'O')
						numberEach[83]++; /* Polonium */
					else if (secondchar == 'A')
						numberEach[90]++; /* Protactinium */
					else if (secondchar == 'U')
						numberEach[93]++; /* Plutonium */
				} else if (firstchar == 'K') {
					if (!isalpha(secondchar))
						numberEach[18]++; /* Potassium */
					else if (secondchar == 'R')
						numberEach[35]++; /* Krypton */
				} else if (firstchar == 'T') {
					if (!isalpha(secondchar))
						numberEach[0]++; /* Tritium */
					else if (secondchar == 'I')
						numberEach[21]++; /* Titanium */
					else if (secondchar == 'C')
						numberEach[42]++; /* Technetium */
					else if (secondchar == 'E')
						numberEach[51]++; /* Tellurium */
					else if (secondchar == 'B')
						numberEach[64]++; /* Terbium */
					else if (secondchar == 'M')
						numberEach[68]++; /* Thulium */
					else if (secondchar == 'A')
						numberEach[72]++; /* Tantalum */
					else if (secondchar == 'L')
						numberEach[80]++; /* Thallium */
					else if (secondchar == 'H')
						numberEach[89]++; /* Thorium */
					else if (secondchar == 'V')
						numberEach[103]++; /* Translation vector */
				} else if (firstchar == 'V') {
					if (!isalpha(secondchar))
						numberEach[22]++; /* Vanadium */
				} else if (firstchar == 'Z') {
					if (secondchar == 'N')
						numberEach[29]++; /* Zinc */
					else if (secondchar == 'R')
						numberEach[39]++; /* Zirconium */
				} else if (firstchar == 'G') {
					if (secondchar == 'A')
						numberEach[30]++; /* Gallium */
					else if (secondchar == 'E')
						numberEach[31]++; /* Germanium */
					else if (secondchar == 'D')
						numberEach[63]++; /* Gadolinium */
				} else if (firstchar == 'R') {
					if (secondchar == 'B')
						numberEach[36]++; /* Rubidium */
					else if (secondchar == 'U')
						numberEach[43]++; /* Ruthenium */
					else if (secondchar == 'H')
						numberEach[44]++; /* Rhodium */
					else if (secondchar == 'E')
						numberEach[74]++; /* Rhenium */
					else if (secondchar == 'N')
						numberEach[85]++; /* Radon */
					else if (secondchar == 'A')
						numberEach[87]++; /* Radium */
				} else if (firstchar == 'Y') {
					if (!isalpha(secondchar))
						numberEach[38]++; /* Ytrium */
					else if (secondchar == 'B')
						numberEach[69]++; /* Ytterbium */
				} else if (firstchar == 'I') {
					if (!isalpha(secondchar))
						numberEach[52]++; /* Iodine */
					else if (secondchar == 'N')
						numberEach[48]++; /* Indium */
					else if (secondchar == 'R')
						numberEach[76]++; /* Iridium */
				} else if (firstchar == 'X') {
					numberEach[53]++; /* Xenon or dummy atom */
				} else if (firstchar == 'E') {
					if (secondchar == 'U')
						numberEach[62]++; /* Europium */
					else if (secondchar == 'R')
						numberEach[67]++; /* Erbium */
					if (secondchar == 'S')
						numberEach[98]++; /* Einsteinium */
				} else if (firstchar == 'W') {
					if (!isalpha(secondchar))
						numberEach[73]++; /* Tungsten */
				} else if (firstchar == 'U') {
					if (!isalpha(secondchar))
						numberEach[91]++; /* Uranium */
				} else if (firstchar == '+') {
					if (secondchar != '+')
						numberEach[54]++; /* "+" sparkle -> Cs */
					else
						numberEach[55]++; /* "++" sparkle -> Ba */
				} else if (firstchar == '-') {
					if (secondchar != '-')
						numberEach[84]++; /* "-" sparkle -> At */
					else
						numberEach[83]++; /* "--" sparkle -> Po */
				}
			}
			
			i++;
			if (!haveSteps) {
				/* Scan past element and comment */
				if (isalpha(aString[i]) || aString[i] == '+' ||
					aString[i] == '-')
					i++;

				if ((cptr = strstr(aString, ")")) != NULL)
					cptr++;
				else
					cptr = aString + i;
					
				/* Now look for reaction coordinate variables */
				if (linecount == 0)
					continue;
				else if (linecount == 1) {
					sscanf(cptr, "%f %d", 
						&geovar1, &optvar1);
					if (optvar1 == -1)
						haveSteps = TRUE;
				} else if (linecount == 2) {
					sscanf(cptr, "%f %d %f %d", 
						&geovar1, &optvar1, &geovar2, &optvar2);
					if (optvar1 == -1 || optvar2 == -1)
						haveSteps = TRUE;
				} else {
					sscanf(cptr, "%f %d %f %d %f %d", 
						&geovar1, &optvar1, &geovar2, &optvar2, 
						&geovar3, &optvar3);
					if (optvar1 == -1 || optvar2 == -1 || optvar3 == -1)
						haveSteps = TRUE;
				}
			}
		}
		
		if (maxLength > 0) {
			buildFormula(numberEach, formula, 
							maxLength, TOTAL_NUM_ELEMS);
			*num_hydrogens = numberEach[0];
			for (i=1; i < TOTAL_NUM_ELEMS; i++)
				*num_heavy += numberEach[i];
		}

		/* Read past additional input for special cases */
		if (strstr(keywords, "SADDLE") != NULL) {
			/* Read past second geometry */
			for (linecount = 0; ; linecount++) {
				if (cfl_fgets(aString, sizeof(aString), input) == 0) {
					alert_user("advanceToNextKeywords: Unable to read "
						"atom coordinate line for target molecule.\n");
					return FALSE;
				}
				/*
				 * If this is a coordinate line, there will be at least
				 * one alphabetical character in it.
				 */
				for (i = 0, haveAlphaChar = FALSE; i < strlen(aString); i++) {
					if(isalpha(aString[i])) {
						haveAlphaChar = TRUE;
						break;
					}
				}
				
				if (!haveAlphaChar)
					break;
				
			}
		} else if (strstr(keywords, "SYMMETRY") != NULL) {
			/* Read past symmetry information */
			for ( ; ; ) {
				if (cfl_fgets(aString, sizeof(aString), input) == 0) {
					alert_user("advanceToNextKeywords: Unable to read "
						"symmetry information line.\n");
					return FALSE;
				}
				/*
				 * If this is a symmetry information line, there will 
				 * be at least one numerical character in it.
				 */
				for (i = 0, haveDigitChar = FALSE; i < strlen(aString); i++) {
					if(isdigit(aString[i])) {
						haveDigitChar = TRUE;
						break;
					}
				}
				
				if (!haveDigitChar) {
					/* There can be an additional line of symmetry info */
					long file_position;
					file_position = ftell(input);
					if (cfl_fgets(aString, sizeof(aString), input) == 0)
						break;

					for (i = 0, haveAlphaChar = FALSE, haveDigitChar = FALSE;
							i < strlen(aString); i++) {
						if(isalpha(aString[i])) {
							haveAlphaChar = TRUE;
							break;
						} else if (isdigit(aString[i])) {
							haveDigitChar = TRUE;
							break;
						}
					}
					if (haveAlphaChar) {
						/* This is a keywords line, so re-position the file */
						fseek(input, file_position, SEEK_SET);
					} else if (haveDigitChar) {
						/* 
						 * This is a symmetry line.  
						 * Read in the next line to skip it 
						 */
						if (cfl_fgets(aString, sizeof(aString), input) == 0) {
							alert_user("advanceToNextKeywords: Unable to read "
								"second blank line after symmetry information.\n");
							return FALSE;
						}
					}
					break;
				}
			}
		} else if (haveSteps && (strstr(keywords, "POINT") == NULL)) {
			/* Read past MOPAC 5-style reaction coordinate information */
			for ( ; ; ) {
				if (cfl_fgets(aString, sizeof(aString), input) == 0) {
					alert_user("advanceToNextKeywords: Unable to read "
						"reaction coordinate information line.\n");
					return FALSE;
				}
				/*
				 * If this is a coordinate value line, there will 
				 * be at least one numerical character in it.
				 */
				for (i = 0, haveAlphaChar = FALSE; i < strlen(aString); i++) {
					if(isdigit(aString[i])) {
						haveAlphaChar = TRUE;
						break;
					}
				}
				
				if (!haveAlphaChar)
					break;
				
			}
		} 
	}
	
	/* See if there are more lines past this point */
	file_position = ftell(input);
	
	if (cfl_fgets(aString, sizeof(aString), input) == 0)
		return FALSE;
	/* 
	 * Check to see if this is a keyword line.
	 * If the line contains keywords, it will have alpha characters.
	 */
	for (i = 0, haveAlphaChar = FALSE; i < strlen(aString); i++) {
		if(isalpha(aString[i])) {
			haveAlphaChar = TRUE;
			break;
		}
	}
	if (haveAlphaChar) {
		fseek(input, file_position, SEEK_SET);
		return TRUE;
	} else
		return FALSE;
}
