/*
** Chemistry Property Utilities header file
**
** 27/Jun/2000 Ingvar Lagerstedt, Oxford Molecular
**             Moved ConnProp structure def to csu.h (as in Client side code)
** 07/Dec/2000 IL Added cpu_getOrbList(), cpu_freeOrbList(), and AtomOrbitalList{}
**             Taken from beautify code
*/

#ifndef _CPU_
#define _CPU_

#ifndef RC_INVOKED     	// Do only error #defines if compiling resources

#include "csu.h"
#include "csuWin.h"

#ifndef __CMU__
#include "cmu.h"
#endif

#endif	// RC_INVOKED     	// Do only error #defines if compiling resources

#define cpu_OK 				0	/* rendering completed successfully */
#define cpu_AllocFailed			-400	/* memory allocation failed */
#define cpu_InvalidMolStruct		-401	/* molecule structure invalid */
#define cpu_NoWorkSpace			-402
#define cpu_EndOfList			-403
#define cpu_InvalidAnum			-404	/* anum < 1 or anum > CPUMaxAnum */
#define cpu_InvalidSGfile 		-405	/* The space group file is invalid */
#define cpu_BadGeom			-406	/* bad geometry */
#define cpu_InvalidXrayfile 		-407	/* The Xray coord file is invalid */
#define cpu_InvalidSymbol		-408
#define cpu_TransNotFound 		-409	/* no equ pos trans match found */
#define cpu_NoSuchBond 			-410	/* The requested bond does not exist */
#define	cpu_NoConfiguration		-411	/* Configuration property missing */
#define cpu_NoBondList			-412	/* couldn't build bond list */
#define	cpu_NoBondTypes			-413	/* Type property missing */
#define	cpu_NotFound			-414	/* Requested object not found */
#define	cpu_Duplicate			-415	/* A duplicate was found */
#define cpu_LockedGeom			-416	/* locks prevented geometry adjustment */
#define cpu_CollinearPoints		-417	/* Atmpt to create dihedral w/collinear pts */
#define cpu_ArrayBoundsExceeded		-418	/* Continuing execution would exceed an array bound */
#define cpu_InvalidGroupIndex		-419	/* groupIndex < 0 or groupIndex > CPUMaxPDBGroups */
#define cpu_InvalidGroupName		-420	/* group name is not defined in PDB dictionary */

#ifndef RC_INVOKED     	// Do only error #defines if compiling resources

/* define object selection flags */
#define USELECT		0x0001	/* selected by user */
#define TSELECT1	0x0002	/* temporarily selected by application */
#define TSELECT2	0x0004	/* ditto */
#define TSELECT3	0x0008	/* ditto */
#define TSELECT		0x000e	/* all three TSELECT flags combined */

#ifndef SMALL_NO
#define SMALL_NO	0.000001
#endif

/* bond type definitions */
#define BondOrder	3 /* lowest two bits represent bond order */
#define IonicBond	0
#define SingleBond	1
#define DoubleBond	2
#define TripleBond	3
#define WeakBond	4
#define CoordBond	5 /* coordinate bond, electrons "belong" to first member */

/* flags for cpu_FormBonds() */

#define CPU_FB_REBOND			  1
#define CPU_FB_WEAKBONDS		  2
#define CPU_FB_IONICBONDS		  4
#define CPU_FB_FORCETYPE		  8
#define CPU_FB_TYPEONLY			 16

/* data types for crystallography */
#define MXEQUPOS 196 /* the maximum number of possible equivalent positions for a space group */
#define MXINEQ 20 /* the maximum number of inequalities needed to identify a point as inside the asymmetric cell */
#define MXAUCE 20 /* the maximum number of edges that an asymmetric cell will ever have */
#define ToUpper(c) (((c) >= 'a' && (c) <= 'z') ? (c - ('a' - 'A')) : c)
#define ToLower(c) (((c) >= 'A' && (c) <= 'Z') ? (c + ('a' - 'A')) : c)
typedef double (*xyz)[3]; /* a three dimensional point */
typedef char (*Symbols)[4];
typedef char (*CoordTrans)[MS_RECLEN];
typedef long (*Bonds)[2];	/* JJS - int to long - can't find use ???? */
typedef double (*Tran)[3][MXEQUPOS]; /* eauivalent position transforms */
typedef double (*AsymInequ)[2][5]; /* inequalities for asymmetric cell */
typedef double (*AsymUntCelEdg)[6]; /* edges for asymmetric cell */
typedef struct {
	double Te[4][4];
} EquPosTransRec, *EquPosTransPtr;

/* call back function to indicate progress */
typedef CelErr (*ProgressFunc)(double fraction_done, char *text);

typedef ValueH DefPvalH;
typedef void (*DefPvalFunc)(); /* default property values function */

typedef DefPvalFunc * DefPvalFuncH;
#define cpu_ObjclsIndex(objcls_locH, objclsID)	*((objcls_locH) + (objclsID))
#define cpu_PropIndex(prop_locH, propID, objclsID)	*((prop_locH) + ((propID) \
		+ ((objclsID) * DataDict.num_props)))

typedef struct {
	double (*relpt)[3];	/* coordinates of points, relative to central point */
	char *pflag;		/* flags describing point attributes:
							CPUPtFor1, a point for first non-moving atom
							CPUPtFor2, a point for second non-moving atom
							CPUPtIsOrb, point for orbital only
							CPUPtInvalid, invalid point (do not use)
							CPUPtReserved, reserved point (do not use)
							CPUPtTaken, occupied point (temporary flag)
						*/
	long num_pts;		/* number of points */
	NameNID conf;		/* name index of configuration */
} ConfTemplate;

/* define pflag bits for configuration templates */
#define CPUPtFor1		0x01
#define CPUPtFor2		0x02
#define CPUPtIsOrb		0x08
#define CPUPtInvalid	0x10
#define CPUPtReserved	0x20
#define CPUPtTaken		0x40

// DW 5/24/94 Moved cpu_GetConnProps to csu library since it seems to be a lower-level
// function that can live in csu.  
//  A macro that equates cpu_GetConnProps to csu_GetConnProps has been put into cpu.h
//   to provide backward compatibility with all the code which already calls cpu_GetConnProps

typedef csu_ObjPair *cpu_BondObjsP;

typedef struct {
    long n_count;		/* number of neighbors,
							< 0 indicates an invalid atom,
							ed_EndOfList means no more valid atoms */
	ObjectID (*n_list)[2];	/* list of atom neighbors where neighbor n is
							represented by an atom index, n_list[n][0],
							and a bond index, n_list[n][1],
							and 0 <= n < n_count */
} NbrRec, *NbrList;

typedef struct {
	CSUObj nbr; /* neighbor object, attached by bond */
	ObjectID bi; /* index of bond which connects neighbor */
} BondedNbr;

typedef struct {
    long n_count;		/* number of neighbors for object,
							< 0 indicates an invalid object,
							ed_EndOfList means no more valid objects */
	BondedNbr *n_list;	/* list of bonded neighbors where neighbor n is
							represented by an object class, n_list[n].nbr.oci,
							an object index, n_list[n].nbr.obi,
							and a bond index, n_list[n].bi,
							and 0 <= n < n_count */
} BondNbrsRec, *BondNbrsP;

typedef struct {
	ConnProps conn_props; /* basic connector properties */
	cpu_BondObjsP blist; /* objects connected by bonds */
	BondNbrsP atom_nbrs; /* objects bonded to atoms */
	BondNbrsP bond_nbrs; /* objects bonded to bonds */
} cpu_NbrObjs;

typedef struct {
    ObjectID lowerbound;
	ObjectID upperbound;
	ObjectID top;
	ObjectID *a_stack;
} AtomStack, *AtomStackPtr;

typedef struct {
    ObjectID lowerbound;
	ObjectID upperbound;
	ObjectID top;
	CSUObj *obj_stack;
} ObjStack, *ObjStackPtr;

// Added 07/Dec/2000 IL, this was previously a local structure in the beautify code,
// but is of more general use.
typedef struct {
    short o_count;      /* number of orbitals connected to atom,
                            < 0 indicates an invalid atom,
                            cpu_EndOfList means no more valid atoms */
    ObjectID *o_list;   /* list of orbitals where orbital n is
                            represented by an object index, o_list[n],
                            and 0 <= n < o_count */
} AtomOrbitals, *AtomOrbitalList;

/* prototypes */

#ifdef __cplusplus	/* For type-safe linkage */
extern "C" {		/* Specify "C"-style linkage */
#endif

Boolean cpu_canBondInMolstruct(
	MolStruct *msPtr,
	double point[], /* equivalent position point to see if can bond with any atoms in molstruct */
	const short id, /* index of originating atom */
	short *const bndtyp
);

// DW 5/24/94 Moved csu_AddMolstruct to cpu library since it knows about selection
//   flags, which are defined in cpu.h, and csu shouldn't be dependent on anything
//   in cpu            

CelErr cpu_AddMolstruct(
	MolStruct * msPtr_from, 
	MolStruct * msPtr_to, 
	int add_objcls, 
	int add_prop
);

CelErr cpu_findBondIndexBetween(
	const MolStruct *const msPtr,
	const ObjectID atomIndex1,
	const ObjectID atomIndex2,
	ObjectID *const bondIndex
);

Boolean cpu_CanLabelBeSearched(
	MolStruct *msPtr,
	ObjclsID label_ocid, 	/* driver label objcls index in DataDict */
	CSUObj *objs,	  	/* array of 2-4 objects (objcls ID + index) for label */
	short move_flag
);

CelErr cpu_CreateLabel(
	MolStruct *msPtr,
	ObjclsID label_ocid,
	CSUObj *objs,
	ObjectID *label_index
);

CelErr cpu_CreateSearchLabel(
	MolStruct *msPtr,
	ObjclsID label_ocid,
	CSUObj *objs,
	ObjectID *label_index,
	double low_val,
	double hi_val,
	long num_steps
);

void cpu_EPAtoEC(
	double P[][3], /* row matrix of principal axes vectors */
	double A[][3]  /* for the form XtAX = d */
);

CelErr cpu_EECtoPA(
	double A[][3]  /* for the form XtAX = d on input row matrix of principal axes vectors on output*/
);

CelErr cpu_GetBondVector(
	MolStruct *msPtr,
	ObjectID attachment_atom_index,
	double *bond_vector
);

CelErr cpu_FindBondVector(
	ObjectID ca,		/* index of central atom */
	ObjectID nbra[],	/* indexes of neighbor objects */
	ObjclsID nbr_oc[],	/* objclsID of neighbor objects */
	ObjectID num_nbrs,	/* number of neighbor objects */
	double (*a_xyz)[3],	/* atom coordinates */
	double (*o_xyz)[3],	/* orbital coordinates */
	ConfTemplate *idealP,	/* ideal geometry points */
	double *bond_vector
);

CelErr cpu_FindConnectedLonePairIDs(
	MolStruct *msPtr,
	ObjectID a_id,
	long *num_lone_pairs,
	ObjectID connected_lp[]
);

CelErr cpu_FindConnectedAtomIDs(
	MolStruct *msPtr,
	ObjectID a_id, /* Atom id of the central atom */
	long max_num, /* The maximum possible number of connected atoms. This
                         is the length of the caller allocated array in which
                         to put the connected atom id's (connected_atoms) */
	long *num_atoms, /* The number of connected atoms found */
	ObjectID connected_atoms[] /* array to contain connected atom id's */
);

double cpu_RotErrRMS( double (*r)[3],
                      double (*vset1)[3],
                      double (*vset2)[3],
                      ObjectID n_v );

CelErr cpu_connectAtomsToObj(
	MolStruct *msPtr,
	ObjectID objectID,
	ObjclsID objclsID,
	u_char dflag		/* data dependency flag */
);

CelErr cpu_onlyAtomsConnectedToObjcls(
	MolStruct *msPtr,
	ObjclsID objclsID
);

CelErr cpu_GetMolstructCrystalTransform(
	MolStruct *msPtr,
	double *a,
	double *b,
	double *c,
	double *alpha,
	double *beta,
	double *gamma,
	double Tc[][4],
	double Tf[][4]
);

CelErr cpu_ComputeCrystalTransform(
	double a,
	double b,
	double c,
	double alpha,
	double beta,
	double gamma,
	double Tc[][4],
	double Tf[][4]
);

CelErr cpu_duplicateObject(
	MolStruct *msPtr,
	ObjclsID ocID,	/* object class id */
	ObjectID obid,	/* source object id */
	ObjectID obid2	/* destination object id */
);

CelErr cpu_onlyConnectedAtoms(
	MolStruct *msPtr
);

CelErr cpu_connectAtoms(
	MolStruct *msPtr
);

CelErr cpu_findChemicalUnit(MolStruct *msPtr);

Boolean cpu_pointExistsInMolstruct(
	MolStruct *msPtr,
	double Tf[][4],
	double point[],
	double e[]
);

short cpu_CanBond(
	const double *const c1,
	const double *const c2,
	const short ia,
	const short ja,
	short *const bndtyp
);

CelErr cpu_Init();

CelErr cpu_getBondEndObjs(
	MolStruct *mp,		/* molecule pointer */
	ObjectID bond,	/* index of bond */
	CSUObj *o1,		/* first object connected to bond */
	CSUObj *o2		/* second object connected to bond */
);

CelErr cpu_getBondEndObjects(
	MolStruct *mp,	/* molecule pointer */
	ObjectID bond_id,	/* ID of bond */
	CSUObject *o1,		/* first object connected to bond */
	CSUObject *o2		/* second object connected to bond */
);

CelErr cpu_getBondObjList(
	MolStruct *mp, /* molecule pointer */
	cpu_BondObjsP *blistp, /* returned bond list */
	ConnProps *connP /* caller-supplied connector properties, if != NULL */
);

void cpu_freeBondObjList(cpu_BondObjsP blist);

CelErr cpu_getNbrObjs(MolStruct *mp, cpu_NbrObjs *nbr_objs);

void cpu_freeNbrObjs(cpu_NbrObjs *nbr_objs);

Boolean objPush(CSUObj obj, ObjStackPtr stack);

Boolean objPop(CSUObj *obj, ObjStackPtr stack);

long cpu_getOrbitalsForAtom(
	ConnProps *connP,
	ObjectID atomi,
	ObjectID *orb_list,
        long max_count
);

CelErr cpu_FlagObjBranch(
	MolStruct *mp,
	cpu_NbrObjs *nbr_objs, /* bonded neighbor info */
	CSUObj obj, /* object (objcls ID + obj index) to be flagged */
	short flag, /* flag to be set */
	UCharH atom_dflagH, /* if non-NULL, used to flag atoms (else gotten from mp) */
	UCharH bond_dflagH, /* if non-NULL, used to flag bonds */
	long bt_mask /* bits set for bond types to be ignored */
);

void cpu_FlagAtomNbr(
	MolStruct *mp,
	cpu_NbrObjs *nbr_objs, /* neighbor info */
	ObjectID ai, /* index of atom */
	CSUObj nbr, /* bonded neighbor */
	UCharH atom_dflagH,
	short a_flag /* flag to be set for neighbor branch */
);

void cpu_FlagObjBranchExcept(
	MolStruct *mp,
	cpu_NbrObjs *nbr_objs, /* neighbor info */
	CSUObj b_obj, /* object branch to flag */
	CSUObj *e_obj, /* pointer to list of end objects */
	long num_e, /* number of end objects in list */
	UCharH atom_dflagH,
	UCharH bond_dflagH,
	short flag, /* flag to set for neighbor branches which don't flag end objects */
	short test_flag /* flag to test for flagging of end objects */
);

CelErr cpu_getBondList(MolStruct *mp, ObjectID (**blistp)[2]);
CelErr cpu_getNbrList(MolStruct *, NbrList *);
CelErr cpu_freeNbrList(NbrList);

double cpu_SBLength( short btype,
                     ObjectID a1,
                     ObjectID a2,
                     short *anum,
                     short *conf );

BOOL cpu_NotSmallAngle(double angle);

CelErr cpu_GetObjPos(
	CSUObj obj,
	double obj_pos[3],
	cpu_NbrObjs *nbr_objsP, /* neighbor info */
	double (*a_xyz)[3] /* atom coordinates */
);

short cpu_GuessDAngle(
	/* return -1 if there is no dihedral angle */
	MolStruct *mp,
	BondNbrsP atom_nbrs, /* neighbor list */
	ObjectID bond,	/* index of bond to adjust dihedral angle on */
	ObjectID atom1, /* index of first atom joined by bond */
	ObjectID atom2, /* index of second atom joined by bond */
	short move_flag /* flag which identifies the moving atoms */
	/* NOTE: atom1 and its neighbors should already be flagged for movement */
);

short cpu_GuessDihedralAtoms(
/* return -1 if there is no dihedral angle  3-1-2-4 */
	MolStruct *mp,
	BondNbrsP atom_nbrs, /* neighbor list */
	ObjectID bond, /* index of bond to adjust dihedral angle on */
	ObjectID atom1, /* index of first atom joined by bond */
	ObjectID atom2, /* index of second atom joined by bond */
	ObjectID *atom3, /* index of the atom attached to atom 1 */
	ObjectID *atom4  /* index of the atom attached to atom 2 */
);

/* JJS - Added proto gau2.c */
Boolean cpu_GeomIsLocked(MolStruct *mp);

CelErr cpu_BeautifyGeom(
	MolStruct *mp,
	cpu_NbrObjs *nbr_objsP, /* neighbor info */
	short sel_flag, /* mark atoms to be beautified */
	short move_flag, /* flag for moving atoms */
	short max_anum /* don't adjust atoms whose anum exceeds this */
);

CelErr cpu_BeautifyBondLengths(
	MolStruct *mp,
	cpu_NbrObjs *nbr_objsP, /* neighbor info */
	short sel_flag, /* mark atoms to be beautified */
	short move_flag, /* flag for moving atoms */
	short max_anum /* don't adjust atoms whose anum exceeds this */
);

CelErr cpu_FixConfGeom(
	ObjectID ca,		/* index of central atom */
	MolStruct *mp,		/* molecule structure */
	cpu_NbrObjs *nbr_objsP,	/* neighbor info */
        CSUObj mova[],          /* moving objects */
        ObjectID mov,           /* number of moving objects */
        CSUObj nmova[],         /* non-moving objects */
        ObjectID nmov,          /* number of non-moving objects */
	short move_flag,	/* used to mark moving objects */
	double (*a_xyz)[3],	/* atom coordinates */
	double (*o_xyz)[3],	/* orbital coordinates */
        ConfTemplate *idealP,   /* ideal geometry points */
	short conf,		/* atom configuration (used if idealP == NULL) */
        short *anum             /* atom atomic numbers */
);

void cpu_MoveLockedAtoms(Boolean can_move);

/* JJS - Added void as parameters */
Boolean cpu_LockedAtomsMove(void);

void cpu_LockFlaggedAtoms(
	MolStruct *msPtr,
	short flag
);

void cpu_UnlockFlaggedAtoms(
	MolStruct *msPtr,
	short flag
);

void cpu_LockFlaggedLabels(
	MolStruct *msPtr,
	short flag
);

void cpu_UnlockFlaggedLabels(
	MolStruct *msPtr,
	short flag
);

Boolean cpu_LockedObjFlagged(
	ObjectID num_objs,
	BitH lockH,
	BitH validH,
	UCharH dflagH,
	short flag
);

Boolean cpu_LockedObjPropFlagged(
	MolStruct *msPtr,
	ObjclsID ocid,
	PropID pid,
	short flag
);

/* determine whether locked atoms are flagged */
Boolean cpu_LockedAtomFlagged(
	MolStruct *mp,
	short flag
);

/* flag locked atoms, return false if no unflagged locked atoms found */
Boolean cpu_FlagLockedAtoms(
	MolStruct *mp,
	short flag
);

/* JJS - Added proto qau1.c */
void cpu_FlagArm( MolStruct *msPtr,
                  NbrList nbr_list, /* neighbor list */
                  long cntr,
                  long arm,
                  UCharH atom_dflagH,
                  short a_flag );

void cpu_FlagSelObjForMove(MolStruct *msPtr, short sel_flag, short mov_flag);

short cpu_NumObjsInLabel(ObjclsID label_ocid);

Boolean cpu_Label1AdjustsLabel2(
	MolStruct *mp,
	ObjclsID label1_ocid, /* driver label objcls index in DataDict */
	CSUObj *objs1,	/* array of 2-4 objects (objcls ID + index) for label1 */
	ObjclsID label2_ocid, /* other label objcls index in DataDict */
	CSUObj *objs2,	/* array of 2-4 objects (objcls ID + index) for label2 */
	short mov_flag	/* flag, set by caller, for the moving objects for label1 */
); /* return true if second label would be adjusted, false if same labels */

Boolean cpu_MoveAdjustsLock(
	MolStruct *mp,
	short num_ctrs, /* number of centers of rotation */
	CSUObj *objs, /* centers of rotation, if any */
	short mov_flag
);

/* return true if locked geometry would be moved, false if locks are disabled */
Boolean cpu_LabelAdjustsLock(
	MolStruct *mp,
	ObjclsID label_ocid, /* driver label objcls index in DataDict */
	CSUObj *objs,	/* array of 2-4 objects (objcls ID + index) for label */
	short mov_flag	/* flag, set by caller, for the moving objects for label */
);

/* return true if able to flag for moving, false if unable to */
Boolean cpu_FlagLabelForMove(
	MolStruct *mp,
	ObjclsID label_ocid,	/* object class ID of label */
	CSUObj *objs,	/* array of 2-4 objects (objcls ID + index) for label */
					/* the first object in the list is the one that moves */
	cpu_NbrObjs *nbr_objsP,	/* neighbor info */
	short mov_flag,	/* for moving objects */
	short stop_flag	/* to stop non-moving objects */
					/* if non-zero, allows changes to internal coordinates of
					   molecule by marking the non-moving objects which have been
					   flagged for movement so that they can be unflagged */
					/* if zero, no changes to internal coordinates are allowed */
);

Boolean cpu_CanSearchLabel(
	MolStruct *mp,
	ObjclsID label_ocid, /* object class ID of label */
	CSUObj *objs, /* array of 2-4 objects (objcls ID + index) for label */
	cpu_NbrObjs *nbr_objsP,	/* neighbor info */
	short mov_flag,	/* for moving objects */
	short stop_flag	/* to stop non-moving objects */
);

Boolean cpu_CanLockLabel(
	MolStruct *mp,
	ObjclsID label_ocid,	/* object class ID of label */
	ObjectID label_obi,	/* index of label to be locked */
	cpu_NbrObjs *nbr_objsP,	/* neighbor info */
	short mov_flag,         /* for moving objects */
	short stop_flag         /* to stop non-moving objects */
);

Boolean cpu_DisableBadSearches(
	MolStruct *mp,
	cpu_NbrObjs *nbr_objsP	/* neighbor info, can be NULL */
); /* return true if search labels were disabled */

CelErr cpu_AdjustLabel(
	MolStruct *mp,
	ObjclsID label_ocid, /* object class ID of label */
	CSUObj *objs, /* array of 2-4 objects (objcls ID + index) for label */
	cpu_NbrObjs *nbr_objsP,	/* neighbor info */
	double value /* the value to set for the label */
);

CelErr cpu_MoveSelected(MolStruct *msPtr, short sel_flag, double cpoint[3]);

Boolean atomPush(ObjectID aID, AtomStackPtr stack);
Boolean atomPop(ObjectID *aID, AtomStackPtr stack);
long cpu_btype_bit(short);

CelErr cpu_FindConnectedAtoms( ObjectID atom,
                               UCharH atom_dflagH,
                               UCharH bond_dflagH,
                               NbrList nbr_list,
                               AtomStackPtr stack,
                               short flag );

void cpu_FlagBranch( MolStruct *,
                     NbrList,
                     ObjectID,
                     short,
                     UCharH,
                     UCharH,
                     long );

void cpu_FlagBranchExcept( MolStruct *mp,
                           NbrList nbr_list,
                           ObjectID c_atom,
                           ObjectID *e_atom, /* pointer to list of end atom indices */
                           long num_e,       /* number of end atoms in list */
                           UCharH atom_dflagH,
                           short flag,
                           short test_flag );

short cpu_ExistsAdjust(
	MolStruct *mp,
	ObjectID atom_list[],
	ObjclsID objclsID,
	ObjectID *object_id
);

short cpu_LabelStatus( MolStruct *mp,
                       ObjectID *atom_list,
                       ObjclsID objclsID,
                       ObjectID *objectID,
                       double *low,
                       double *high,
                       long *steps );

void cpu_getLabelAtoms( MolStruct *mp,
                        ObjectID atom_list[],
                        ObjclsID objclsID,
                        ObjectID label_index );

void cpu_getLabeledItems( MolStruct *mp,
                          ObjectID sel_list[],
                          ObjclsID type_list[],
                          ObjclsID objclsID,
                          ObjectID label );

short cpu_AdjustGeom( MolStruct *mp,
                      ObjclsID objclsID,
                      ObjectID atoms[],
                      NbrList nbr_list,
                      double value );

BOOL pts_in_line(double p1[], double p2[], double p3[]);

double mapShortToDouble(double low, double hi, short number);

short mapDoubleToShort(double low, double hi, double number);

double cpu_alphaFrom4points(double *p1, double *p2, double *p3, double *p4, double *R);

double cpu_ImpTorThetaFromAlpha(double alpha);

double cpu_ImpTorAlphaFromTheta(double thetaD, double alpha);

/* JJS - added proto geomlbl.c */
Boolean cpu_HasLockedLabel(MolStruct *mp);

void cpu_PRotate(double ang, double a[], double p[], double point[]);

void cpu_PTranslate(double v1[], double delta, double point[]);

void ftranslate(MolStruct *mp, double v1[], double delta, short flag);

short cpu_XformMolstruct(MolStruct *mp, short flag, double t[4][4]);

short frotate(MolStruct *mp, short flag, double angle, double axis[], double point[]);

short rotate3d(double t[4][4], double angle, double axis[], double point[]);

void vector_mult3d(double vector[], double xform[4][4], double outvec[]);

void xform_point(double m[4][4], double p[], double r[]);

double vec_signed_ang(double a[], double b[]);

short cpu_BestVRotation(
	double (*pset1)[3],
	double (*pset2)[3],
	ObjectID n_p,
	Boolean translate, /* if true, translate origin */
	double rt[4][4], /* cmu_RTSPoint(pset1[i], rt, pset2[i]) */
	double *ang_err, /* RMS error in radians between (pset1 * rt) and pset2 */
	double *w	/* weighting factors (NULL if all vectors have equal weight) */
);

short cpu_BestRotation( double (*pset1)[3],
                        double (*pset2)[3],
                        ObjectID n_p,
                        Boolean translate,
                        double rt[4][4],
                        double *ang_err );

long cpu_Flag1of2( MolStruct *mp,
                   ObjectID *atom_list, /* first element is count, followed by atom indexes */
                   short s_flag,        /* used to flag selected atoms (e.g. USELECT) */
                   short m_flag,        /* used to flag moving atoms (e.g. TSELECT1) */
                   ObjectID *pair_list  /* atom_list sorted into pairs */ );

long cpu_Flag1of2Pairs(
	MolStruct *mp,
	ObjectID *atom_list,
	short s_flag,
	short m_flag,
	ObjectID *pair_list
);

Boolean cpu_UpdateSuperposition (MolStruct *aMSPtr, ObjectID aIndex, Boolean aUpdateXYZ, double aTrans[4][4]);
Boolean cpu_CalculateRMS (MolStruct *aMSPtr, ObjectID aIndex, Boolean aUpdateXYZ);
CelErr cpu_SuperpositionCanBond (MolStruct *aMSPtr, ObjclsID aOC1, ObjectID aO1, ObjclsID aOC2, ObjectID aO2, Boolean *aCanBond);
CelErr cpu_SuperpositionCheck (MolStruct *aMSPtr, ObjectID *aAtomList, Boolean aComplete, ObjectID *aGroupID);
int cpu_Superimpose (MolStruct *mp, ObjectID *atom_list, short s_flag, short m_flag, Boolean move);
int cpu_SuperimposePairs (MolStruct *mp, ObjectID *atom_list, short s_flag, short m_flag, Boolean move);
int cpu_RMSErrorPairs (MolStruct *mp, ObjectID *atom_list, short s_flag, short m_flag);
CelErr cpu_SuperpositionFlag (MolStruct *aMSPtr, ObjectID aIndex, short aFlag1, short aFlag2, Boolean aMolecule, Boolean aFlag);
CelErr cpu_FlagFragment (MolStruct *msPtr,ObjclsID objclsID,ObjectID obi,short flag,short branch_flag);
CelErr cpu_FlagFragmentEx (MolStruct *msPtr,ObjclsID objclsID,ObjectID obi,short flag,short branch_flag, ObjectID* count);
CelErr cpu_UnflagFragment(MolStruct *msPtr,ObjclsID objclsID,ObjectID obi,short flag,short branch_flag);

CelErr cpu_Fix3dPos(
	long ca,		/* index of central atom */
	MolStruct *mp,		/* molecule structure */
	NbrList nbr_list,	/* neighbor list */
	long mova[],		/* indexes of moving objects */
	long mov_oc[],		/* objclsID of moving objects */
	ObjectID mov,		/* number of moving objects */
	long nmova[],		/* indexes of non-moving atoms */
	ObjectID nmov,		/* number of non-moving atoms */
	short move_flag,	/* used to mark moving objects */
	double (*a_xyz)[3],	/* atom coordinates */
	double (*o_xyz)[3],	/* orbital coordinates */
	ConfTemplate *idealP    /* ideal geometry points */
);

ShortH cpu_GetObjclsLoc(MolStruct *);

ShortH cpu_GetPropLoc(MolStruct *);

// DW 5/24/94 Moved cpu_GetConnProps to csu library since it seems to be a lower-level
// function that can live in csu.  
//  A macro that equates cpu_GetConnProps to csu_GetConnProps has been put into cpu.h
//   to provide backward compatibility with all the code which already calls cpu_GetConnProps
#define cpu_GetConnProps csu_GetConnProps

short cpu_BondColor(short);

void cpu_SetMaxChiralRecursionLevel(short max_r_level);

short cpu_GetMaxChiralRecursionLevel();

CelErr cpu_ChiralCenter( MolStruct *mp,
                         ObjectID a_i,
                         char *chiral_status );

CelErr cpu_InvertChiral( MolStruct *mp,
                         short sel_flag,
                         short move_flag );

/* functions to get and set properties of elements in periodic table */
CelErr cpu_GetAnumFromSymbol(
	char *symbol,
	short *anum
);

char *cpu_GetSymbol(short anum);

CelErr cpu_SetSymbol(short anum, char *sym);

double cpu_GetCovRadius(short anum, double charge);

CelErr cpu_SetElCovRadius(MolStruct *msPtr);

CelErr cpu_SetCovRadius(short anum, double charge, double rad);

double cpu_GetAtomRadius(short anum, double charge);

CelErr cpu_SetAtomRadius(short anum, double charge, double rad);

double cpu_GetVDWRadius(short anum, double charge);

CelErr cpu_SetVDWRadius(short anum, double charge, double rad);

short cpu_GetAtomColorID(short anum);

CelErr cpu_SetAtomColorID(short anum, short colorID);

double cpu_GetPaulingElneg(short anum);

CelErr cpu_SetPaulingElneg(short anum, double elneg);

double cpu_GetAtomicWeight(short anum);

CelErr cpu_SetAtomicWeight(short anum, double aw);

CelErr cpu_ReadPeriodicTable(FILE *fp);

CelErr cpu_WritePeriodicTable(FILE *fp);

/* Functions to get and set group  names and types in PDB dictionary*/
int cpu_GetDictGroupCount();
char* cpu_GetDictGroupPDBName(int groupIndex);
CelErr cpu_SetDictGroupPDBName(int groupIndex, const char *GroupPDBName);
CelErr cpu_GetDictGroupIndexFromPDBName(const char *GroupPDBName, int *groupIndex);
CelErr cpu_GetDictGroupIndexFromCode(char AAcode, int *groupIndex);
CelErr cpu_GetDictGroupIndexFromShortCut(const char *groupShortCut, int *groupIndex);

/* Functions to get and set other group properties in the dictionary */
/* group types */
long cpu_GetDictGroupType(char* GroupPDBName);
long cpu_GetDictGroupTypebyIndex(int groupIndex);
CelErr cpu_SetDictGroupType(int groupIndex, long type);
/* one-letter code */
char cpu_GetDictGroupOneLetterCode(const char* GroupPDBName);
char cpu_GetDictGroupOneLetterCodebyIndex(int groupIndex);
CelErr cpu_SetDictGroupOneLetterCode(int groupIndex, char Code);
/* filename */
char* cpu_GetDictGroupFilename(const char* GroupPDBName);
char* cpu_GetDictGroupFilenamebyIndex(int groupIndex);
CelErr cpu_SetDictGroupFilename(int groupIndex, char* filename);
/* shortcut */
char* cpu_GetDictGroupShortCut(const char* GroupPDBName);
char* cpu_GetDictGroupShortCutbyIndex(int groupIndex);
CelErr cpu_SetDictGroupShortCut(int groupIndex, char* shortcut);



bool cpu_IsPDBAtomOnBackbone(char* sAtomPDBName);

CelErr cpu_AddPDBGroup(const char *GroupPDBName, long type, char code);
CelErr cpu_RemovePDBGroup(const char *GroupPDBName);
void cpu_ReadPDBGroupDict();
void cpu_WritePDBGroupDict();

#define AA_CGF_MAX					32		//18 are taken from OMIGA
#define AA_TYPES_MAX					27    //maximum for CGF values, 26 letters plus *
#define AA_EPITOPE_MAX				14		//?? are taken from OMIGA
#define DEFAULT_MIN_MAX_COLORS   12		//default colors count for sequence protocols

typedef struct
{
	char Name[NAMELEN];
	char Description[MS_NAMELEN];
	int  iTypesCount;
	char TypeName[AA_TYPES_MAX][NAMELEN];
	int  RGB[AA_TYPES_MAX][3];
	short colorID[AA_TYPES_MAX];
	char AAgroupTypes[AA_TYPES_MAX];

} CGFColorSchemeStruct, *CGFColorSchemeStructPtr;

int* cpu_GetCGFResidueColor(char AAcode, int iColorScheme);
short cpu_GetCGFResidueColorID(char AAcode, int iColorScheme);
char* cpu_GetCGFColorSchemeName(int iColorScheme);
char* cpu_GetCGFColorSchemeDesc(int iColorScheme);
int cpu_GetCGFColorSchemeTypeCount(int iColorScheme);
char* cpu_GetCGFColorSchemeTypeName(int iColorScheme, int iType);
int* cpu_GetCGFColorSchemeTypeColor(int iColorScheme, int iType);

typedef struct
{
	char Name[NAMELEN];
	char Description[MS_NAMELEN];
	int  iWindowSize;
	double Params[AA_TYPES_MAX];
} EpitopeProtocolsStruct, *EpitopeProtocolsStructPtr;

double cpu_GetEpitopeParam(char AAcode, int iEpitopeProtocol);
char* cpu_GetEpitopeProtocolName(int iEpitopeProtocol);
char* cpu_GetEpitopeProtocolDesc(int iEpitopeProtocol);
int cpu_GetEpitopeProtocolWindowSize(int iEpitopeProtocol);
void cpu_SetEpitopeProtocolWindowSize(int iEpitopeProtocol, int iWindowSize);
int* cpu_GetSeqProtocolColor(int iEpitopeProtocol, int colorID);
int cpu_GetSeqProtocolColorsCount(int iEpitopeProtocol);
void cpu_ComputeSeqProtocolValues(int iEpitopeProtocol, char* buffSeq, double* SeqValues, int iSeqLen, int* SeqValuesValid);
void cpu_ComputeKarplusSchulzValues(char* buffSeq, double* SeqValues, int iSeqLen, int* SeqValuesValid);

/* functions that support crystallography */

short strncmpNoCase(const char *s1, const char *s2, short n);

void convertToLower(char *s1, short n);

CelErr cpu_BuildUnitCell(
	MolStruct *msPtr,
	int nequ,
	double a,
	double b,
	double c,
	double low_ncella,
	double low_ncellb,
	double low_ncellc,
	double ncella,
	double ncellb,
	double ncellc,
	EquPosTransPtr trans,
	double Tf[][4],
	double Tc[][4],
	ProgressFunc funcP
);

CelErr	cpu_GetSpGrFromTrans(
	char *SpaceGroupFile, 	/* name of file containing space groups */
	int no_s_equ,		/* number of equivalent position transforms in the search array */
	EquPosTransPtr s_trans,	/* array of 4 x 4 homogeneous equivalent position transform matrices to be
				   used to find the space group whose equivalent position transforms match */
	char *SpaceGroup, 	/* string representing the space group who's equivalent
				   position transforms match those in trans */
	char *descriptor 	/* the descriptor for the space group */
);

CelErr	cpu_GetSpGrFromfullHMsymbol(
	const char *SpaceGroupFile,/* input - name of file containing space groups */
	const char *fullHMsym,		/* input - The full Hermann-Mauguin symbol for the space group */
	char *HMsym,					/* output - The Hermann-Mauguin symbol for the space group */
	char *descriptor				/* output - String representing the descriptor */
);

CelErr	cpu_GetfullHMsymbolFromSpaceGroup(
	const char *SpaceGroupFile, 		/* input - name of file containing space groups */
	const char *HMsym,					/* input - The Hermann-Mauguin symbol for the space group */
	const char *descriptor,				/* input - String representing the descriptor */
	char *fullHMsym				/* output - The full Hermann-Mauguin symbol for the space group */
);

CelErr cpu_FormBonds(
	MolStruct *const msPtr,
	const unsigned long flags,
	ProgressFunc funcP
);

Boolean	cpu_PointInAsymUnit(
	int nIneq,		/* Number of Asymmetric Unit inequalities */
	AsymInequ asymIneq,	/* Pointer to array of Asymmetric inequalties */
	double p[],
	double Tf[][4]
);

Boolean	cpu_PointInCell(
	double p[],
	double ncella,
	double ncellb,
	double ncellc
);

void atchrg(
	int *charge,
	char *symbol,
	int *ierr
);

CelErr	cpu_GetAsymInEqu(
	char *string, 		/* of asymmetric unit inequalities */
	int *nIneq,		/* Number of Asymmetric Unit inequalities */
	AsymInequ asymIneq	/* Pointer to array of Asymmetric inequalties */
);

CelErr cpu_GetSpaceGroupInfo(
	char *SpaceGroupFile, 		/* Name of file containing space groups */
	char *HMsym,			/* The Hermann-Mauguin symbol for the space group */
	char *CrystalSystem,		/* Crystal system for the space group */
	char *cell_ch,			/* String representing the cell choice */
	char *fullHMsym,		/* The full Hermann-Mauguin symbol for the space group */
	int *nIneq,			/* Number of Asymmetric Unit inequalities */
	AsymInequ asymIneq,	  	/* Pointer to array of Asymmetric inequalties */
	int *nAsyEdgs,			/* Number of asymmetric unit edges */
	AsymUntCelEdg asymUntCelEdgs,	/* Pointer to array of edges for the asymmetric polyhedron */
	int *nequ,			/* Number of equivalent positions */
	EquPosTransPtr trans		/* Transforms for the equivalent positions */
);

CelErr cpu_CheckConf(
	MolStruct *const msPtr,
	const short sel_flag,
	const Boolean cleanup
);

/* JJS - Changed name from const char * to char * */
/* DW - Changed name back to const char * */
CelErr cpu_CreateGroup(MolStruct *msPtr, const char *name, ObjectID *groupID);

CelErr cpu_GetMolgroupByName(
	const MolStruct *const msPtr,
	const char *const name,
	ObjectID *const groupID
);

CelErr cpu_AddObjectToGroup(
	MolStruct *msPtr,
	const ObjclsID objcls,
	const ObjectID object,
	const ObjectID groupID
);

CelErr cpu_GroupFlag(MolStruct *wp, ObjectID molindex, short flags, Boolean aMolecule, Boolean aFlag);
CelErr cpu_GroupFindAtom(MolStruct *wp, ObjectID groupStart, ObjectID atomIndex);

//
//SS 15.11.2000
//Routines for manipulating residues
//implemented for the PDB input/output filter
//used in OMChemicalSample classes
//
CelErr cpu_GetTotalResidueCount(MolStruct *wp, long* theResidueCount);
CelErr cpu_GetGroupSize(MolStruct *wp, ObjectID Group_index, long* NOfAtoms);
CelErr cpu_GetGroupAtoms(MolStruct *wp, ObjectID Residue_index, 
									ObjectID* ObjList, long* NOfAtoms);
CelErr cpu_GetAtomResidueTable(MolStruct *wp,ObjectID** ObjList, long* NOfAtoms);
 
// DW 5/16/94 Moved CheckBonds from editor to cpu so that it can be called
// from translators too.
CelErr cpu_CheckBonds(MolStruct* msPtr);

void cpu_UnflagBranch(
	MolStruct *mp,
	NbrList nbr_list, /* list of all atom neighbors */
	ObjectID a_index, /* atom index */
	short flag,
	UCharH atom_dflagH,
	UCharH bond_dflagH,
	long bt_mask /* bits set for bond types to be ignored */
);


// IL 07/Dec/2000 Moved getOrbList and freeOrbList from Editor to cpu,
// as they are needed in cpu_BeautifyGeom
AtomOrbitalList cpu_getOrbList( MolStruct *mp, ConnProps *connP );
void cpu_freeOrbList( AtomOrbitalList aoList );

/* globals */
extern double *glp1, *glp2, *glp3, *glp4; /* four points defining a geometry label value to communicate with scroll action */
extern double R_Axis[3]; /* rotation axis for geometry labels */
extern ConfTemplate cpu_Octahedral;
extern ConfTemplate cpu_SqrPlanar;
extern ConfTemplate cpu_Pyramidal;
extern ConfTemplate cpu_Linear;
extern ConfTemplate cpu_Tetrahedral;
extern ConfTemplate cpu_TrBiPyramidal;
extern ConfTemplate cpu_TriPlanar;
extern ConfTemplate cpu_SqrPyramidal;

#ifdef __cplusplus
}
#endif

/* The colors from black through yellow are defined in Inside Mac V. */

#ifndef _COLOR_DEFS_
#define _COLOR_DEFS_

/*
**	A color ID associates a color name with an index.
**	These are the default colors for the indexes;
**	the aplication specifies the actual colors.
*/

#define GRAY		0
#define DK_GRAY		1
#define RED			2
#define YELLOW		3
#define GREEN		4
#define BLUE		5
#define PURPLE		6
#define CYAN		7
#define BROWN		7

#endif /* _COLOR_DEFS_ */

#define CPUMaxAnum 105 /* Highest atomic number represented in periodic table */
#define CPUMaxPDBGroups 250 /* highest number of groups, that can be stored in CPU */
#define CPUPredefinedGroups 40 /* number of predefined factory groups, which cannot be changed by the user */

/* macros */
#define labPropFrObjCls(objclsID)  (((objclsID) == Atom_distID ? DistanceID : AngleID))
#define rngPropFrObjCls(objclsID)  (((objclsID) == Atom_distID ? DistanceRangeID : AngleRangeID))

#endif	// RC_INVOKED     	// Do only error #defines if compiling resources

#endif /* _CPU_ */
