#ifndef	_CONN_H
#define	_CONN_H

enum connbl {
	connblfa = 0,
	connbltr
};

enum conner {
	connernun = 0,
	connerunk = -10000,
	connerrei,
	connereti,
	connereif,
	connerx,
	connermccf,
	connermpcf,
	connermsaf,
	connermraf,
	connermrf,
	connermwf,
	connermaf,
	connermcf
};

#endif /* _CONN_H */
