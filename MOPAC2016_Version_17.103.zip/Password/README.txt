For "perpetual" licenses, use:   999 Commercial 1 <Name of customer>
For multiple licenses, use:      <name> Commercial 15 <Name of customer>  (for 15 licenses)
For time-limited, use: 9  (for 9 weeks)
