#include <compat.h>
#include <MOPACDriver.h>

int PutMOPACControlFile(FILE *file, MOPACControl *controlPanel)
{
	CheckControlPanel(controlPanel);
	
	/*      Write Control settings  	*/

	if (fprintf(file,"startMOPAC\n") < 0) return (-1);
	if (fprintf(file,"   calculate %d\n",
				controlPanel->calculate) < 0) return (-1);
	if (fprintf(file,"   multiplicity %d\n",
				controlPanel->multiplicity) < 0) return (-1);
	if (fprintf(file,"   parameters %d\n",
				controlPanel->parameters) < 0) return (-1);
	if (fprintf(file,"   geometrySearch %d\n",
				controlPanel->geometrySearch) < 0) return (-1);
	if (fprintf(file,"   minimizeGradient %d\n",
				controlPanel->minimizeGradient) < 0) return (-1);
	if (fprintf(file,"   rotationalSymmetry %d\n",
				controlPanel->rotationalSymmetry) < 0) return (-1);
	if (fprintf(file,"   maxSCFiterations %d\n",
				controlPanel->maxSCFiterations) < 0) return (-1);
	if (fprintf(file,"   scfConverger %d\n",
				controlPanel->scfConverger) < 0) return (-1);
	if (fprintf(file,"   CIlevel %d\n",
				controlPanel->CIlevel) < 0) return (-1);
	if (fprintf(file,"   CItype %d\n",
				controlPanel->CItype) < 0) return (-1);
	if (fprintf(file,"   CIroot %d\n",
				controlPanel->CIroot) < 0) return (-1);
	if (fprintf(file,"   timeLimit %d\n",
				controlPanel->timeLimit) < 0) return (-1);
	if (fprintf(file,"   timeLimitUnits %d\n",
				controlPanel->timeLimitUnits) < 0) return (-1);

    if (fprintf(file,"   title\n") < 0) return (-1);
	if (fprintf(file,"%s\n",controlPanel->title) < 0) return (-1);

    if (fprintf(file,"   extraKeyWords\n") < 0) return (-1);
	if (fprintf(file,"%s\n",controlPanel->extraKeyWords) < 0) return (-1);

	if (fprintf(file,"   saveHOMO %d\n",
				controlPanel->saveHOMO) < 0) return (-1);
	if (fprintf(file,"   saveLUMO %d\n",
				controlPanel->saveLUMO) < 0) return (-1);

	if (fprintf(file,"   ircMode %d\n",
				controlPanel->ircMode) < 0) return (-1);
				
	if (fprintf(file,"   drcMode %d\n",
				controlPanel->drcIrcMode) < 0) return (-1);
				
    if (fprintf(file,"   addKEforDRC %f\n",
				controlPanel->addKEforDRC) < 0) return (-1);

    if (fprintf(file,"   addKEforIRC %f\n",
				controlPanel->addKEforIRC) < 0) return (-1);

    if (fprintf(file,"   DRCdampKinetic %d\n",
				controlPanel->DRCdampKinetic) < 0) return (-1);

    if (fprintf(file,"   DRChPrio %d\n",
				controlPanel->DRChPrio) < 0) return (-1);

    if (fprintf(file,"   DRCtPrio %d\n",
				controlPanel->DRCtPrio) < 0) return (-1);

    if (fprintf(file,"   DRCxPrio %d\n",
				controlPanel->DRCxPrio) < 0) return (-1);

    if (fprintf(file,"   halfLifeForDRC %f\n",
				controlPanel->halfLifeForDRC) < 0) return (-1);

    if (fprintf(file,"   hPrioStep %f\n",
				controlPanel->hPrioStep) < 0) return (-1);

    if (fprintf(file,"   tPrioStep %f\n",
				controlPanel->tPrioStep) < 0) return (-1);

    if (fprintf(file,"   xPrioStep %f\n",
				controlPanel->xPrioStep) < 0) return (-1);

    if (fprintf(file,"   controlRestart %d\n",
				controlPanel->controlRestart) < 0) return (-1);

    if (fprintf(file,"   searchType %d\n",
				controlPanel->searchType) < 0) return (-1);

    if (fprintf(file,"   MOZYME %d\n",
				controlPanel->MOZYME) < 0) return (-1);

    if (fprintf(file,"   detailsGeoType %d\n",
				controlPanel->detailsGeoType) < 0) return (-1);

    if (fprintf(file,"   detailsMMOK %d\n",
				controlPanel->detailsMMOK) < 0) return (-1);

    if (fprintf(file,"   detailsEnergyPart %d\n",
				controlPanel->detailsEnergyPart) < 0) return (-1);

    if (fprintf(file,"   detailsESR %d\n",
				controlPanel->detailsESR) < 0) return (-1);

    if (fprintf(file,"   detailsLocalize %d\n",
				controlPanel->detailsLocalize) < 0) return (-1);

    if (fprintf(file,"   detailsMulliken %d\n",
				controlPanel->detailsMulliken) < 0) return (-1);

    if (fprintf(file,"   detailsPI %d\n",
				controlPanel->detailsPI) < 0) return (-1);

    if (fprintf(file,"   detailsPolar %d\n",
				controlPanel->detailsPolar) < 0) return (-1);

    if (fprintf(file,"   detailsThermo %d\n",
				controlPanel->detailsThermo) < 0) return (-1);

    if (fprintf(file,"   detailsBondOrder %d\n",
				controlPanel->detailsBondOrder) < 0) return (-1);

    if (fprintf(file,"   detailsDensity %d\n",
				controlPanel->detailsDensity) < 0) return (-1);

    if (fprintf(file,"   detailsFock %d\n",
				controlPanel->detailsFock) < 0) return (-1);

    if (fprintf(file,"   detailsGradients %d\n",
				controlPanel->detailsGradients) < 0) return (-1);

    if (fprintf(file,"   detailsInterADist %d\n",
				controlPanel->detailsInterADist) < 0) return (-1);

    if (fprintf(file,"   detailsXYZCoord %d\n",
				controlPanel->detailsXYZCoord) < 0) return (-1);

    if (fprintf(file,"   detailsSpin %d\n",
				controlPanel->detailsSpin) < 0) return (-1);

    if (fprintf(file,"   detailsVectors %d\n",
				controlPanel->detailsVectors) < 0) return (-1);

    if (fprintf(file,"   detailsPrecise %d\n",
				controlPanel->detailsPrecise) < 0) return (-1);

    if (fprintf(file,"   detailsLarge %d\n",
				controlPanel->detailsLarge) < 0) return (-1);

    if (fprintf(file,"   detailsAnalytGrad %d\n",
				controlPanel->detailsAnalytGrad) < 0) return (-1);

    if (fprintf(file,"   detailsExternParam %d\n",
				controlPanel->detailsExternParam) < 0) return (-1);

    if (fprintf(file,"   detailsUseXYZ %d\n",
				controlPanel->detailsUseXYZ) < 0) return (-1);

    if (fprintf(file,"   detailsDIIS %d\n",
				controlPanel->detailsDIIS) < 0) return (-1);

    if (fprintf(file,"   detailsKeepOrient %d\n",
				controlPanel->detailsKeepOrient) < 0) return (-1);

    if (fprintf(file,"   controlUseCosmo %d\n",
				controlPanel->controlUseCosmo) < 0) return (-1);

    if (fprintf(file,"   cosmoDielectric %lf\n",
				controlPanel->cosmoDielectric) < 0) return (-1);

    if (fprintf(file,"   cosmoRadius %lf\n",
				controlPanel->cosmoRadius) < 0) return (-1);

    if (fprintf(file,"   temperature\n") < 0) return (-1);
	if (fprintf(file,"%s\n",controlPanel->temperature) < 0) return (-1);

    if (fprintf(file,"   cosmoSolvent\n") < 0) return (-1);
	if (fprintf(file,"%s\n",controlPanel->cosmoSolvent) < 0) return (-1);

	if (fprintf(file,"endMOPAC\n") < 0) return (-1);
	
	return (0);
}

void CheckControlPanel(MOPACControl *controlPanel)
{
	int i;
	i = controlPanel->calculate;
}
