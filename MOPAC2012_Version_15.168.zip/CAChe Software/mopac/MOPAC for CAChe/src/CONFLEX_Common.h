/*
** MODULE:
**	CONFLEX_Common.h
**
** DESCRIPTION:
**	Definitions for CONFLEX defines, structures.
**
** NOTES:
**
** HISTORY:
**	10/Jul/98 - KazuoOhta - Created.
*/

/* Duplicate header file lock */
#ifndef __CFX_COMMON__
#define __CFX_COMMON__

#include <compat.h>
#include <csu.h>
#include <cpu.h>
#include <cul.h>
#include <cmu.h>
#include <SSQFileTypes.h>
#include <CACheFileLib.h>

/* Things that are R/W from settings file. */

/*
** Mol/map (data) file, optional CFX accessory file and optional log
** file are output files.
**
** Even though the 'Extended Huckel Output' file and the log file aren't
** always generated data areas are always allocated in the output file
** list structure.
*/
/*
** File types that are put in file lists telling what file is used for.
*/
enum CFX_file_type
{
	CFX_MM_SETTINGS_FILE = ssq_file_custom,
	CFX_MM_PARAMETERS_FILE,
	CFX_DUMMY_FILE = ssq_file_dummy
};

#define CONFLEX_TMPFILE_NAME "ConflexOutputFileList.tmp"

typedef struct
{
	char name[32]; /* name of driver */
	char units[32]; /* name of units for driver values */
	double low_value; /* lowest value of driver */
	double hi_value; /* highest value of driver */
	long sub_steps; /* number of sequential frames between change of value */
	short num_steps; /* number of values driver is set to */
	short cur_step; /* index for current value of driver */
} DriverRec;

typedef struct
{
	char objcls_name[32]; /* name of object class */
	char prop_name[32]; /* name of property */
	char units[32]; /* name of units for property */
	double mult_std; /* for conversion to std units, zero if no conversion */
	double offset; /* for unit conversion */
	long f_bytes; /* number of bytes per frame for all values in this group */
	short v_bytes; /* number of bytes per value field */
	short vec_len; /* number of fields per value */
	short cfx_vtype; /* type of data stored in file */
	short num_IDs; /* number of IDs, equals number of values per frame */
	short *ID_list; /* list of IDs for objects in molstruct */
} DependRec;

typedef struct
{
	long movie_start; /* file offset to start of binary movie data */
	long f_bytes; /* number of bytes per frame */
	long num_frames; /* number of data frames in the movie file */
	long cur_frame; /* current frame (0 <= cur_frame < num_frames) */
	short num_drives; /* number of independent driving variables */
	short num_depends; /* number of dependent driven variables */

	DriverRec *driverP; /* handle to array of drivers */
	DependRec *dependP; /* handle to array of depends */
} MovieTable;

#define CFX_RUNNING				1		/* 68K tells 88K to start calc */
#define CFX_STOPPED				2		/* 68K tells 88K to stop calc */
#define CFX_WAITING				4		/* 88K is waiting for 68K */
#define CFX_QUITTING			8		/* 88K quits application */
#define CFX_ERROR_EXIT			128		/* Error in application code. */

#define MAXCNF						5000
#define MAXTBONDS					10
#define DUMMY_INT                -999     /* dummy integer for initialization */

#define CFX_ERROR					-1
#define CFX_NOERROR					0

/* Message control-structure pointers */
extern cul_CPMsgChannel *cfxMsg1, *cfxMsg2, *cfxMsg3;

/* Define number of channels and message channels IDs.*/
#define	CFX_NUM_CHANNELS		3		 /* Number of channels used */
#define CFX_MSG_BUFFER_SIZE		256		 /* Chars in channel message buffer */

/*
** Defines for message channels that write info in status box.
**
** NOTE:  These numbers should agree with those in ServerStepQueue.h
**
*/
#define CFX_SCROLL_MSG_CHAN		0		 /* Scroll area in sts dialog chan num	     */
#define CFX_CURRENT_CALC_CHAN	1		 /* Current calc in sts dialog box.			 */
#define CFX_CURRENT_OP_CHAN		2		 /* Current operation in sts dialog chan num */

/*
** This structure contains the number of input files and a buffer that holds
** the settings file and mol/map file names. The indexs for these are defined
** above.
*/
/* File name communication structures */

#define CFX_MAX_NUM_INPUT_FILES		5
#define CFX_MAX_NUM_OUTPUT_FILES	8

typedef struct
{
	long entryIsValid;	/* Boolean: indicates whether this entry is valid */
	char fileName[CFL_PATH_MAX];
} cfx_InputFileSpec, *cfx_InputFileSpecPtr;

typedef struct
{
	unsigned int maxNumEntries;
	cfx_InputFileSpec inputFileSpec[CFX_MAX_NUM_INPUT_FILES];
} cfx_InputFileList, *cfx_InputFileListPtr;

/* Defines of files in above list */

#define CFX_IL_SETTINGS		0		/* settings (control) file */
#define CFX_IL_MOLSTRUCT	1		/* file on which to work */
#define CFX_IL_MMSETTINGS	2		/* MM settings file */
#define CFX_IL_MMPARAMS		3		/* MM parameters file */
#define CFX_IL_DATADICT		4		/* path of data dictionary */

/* Definition of the calculation history information structure */

#ifndef __MM_COMMON__
#define ServerNameSize 32 /* should match ssq_ServerNameSize */
typedef struct CalcHistInfo
{
	char serverName[ServerNameSize];
} CalcHistInfo, *CalcHistInfoPtr;
#endif

typedef struct cfx_OutputFileSpec
{
	long CACheFolderType;
	long CACheFileType;
	long CACheTransferFormat;
	long entryIsValid;	/* Boolean: indicates whether this entry is valid */
	char fileName[CFL_PATH_MAX];
} cfx_OutputFileSpec, *cfx_OutputFileSpecPtr;

typedef struct cfx_OutputFileList
{
    unsigned int maxNumEntries;
    cfx_OutputFileSpec outputFileSpec[CFX_MAX_NUM_OUTPUT_FILES];
} cfx_OutputFileList, *cfx_OutputFileListPtr;

typedef struct CFX_DriverParam
{
    cfx_InputFileListPtr	inputFileListPtr;
    cfx_OutputFileListPtr	outputFileListPtr;
    cul_CPMsgChannel		*msgChannelPtr;
    CalcHistInfoPtr			calcHistInfoP;
    char					*applicationVersionPtr;
    char					*serverNamePtr;
    char					*dateTimePtr;
    char					structureIsValid;
    char					runFlag;
} CFX_DriverParam, *CFX_DriverParamPtr;

/*
** Here data for the lists and communication area for the 88K are keep for
** the CFX application manager.
*/ 
typedef struct CFX_Settings
{
	void					*sharedMemAddr;
	cul_CPMsgChannel		*msgChannelPtr;
	cfx_InputFileList		inputFileList;
	cfx_OutputFileListPtr	outputFileListPtr;
} CFX_Settings, *CFX_SettingsPtr;

typedef enum
{
	Best,
	Sequence,
	All
}
cfx_outputFormat;

/*
**  Data structure for CONFLEX input control parameters
 	double			timeLimit;				: the time limit of calculation in secs
 	double			timeLimitUnits;			:  the units of the time limits
 	cfx_outputFormat outputFormat;			:  output format
	char			version[32];			:  the date/time of compilation of this version
	char			datetime[32];			:  the date and time string for the calculation
	char			molStructName[256];		:  the name of the molecule file
	char			startupVolume[32];		:  the name of the startup Volume
	char			SystemFolderPath[256];
	char			CACheSystemPath[256];
	char			settingFileName[256];	:  Settings file name
	char			inpbuff[768];			:  holds contents of .inp file
*/

typedef struct CFXControl
{
 	double			timeLimit;
 	double			timeLimitUnits;
 	cfx_outputFormat outputFormat;
	int				seqFile;
	int				molFile;
	char			version[32];
	char			datetime[32];
	char			molStructName[256];
	char			startupVolume[32];
	char			SystemFolderPath[256];
	char			CACheSystemPath[256];
	char			settingFileName[256];
	char			inpbuff[768];
 } CFXControl, *CFXControlPtr;

/*
**  Data structure for CONFLEX COMMON parameters
*/

typedef struct CFXControl1
{
	short			searchLimitUnits;
	short			symmetryCheck;
	short			preCheck;
	short			condense;
	short			characterize;
	short			Methods;
	short			history;
	short			PrintControl;
} CFXControl1;

typedef struct CFXControl2
{
	short			maxNoConformers;
	float			highestStericEnergy;
	float			flapDistance;
	float			compareStericEnergy;
	float			compareDihedralAngle;
	float			energyMinimum;
	float			energyMaximum;
	float			searchLimit;
} CFXControl2;

typedef struct CFXcnf
{
	float			egynw[MAXCNF];
	char			lcnd[MAXCNF];
	char			lflp[MAXCNF];
	short			idnumb[MAXCNF];
	short			nconf;
	short			natoms;
	short			inum;
} CFXcnf, *CFXcnfPtr;

typedef struct CFXOptim
{
    float           ENERGY;
    float            TMAX;
	short			iters1;
} CFXOptim;

#if defined(cache_irix) || defined(_WIN32)
#define F77_FN(fn)      fn##_
#else
#define F77_FN(fn)      fn
#endif

/*
** External declarations of CONFLEX Common blocks
*/

#if defined(cache_irix)
#define CFXCONTROL1	cfxcontrol1_
#define CFXCONTROL2	cfxcontrol2_
#define OPTIM		optim_
#elif defined(cache_aix)
#define CFXCONTROL1	cfxcontrol1
#define CFXCONTROL2	cfxcontrol2
#define OPTIM		optim
#elif defined(cache_bsd)
#define CFXCONTROL1	_Ccfxcontrol1
#define CFXCONTROL2	_Ccfxcontrol2
#define OPTIM		_COPTIM
#elif defined(_WIN32)
#define CFXCONTROL1	_Ccfxcontrol1
#define CFXCONTROL2	_Ccfxcontrol2
#define OPTIM		_Coptim
#else
#define CFXCONTROL1	cfxcontrol1
#define CFXCONTROL2	cfxcontrol2
#define OPTIM		OPTIM
#endif

extern CFXControl1	CFXCONTROL1;
extern CFXControl2	CFXCONTROL2;
extern CFXOptim		OPTIM;

/*
** Simplified Env structure for unix version -- The Env structure
** for the coprocessor and Mac versions can be found in Env.h
*/
#if defined (unix) || defined (_WIN32)

#ifndef __MM_COMMON__
typedef struct Environ
{
    long	user[16];	
}
Environ, *EnvPtr;
#endif

extern volatile Environ *Env;
#endif

/* Ring size */
#define CHSIZE 32

#endif /* __CFXCOMMON__ */
