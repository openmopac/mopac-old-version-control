/*
 * CACheEventsFTM.h
 */

#ifndef	CACHE_EVENTS_FTM_H
#define	CACHE_EVENTS_FTM_H

#include <CACheMacros.h>

#define ftm_MsgClass	CM_C4TOLONG('F','T','M','c')
#define ftm_MsgAckID	CM_C4TOLONG('F','T','M','a')	
#define ftm_MsgReqID	CM_C4TOLONG('F','T','M','r')
#define ftm_MsgAbtID	CM_C4TOLONG('F','T','M','b')

/* Abort file transfer (Client->Server). */
struct cev_FTMAbt {
	UEM_UNIX_EVENT_BASE

	/* MESSAGE */
	ftm_AbtMsg msg;

	/* REPLY */
};

/* Ack file transfer (Server->Client). */
struct cev_FTMAck {
	UEM_UNIX_EVENT_BASE

	/* MESSAGE */
	ftm_AckMsg msg;

	/* REPLY */
};

/* Request file transfer (Client->Server). */
struct cev_FTMReq {
	UEM_UNIX_EVENT_BASE

	/* MESSAGE */
	ftm_ReqMsg msg;
	ftm_ReqMsgFileListPtr msgFileList;

	/* REPLY */
	ftm_ReqReply reply;
	ftm_ReqReplyFileListPtr replyFileList;
};

#endif	/* CACHE_EVENTS_FTM_H */
