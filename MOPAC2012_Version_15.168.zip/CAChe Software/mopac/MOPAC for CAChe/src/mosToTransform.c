#include <compat.h>

#include <math.h>

#include "MOPACDriver.h"

void mosToTransform(Boolean UHF, double degeneracy_criterion, 
			double MOocc[], double eigenValues[], 
			int saveHOMO, int saveLUMO, int nOrbitals,
			int *startalpha, int *startbeta, int *vendalpha, int *vendbeta)
{
	int 	i;
	int 	homoalpha, homobeta;
	int		endalpha, endbeta, vstartalpha, vstartbeta;
	
	homoalpha = 0;
	homobeta = 0;
	
	for (i=0; i< nOrbitals; i++) {
		if (MOocc[i] > 0.0) 
				homoalpha = i;
	}
	if (UHF) {
		for (i=nOrbitals; i< 2*nOrbitals; i++) {
			if (MOocc[i] > 0.0) 
					homobeta = i;
		}
	}

	/* Check for degenerate HOMO */
	endalpha = homoalpha;
	endbeta = homobeta;
	*startalpha = homoalpha;
	*startbeta = homobeta;
  	for (i=homoalpha+1; i<nOrbitals; i++) {
		if (fabs((double)(eigenValues[i] - eigenValues[homoalpha])) > degeneracy_criterion) {
			endalpha = i - 1;
			break;
		} else
		endalpha = i;
	}
	for (i=homoalpha-1; i>=0; i--) {
		if (fabs((double)(eigenValues[i] - eigenValues[homoalpha])) > degeneracy_criterion) {
 			*startalpha = i + 1;
			break;
		} else
  		  	 *startalpha = i;
	}
	if (UHF) {
		for (i=homobeta+1; i<2*nOrbitals; i++) {
  			if (fabs((double)(eigenValues[i] - eigenValues[homobeta])) > degeneracy_criterion) {
				endbeta = i - 1;
				break;
			} else
				endbeta = i;
		}
		for (i=homobeta-1; i>=nOrbitals; i--) {
			if (fabs((double)(eigenValues[i] - eigenValues[homobeta])) > degeneracy_criterion) {
 				*startbeta = i + 1;
				break;
			} else
  		   		*startbeta = i;
		}
	}

 /*
  *  Determine if the Lowest Unoccupied MO is part of a degenerate
  *  set.
  */
  
	vstartalpha = endalpha + 1;
	vstartbeta = endbeta + 1;
	*vendalpha = endalpha + 1;
	*vendbeta = endbeta + 1;
	for (i=vstartalpha+1; i<nOrbitals; i++) {
 		if (fabs((double)(eigenValues[i] - eigenValues[vstartalpha])) > degeneracy_criterion) {
 			*vendalpha = i - 1;
 			break;
		} else
			*vendalpha = i;
	}
	if (UHF) {
 		for (i=vstartbeta+1; i<2*nOrbitals; i++) {
 			if (fabs((double)(eigenValues[i] - eigenValues[vstartbeta])) > degeneracy_criterion) {
 				*vendbeta = i - 1;
 					break;
			} else
				*vendbeta = i;
	 	}
	} 

	/* Add user-specified range to homo and lumo */
	*startalpha -= saveHOMO;
	if (*startalpha < 0)
		*startalpha = 0;
	*vendalpha += saveLUMO;
	if (*vendalpha >= nOrbitals)
		*vendalpha = nOrbitals -1;
	if(UHF) {
	 	*startbeta -= saveHOMO;
		if (*startbeta < nOrbitals)
			*startbeta = nOrbitals;
	 	*vendbeta += saveLUMO;
		if (*vendbeta >= 2*nOrbitals)
			*vendbeta = 2*nOrbitals-1;
	}
	
	if (*startalpha > *vendalpha) {
		i = *vendalpha;
		*vendalpha = *startalpha;
		*startalpha = i;
	}
	if (*startbeta > *vendbeta) {
		i = *vendbeta;
		*vendbeta = *startbeta;
		*startbeta = i;
	}
}
