/*
 * CACheServer.h
 */

#ifndef	_CACHE_SERVER_H_
#define	_CACHE_SERVER_H_

enum ux_Err {
	ux_ErrNone = 0,

	ux_ErrUnknown = -9299,
	ux_ErrOperationFailed,
	ux_ErrOutOfMemory,
	ux_ErrCannotOpenLogFile,
	ux_ErrCannotConnect,
	ux_ErrExecFailed,
	ux_ErrPutEnvFailed,
	ux_ErrFileNotFound,
	ux_Err_sch_SigChldHdlr_BeginCritical_failed,
	ux_Err_sch_SigChldHdlr_EndCritical_failed,
	ux_Err_sch_SigChldHdlr_Suspend_failed,
	ux_Err_sch_SigChldHdlr_Register_failed,
	ux_Err_ux_State_uam_not_null,
	ux_Err_chm_Channel_Create_failed,
	ux_Err_chm_Channel_InitiateConnection_failed,
	ux_Err_uem_UnixEventMgr_Create_failed,
	ux_Err_fork_failed,
	ux_ErrWaitForConnectionFailed,
	ux_ErrUnexpectedExitOfChild,
	ux_ErrNoSignalFromChild,
	ux_ErrDirNotFound,
	
	/* exit codes for server process (0 - 255) */
	ux_ErrParentUnknown = 1,
	ux_ErrParentFatalError,
	ux_ErrParentSignal,
	
	/* exit codes for forked child process (0 - 255) */
	ux_ErrChildUnknown = 1,
	ux_ErrChildNever,
	ux_ErrChildEndCriticalFailed,
	ux_ErrChildWaitForConnectionFailed,
	ux_ErrChildExecFailed,
	ux_ErrChildFileNotFound,
	ux_ErrChildOutOfMemory,
	
	ux_ErrDummy = 0x12345678
};
typedef enum ux_Err ux_Err;

enum ux_Boolean {
	ux_BooleanFalse,
	ux_BooleanTrue,
	ux_BooleanDummy = 0x12345678
};
typedef enum ux_Boolean ux_Boolean;

/*
 * Function prototypes
 */

#if	defined(__cplusplus)
extern "C" {
#endif

ux_Err
ux_Server_Init(
ux_Boolean	debug,
unsigned	cemDebug,
FILE*		logFile,
ux_Boolean	saveTmp,
char*		myVersion
);

void
ux_Server_Term(
void
);

uem_UnixEventMgr*	ux_Server_GetClientUEM();
void				ux_Server_SetClientUEM(uem_UnixEventMgr* uem);
uem_UnixEventMgr*	ux_Server_GetAppMgrUEM();
void				ux_Server_SetAppMgrUEM(uem_UnixEventMgr* uem);

void ux_Server_CriticalBegin();
void ux_Server_CriticalEnd();

ux_Boolean	ux_Server_HaveJob();
ux_Err		ux_Server_StartNextStep(unsigned short rPort, unsigned short sPort);
ux_Err		ux_Server_SendStartApp();

typedef void (*ux_Server_NewJobHdlr)(void* newJobHdlrData);
void ux_Server_SetNewJobHdlr(ux_Server_NewJobHdlr newJobHdlr, void* newJobHdlrData);

#if	defined(__cplusplus)
}
#endif

#endif	/* _CACHE_SERVER_H_ */

