#include <CACheFileLibAD.h>
#include <CACheFileLib.h>
#include <cpu.h>
#include <MOPACDriver.h>
#include <CACheFileTypes.h>
int UpdateBondOrders(MolStruct *molStruct,  FILE *MOPACoutput, long NAtoms,
                 MoleculeInfo *moleculeInfo, float *bond_order, long numberBonds, bool first )
{
    long ij, i, j, nLinear, bond,  *bondListPointer, atom1,
        atom2, Idx;
    double *bondOrders = NULL;
    float values[8];
   	char errs[256], string[256];
    ObjectID (*bondList)[2] = NULL;
    ObjclsID offset;
        for (;;) {
	    	if (cfl_fgets(string, sizeof(string), MOPACoutput) == NULL) 
						break;
            if (strncmp(string, 
						"                    BOND ORDERS AND VALENCIES", 45) == 0) 
                        break;
        }
    if (csu_ExistsObjclsID (molStruct, AtomID, &offset))
     NAtoms = (long) ((GetPtr(molStruct->objclsH) + offset)->num_objs);
   else {
     alert_user ("writeReactionCoord: Error attempting to locate AtomID index.");
   }
    nLinear = (NAtoms*(NAtoms+1))/2;
    numberBonds = cpu_getBondList(molStruct, &bondList);
    if ((bondOrders = (double *) NewHandle(nLinear*sizeof(double))) == NULL) {
	    alert_user("writeReactionCoord: Unable to allocate bondOrders array");
    }

				/* initialize bond order matrix */
				for (ij=0; ij < (nLinear -1); ij++)
					(GetPtr( bondOrders))[ij] = 0.0;
					ij = 0;
					while (ij < (nLinear - 1)) {
						int num_accross, j_val[6];
						num_accross = 0;
						if (strlen(string) > 15) {
							num_accross += 
								sscanf(&string[19],"%ld", &j_val[0]);
							num_accross += 
								sscanf(&string[30],"%ld", &j_val[1]);
							num_accross += 
								sscanf(&string[41],"%ld", &j_val[2]);
							num_accross += 
								sscanf(&string[52],"%ld", &j_val[3]);
							num_accross += 
								sscanf(&string[63],"%ld", &j_val[4]);
							num_accross += 
								sscanf(&string[74],"%ld", &j_val[5]);
						}
	
						if (num_accross<=0) 
							break;
						cfl_fgets(string, sizeof(string), MOPACoutput); /* skip a line */
						for (;;) {
							if (cfl_fgets(string, sizeof(string), MOPACoutput) == NULL) 
								break;
							if (strlen(string) < 3)
								break;
							if (strlen(string) > 7) 
								num_accross = sscanf(&string[7],"%ld %f %f %f %f %f %f\n",
											&i, &values[0], &values[1], &values[2], &values[3],
											&values[4], &values[5]);
							else
								num_accross = 0;
							if (num_accross<=0) break;
							for (j=0; j<(num_accross-1); j++) {
								ij = ((i*(i-1))/2) + j_val[j] -1;
								if (ij > (nLinear -1)) {
									sprintf(errs,"updateMolStruct: bondOrders "
										"index %d out of range (%d)",
										ij, nLinear-1);
									return(1);
								}
								(GetPtr(bondOrders))[ij] = values[j];
							}
							if (ij >= (nLinear - 1))
								break;
						}
	
						if (ij >= (nLinear -1)) 
							break;
						if (cfl_fgets(string, sizeof(string), MOPACoutput) == NULL) 
							break;
						if (strlen(string) < 3) {
							/* skip a line */
							cfl_fgets(string, sizeof(string), MOPACoutput); 
						}
						if (strlen(string) < 3) {
							/* skip a second line line (for some VAX output) */
							cfl_fgets(string, sizeof(string), MOPACoutput); 
						}
					} /* ij < nLinear -1 */
  /* build the list of bonds */	
    /* Add the bond order to each bond and mark the bondOrderDefined
	   array to indicate that the bond order has already been filled
	   in.
	*/
  if (first)		AddBondOrder (molStruct, bondOrders, NAtoms, 
            moleculeInfo->locationWithoutDummies, MOPAC_SRC);

	for (bond=0; bond<numberBonds; bond++) {
	  bondListPointer = bondList[bond];
	  atom1 = whichAtomIndex(bondListPointer[0], NAtoms, moleculeInfo->locationWithoutDummies);
	  if (atom1 >= 0) {
		 atom2 = whichAtomIndex(bondListPointer[1], NAtoms, moleculeInfo->locationWithoutDummies);
		 Idx = (atom1>atom2) ? ((atom1*(atom1+1))/2 + atom2) : ((atom2*(atom2+1))/2 + atom1);
          bond_order[bond] = (float)bondOrders[Idx];
		 
        }
    }
	  if (bondOrders != NULL) HUnlock((Handle) bondOrders);
      if (bondOrders != NULL) DisposHandle((Handle) bondOrders);
      if (bondOrders != NULL) bondOrders = NULL;
    return (0);
}
