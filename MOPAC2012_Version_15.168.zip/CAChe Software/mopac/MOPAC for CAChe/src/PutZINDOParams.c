#include <compat.h>
#include <ZINDODriver.h>

/* This routine assumes that the file to be written is open and
 * is positioned at the begining of the file.
 * This routine does NOT close the settings file.
 */

int PutZINDOParams(ZINDOControl *controlPanel, FILE *file)
{
	/* 
	 * CheckControlPanel(controlPanel);
	 * NOTE 7/2/92 SJC - this currently is a no-op.  If and when
	 * it is done, then make a copy of the settings, modify
	 * the copy & save the modified copy.
	 */
	
	if (file == NULL) return (-1);

	if (fprintf(file,"startZINDO\n") < 0) return (-1);
	if (fprintf(file,"   calculate %d\n",
				controlPanel->calculate) < 0) return (-1);
	if (fprintf(file,"   multiplicity %d\n",
				controlPanel->multiplicity) < 0) return (-1);
	if (fprintf(file,"   parameters %d\n",
				controlPanel->parameters) < 0) return (-1);
	if (fprintf(file,"   geometrySearch %d\n",
				controlPanel->geometrySearch) < 0) return (-1);
	if (fprintf(file,"   geometryConvergence %d\n",
				controlPanel->geometryConvergence) < 0) return (-1);
	if (fprintf(file,"   spaceSymmetry %d\n",
				controlPanel->spaceSymmetry) < 0) return (-1);
	if (fprintf(file,"   maxSCFiterations %d\n",
				controlPanel->maxSCFiterations) < 0) return (-1);
	if (fprintf(file,"   SCFtype %d\n",
				controlPanel->SCFtype) < 0) return (-1);
	if (fprintf(file,"   scfConvergence %d\n",
				controlPanel->scfConvergence) < 0) return (-1);
	if (fprintf(file,"   maxGeometrySteps %d\n",
				controlPanel->maxGeometrySteps) < 0) return (-1);
	/* add one to C.I. level to be compatible with CAChe 2 */
	if (fprintf(file,"   CIlevel %d\n",
				(controlPanel->CIlevel + 1)) < 0) return (-1);
	if (fprintf(file,"   spectraCutoff %lf\n",
				controlPanel->spectraCutoff) < 0) return (-1);
	if (fprintf(file,"   printAmount %d\n",
				controlPanel->printAmount) < 0) return (-1);
	if (fprintf(file,"   cavityRadiusMeaning %d\n",
				controlPanel->cavityRadiusMeaning) < 0) return (-1);
	if (fprintf(file,"   cavityRadiusExtend %lf\n",
				controlPanel->cavityRadiusExtend) < 0) return (-1);
	if (fprintf(file,"   cavityRadiusTotal %lf\n",
				controlPanel->cavityRadiusTotal) < 0) return (-1);
	if (fprintf(file,"   dielectric %lf\n",
				controlPanel->dielectric) < 0) return (-1);
	if (fprintf(file,"   refractiveIndex %lf\n",
				controlPanel->refractiveIndex) < 0) return (-1);
	if (fprintf(file,"   metalConfigMixing %d\n",
				controlPanel->metalConfigMixing) < 0) return (-1);
	if (fprintf(file,"   controlRestart %d\n",
				controlPanel->controlRestart) < 0) return (-1);
	if (fprintf(file,"   detailsSCRxnF %d\n",
				controlPanel->detailsSCRxnF) < 0) return (-1);
	if (fprintf(file,"   detailsMap %d\n",
				controlPanel->detailsMap) < 0) return (-1);
	if (fprintf(file,"   saveBasis %d\n",
				controlPanel->saveBasis) < 0) return (-1);
	if (fprintf(file,"   saveVectors %d\n",
				controlPanel->saveVectors) < 0) return (-1);
	if (fprintf(file,"   saveGraphics %d\n",
				controlPanel->saveGraphics) < 0) return (-1);
	if (fprintf(file,"   saveInput %d\n",
				controlPanel->saveInput) < 0) return (-1);
	if (fprintf(file,"   saveOutput %d\n",
				controlPanel->saveOutput) < 0) return (-1);
	if (fprintf(file,"   saveCon %d\n",
				controlPanel->saveCon) < 0) return (-1);
	if (fprintf(file,"   saveOpt %d\n",
				controlPanel->saveOpt) < 0) return (-1);
	if (fprintf(file,"   saveSummary %d\n",
				controlPanel->saveSummary) < 0) return (-1);
	if (fprintf(file,"   saveLog %d\n",
				controlPanel->saveLog) < 0) return (-1);
	if (fprintf(file,"   netCharge %d\n",
				controlPanel->netCharge) < 0) return (-1);

	if (fprintf(file,"\n") < 0) return (-1);

    if (fprintf(file,"   title\n") < 0) return (-1);
	if (fprintf(file,"%s\n",controlPanel->title) < 0) return (-1);

	if (fprintf(file,"\n") < 0) return (-1);

    if (fprintf(file,"   extraKeyWords\n") < 0) return (-1);
	if (fprintf(file,"%s\n",controlPanel->extraKeyWords) < 0) return (-1);

	if (fprintf(file,"endZINDO\n\n") < 0) return (-1);

	return (0);
}

int CheckControlPanel(ZINDOControl *controlPanel)
{
	/* Return !=0 indicates that changes were made */
//	int i;
//	i = controlPanel->calculate;
	return 0;
}
