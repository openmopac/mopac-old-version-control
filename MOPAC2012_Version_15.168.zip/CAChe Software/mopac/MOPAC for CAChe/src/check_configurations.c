#include  "compat.h"
#include  "MOPACDriver.h"
#include  "cpu.h"

/* The following should be in Linus.h -- change when other CAChe applications are
	ported to RS6000 */
#define ed_InvalidMolStruct	-2001 

/* "Borrowed" from the MS_Editor routines 2/19/92 SJC */

int MOPAC_check_conf(MolStruct *msPtr)
{
	cpu_BondObjsP bp, blist = NULL;
	long i, num, num_valloc;
	ConnProps conn_props;
	UCharH atom_dflagH;
	ShortH oc1, oc2, btype, conf;
	LongH  o1, o2;
	BitH a_valid, c_valid, conf_valid;
	PropID pid;
	ObjclsID ocid;
	long a, b, c;
	ObjclsID atomN, orbitalN;
	long n_bonds;
	short n_lobes, n_orbitals;
	short num_orb, hi_btype;

	if ((num_valloc = csu_GetPropArrays(msPtr, AtomID, DflagID, NULL,
	  				(BitH*)&a_valid, (ValueH *)&atom_dflagH)) < 1)
		return(0); /* configuration property does not exist (whatever the reason) */


	if ((i = csu_GetPropArrays(msPtr, AtomID, ConfID,
	  NULL, &conf_valid, (ValueH *)&conf)) < num_valloc) {
		/* create the configuration property */
		csu_ExistsObjclsID(msPtr, AtomID, &ocid);
		if ((i = csu_InstProp(msPtr->objclsH, ocid, ConfID, 1, csu_Src,
		  						CSU_NAME, NoUnit, 0, &pid)) > -1)
			i = csu_GetPropArrays(msPtr, AtomID, ConfID, NULL,
				&conf_valid, (ValueH *)&conf);
		if (i < num_valloc) {
			alert_user("can't get configurations");
			return(i);
		}
	}

	if (cpu_GetConnProps(msPtr, &conn_props) < 0) {
		alert_user("no connectors");
		return ed_InvalidMolStruct;
	}

	if ((b = cpu_getBondObjList(msPtr, &blist, &conn_props)) < 0) {
		alert_user("MOPAC_check_conf: not enough memory for bond list");
		return(b);
	}
	if (csu_GetPropArrays(msPtr, BondID, TypeID,
	  NULL, NULL, (ValueH *)&btype) < b) {
		alert_user("can't get bond types");
		cpu_freeBondObjList(blist);
		return(CSUNoValues);
	}

	num = conn_props.num_valloc;
	oc1 = conn_props.objcls1H;
	oc2 = conn_props.objcls2H;
	o1 = conn_props.obj1H;
	o2 = conn_props.obj2H;
	c_valid = conn_props.validH;

	atomN = (GetPtr(DataDict.objclsdictH) + AtomID)->objclsN;
	orbitalN = (GetPtr(DataDict.objclsdictH) + OrbitalID)->objclsN;


	/* for each atom configuration determine how many bonds and orbitals it has
		also determine the strongest bond for this atom */
	for (a = 0; a < num_valloc; a++) {
		if (!csu_GetBit(a_valid, a))
			continue;
		/* count the number of bonds and the number of orbitals for this atom */

		n_lobes = 0; /* initialize the number of attached objects */
		n_bonds = 0; /* initialize the number of bonded atoms */
		n_orbitals = 0; /* initialize the number of orbitals */
		hi_btype = 0; /* initialize the strongest bond type */
		for (i = 0, bp = blist; i < b; i++, bp++) {
			if (bp->o1.oci < 0)
				continue;
			if ((bp->o1.obi != a || bp->o1.oci != AtomID)
			 && (bp->o2.obi != a || bp->o2.oci != AtomID))
				continue;
			if ((num_orb = bondOrbitals((GetPtr(btype))[i])) < 1)
				continue;
			n_lobes++;
			n_bonds++;
			n_orbitals += num_orb;
			/* set the strongest bond so far */
			if (num_orb > hi_btype)
				hi_btype = num_orb;
		}

		/* add in all the nonbonded orbital electrons */

		for (c = 0; c < num; c++)
			/* find orbitals to atom a */
			if ((GetPtr(o1))[c] == a && (GetPtr(oc1))[c] == atomN && csu_GetBit(c_valid, c)
			 && (GetPtr(oc2))[c] == orbitalN && (GetPtr(o2))[c] >= 0) {
				n_lobes++;
				n_orbitals++;
			}

		/* now have the number of bonds, the number of orbitals and highest number
			of orbitals in any of the bonds */
		c = confCheck(n_lobes, n_orbitals, n_bonds, hi_btype, -1);
		if (c == sp3CONF && n_bonds < 4) { /* may be sp2CONF */
			/* check neighbors for pi bonds */
			for (n_bonds = b; n_bonds-- > 0; ) {
				/* find neighbors of a */
				bp = blist + n_bonds;
				if (bp->o1.oci != AtomID || bp->o2.oci != AtomID)
					continue;
				if (bp->o1.obi == a)
					c = bp->o2.obi;
				else if (bp->o2.obi == a)
					c = bp->o1.obi;
				else
					continue;
				/* find bonds to neighbor c */
				for (i = 0, bp = blist; i < b; i++, bp++) {
					if (bp->o1.oci < 0)
						continue;
					if ((bp->o1.obi != c || bp->o1.oci != AtomID)
					 && (bp->o2.obi != c || bp->o2.oci != AtomID))
						continue;
					if (bondOrbitals((GetPtr(btype))[i]) > 1)
						break;
				}
				if (i < b)
					break; /* found a double or triple bond */
			}
			if (n_bonds >= 0)
				c = sp2CONF;
			else
				c = sp3CONF;
		}
		(GetPtr(conf))[a] = (short)c;
		csu_SetBit(conf_valid, a);
	} /* end of atom checking loop */

	cpu_freeBondObjList(blist);

	return(0);
}

int bondOrbitals(short btype)
{
	switch (btype) {
	case SINGLE_B:
	case COORD_B:
		return 1;
	case DOUBLE_B:
		return 2;
	case TRIPLE_B:
		return 3;
	default:
		return 0;
	}
}

int confCheck(short n_lobes, short n_orbitals, long n_bonds, 
	short hi_btype, short conf)
/* if conf is less than zero return the best configuration
** else return minus 1 if configuration is unacceptable
*/
{
	if (conf < 0 || conf == sCONF)
		if (n_lobes < 2
		&& n_orbitals < 2)
			return sCONF;
		else if (conf >= 0)
			return -1;

	if (conf < 0 || conf == spCONF)
		if (n_lobes < 3
		&& n_orbitals < 5
		&& hi_btype < 4)
			return spCONF;
		else if (conf >= 0)
			return -1;

	if (conf < 0)
		if (n_lobes == 4
		&& ((n_orbitals < 5 && hi_btype < 2) || n_bonds == 4))
			return sp3CONF;

	if (conf < 0 || conf == sp2CONF)
		if (n_lobes < 5
		&& n_bonds < 4
		&& n_orbitals < 5
		&& hi_btype < 3)
			return sp2CONF;
		else if (conf >= 0)
			return -1;

	if (conf == sp3CONF)
		if (n_lobes < 5
		&& (n_orbitals < 5 || hi_btype < 3))
			return sp3CONF;
		else
			return -1;

	if (conf == sd3CONF)
		if (n_lobes < 5
		&& (n_orbitals < 5 || hi_btype < 3))
			return sd3CONF;
		else
			return -1;

	if (conf < 0 || conf == dzsp3CONF)
		if (n_lobes < 6
		&& (n_orbitals < 6 || hi_btype < 3))
			return dzsp3CONF;
		else if (conf >= 0)
			return -1;

	if (conf < 0 || conf == d2sp3CONF)
		if (n_lobes < 7
		&& (n_orbitals < 7 || hi_btype < 3))
			return d2sp3CONF;
		else if (conf >= 0)
			return -1;

	if (conf == dxysp3CONF)
		if (n_lobes < 6
		&& (n_orbitals < 6 || hi_btype < 3))
			return dxysp3CONF;
		else
			return -1;

	if (conf == p3CONF)
		if (n_lobes < 4
		&& n_orbitals < 4)
			return p3CONF;
		else
			return -1;

	if (conf == dsp2CONF)
		if (n_lobes < 5
		&& (n_orbitals < 5 || hi_btype < 3))
			return dsp2CONF;
		else
			return -1;

	return unCONF;
}
