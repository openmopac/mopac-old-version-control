#include "compat.h"
#include "MOPACDriver.h"

int determineAtomicNumber(char symbol[2])
{
/* Given the atomic symbol, return the atomic number */
   
	if (symbol[0] == 'H') {
		if (symbol[1] == 'e') { 		/* Helium */
			return (2);
		} else if (symbol[1] == 'o') {	/* Holmium */
			return (67);
		} else if (symbol[1] == 'f') {	/* Hafnium */
			return (72);
		} else if (symbol[1] == 'g') {	/* Mercury */
			return (80);
		} else { 						/* Hydrogen */
			return (1);
		}
	} else if (symbol[0] == 'L') {
		if (symbol[1] == 'i') { 		/* Lithium */
			return (3);
		} else if (symbol[1] == 'a') {	/* Lanthanum */
			return (57);
		} else if (symbol[1] == 'u') {	/* Lutetium */
			return (71);
		} else if (symbol[1] == 'r') {	/* Lawrencium */
			return (103);
		}
	} else if (symbol[0] == 'B') {
		if (symbol[1] == 'e') {			/* Beryllium */
			return (4);
		} else if (symbol[1] == 'r') {	/* Bromine */
			return (35);
		} else if (symbol[1] == 'a') {	/* Barium */
			return (56);
		} else if (symbol[1] == 'i') {	/* Bismuth */
			return (83);
		} else if (symbol[1] == 'k') {	/* Berkelium */
			return (97);
		} else { 						/* Boron */
			return (5);
		}
	} else if (symbol[0] == 'C') {
		if (symbol[1] == 'a') { 		/* Calcium */
			return (20);
		} else if (symbol[1] == 'l') { 	/* Chlorine */
			return (17);
		} else if (symbol[1] == 'r') { 	/* Chromium */
			return (24);
		} else if (symbol[1] == 'o') { 	/* Cobalt */
			return (27);
		} else if (symbol[1] == 'u') { 	/* Copper */
			return (29);
		} else if (symbol[1] == 'd') { 	/* Cadmium */
			return (48);
		} else if (symbol[1] == 's') { 	/* Cesium */
			return (55);
		} else if (symbol[1] == 'e') { 	/* Cerium */
			return (58);
		} else if (symbol[1] == 'm') { 	/* Curium */
			return (96);
		} else if (symbol[1] == 'f') { 	/* Californium */
			return (98);
		} else if (symbol[1] == 'b') { 	/* Capped bond for MOPAC*/
			return (86);				/* translate to Rn */
		} else { /* Carbon */
			return (6);
		}
	} else if (symbol[0] == 'N') {
		if (symbol[1] == 'e') { 		/* Neon */
			return (10);
		} else if (symbol[1] == 'a') { 	/* Sodium */
			return (11);
		} else if (symbol[1] == 'b') { 	/* Niobium */
			return (41);
		} else if (symbol[1] == 'i') { 	/* Nickel */
			return (28);
		} else if (symbol[1] == 'd') { 	/* Neodymium */
			return (60);
		} else if (symbol[1] == 'p') { 	/* Neptunium */
			return (93);
		} else if (symbol[1] == 'o') { 	/* Nobelium */
			return (102);
		} else { 						/* Nitrogen */
			return (7);
		}
	} else if (symbol[0] == 'O') {
		if (symbol[1] == 's') { 		/* Osmium */
			return (76);
		} else { 						/* Oxygen */
			return (8);
		}
	} else if (symbol[0] == 'F') {
		if (symbol[1] == 'e') { 		/* Iron */
			return (26);
		} else if (symbol[1] == 'r') { 	/* Francium */
			return (87);
		} else if (symbol[1] == 'm') { 	/* Fermium */
			return (100);
		} else { 						/* Fluorine */
			return (9);
		}
	} else if (symbol[0] == 'M') {
		if (symbol[1] == 'g') { 		/* Magnesium */
			return (12);
		} else if (symbol[1] == 'n') { 	/* Manganese */
			return (25);
		} else if (symbol[1] == 'o') { 	/* Molybdenum */
			return (42);
		} else if (symbol[1] == 'd') { 	/* Mendelevium */
			return (101);
		}
	} else if (symbol[0] == 'A') {
		if (symbol[1] == 'l') { 		/* Aluminum */
			return (13);
		} else if (symbol[1] == 'r') { 	/* Argon */
			return (18);
		} else if (symbol[1] == 's') { 	/* Arsenic */
			return (33);
		} else if (symbol[1] == 'g') { 	/* Silver */
			return (47);
		} else if (symbol[1] == 'u') { 	/* Gold */
			return (79);
		} else if (symbol[1] == 't') { 	/* Astatine */
			return (85);
		} else if (symbol[1] == 'c') { 	/* Actinium */
			return (89);
		} else if (symbol[1] == 'm') { 	/* Americium */
			return (95);
		}
	} else if (symbol[0] == 'S') {
		if (symbol[1] == 'i') { 		/* Silicon */
			return (14);
		} else if (symbol[1] == 'c') { 	/* Scandium */
			return (21);
		} else if (symbol[1] == 'e') { 	/* Selenium */
			return (34);
		} else if (symbol[1] == 'r') { 	/* Strontium */
			return (38);
		} else if (symbol[1] == 'n') { 	/* Tin */
			return (50);
		} else if (symbol[1] == 'b') { 	/* Antimony */
			return (51);
		} else if (symbol[1] == 'm') { 	/* Samarium */
			return (62);
		} else { 						/* Sulfur */
			return (16);
		}
	} else if (symbol[0] == 'P') {
		if (symbol[1] == 'd') { 		/* Palladium */
			return (46);
		} else if (symbol[1] == 'r') { 	/* Praseodynium */
			return (59);
		} else if (symbol[1] == 'm') { 	/* Promethium */
			return (61);
		} else if (symbol[1] == 't') { 	/* Platinum */
			return (78);
		} else if (symbol[1] == 'b') { 	/* Lead */
			return (82);
		} else if (symbol[1] == 'o') { 	/* Polonium */
			return (84);
		} else if (symbol[1] == 'a') { 	/* Protactinium */
			return (91);
		} else if (symbol[1] == 'u') { 	/* Plutonium */
			return (94);
		} else { 						/* Phosphorus */
			return (15);
		}
	} else if (symbol[0] == 'K') {
		if (symbol[1] == 'r') { 		/* Krypton */
			return (36);
		} else { 						/* Potasium */
			return (19);
		}
	} else if (symbol[0] == 'T') {
		if (symbol[1] == 'i') { 		/* Titanium */
			return (22);
		} else if (symbol[1] == 'c') { 	/* Technetium */
			return (43);
		} else if (symbol[1] == 'e') { 	/* Tellurium */
			return (52);
		} else if (symbol[1] == 'b') { 	/* Terbium */
			return (65);
		} else if (symbol[1] == 'm') { 	/* Thulium */
			return (69);
		} else if (symbol[1] == 'a') { 	/* Tantalum */
			return (73);
		} else if (symbol[1] == 'l') { 	/* Thallium */
			return (81);
		} else if (symbol[1] == 'h') { 	/* Thorium */
			return (90);
		} else { 						/* Tritium */
			return (1);
		}
	} else if (symbol[0] == 'V') {		/* Vanadium */
		return (23);
	} else if (symbol[0] == 'Z') {
		if (symbol[1] == 'n') { 		/* Zinc */
			return (30);
		} else if (symbol[1] == 'r') { 	/* Zirconium */
			return (40);
		}
	} else if (symbol[0] == 'G') {
		if (symbol[1] == 'a') { 		/* Gallium */
			return (31);
		} else if (symbol[1] == 'e') { 	/* Germanium */
			return (32);
		} else if (symbol[1] == 'd') { 	/* Gadolonium */
			return (64);
		}
	} else if (symbol[0] == 'R') {
		if (symbol[1] == 'b') { 		/* Rubidium */
			return (37);
		} else if (symbol[1] == 'u') { 	/* Ruthenium */
			return (44);
		} else if (symbol[1] == 'h') { 	/* Rhodium */
			return (45);
		} else if (symbol[1] == 'e') { 	/* Rhenium */
			return (75);
		} else if (symbol[1] == 'n') { 	/* Radon */
			return (86);
		} else if (symbol[1] == 'a') { 	/* Radium */
			return (88);
		}
	} else if (symbol[0] == 'Y') {
		if (symbol[1] == 'b') { 		/* Ytterbium */
			return (70);
		} else { 						/* Yttrium */
			return (39);
		}
	} else if (symbol[0] == 'I') {
		if (symbol[1] == 'n') { 		/* Indium */
			return (49);
		} else if (symbol[1] == 'r') { 	/* Iridium */
			return (77);
		} else { 						/* Iodine */
			return (53);
		}
	} else if (symbol[0] == 'X') {
		if (symbol[1] == 'e') { 		/* Xenon */
			return (54);
		} else if (symbol[1] == 'X') {	/* MOPAC dummy atom */
			return (54);
		}
	} else if (symbol[0] == 'x') {
		if (symbol[1] == 'x') { 		/* MOPAC dummy atom */
			return (54);
		}
	} else if (symbol[0] == 'D') {
		if (symbol[1] == 'y') { 		/* Dysprosium */
			return (66);
		} else { 						/* Deuterium */
			return (1);
		}
	} else if (symbol[0] == 'E') {
		if (symbol[1] == 'u') { 		/* Europium */
			return (63);
		} else if (symbol[1] == 'r') { 	/* Erbium */
			return (68);
		} else if (symbol[1] == 's') { 	/* Einsteinium */
			return (99);
		}
	} else if (symbol[0] == 'W') {		/* Tungsten */
		return (74);
	} else if (symbol[0] == 'U') {		/* Uranium */
		return (92);
	} else if (symbol[0] == '+') {
		if (symbol[1] == '+') { 		/* +2 sparkle for MOPAC */
			return (56);				/* translate to Ba */
		} else { 						/* +1 sparkle for MOPAC */
			return (55);				/* translate to Cs */
		}
	} else if (symbol[0] == '-') {
		if (symbol[1] == '-') { 		/* -2 sparkle for MOPAC */
			return (84);				/* translate to Po */
		} else { 						/* -1 sparkle for MOPAC */
			return (85);				/* translate to At */
		}
	} else {
		return (0);
	}

	return (0);	/* avoid compiler warning */
}
