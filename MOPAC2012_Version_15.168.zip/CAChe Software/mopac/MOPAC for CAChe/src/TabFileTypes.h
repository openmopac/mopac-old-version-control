/* break out of file transfer types for ProjectLeader */
/* CAChe file type definitions */
enum Tab_File_Type
{
	TAB_CCLIST_FILE = ssq_file_custom,
	TAB_DUMMY_FILE = ssq_file_dummy
};
