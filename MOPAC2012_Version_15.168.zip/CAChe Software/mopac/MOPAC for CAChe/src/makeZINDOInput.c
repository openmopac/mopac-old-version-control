#include <compat.h>
#include <math.h>

#if defined(unix)
#include <CACheFileLibAD.h>
#endif

#include <cpu.h>
#include <CACheFileTypes.h>
#include <ZINDODriver.h>

void alert_user_watch(char *errs)
{
	/*  ASSUMES that we are currently in the busy state */
	leaveBusyState();
	alert_user(errs);
	enterBusyState();
}

void inform_user_watch(char *errs)
{
	/*  ASSUMES that we are currently in the busy state */
	leaveBusyState();
	inform_user(errs);
	enterBusyState();
}

void instruct_user_watch(char *errs)
{
	/*  ASSUMES that we are currently in the busy state */
	leaveBusyState();
	instruct_user(errs);
	enterBusyState();
}

int makeZINDOInput1(
	MolStruct *molStruct, 
	ZINDOControl *controlPanel,
	double *new_cutoff
)
{
	FILE		*file;
	char		outputfile[256];
	char		string[256];
	int			numberOfUnpaired = 0;
	int			i, j, k;
	int			NAtom;
	int			rtn_code;
	ObjclsID	offset;
	short		*atomicNumber;
	short		*basisType;
	double		*netValenceCharge;
	char		errs[256];
	int         errorCode;
	char		*cp;
	int			numberWithNoBasis = 0;
	int			numberWithOneBasis = 0;
	int			numberWithFourBasis = 0;
	int			numberWithNineBasis = 0;
	int			numberWithSixteenBasis = 0;
	int			numberTransitionMetals = 0;
	int			numberTransitionMetals2 = 0;
	int			totalBasis = 0;
	int			number_of_configurations = 0;
	long		numLockedAtoms = 0L;
	long		numLockedLabels = 0L;
	long		max_ci_level = 0L;
	
	errorCode = ZINDOerrors - 110;

	/* Check for commas in the molecule name */
	if (strstr(controlPanel->molStructName,",") != NULL) {
		alert_user("ZINDO is unable to process molecules with "
			"a comma in their name.  Please rename your molecule "
			"file and try again.");
		controlPanel->molStructName[0] = 0;
		return (-1);
	}


	/*      Write input file  	*/
    strcpy(outputfile, "ZINDO Input");

	if (!(file = fopen(outputfile,"w"))) {
		alert_user("The file, 'ZINDO Input', cannot be opened because "
				   "the file may be in use or "
				   "locked, or the disk may be full.  "
				   "Use the Finder command Get Info to discover whether "
				   "the file is locked and to unlock the file.");
		return (-1);
	}

	enterBusyState();
	
	/* Strip non printable characters from the keywords and upper-case them*/
	for (i=0; controlPanel->extraKeyWords[i] != 0; i++) {
		if (controlPanel->extraKeyWords[i] < 32 ||
		    controlPanel->extraKeyWords[i] > 126) 
				controlPanel->extraKeyWords[i] = ' ';
		else
			controlPanel->extraKeyWords[i] = 
				ToUpper(controlPanel->extraKeyWords[i]);
	}
	/* 
	 * Search extra keywords for CUTOFF (high-energy cutoff energy
	 * spectra).
	 */
	if ((cp = strstr(controlPanel->extraKeyWords, "CUTOFF")) != NULL) {
		char *cp_save;
		Boolean got_cutoff = FALSE;
		
		cp_save = cp; /* Save the original start of CUTOFF */
		
		/* Skip CUTOFF */
		cp += 6;
		/* Look for the next digit */
		while (*cp != 0) {
			if (isdigit(*cp)) {
				got_cutoff = TRUE;
				break;
			} else if (isalpha(*cp)) {
				break; /* No numeric value */
			}
			cp++;
		}
		if (got_cutoff) { /* Found a numeric value */
			sscanf(cp,"%lf",new_cutoff);
		}
		
		/* Continue skipping characters until a letter is found */
		while (*cp != 0) {
			if (isalpha(*cp)) {
				break;
			}
			cp++;
		}
		
		/* Slide the rest of the keywords back */
		while (*cp != 0) {
			*cp_save = *cp;
			cp_save++;
			cp++;
		}
		/* Transfer the null character */
		if (*cp == 0)
			*cp_save = *cp;
		
	}

    /* Write the $TITLEI information to the ZINDO Input file. */

	for (i=0; controlPanel->title[i] != 0; i++)
		if (controlPanel->title[i] < 32) controlPanel->title[i] = ' ';
	strncpy(string, controlPanel->title, 72);
	string[72] = '\0';

	fprintf(file," $TITLEI\n");
	fprintf(file," %s\n", string);
	if (strlen(controlPanel->title) <= 72)
		fprintf(file," \n");
	else {
		strncpy(string, controlPanel->title+72, 72);
		string[72] = '\0';
		fprintf(file," %s\n", string);
	}
	fprintf(file," $END\n");


    /* Write the $CONTRL information to the ZINDO Input file. */

	fprintf(file," $CONTRL\n");

	strncpy(string, controlPanel->molStructName, 72);
	string[72] = 0;
    replaceBlanks(string,'_');
#if defined(unix)
	{
		char ad_header[73];
		cfl_MacNameToADNames(string, CFL_AD_HEADER_PREFIX, 
			CFL_AD_ESCAPE_CHAR, "/", 72, ad_header, errs);
		strncpy(string, errs, 72);
		string[72] = 0;
	}
#endif
	/* write the name of the output file */
	if (strstr(controlPanel->extraKeyWords, "ONAME") == NULL)
		fprintf(file," ONAME = %s\n", string); 

    string[0] = 0;
    fprintf(file," UNITS = ANGS");   		/* angstrom units */
    fprintf(file," ENTTYP = COORD"); 		/* coordinates in cartesians */

	if (strstr(controlPanel->extraKeyWords, "ONAME") == NULL) {
		if (controlPanel->saveBasis)
		   fprintf(file," IELEC = 1\n");    /* basis set is written to .inb file. */
		else
		   fprintf(file," IELEC = 0\n");    /* basis set is not written to disk */
	}

	if (strstr(controlPanel->extraKeyWords, "VEC") == NULL) {
		if (controlPanel->saveVectors && controlPanel->controlRestart) {
		   fprintf(file," VEC = 10"); 			/* 	save eigenvectors every 5 cycles and
													restart from saved vectors. */
		} else if (controlPanel->controlRestart) {
		   fprintf(file," VEC = 8");  			/* restart from saved vectors. */
		} else if (controlPanel->saveVectors) {
		   fprintf(file," VEC = 9");  			/* save eigenvectors every 5 cycles. */
		}
	}

   /*
    *  Find out how many of atoms there are.
    */

   if (csu_ExistsObjclsID (molStruct, AtomID, &offset))
     NAtom = (long) ((GetPtr(molStruct->objclsH) + offset)->num_objs);
   else {
     alert_user_watch (" Error attempting to locate AtomID index.");
     goto errorReturn;
   }
    fprintf(file," NAT = %d\n", NAtom);


	if ((rtn_code = csu_GrabVal (molStruct, AtomID, AnumID, (char **)&atomicNumber)) < 0) {
	  sprintf (errs," makeZINDOInput : csu_GrabVal AnumID, errno %d", rtn_code);
	  alert_user_watch(errs);
	  goto errorReturn;
	}

	if ((basisType = (short *) malloc(NAtom*sizeof(short))) == NULL) {
	  sprintf (errs,"ZINDO: basisType memory request %ld too large\n",
			   NAtom*sizeof(short));
	  alert_user_watch(errs);
	  errorCode = ZINDOerrors - 111;
	  goto errorReturn;
	}

	if ((netValenceCharge = (double *) malloc(NAtom*sizeof(double))) == NULL) {
	  sprintf (errs,"ZINDO: netValenceCharge memory request %ld too large\n",
			   NAtom*sizeof(double));
	  alert_user_watch(errs);
	  errorCode = ZINDOerrors - 112;
	  goto errorReturn;
	}
	
	/* Check to see if there are locked atoms or locked labels */
	numLockedAtoms = getNumberLockedAtoms(molStruct,NAtom);
	numLockedLabels = getNumberLockedLabels(molStruct);
	if (((numLockedAtoms > 0) || (numLockedLabels > 0)) && 
		((controlPanel->calculate == CALCTYPE_TS) ||
		(controlPanel->calculate == CALCTYPE_OPT))) {
		if (controlPanel->calculate == CALCTYPE_OPT){
			if ((numLockedAtoms > 0) && (numLockedLabels > 0)) {
				sprintf(errs,"The molecule has %ld locked atoms and %ld "
							 "locked labels.  These locks will not be honored "
							 "in a ZINDO geometry optimization.",numLockedAtoms,
							 numLockedLabels);
			} else if (numLockedAtoms > 0) {
				sprintf(errs,"The molecule has %ld locked atoms.  These locks "
							 "will not be honored "
							 "in a ZINDO geometry optimization.",numLockedAtoms);
			} else if (numLockedLabels > 0) {
				sprintf(errs,"The molecule has %ld "
							 "locked labels.  These locks will not be honored "
							 "in a ZINDO geometry optimization.",numLockedLabels);
			}
		}
		if (controlPanel->calculate == CALCTYPE_TS){
			if ((numLockedAtoms > 0) && (numLockedLabels > 0)) {
				sprintf(errs,"The molecule has %ld locked atoms and %ld "
							 "locked labels.  These locks will not be honored "
							 "in a ZINDO transition state search.",numLockedAtoms,
							 numLockedLabels);
			} else if (numLockedAtoms > 0) {
				sprintf(errs,"The molecule has %ld locked atoms.  These locks "
							 "will not be honored "
							 "in a ZINDO transition state search.",numLockedAtoms);
			} else if (numLockedLabels > 0) {
				sprintf(errs,"The molecule has %ld "
							 "locked labels.  These locks will not be honored "
							 "in a ZINDO transition state search.",numLockedLabels);
			}
		}
		alert_user_watch(errs);
	}


    controlPanel->numberOfElectrons = 0;
	numberWithOneBasis = 0;
	numberWithFourBasis = 0;
	numberWithNineBasis = 0;
	numberWithSixteenBasis = 0;
	numberTransitionMetals = 0;
	numberTransitionMetals2 = 0;
	for (i=0; i < NAtom; i++) {
	    j=0;
        if (atomicNumber[i] >= 21 && atomicNumber[i] <= 30) numberTransitionMetals++;
        if (atomicNumber[i] >= 39 && atomicNumber[i] <= 47) numberTransitionMetals2++;
        if (atomicNumber[i] >= 57 && atomicNumber[i] <= 80) numberTransitionMetals++;
		if (atomicNumber[i] <= 0) numberWithNoBasis++;
	    if (atomicNumber[i] <= 2) {
		    j = atomicNumber[i];
			numberWithOneBasis++;
            basisType[i] = BASISTYPE_S;

		} else if (atomicNumber[i] <= 10) {
			j = atomicNumber[i] - 2;
			numberWithFourBasis++;
            basisType[i] = BASISTYPE_P;

		} else if (atomicNumber[i] <= 14) {
			j = atomicNumber[i] - 10;
			numberWithFourBasis++;
            basisType[i] = BASISTYPE_P;

		} else if (atomicNumber[i] <= 16) {
			j = atomicNumber[i] - 10;
			numberWithNineBasis++;
            basisType[i] = BASISTYPE_D;

		} else if (atomicNumber[i] <= 18) {
			j = atomicNumber[i] - 10;
			numberWithFourBasis++;
            basisType[i] = BASISTYPE_P;

/* Ca (atomic number 20) had a d-orbital basis */
		} else if (atomicNumber[i] <= 19) {
			j = atomicNumber[i] - 18;
			numberWithFourBasis++;
            basisType[i] = BASISTYPE_P;
/* Zn (atomic number 30) has a filled d shell, so there is no need
   to but a d-orbital basis on it */
		} else if (atomicNumber[i] <= 29) {
			j = atomicNumber[i] - 18;
			numberWithNineBasis++;
            basisType[i] = BASISTYPE_DNMINUS1;
		} else if (atomicNumber[i] <= 33) {
			j = atomicNumber[i] - 28;
			numberWithFourBasis++;
            basisType[i] = BASISTYPE_P;
		} else if (atomicNumber[i] <= 34) {
			j = atomicNumber[i] - 28;
			numberWithNineBasis++;
            basisType[i] = BASISTYPE_D;
		} else if (atomicNumber[i] <= 36) {
			j = atomicNumber[i] - 28;
			numberWithFourBasis++;
            basisType[i] = BASISTYPE_P;

		} else if (atomicNumber[i] <= 38) {
			j = atomicNumber[i] - 36;
			numberWithFourBasis++;
            basisType[i] = BASISTYPE_P;
/* Cd (atomic number 48) has a filled d shell, so there is no need
   to but a d-orbital basis on it */
		} else if (atomicNumber[i] <= 47) {
			j = atomicNumber[i] - 36;
			numberWithNineBasis++;
            basisType[i] = BASISTYPE_DNMINUS1;
		} else if (atomicNumber[i] <= 54) {
			j = atomicNumber[i] - 46;
			numberWithFourBasis++;
            basisType[i] = BASISTYPE_P;

		} else if (atomicNumber[i] <= 56) {
			j = atomicNumber[i] - 54;
			numberWithFourBasis++;
            basisType[i] = BASISTYPE_P;
		} else if (atomicNumber[i] <= 71) {
			j = atomicNumber[i] - 54;
			numberWithSixteenBasis++;
            basisType[i] = BASISTYPE_F;
/* Hg (atomic number 80) has a filled d shell, so there is no need
   to but a d-orbital basis on it */
		} else if (atomicNumber[i] <= 79) {
			j = atomicNumber[i] - 68;
			numberWithNineBasis++;
            basisType[i] = BASISTYPE_DNMINUS1;
		} else if (atomicNumber[i] <= 86) {
			j = atomicNumber[i] - 78;
			numberWithFourBasis++;
            basisType[i] = BASISTYPE_P;

		} else if (atomicNumber[i] <= 88) {
			j = atomicNumber[i] - 54;
			numberWithFourBasis++;
            basisType[i] = BASISTYPE_P;
		} else if (atomicNumber[i] <= 103) {
			j = atomicNumber[i] - 86;
			numberWithSixteenBasis++;
            basisType[i] = BASISTYPE_F;
		}
		controlPanel->numberOfElectrons += j;
		netValenceCharge[i] = j;
	}
	controlPanel->numberOfElectrons -= controlPanel->netCharge;
    totalBasis = numberWithOneBasis + 4*numberWithFourBasis + 9*numberWithNineBasis
	   + 16*numberWithSixteenBasis;
	numberTransitionMetals += numberTransitionMetals2;
	
	/* 
	 * Do a sanity check on the multiplicity.
	 * If there is an even number of electrons and the multiplicity
	 * is a doublet, quartet, or sextet, suggest that the multiplicity be
	 * set one level lower (e.g., doublet -> singlet).
	 * If there is an odd number of electrons and the multiplicity
	 * is a singlet, triplet or quintet, suggest that the multiplicity be 
	 * set one level higher (e.g., singlet -> doublet)
	 *
	 * Do a sanity check on the SCF type.  It there are an even number
	 * of electrons, all wavefunction types are sensible.  If the 
	 * multiplicity is higher than singlet, then the SCF type should be 
	 * either ROHF or UHF.  However, UHF cannot be used for C.I. 
	 *
	 * Return a positive error code to indicate to the application
	 * manager that it is OK to continue.
	 *
	 * Note: instruct_user_watch and inform_user_watch have different
	 * functions depending on whether the calling program is interactive
	 * or not.  For interactive (user interface) programs, 
	 * instruct_user_watch passes the message to the user, 
	 * inform_user_watch does nothing, and thecalling routine should 
	 * report an error for positive error codes.
	 * For detached (application manager, e.g.) programs, instruct_user_watch
	 * does nothing, inform_user_watch passes the message on to the
	 * user, and the calling routine should ignore positive error codes.
	 */
	if ((controlPanel->numberOfElectrons % 2) == 0) {

		/* even number of electrons */

		if (controlPanel->multiplicity == DOUBLET) {

			instruct_user_watch("You must change the multiplicity to be consistent "
				"with the number of electrons in your molecule.  Singlet "
				"multiplicity would be appropriate.");
			inform_user_watch("This calculation is being run as a singlet.");
			controlPanel->multiplicity = SINGLET;
			errorCode = 1;

		} else if (controlPanel->multiplicity == TRIPLET) {

			if (controlPanel->calculate == CALCTYPE_CI) {
				instruct_user_watch("A C.I. calculation cannot be done "
					"with this multiplicity.  Singlet multiplicity would "
					"be appropriate for an even number of electrons.");
				inform_user_watch("This calculation is being run as a singlet.");
				controlPanel->multiplicity = SINGLET;
				errorCode = 1;
			}

		} else if (controlPanel->multiplicity == QUARTET) {

			if (controlPanel->calculate == CALCTYPE_CI) {
				instruct_user_watch("You must change the multiplicity to be consistent "
					"with the number of electrons in your molecule.  Singlet "
					"multiplicity would be appropriate for a C.I. calculation.");
				inform_user_watch("This calculation is being run as a singlet.");
				controlPanel->multiplicity = SINGLET;
			} else {
				instruct_user_watch("You must change the multiplicity to be consistent "
					"with the number of electrons in your molecule.  Triplet "
					"multiplicity would be appropriate.");
				inform_user_watch("This calculation is being run as a triplet.");
				controlPanel->multiplicity = TRIPLET;
			}
			errorCode = 1;

		} else if (controlPanel->multiplicity == QUINTET) {

			if (controlPanel->calculate == CALCTYPE_CI) {
				instruct_user_watch("A C.I. calculation cannot be done "
					"with this multiplicity.  Singlet multiplicity would "
					"be appropriate for an even number of electrons.");
				inform_user_watch("This calculation is being run as a singlet.");
				controlPanel->multiplicity = SINGLET;
				errorCode = 1;
			}

		} else if (controlPanel->multiplicity == SEXTET) {

			if (controlPanel->calculate == CALCTYPE_CI) {
				instruct_user_watch("You must change the multiplicity to be consistent "
					"with the number of electrons in your molecule.  Singlet "
					"multiplicity would be appropriate for a C.I. calculation.");
				inform_user_watch("This calculation is being run as a singlet.");
				controlPanel->multiplicity = SINGLET;
			} else {
				instruct_user_watch("You must change the multiplicity to be consistent "
					"with the number of electrons in your molecule.  Quintet "
					"multiplicity would be appropriate.");
				inform_user_watch("This calculation is being run as a quintet.");
				controlPanel->multiplicity = QUINTET;
			}
			errorCode = 1;

		}

	} else {
		/* odd number of electrons */

		if (controlPanel->multiplicity == SINGLET) {

			instruct_user_watch("You must change the multiplicity to be consistent "
				"with the number of electrons in your molecule.  Doublet "
				"multiplicity would be appropriate.");
			inform_user_watch("This calculation is being run as a doublet.");
			controlPanel->multiplicity = DOUBLET;
			errorCode = 1;

		} else if (controlPanel->multiplicity == TRIPLET) {

			if (controlPanel->calculate == CALCTYPE_CI) {
				instruct_user_watch("You must change the multiplicity to be consistent "
					"with the number of electrons in your molecule.  Doublet "
					"multiplicity would be appropriate for a C.I. calculation.");
				inform_user_watch("This calculation is being run as a doublet.");
				controlPanel->multiplicity = DOUBLET;
			} else {
				instruct_user_watch("You must change the multiplicity to be consistent "
					"with the number of electrons in your molecule.  Quartet "
					"multiplicity would be appropriate.");
				inform_user_watch("This calculation is being run as a quartet.");
				controlPanel->multiplicity = QUARTET;
			}
			errorCode = 1;

		} else if (controlPanel->multiplicity == QUARTET) {

			if (controlPanel->calculate == CALCTYPE_CI) {
				instruct_user_watch("A C.I. calculation cannot be done "
					"with this multiplicity.  Doublet multiplicity would "
					"be appropriate for an odd number of electrons.");
				inform_user_watch("This calculation is being run as a doublet.");
				controlPanel->multiplicity = DOUBLET;
				errorCode = 1;
			}

		} else if (controlPanel->multiplicity == QUINTET) {

			if (controlPanel->calculate == CALCTYPE_CI) {
				instruct_user_watch("You must change the multiplicity to be consistent "
					"with the number of electrons in your molecule.  Doublet "
					"multiplicity would be appropriate for a C.I. calculation.");
				inform_user_watch("This calculation is being run as a doublet.");
				controlPanel->multiplicity = DOUBLET;
			} else {
				instruct_user_watch("You must change the multiplicity to be consistent "
					"with the number of electrons in your molecule.  Sextet "
					"multiplicity would be appropriate.");
				inform_user_watch("This calculation is being run as a sextet.");
				controlPanel->multiplicity = SEXTET;
			}
			errorCode = 1;

		} else if (controlPanel->multiplicity == SEXTET) {

			if (controlPanel->calculate == CALCTYPE_CI) {
				instruct_user_watch("A C.I. calculation cannot be done "
					"with this multiplicity.  Doublet multiplicity would "
					"be appropriate for an odd number of electrons.");
				inform_user_watch("This calculation is being run as a doublet.");
				controlPanel->multiplicity = DOUBLET;
				errorCode = 1;
			}
		}

	}
	
	/* Now that the multiplicity is set, check the SCF type */

	if (controlPanel->multiplicity == SINGLET) {
		if (errorCode == 1) /* Changed multiplicity */
			if (controlPanel->SCFtype == ROHFTYPE)
				alert_user_watch("Note that a ROHF wavefunction with "
					"singlet multiplicity calculates the first "
					"excited state.");
	} else {
		if (controlPanel->SCFtype == RHFTYPE) {
			instruct_user_watch("You must change the SCF type "
				"to be consistent with the number of electrons "
				"in your molecule. ROHF would be appropriate.");
			inform_user_watch("The SCF type for this calculation "
				"is being changed to ROHF in order to be consistent "
				"with the spin multiplicity.");
			controlPanel->SCFtype = ROHFTYPE;
			errorCode = 1;
		} else if (controlPanel->SCFtype == UHFTYPE && 
				controlPanel->calculate == CALCTYPE_CI) {
			instruct_user_watch("You must change the SCF type "
				"to be consistent with a C.I. calculation. "
				"ROHF would be appropriate.");
			inform_user_watch("The SCF type for this calculation "
				"is being changed to ROHF in order to be consistent "
				"with a C.I. calculation.");
			controlPanel->SCFtype = ROHFTYPE;
			errorCode = 1;
		} 
	}

	/* Get atom limits */

	if ((AtomLimit == 0) || (CiLimit == 0)) {

		/* If they've not been set by mam_PreProcess or getMolecule, get 
		 * atom and configuration limits for computational application */

		if (getAtomLimits(&AtomLimit, &CiLimit) != 0) {
			alert_user_watch("makeZINDOInput: unable to get atom limits.");
			csu_ReleaseVal (molStruct, AtomID, AnumID);
			/* clean up molstruct before returning */
			csu_DeleteMolstruct(molStruct, true, true);
			return (-1L); 
		}
	}

    if (controlPanel->calculate != CALCTYPE_CI) {
	   controlPanel->CIlevel = 0;
	   j = 0;
	   number_of_configurations = 0;
	} else {
	  /* Make sure that the C.I. level is at least 1 */
	  if (controlPanel->CIlevel < 1)
	  	controlPanel->CIlevel = 1;

	  /*
		  The maximum C.I. level (except for doublets, see below) is the square 
		  root of the maximum number of configurations.  E.g., for a CiLimit of
		  210, the maximum C.I. level is 14.
	  */
	  max_ci_level = (long) sqrt((double) (CiLimit - 1));
	  if ((controlPanel->CIlevel > max_ci_level) && 
	  		(controlPanel->multiplicity != DOUBLET)) {
		  sprintf(errs,"The C.I. level has been set to %d, the maximum available.",
			  max_ci_level);
		  alert_user_cilevel(errs);
		  controlPanel->CIlevel = max_ci_level;
	  }
	  if (controlPanel->multiplicity == SINGLET) {

	  /* Open-shell singlet state, two open shells one electron in each
		 orbital */
		numberOfUnpaired = 0;

	  /* Treat the highest spin cases only */
	  } else if (controlPanel->multiplicity == DOUBLET) {
		numberOfUnpaired = 1;
		
		/*
			For (ROHF) doublets, the maximum C.I. level is:  take half of the
			CiLimit (determined by where the calculation will run), since there
			are alpha and beta orbital blocks.  Then take the square root of this
			number.  This is the number of orbitals that can participate.  
			E.g., for a CiLimit of 210, the maximum C.I. level is 10.  This 
			gives 10x10 configs for the alpha block, and 9x9 configs for the 
			beta block.
		*/
		max_ci_level = (long) ((sqrt((double) (2*CiLimit - 1)) - 1) / 2);
		if (controlPanel->CIlevel > max_ci_level) {
			sprintf(errs,"The C.I. level has been set to %d, the maximum available "
					   "for doublet states.", max_ci_level);
			alert_user_cilevel(errs);
			controlPanel->CIlevel = max_ci_level;
		}

	  } else if (controlPanel->multiplicity == TRIPLET) {
		numberOfUnpaired = 2;

	  } else if (controlPanel->multiplicity == QUARTET) {
		numberOfUnpaired = 3;

	  } else if (controlPanel->multiplicity == QUINTET) {
		numberOfUnpaired = 4;

	  } else if (controlPanel->multiplicity == SEXTET)  {
		numberOfUnpaired = 5;
	  }
	  j = (controlPanel->numberOfElectrons+1)/2 + controlPanel->CIlevel;
      number_of_configurations = 
		ZINDO_MIN(CiLimit, controlPanel->CIlevel * controlPanel->CIlevel * 
		(numberOfUnpaired + 1) + 1 + controlPanel->CIlevel * 
		numberOfUnpaired * 2);
    }

	if (strstr(controlPanel->extraKeyWords, "NEL") == NULL)
		fprintf(file," NEL = %d\n", controlPanel->numberOfElectrons);

	if (strstr(controlPanel->extraKeyWords, "DYNAL") == NULL) {
		fprintf(file," DYNAL(1) = %d %d %d %d %d %d %d\n",numberWithNoBasis,
				numberWithOneBasis, numberWithFourBasis, numberWithNineBasis,
				numberWithSixteenBasis, number_of_configurations, j);
	}

	if (strstr(controlPanel->extraKeyWords, "IPRINT") == NULL)
    	fprintf(file," IPRINT = %d\n",controlPanel->printAmount);

	if (strstr(controlPanel->extraKeyWords, "RUNTYP") == NULL) {
		if (controlPanel->calculate == CALCTYPE_ENERGY) {
		   fprintf(file," RUNTYP = ENERGY\n");
		} else if ((controlPanel->calculate == CALCTYPE_OPT) ||
					(controlPanel->calculate == CALCTYPE_TS)){
		   fprintf(file," RUNTYP = GEOM\n");
		} else if (controlPanel->calculate == CALCTYPE_CI) {
		   fprintf(file," RUNTYP = CI\n");
		} 
	}

    if (controlPanel->detailsSCRxnF &&
		strstr(controlPanel->extraKeyWords, "ISCRF") == NULL) {
		fprintf(file," ISCRF = 1\n");
	}

	string[0] = 0;
	if (controlPanel->SCFtype == RHFTYPE)
		strncat(string, "RHF", 3);
	else if (controlPanel->SCFtype == UHFTYPE)
		strncat(string, "UHF", 3);
	else if (controlPanel->SCFtype == ROHFTYPE)
		strncat(string, "ROHF", 4);

	if (string[0] != 0 &&
		strstr(controlPanel->extraKeyWords, "SCFTYP") == NULL) {
	   fprintf(file," SCFTYP = %s \n", string);
	}

	if (controlPanel->SCFtype == ROHFTYPE) {
	   if (controlPanel->multiplicity == SINGLET) {

	   /* Open-shell singlet state, two open shells one electron in each
		  orbital */
	     fprintf(file,"    NOP = 2  NDT = 1 FOP(1) = %d.0  2.0\n",
		         controlPanel->numberOfElectrons - 2);

	   /* Treat the highest spin cases only */
	   } else if (controlPanel->multiplicity == DOUBLET) {
	     fprintf(file,"    NOP = 1  NDT = 1 FOP(1) = %d.0  1.0\n",
		         controlPanel->numberOfElectrons - 1);

	   } else if (controlPanel->multiplicity == TRIPLET) {
	     fprintf(file,"    NOP = 2  NDT = 1 FOP(1) = %d.0  2.0\n",
		         controlPanel->numberOfElectrons - 2);

	   } else if (controlPanel->multiplicity == QUARTET) {
	     fprintf(file,"    NOP = 3  NDT = 1 FOP(1) = %d.0  3.0\n",
		         controlPanel->numberOfElectrons - 3);

	   } else if (controlPanel->multiplicity == QUINTET) {
	     fprintf(file,"    NOP = 4  NDT = 1 FOP(1) = %d.0  4.0\n",
		         controlPanel->numberOfElectrons - 4);

	   } else if (controlPanel->multiplicity == SEXTET)  {
	     fprintf(file,"    NOP = 5  NDT = 1 FOP(1) = %d.0  5.0\n",
		         controlPanel->numberOfElectrons - 5);
	   }
	}

	string[0] = 0;
	if (controlPanel->scfConvergence == SCFCONVERGENCE_001)
		strncat(string, "0.001", 5);
	else if (controlPanel->scfConvergence == SCFCONVERGENCE_0001)
		strncat(string, "0.0001", 6);
	else if (controlPanel->scfConvergence == SCFCONVERGENCE_00001)
		strncat(string, "0.00001", 7);
	else if (controlPanel->scfConvergence == SCFCONVERGENCE_000001)
		strncat(string, "0.000001", 8);
	else if (controlPanel->scfConvergence == SCFCONVERGENCE_0000001)
		strncat(string, "0.0000001", 9);
	else if (controlPanel->scfConvergence == SCFCONVERGENCE_00000001)
		strncat(string, "0.00000001", 10);
	else if (controlPanel->scfConvergence == SCFCONVERGENCE_000000001)
		strncat(string, "0.000000001", 11);

	if (string[0] != 0 &&
		strstr(controlPanel->extraKeyWords, "SCFTOL") == NULL) {
	   fprintf(file," SCFTOL = %s\n", string);
	}

    /* Write geometry optimization information */

	if (controlPanel->calculate == CALCTYPE_TS) i=3;
	  else if (controlPanel->calculate == CALCTYPE_ENERGY
	  		|| controlPanel->calculate == CALCTYPE_CI) i=0;
	  else i=2;

    if (controlPanel->calculate == CALCTYPE_TS)
		/* If transition state, geometry search via analytic Hessian */
		j=2; 
	  else 
	  	/* otherwise geometry search via Updated Hessian */
		j=0;

	if (strstr(controlPanel->extraKeyWords, "III") == NULL) {
		if (controlPanel->calculate == CALCTYPE_OPT) {
	
			k = 0;
			if (controlPanel->geometrySearch == SEARCHTYPE_AH)
				k = 1;
			else if (controlPanel->geometrySearch == SEARCHTYPE_GN)
				k = 4;
	
			fprintf(file," III = %1d%1d%1d%1d\n", i, k, j,
					controlPanel->geometryConvergence -1);
		} else if (controlPanel->calculate == CALCTYPE_TS) {
	
			/* Always use Augmented Hessian for transition state searches */
			k = 1;
			fprintf(file," III = %1d%1d%1d%1d\n", i, k, j,
					controlPanel->geometryConvergence -1);
		}
	}

	if (strstr(controlPanel->extraKeyWords, "INTFA") == NULL) {
		if (controlPanel->parameters == PARAMTYPE_IEH) {
			fprintf(file," INTFA(1) = 1.89 1.89 1.89 1.89 1.89 1.89\n");
		} else if (controlPanel->calculate == CALCTYPE_TS || controlPanel->calculate == CALCTYPE_OPT) {
			if (numberTransitionMetals2 > 0) {
	/*
	
	   Mike Zerner has vacillated on the interaction factors to be used for geometries
	   of transition metal complexes.  Spectroscopic interaction factors seem to be
	   required to reproduce the  January, 1990 Inorganic Chemistry article,
	   but now (July, 1990) he recommends the use of all 1.0's for the interaction factors,
	   so that total energies are consistent.  Thus, the total energy
	   of ethylene plus the total energy of Fe equals the total energy
	   of the ethylene-Fe complex at long distances.
	
	
	 */
			  fprintf(file," INTTYP = 0 INTFA(1) = 1.0 1.0 1.0 1.0 1.0 1.0"
						   " ISW2 = %d\n", controlPanel->metalConfigMixing - 1);
			} else if (numberTransitionMetals > 0 &&
					   ((controlPanel->metalConfigMixing -1) != 3)) {
			  fprintf(file," INTTYP = 0 INTFA(1) = 1.0 1.0 1.0 1.0 1.0 1.0"
						   " ISW2 = %d\n", controlPanel->metalConfigMixing - 1);
			} else
			  fprintf(file," INTTYP = 0 INTFA(1) = 1.0 1.0 1.0 1.0 1.0 1.0\n");
		} else if ((strstr(controlPanel->extraKeyWords,"INTTYP=0") != 0) && 
			controlPanel->calculate == CALCTYPE_ENERGY) {
			/*
				Put in the same values of INTFA generated for the geometry 
				optimization if INTTYP=0 is present in the extra keywords.
			 */
			if (numberTransitionMetals2 > 0) {
			  fprintf(file," INTFA(1) = 1.0 1.0 1.0 1.0 1.0 1.0"
						   " ISW2 = %d\n", controlPanel->metalConfigMixing - 1);
			} else if (numberTransitionMetals > 0 &&
					   ((controlPanel->metalConfigMixing -1) != 3)) {
			  fprintf(file," INTFA(1) = 1.0 1.0 1.0 1.0 1.0 1.0"
						   " ISW2 = %d\n", controlPanel->metalConfigMixing - 1);
			} else
			  fprintf(file," INTFA(1) = 1.0 1.0 1.0 1.0 1.0 1.0\n");
		} else if (controlPanel->calculate == CALCTYPE_CI) {
		  if (numberTransitionMetals > 0) {
			fprintf(file," INTTYP = 1  INTFA(1) = 1.0 1.2675 0.640 1.0 1.0 1.0"
						 " ISW2 = %d\n", controlPanel->metalConfigMixing - 1);
		  } else if (controlPanel->multiplicity == 3) {
			fprintf(file," INTTYP = 1  INTFA(1) = 1.0 1.2675 0.680 1.0 1.0 1.0\n");
		  } else {
			fprintf(file," INTTYP = 1  INTFA(1) = 1.0 1.2675 0.585 1.0 1.0 1.0\n");
		  }
		}
	}

	if (strstr(controlPanel->extraKeyWords, "MULT") == NULL)
		fprintf(file," MULT = %d\n", controlPanel->multiplicity);

	if (strstr(controlPanel->extraKeyWords, "IAPX") == NULL)
		fprintf(file," IAPX = %d\n", (controlPanel->parameters - 1));

	string[0] = 0;
	if (controlPanel->spaceSymmetry == SPACESYMMETRY_C2V)
		strncat(string,"C2V",3);
	else if (controlPanel->spaceSymmetry == SPACESYMMETRY_C2)
		strncat(string,"C2",2);
	else if (controlPanel->spaceSymmetry == SPACESYMMETRY_CI)
		strncat(string,"CI",2);
	else if (controlPanel->spaceSymmetry == SPACESYMMETRY_CH)
		strncat(string,"CH",2);
	else if (controlPanel->spaceSymmetry == SPACESYMMETRY_C2H)
		strncat(string,"C2H",3);
	else if (controlPanel->spaceSymmetry == SPACESYMMETRY_D2)
		strncat(string,"D2",2);
	else if (controlPanel->spaceSymmetry == SPACESYMMETRY_D2H)
		strncat(string,"D2H",3);

	if (string[0] != 0 &&
		strstr(controlPanel->extraKeyWords, "ASYM") == NULL) {
		fprintf(file," ASYM = %s\n", string);
	}

	if (strstr(controlPanel->extraKeyWords, "ITMAX") == NULL)
    	fprintf(file," ITMAX = %d\n", controlPanel->maxSCFiterations);

	/* Print the keywords */
	if (controlPanel->extraKeyWords[0] != 0)
	    fprintf (file, " %s\n", controlPanel->extraKeyWords);

    /* $CONTRL block is complete. */
	fprintf(file," $END\n");

    if (controlPanel->detailsSCRxnF) {
		fprintf(file," $SCRFIN\n");
		if (controlPanel->cavityRadiusMeaning == RADIUS_EXTEND) {
			/* Change the sign of the radius */
			fprintf(file,"%5d%5d%10lf%10lf%10lf%10lf%10lf%10lf\n",
		        1, 2, -controlPanel->cavityRadiusExtend, controlPanel->dielectric,
				controlPanel->refractiveIndex, 0., 0., 0.);
		} else {
			fprintf(file,"%5d%5d%10lf%10lf%10lf%10lf%10lf%10lf\n",
		        1, 2, controlPanel->cavityRadiusTotal, controlPanel->dielectric,
				controlPanel->refractiveIndex, 0., 0., 0.);
		}
		fprintf(file," $END\n");
	}

{
	char	(*atsymbol)[2];
	double  (*tmpcoord)[3];
	PropID	propi, numprops;
	ObjectID num_valloc;
	int		i;
    BitH 	XYZ_hasValueH;
	PropH	propsH;

   /* delete Molecular Orbital object classes as they will be re-used.
      This is a fix for the aging problem */

   if (csu_ExistsObjclsID (molStruct, MolecOrbitalID, &offset))
     ed_DeleteObjcls(molStruct, MolecOrbitalID, 2);
   if (csu_ExistsObjclsID (molStruct, STOBasisFxnID, &offset))
     ed_DeleteObjcls(molStruct, STOBasisFxnID, 2);

	/* Since we don't move electrons during a geometry optimization,
	   better invalidate the coordinates of the lone pairs now. */

   if (csu_ExistsObjclsID (molStruct, OrbitalID, &offset)) {
	  propsH   = (GetPtr(molStruct->objclsH) + offset)->propsH;
	  numprops = (GetPtr(molStruct->objclsH) + offset)->num_props;
	  num_valloc = (GetPtr(molStruct->objclsH) + offset)->num_valloc;
	  if (csu_ExistsPropID(propsH, XYZID, numprops, &propi)) {
		  XYZ_hasValueH  = (GetPtr(propsH) + propi)->has_valueH;
		  for (i=0; i<num_valloc; i++)
		     csu_ClearBit (XYZ_hasValueH, i);	/* now has a invalid value */
	  }
   }


   /*
    *  Set the array pointers for the atomic coordinates, atomic numbers,
    *  and atom symbols.
    */

   if ((rtn_code = csu_GrabVal (molStruct, AtomID, XYZID, (char **)&(tmpcoord))) < 0) {
     sprintf (errs," makeZINDOInput : csu_GrabVal XYZID, errno %d", rtn_code);
	 alert_user_watch(errs);
     goto errorReturn;
   }

  if ((rtn_code = csu_GrabVal (molStruct, AtomID, SymID, (char **)&atsymbol)) < 0) {
    sprintf (errs," makeZINDOInput : csu_GrabVal SymID, errno %d", rtn_code);
    alert_user_watch(errs);
     goto errorReturn;
  }

  /* Write the Coordinate information to the ZINDO Input file */

  /* This block of code is used when input in cartesian coordinates
	 is required. */

  fprintf(file," $DATAIN\n");
  for (i=0; i<NAtom; i++) {
	  fprintf(file,"%10.6lf%10.6lf%10.6lf%5d%10.6lf%5d\n",
			  tmpcoord[i][0], tmpcoord[i][1], tmpcoord[i][2],
			  atomicNumber[i], netValenceCharge[i], basisType[i]);
  }
  fprintf(file," $END\n");
  
  if (basisType != NULL) {
	  free(basisType);
	  basisType = NULL;
  }
  if (netValenceCharge != NULL) {
	  free(netValenceCharge);
	  netValenceCharge = NULL;
  }

    /* Define the $CIINP input block if a CI calculation is performed. */
    if (controlPanel->calculate == CALCTYPE_CI) {
	    int fermiLevel;
		fermiLevel = (controlPanel->numberOfElectrons - numberOfUnpaired)/2;
		fprintf(file," $CIINPU\n");
/*		fprintf(file,"    4    1   20    1    1    1    0    1    1    2   20\n");*/
		/* Have ZINDO calculate all the roots accessible for the specified CI level */
		fprintf(file,"    4    1 %4d    1    1    1    0    1    1    2 %4d\n",
			number_of_configurations,number_of_configurations);
		fprintf(file,"   -60000.   0.       \n");
		fprintf(file,"    0    0    0    0    0    0    0    0    0\n");
		
/*		modified 1/25/91 SJC to allow for > 99 basis functions.
		fprintf(file,"0001%2d%2d",fermiLevel,fermiLevel);
		for (j = fermiLevel+1; j <= fermiLevel+numberOfUnpaired; j++) fprintf(file,"%2d",j);
		fprintf(file," 0\n");
		fprintf(file,"0021%2d%2d%2d%2d\n", ZINDO_MAX(fermiLevel - controlPanel->CIlevel + 1,1),
		        fermiLevel + numberOfUnpaired, fermiLevel+1,
				ZINDO_MIN(fermiLevel + controlPanel->CIlevel + numberOfUnpaired,totalBasis));*/

		fprintf(file,"00001%5d%5d",fermiLevel,fermiLevel);
		for (j = fermiLevel+1; j <= fermiLevel+numberOfUnpaired; j++) fprintf(file,"%5d",j);
		fprintf(file,"    0\n");
		fprintf(file,"00021%5d%5d%5d%5d\n", ZINDO_MAX(fermiLevel - controlPanel->CIlevel + 1,1),
		        fermiLevel + numberOfUnpaired, fermiLevel+1,
				ZINDO_MIN(fermiLevel + controlPanel->CIlevel + numberOfUnpaired,totalBasis));
		fprintf(file," $END\n");
	}

    if ((rtn_code = csu_ReleaseVal (molStruct, AtomID, AnumID)) < 0) {
       sprintf (errs," makeZINDOInput : csu_ReleaseVal AnumID, errno %d", rtn_code);
       alert_user_watch(errs);
    }

    if ((rtn_code = csu_ReleaseVal (molStruct, AtomID, SymID)) < 0) {
       sprintf (errs, "makeZINDOInput : csu_ReleaseVal SymID, errno %d", rtn_code);
       alert_user_watch(errs);
    }

    if ((rtn_code = csu_ReleaseVal (molStruct, AtomID, XYZID)) < 0) {
       sprintf (errs, "makeZINDOInput : csu_ReleaseVal XYZID, errno %d", rtn_code);
       alert_user_watch(errs);
    }

 }
	fclose(file);

	leaveBusyState();
	
	if (errorCode > 0)
		return(errorCode);
	else
		return (0);

errorReturn:
	if (basisType != NULL) {
		free(basisType);
		basisType = NULL;
	}

	if (netValenceCharge != NULL) {
		free(netValenceCharge);
		netValenceCharge = NULL;
	}

	fclose(file);
	leaveBusyState();
	return (errorCode);

}

int makeZINDOInput(
	MolStruct *molStruct, 
	ZINDOControl *origControlPanel,
	double *new_cutoff
)
{
	/* makeZINDOInput is not allowed to modify the contents of the control panel */
	ZINDOControl *controlPanel;
	int			rtn_code = 0;

	controlPanel = (ZINDOControl *) malloc(sizeof(ZINDOControl));
	if (controlPanel == NULL) {
		alert_user("makeZINDOInput: ZINDO is unable to allocate memory for "
			"control panel.");
		return (-1);
	}

	*controlPanel = *origControlPanel;

	rtn_code = makeZINDOInput1(molStruct, controlPanel, new_cutoff);

	free(controlPanel);
	return (rtn_code);
}
