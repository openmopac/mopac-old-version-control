/*
 * SimpleExceptions.h
 *
 * SimpleExceptions are a limited C version of C++ exceptions.
 * Normal code goes in the SPX_TRY block.
 * Exception code goes in the SPX_CATCH blocks.
 * Exceptions are raised by the SPX_THROW operation.
 * Exactly one SPX_CATCH block is executed when an exception is thrown.
 * No SPX_CATCH block is executed if no exception is thrown.
 *
 * The sample code below can be modified to throw no exception
 * or to throw either err1 or err2.
 */

#ifndef SIMPLE_EXCEPTIONS_H
#define SIMPLE_EXCEPTIONS_H

#define SPX_TRY             if (1)
#define SPX_THROW(xlabel)   goto xlabel
#define SPX_CATCH(xlabel)   else if (0) xlabel:

#if 0

#include <stdio.h>

main()
{
    int dummy_err_flag = 1; // Change this to 0 if no exception is to be thrown

    printf("main: enter\n");

    SPX_TRY {
        printf("main: begin try\n");
        if (dummy_err_flag) SPX_THROW(err1); /* change the SPX_CATCH block name here */
        printf("main: end try\n");
    }
    SPX_CATCH(err1) {
        printf("main: err1\n");
    }
    SPX_CATCH(err2) {
        printf("main: err2\n");
    }

    printf("main: exit\n");
}

#endif

#endif
