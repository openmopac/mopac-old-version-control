/*
 * UnixEventMgr.h
 */

#ifndef	UNIX_EVENT_MGR_H
#define	UNIX_EVENT_MGR_H

#include <stddef.h>
#include <stdio.h>

#if defined(_WIN32)
#include <process.h>
#endif

#include <ChannelMgr.h>

#define UEM_MAX_UEMS	16

enum uem_Boolean {
	uem_BooleanFalse,
	uem_BooleanTrue,
	uem_BooleanDummy = 0x12345678
};
typedef enum uem_Boolean uem_Boolean;

enum uem_Err {
	uem_ErrNone = 0,
	uem_ErrUnknown = -8999,
	uem_ErrOutOfMemory,
	uem_ErrTimeout,
	uem_ErrNoSuchEvent,
	uem_ErrBadEvent,
	uem_ErrChannelSendFailed,
	uem_ErrChannelRecvFailed,
	uem_ErrBadUEM,
	uem_ErrBadState,
	uem_ErrStopped,
	uem_ErrBadAddrType,
	uem_ErrArrayOverrun,
	uem_ErrDummy = 0x12345678
};
typedef enum uem_Err uem_Err;

enum uem_ReplyType {
	uem_ReplyType_None,
	uem_ReplyType_Wait,
	uem_ReplyType_Queue,
	uem_ReplyType_Dummy = 0x12345678
};
typedef enum uem_ReplyType uem_ReplyType;

#if defined(_WIN32)

enum uem_State {
	uem_State_Start,
	uem_State_Run,
	uem_State_Stop,
	uem_State_Exit,
	uem_State_Dummy = 0x12345678
};
	
#elif	defined(unix)

enum uem_State {
	uem_State_Start,
	uem_State_RcvgHdr,
	uem_State_RcvgData,
	uem_State_Stop,
	uem_State_Dummy = 0x12345678
};
	
#endif

typedef enum uem_State uem_State;

#if defined(unix)
typedef int uem_CriticalSection;
#elif defined(_WIN32)
typedef CRITICAL_SECTION uem_CriticalSection;
#endif

typedef void (*uem_ExitHdlr)(uem_Err uem_err, void *exitHdlrData);

struct uem_Buffer {
	long	len;
	char	data[1];
};
typedef struct uem_Buffer uem_Buffer;

/*
 * These structure precede evey UE sent
 * so that the recipient may create a UE
 * and its message buffer.
 */
struct uem_MsgHdr {
	long			len;	/* length of the UE to be sent (from uem_Buffer) */

	/* These contain four-character names identical to the Apple Event class and id. */
	/* These are taken from the uem_UnixEventItem structure. */
	unsigned long	class_desc;
	unsigned long	id_desc;
	unsigned long	id;		/* id from message (used for async replies) */
};
typedef struct uem_MsgHdr uem_MsgHdr;

struct uem_ReplyHdr {
	long			len;	/* length of the UE reply to be sent (from uem_Buffer) */
	unsigned long	id;		/* id from message (used for async replies) */
};
typedef struct uem_ReplyHdr uem_ReplyHdr;

/* UnixEvent class */

struct uem_UnixEventItem {
	char			*name;

	/* These contain 4 character names identical to the Apple Event class and id. */
	unsigned long	class_desc;
	unsigned long	id_desc;

	size_t			instance_size;
	
	/* Defined in sender. */
	uem_Err (*packMsg)(/* struct uem_UnixEvent */void *ue);
	uem_Err (*unpackReply)(/* struct uem_UnixEvent */void *ue);

	/* Defined in receiver. */
	uem_Err (*handler)(/* struct uem_UnixEvent */void *ue);
	uem_Err (*unpackMsg)(/* struct uem_UnixEvent */void *ue);
	uem_Err (*packReply)(/* struct uem_UnixEvent */void *ue);
};
typedef struct uem_UnixEventItem  uem_UnixEventItem;
typedef struct uem_UnixEventItem* uem_UnixEventItemPtr;

struct uem_UnixEventList {
	long				numItems;
	uem_UnixEventItem	item[1];
};
typedef struct uem_UnixEventList  uem_UnixEventList;
typedef struct uem_UnixEventList* uem_UnixEventListPtr;

struct uem_UnixEventClass {

	uem_UnixEventListPtr	eventList;
	long			next_id; /* unique id of next UE to be created */
};
typedef struct uem_UnixEventClass uem_UnixEventClass;


#define UEM_UNIX_EVENT_BASE				\
	uem_UnixEventItemPtr	classp;			\
	unsigned long		id;			\
	enum uem_ReplyType	replyType;		\
	void			*eventHdlrData;		\
	chm_NetAddr		receiver;		\
	chm_NetAddr		sender;			\
	struct uem_Buffer	*msgBuf;		\
	struct uem_Buffer	*replyBuf;		\
	long			uem_unix_event_pad;

struct uem_UnixEvent {
	UEM_UNIX_EVENT_BASE
	/* Subclass attributes are added here. */
};
typedef struct uem_UnixEvent uem_UnixEvent;

#ifdef __cplusplus
extern "C" {
#endif

/* UnixEvent class operations */

uem_Err uem_UnixEventClass_Init(uem_UnixEventListPtr eventList);
uem_Err uem_UnixEventClass_Term(void);

/* UnixEvent operations */

uem_Err uem_UnixEvent_Create(struct uem_UnixEvent **ue,
	unsigned long class_desc, unsigned long id_desc);
uem_Err uem_UnixEvent_Delete(struct uem_UnixEvent *ue);

uem_Err	uem_UnixEvent_PackMsg(struct uem_UnixEvent *ue);
uem_Err	uem_UnixEvent_UnpackMsg(struct uem_UnixEvent *ue);
uem_Err	uem_UnixEvent_PackReply(struct uem_UnixEvent *ue);
uem_Err	uem_UnixEvent_UnpackReply(struct uem_UnixEvent *ue);
uem_Err	uem_UnixEvent_Handler(struct uem_UnixEvent *ue);

#ifdef __cplusplus
}
#endif

/* UnixEventMgr class */

/* Forward references */
typedef struct uem_UnixEventMgr uem_UnixEventMgr;

struct uem_UnixEventMgrClass {
	char			*name;
	uem_CriticalSection	cs;
	int			num_uems;		/* number of UEMs used */
	uem_UnixEventMgr	*uem[UEM_MAX_UEMS];	/* null means not used */
	long			next_id;		/* unique id of next UEM to be created */
	uem_Boolean		debug;			/* turns debugging on & off */
	FILE			*fp;			/* logfile or NULL */
};
typedef struct uem_UnixEventMgrClass uem_UnixEventMgrClass;
 
struct uem_UnixEventMgr {

	uem_UnixEventMgrClass		*classp;
	long				id;
	uem_State			state;

	uem_CriticalSection		cs;

	chm_Channel			*rchan;		/* recv messages, send replies */
	chm_Channel			*schan;		/* send messages, recv replies */
	void				*eventHdlrData;	/* data passed to event handler in UEM_UNIX_EVENT_BASE */
	uem_ExitHdlr			exitHdlr;	/* UEM exit handler */
	void				*exitHdlrData;	/* data passed to UEM exception handler */
	
	chm_ChannelClient		rClient;	/* saved copy of rchan's client */
	chm_ChannelClient		sClient;	/* saved copy of schan's client */

#if defined(unix)
	uem_MsgHdr			msgHdr;
	uem_ReplyHdr			replyHdr;
	uem_UnixEvent			*evt;
#elif defined(_WIN32)
	HANDLE				thread;
	unsigned			threadId;
#endif
};
/* typedef struct uem_UnixEventMgr uem_UnixEventMgr; */

#ifdef __cplusplus
extern "C" {
#endif

/* UnixEventMgr class operations */

uem_Err
uem_UnixEventMgrClass_Init(
uem_Boolean	debug,
FILE		*fp		/* logfile or NULL */
);

uem_Err
uem_UnixEventMgrClass_Term(
void
);


/* UnixEventMgr operations */

uem_Err
uem_UnixEventMgr_Create(
uem_UnixEventMgr	**newUem,	/* ptr to new UEM OUT */
chm_Channel		*rchan,		/* recv channel connected to peer UEM */
chm_Channel		*schan,		/* send channel connected to peer UEM */
void			*eventHdlrData,	/* data passed to event handler in UEM_UNIX_EVENT_BASE */
uem_ExitHdlr		exitHdlr,	/* UEM exit handler */
void			*exitHdlrData	/* data passed to UEM exception handler */
);

uem_Err
uem_UnixEventMgr_Delete(
uem_UnixEventMgr	*uem
);

uem_Err
uem_UnixEventMgr_Send(
uem_UnixEventMgr	*uem,
uem_UnixEvent		*evt
);

uem_Err uem_UnixEventMgr_Stop( uem_UnixEventMgr *uem, chm_Boolean async );

#ifdef __cplusplus
}
#endif

#endif
