#include "compat.h"
#include "ZINDODriver.h"
#include "cpu.h"

extern FILE	*movie_fp;

int dependentHeader(MolStruct *ms, ObjclsID objclsID, PropID propID, long v_bytes, 
	long vec_len, long v_type, long unitN, long num_IDs, long *ID_list)
/* 
 * objclsID, propID		object class and property where values are stored
 * v_bytes, vec_len		bytes per field, fields per value
 * v_type				type of values
 * ID_list				object indexes for whom IDs are to be written
 *
 * return number of IDs written 
 *
** Discussion:
**	!(v_type & 1) -> integer, (v_type & 1) -> floating
**	!(v_type & 2) -> unsigned, (v_type & 2) -> signed
**	v_bytes can be 1, 2, 3, or 4.
**	if !(v_type & 1), one 8, 16, 24, or 32 bit integer is written for each field.
**	if (v_type & 1) and v_bytes is 4, one 32 bit float is written for each field.
**	if (v_type & 1) and v_bytes < 4, one 32 bit float (written at the start
**	of the values for this object class and property), is muliplied by the
**	8, 16, or 24 bit integers for each field to produce floating point values.
*/
{
	LongH valuesH;		/* handle to array of IDs */
	ObjclsID name_i;
	long i, j;
	long num;

	if (vec_len < 1 || v_bytes < 1 || v_bytes > 4)
		return -1; /* invalid number of bytes or fields */

	/* write objcls name */
	if (objclsID >= 0 && objclsID < DataDict.num_objcls) {
		name_i = (GetPtr(DataDict.objclsdictH) + objclsID)->objclsN;
		fprintf(movie_fp, "%s ", GetPtr(DataDict.namesH)[name_i]);
	}
	else
		fprintf(movie_fp, "not_objcls ");

	/* write prop name */
	if (propID >= 0 && propID < DataDict.num_props) {
		name_i = (GetPtr(DataDict.propdictsH) + propID)->propN;
		fprintf(movie_fp, "%s ", GetPtr(DataDict.namesH)[name_i]);
	}
	else
		fprintf(movie_fp, "not_prop ");

	/* write data length and type */
	fprintf(movie_fp, "%d %d %d ", v_bytes, vec_len, v_type);

	/* write units of property */
	if (unitN < 0 || unitN >= DataDict.num_names)
		unitN = NoUnit;
	fprintf(movie_fp, "%s ", GetPtr(DataDict.namesH)[unitN]);

	/* write number of objects and object IDs */
	num = csu_GetPropArrays(ms,objclsID,ID_ID,NULL,NULL,(ValueH *)&valuesH);
	if (num < 0)
		num = 0;
	if (ID_list == NULL) {
		if (num_IDs < 0) {
			i = num_IDs;
			num_IDs = -i;
			fprintf(movie_fp, "%d\n", num_IDs);
			for (; i < 0; i++)
				fprintf(movie_fp, " %d", i);
		}
		else {
			if (num_IDs == 0)
				num_IDs = num;
			fprintf(movie_fp, "%d\n", num_IDs);
			for (i = 0; i < num_IDs; i++) {
				if (i < num)
					fprintf(movie_fp, " %d", GetPtr(valuesH)[i]);
				else
					fprintf(movie_fp, " %d", i - num_IDs);
			}
		}
	}
	else {
		if (num_IDs < 0)
			num_IDs = 0;
		fprintf(movie_fp, "%d\n", num_IDs);
		for (j = 0; j < num_IDs; j++) {
			i = ID_list[j];
			if (i < num && i >= 0)
				fprintf(movie_fp, " %d", GetPtr(valuesH)[i]);
			else
				fprintf(movie_fp, " %d", j - num_IDs);
		}
	}
	fprintf(movie_fp, "\n");
	return num_IDs;
}
