#ifndef OMFCACheULD__ 
#define OMFCACheULD__ 

// Define symbol which controls DLL import/export on Windows platforms

#ifdef macintosh

#define _CACHE_LIC_IMPEXP

#else

#ifdef WIN32
#ifndef _CACHE_LIC_IMPEXP
#ifdef _CACHE_LIC_DLL
#define _CACHE_LIC_IMPEXP _declspec(dllexport)
#else
#define _CACHE_LIC_IMPEXP _declspec(dllimport)
#endif
#endif
#endif

#endif

// 
// File: OMFCACheULD.h 
// 
// Class: OMFCACheULD 
// 
// Description: a class which represents CAChe Universal License
// Descriptors.
// 
// Intended usage: 
// Outline the function of the class, and how it should be 
// used by the programmer, here. Note if this is an abstract 
// base class. 
// 
// Design notes: 
// 
// (1) Any further detailed design information can go here. 
// (2) This is a good place to explain how to subclass a class 
// which is intended as a base class. 
// (3) TODO: this is one way to add notes as placeholders for future enhancements. 
// 
// Created: 06/03/98 David J Allan, Oxford Molecular 
// 
// Modification history: 
// Who When What 
// JAW 01/02/96 Put comments here in this format for minor changes 
// 

// Includes 

#ifndef macintosh

// System headers first - in <> 
#include <windows.h>
#include <winreg.h>

#endif

#include <iostream.h> 
#include "OMFBool.h"
#include "OMFStlString.h"
#include "config.h"

#ifdef macintosh

#define _CACHE_LIC_IMPEXP

#else

#ifdef WIN32
#ifndef _CACHE_LIC_IMPEXP
#ifdef _CACHE_LIC_DLL
#define _CACHE_LIC_IMPEXP _declspec(dllexport)
#else
#define _CACHE_LIC_IMPEXP _declspec(dllimport)
#endif
#endif
#endif

#endif

// ULD version numbers
#define ULD_VERSION_4_4  '1'
#define ULD_VERSION_5_0  '2'
#define ULD_VERSION_6_0  '3'


// Pre-declarations 
class _CACHE_LIC_IMPEXP ByteInputStream
{
public:
    ByteInputStream( unsigned char* area, size_t areaLen );
    void SetFail(void);
    bool Fail(void) const;
    void Read( void* theData, size_t theDataSize );

private:
    unsigned char* itsArea;
    size_t itsAreaLen;
    size_t itsSpaceUsed;
    size_t itsSpaceLeft;
    bool itsFailed;
};

class _CACHE_LIC_IMPEXP ByteOutputStream
{
public:
    ByteOutputStream( unsigned char* area, size_t areaLen );
    void SetFail(void);
    bool Fail(void) const;
    void Write( void* theData, size_t theDataSize );
    size_t GetUsed(void) const;

private:
    unsigned char* itsArea;
    size_t itsAreaLen;
    size_t itsSpaceUsed;
    size_t itsSpaceLeft;
    bool itsFailed;
};

// Class declaration - OMFCACheULD 
class _CACHE_LIC_IMPEXP OMFCACheULD
{ 
public:

   // Constructor 1 
   OMFCACheULD(void); 

   // Destructor 

   // Virtual destructor 
   virtual ~OMFCACheULD(void); 


   // Other public member functions and typedefs 

   typedef unsigned long CUSTOMERID;

   // Asynchronous event types
   enum HANDLED_EVENT
   {
       LOSS_OF_SERVER=1,
      SYS_TIME_CHANGE=2
   };

   // External handler for asynchronous events
   typedef void (*ASYNCH_EVENT_HANDLER)( OMFCACheULD* theULD, HANDLED_EVENT theHandler, const char *theError );


   // ULD license types
   enum LICTYPE
   {
       LO_ILLEGAL_LICTYPE=0,
       CPD=1,
       FLOATING=2,
       TIMEBOMB=3,
       SW_PERMANENT=4,
       HI_ILLEGAL_LICTYPE=5
   };

   enum SPECIALID
   {
       NONE=0,
       AASL=1,
       ACADEMIC=2,
       CORPORATE=3,
       EVALUATION=4,
       ACS_FREEBEE=5,
       SPECIAL1=6,
       SPECIAL2=7,
       SPECIAL3=8,
       SPECIAL4=9,
       TEMPORARY=10
   };

   enum ENCRYPTION_TYPE
   {
       //indicates encryption keys used in current CAChe version - v6.0
       MACHINE_CHARACTERISTIC=1,
       MACHINE_CHARACTERISTIC_MAC,
       KEY_VERSION_1,
       //indicates encryption keys used in current CAChe version - v5.0/4.9
       MACHINE_CHARACTERISTIC_CACHE_V5,
       MACHINE_CHARACTERISTIC_MAC_CACHE_V5,
       KEY_VERSION_1_CACHE_V5,
       //indicates encryption keys used in previous CAChe version
       // V4 - CAChe v4.4for Windows, and CAChe 4.5 for Macintosh
       MACHINE_CHARACTERISTIC_MAC_CACHE_V4,
       MACHINE_CHARACTERISTIC_CACHE_V4,
       KEY_VERSION_1_CACHE_V4,
       // V3 - CAChe v3.22 (and earlier) for Windows, and CAChe 4.12 (and earlier) for Macintosh
       MACHINE_CHARACTERISTIC_MAC_CACHE_V3,
       MACHINE_CHARACTERISTIC_CACHE_V3,
       KEY_VERSION_1_CACHE_V3,

       //TODO Add a new encryption type if you want to change the licensing method
   };

   enum PLATFORM
   {
       PLATFORM_MAC,PLATFORM_PC
   };

   enum ENCRYPT_FORMAT
   {
      CREDIT_CARD_FORMAT=1,
      MACHINE_FORMAT=2
   };

    // ULD feature identifiers
    //
    // Note the values of composite features are constrained by license
    // numbers issued for CAChe 3.1 and earlier.

    enum FEATURE
    {
        // Illegal feature
        FF_ILLEGAL = 0,

        // Composite feature identifiers
        CF_QUANTUM_CACHE = 1,
        CF_PERSONAL_CACHE = 2,
        CF_CACHE_SATELLITE = 3,
        CF_CACHE_WORKSYSTEM = 4,
        CF_PC_PLUS_PL = 5,
        CF_PC_W_ACCESS = 6,
        CF_PC_W_ACCESS_PLUS_PL = 7,
        CF_CACHE_MEDCHEM = 8,
        // CAChe 5.0 new products
        CF_AB_INITIO_CACHE = 9,
        CF_CACHE_WORKSYSTEM_PRO = 10,
        // CAChe 6.0 new products
        CF_BIO_CACHE = 11,

        CF_MAX_FEATURE = 99,

        // Base feature identifiers

        // GUIs
        BF_WORKSPACE = 100,
        BF_PROJECTLEADER = 102,
        BF_PROCEDUREEDITOR = 103,
        BF_EDITOR = 104,
        BF_VISUALIZER = 105,

        // Server capability (regardless of server)
        BF_SERVER_LOCAL = 200,
        BF_SERVER_REMOTE = 201,

        // Server identities
        BF_GUI_EHT = 300,
        BF_GUI_MECHANICS = 301,
        BF_GUI_TABULATOR = 302,
        BF_GUI_MOPAC = 303,
        BF_GUI_ZINDO = 304,
        BF_GUI_DYNAMICS = 305,
        BF_GUI_DGAUSS = 306,
        BF_GUI_CORINA = 309,
        BF_GUI_TOPKAT = 310,
        BF_GUI_ASP = 312,
        BF_GUI_COSMIC = 313,
        BF_GUI_AMSOL = 314,
        BF_GUI_CONFLEX = 315,
        BF_GUI_ACTIVESITE = 316,
        BF_GUI_MATEXP = 317,
        BF_GUI_GAUSSIAN = 318,

        BF_LOC_EHT = 330,
        BF_LOC_MECHANICS = 331,
        BF_LOC_TABULATOR = 332,
        BF_LOC_MOPAC = 333,
        BF_LOC_ZINDO = 334,
        BF_LOC_DYNAMICS = 335,
        BF_LOC_DGAUSS = 336,
        BF_LOC_CORINA = 339,
        BF_LOC_TOPKAT = 340,
        BF_LOC_ASP = 342,
        BF_LOC_COSMIC = 343,
        BF_LOC_AMSOL = 344,
        BF_LOC_CONFLEX = 345,
        BF_LOC_ACTIVESITE = 346,
        BF_LOC_MATEXP = 347,
        BF_LOC_GAUSSIAN = 348,

        BF_REM_EHT = 360,
        BF_REM_MECHANICS = 361,
        BF_REM_TABULATOR = 362,
        BF_REM_MOPAC = 363,
        BF_REM_ZINDO = 364,
        BF_REM_DYNAMICS = 365,
        BF_REM_DGAUSS = 366,
        BF_REM_CORINA = 369,
        BF_REM_TOPKAT = 370,
        BF_REM_ASP = 372,
        BF_REM_COSMIC = 373,
        BF_REM_AMSOL = 374,
        BF_REM_CONFLEX = 375,
        BF_REM_ACTIVESITE = 376,
        BF_REM_MATEXP = 377,
        BF_REM_GAUSSIAN = 378,

        // DGauss server licensing
        BF_SER_DGAUSS_SPROC = 390,
        BF_SER_DGAUSS_PPROC = 391,

        //MOPAC atom limits
        BF_SER_MOPAC_LIMIT1 = 410,
        BF_SER_MOPAC_LIMIT2 = 411,
        BF_SER_MOPAC_LIMIT_NONE = 412,

        // Bio Tools licensing (e.g., Sequence View, Analyze | Accessible Surface, Analyze | Crevice Surface, etc.)
        BF_BIO_TOOLS = 420,

        // Stereo related
        BF_GL = 600,
        BF_STEREO = 601,

        // End marker (used for validation)
        BF_LAST_NOT_USED
    };

   enum FEATURE_QUERY_MODE 
   {
       FQM_NONE, FQM_GUI, FQM_LOCAL, FQM_REMOTE
   };
     
   static void InitialiseULD(ASYNCH_EVENT_HANDLER theEventHandler);
   static void TerminateULD(void);
   static OMFCACheULD* MakeULDfromText( const char* theText, ENCRYPTION_TYPE theMethod );
   static OMFCACheULD* MakeULDfromRegistryText( const char* );
   static OMFCACheULD* MakeULDfromInstallerText( const char* );
   static const char* GetNameOfFeature( FEATURE theFeature );
   static const char* GetProductNameOfFeature( FEATURE theFeature );
   static FEATURE GetFeatureOfName( const char* theName, FEATURE_QUERY_MODE theMode = FQM_NONE );
   static const char* GetNameOfSpecial( SPECIALID theSpecial );
   static const char* GetNameOfLicType( LICTYPE theLicType );
   static bool CompositeContains( FEATURE parent, FEATURE child );
   static void SetLastError( const char *theText );
   static OMFStlString& GetLastError(void);
   static bool Decrypt( const char* theText, ENCRYPTION_TYPE theMethod, unsigned char*& theOutput, size_t& theOutputLen );
   static bool Encrypt( ENCRYPTION_TYPE theMethod, unsigned char* theIn, size_t theInLen, OMFStlString& theText );
   static bool ReadLicenseFromStream( istream& istr, OMFStlString& theLic );
   static void SetULDVersion(char version);

    void SetLicenseType( LICTYPE theType );
    LICTYPE GetLicenseType(void) const;
    size_t GetNumFeatures() const;
    FEATURE GetNthFeature( size_t theFeatureID ) const;
    void SetFeature( FEATURE theFeature );
    void RemoveAllFeatures( void );
    CUSTOMERID  GetCustomerID(void) const;
    void SetCustomerID( CUSTOMERID theCustomer );
    SPECIALID GetSpecialID(void) const;
    void SetSpecialID( SPECIALID theString );
    const char* GetString(void) const;
    void SetString( const char* theString );
    PLATFORM GetPlatform(void) const;
    void SetPlatform( PLATFORM thePlatform );

    bool AreEquivalent(const OMFCACheULD *aULD);

    enum VALIDATION_CONTEXT {VCX_GENERATOR, VCX_INSTALLER, VCX_RUNTIME};

   virtual bool FetchFeature( FEATURE theFeature ) = 0;
   virtual bool ReturnFeature( FEATURE theFeature ) = 0;
   virtual bool Validate( VALIDATION_CONTEXT vctx ) const;
   virtual bool PeriodicCheck( void ) const = 0;

   virtual bool Unpack( ByteInputStream& theStream );
   virtual bool Pack( ByteOutputStream& theStream );
   virtual void Initialise(void);
   virtual bool Encrypt( OMFCACheULD::ENCRYPTION_TYPE theEnType, OMFStlString& theText );
   virtual bool QueryFeature( FEATURE theFeature );
   virtual void GetCustomerRef( OMFStlString& theNumber );
   virtual void GetCACheProductName( OMFStlString& theProduct, bool& bIsMain ) const;

   static ASYNCH_EVENT_HANDLER itsEventHandler;

   // The feature list data type
   typedef std::vector<FEATURE> FEATURE_LIST;

private: 
   static void formatEncryptString( OMFStlString& theString, ENCRYPT_FORMAT theFormat );

   static OMFCACheULD* GenerateULD( const char* theText, ENCRYPTION_TYPE theMethod );

   static bool GetMachineCharacteristic( byte theKey[], size_t& theKeyLen );

   static bool DropFeature( FEATURE_LIST& theList, FEATURE fInPresenceOf, FEATURE fRemove );

   static int strcmpIn( const char* str1, const char* str2 );
   // Protect copy constructor and operator= - these are not allowed 
   // for this class. 
   OMFCACheULD(const OMFCACheULD& aSample); 
   OMFCACheULD& operator=(const OMFCACheULD& aSample); 

   // Data members
#ifndef macintosh
#pragma warning( disable : 4251 ) // This is ok since the variable is private
#endif
   FEATURE_LIST itsFeatures;
#ifndef macintosh
#pragma warning( default : 4251 )
#endif
   LICTYPE itsLicenseMechanism;
   CUSTOMERID itsCustomerID;
   SPECIALID itsSpecialID;
   OMFStlString itsString;
   PLATFORM itsPlatform;

   // Static data members
   static OMFStlString itsLastError;
   static char itsKeyVersion;
}; // class OMFCACheULD 

// 
// Related global functions 
// 

// Functions to read and write to our byte stream
//
// Streaming functions for various types
//
template<class T>
ByteOutputStream& operator<<(ByteOutputStream& outStream, T theData )
{
    outStream.Write( &theData, sizeof(T) );
    return outStream;
}

template<class T>
ByteInputStream& operator>>(ByteInputStream& inStream, T& theData )
{
    inStream.Read( &theData, sizeof(T) );
    return inStream;
}

#endif // OMFCACheULD__ 
