#include  "compat.h"
#include  "csu.h"
#include  "MOPACDriver.h"

/***************************************************************************************
 *
 *  Add_BasisSet			George D. Purvis III			8/28/89
 *
 *  This function adds the Basis Set information to the MolStruct.  The explicit
 *  basis functions are printed out from the shell description contained in the
 *  BasisSet structure.
 *
 *	parameters			:		msPtr		-pointer to a MolStruct structure.
 *								exponents	-array of doubles containing STO exponents
 *								nOrbitals	-not used
 *								nAtoms		-number of Atoms
 *								orbitalRange-start and end of shell
 *								nuclearNumber-an array of atomic numbers
 *								
 *
 *	calls				:		csu_AddObjVal, ExitToShell, printf.
 *
 *	returns				:		nothing.
 *
 ***************************************************************************************/
short NPQ[] = {1,1, 2,2,2,2,2,2,2,2, 3,3,3,3,3,3,3,3, 4,4,4,4,4,4,4,4,
      		 4,4,4,4,4,4,4,4,4,4, 5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,
			 6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,
			 7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7}; /* go to element 106 */
 
void MOPACaddBasisSet (MolStruct *msPtr, double *exponents, long nAtoms,
					   long orbitalRange[], long nuclearNumber[],
					   long atomLocation[])
{
 long		j, k;
 short		contrlen, Nquant, shellType, shellnum, numShells, shellLength,
            angtype[16];
 long       atom, basisfxn;
 u_char     dflagval=(csu_Delete2if1 | csu_Delete2ifC);
 char		errs[256];
 int		zNuc;
 CelErr	rtn_code;
  /*
   *  Put the basis function objects and their properties into 
   *  the basis function object class.
   */
  for (basisfxn=0, shellnum=1, atom=0; atom < nAtoms; atom++) {
  
    contrlen = 6;
	/* MOPAC has no basis functions on elements with atomic number >98
	   These atomic numbers are reserved for special effects.
	 */
#if 0
	sprintf(errs,"atom %d  nuclear number %d",atom,nuclearNumber[atom]);
	alert_user(errs);
	sprintf(errs,"Principal quantum number %d",(short) NPQ[nuclearNumber[atom] - 1]);
	alert_user(errs);
#endif
	if (((nuclearNumber[atom] < 99) ||
		(nuclearNumber[atom] == 102)) &&
		(nuclearNumber[atom] != 11) &&		
		(nuclearNumber[atom] != 19) &&		
		(nuclearNumber[atom] != 55) &&		
		(nuclearNumber[atom] != 56) &&		
		(nuclearNumber[atom] != 84) &&		
		(nuclearNumber[atom] != 85)) {
	   
	   k = orbitalRange[atom*2] - orbitalRange[atom*2 + 1];

	   
#if 0
	   sprintf(errs,"orbitalRange for atom %hd: %d %d", atom,
			   orbitalRange[atom*2], orbitalRange[atom*2 + 1]);
	   alert_user(errs);
#endif
   
	   if (k < 2) numShells = 1;
		   else if (k > 1 && k < 5) numShells=2;
			   else numShells=3;
	   
	   for (shellType = 0; shellType < numShells; shellType++, shellnum++) {
   
	   switch (shellType) {
		 case MOPAC_S :
    	   Nquant   = NPQ[nuclearNumber[atom] - 1];
		   angtype[0] = Stype;
		   shellLength = 1;
		   break;
		   
		 case MOPAC_P :
    	   Nquant   = NPQ[nuclearNumber[atom] - 1];
		   angtype[0] = Pxtype; angtype[1] = Pytype; angtype[2] = Pztype;
		   shellLength = 3;
		   break;
		   
		 case MOPAC_D :
		   /* 
			* quantum number of AM1/d d-shell is always Nquant(s,p) - 1 
			* in MOPAC. Fe=26, Cu=29, Ag=47, Pt=78
			*/
		   zNuc = nuclearNumber[atom];
		   if (zNuc == 26 || zNuc == 29 || zNuc == 47 || zNuc == 78)
    	      Nquant   =  NPQ[nuclearNumber[atom] - 1] - 1;
		   else
	    	  Nquant   =  NPQ[nuclearNumber[atom] - 1]-2;
			  /*
			   * CAChe Tabulator expects d-orbitals in order:  x2-y2, z2, xy, xz, yz.
			   */
		   angtype[0] = Dx2y2type;  angtype[1] = Dz2type; angtype[2] = Dxytype;
		   angtype[3] = Dxztype;    angtype[4] = Dyztype;
		   shellLength = 5;
		   break;
		   
		 case MOPAC_F :
		   /*
		    *  when support for f-orbitals will be added to MOPAC this
		    *  expression for Nquant must be revised 
		    */
    	   Nquant   = NPQ[nuclearNumber[atom] - 1];
		   angtype[0] = Fx3type;    angtype[1] = Fy3type;   angtype[2] = Fz3type;
		   angtype[3] = Fy2z2type;  angtype[4] = Fz2x2type; angtype[5] = Fx2y2type;
		   angtype[6] = Fxyztype;
		   shellLength = 7;
		   break;
		   
		 default :
		   sprintf (errs,"AddBasisSet: unrecognized shell->type %ld\n",
				   (long)shellType);
		   alert_user(errs);
		   break;
	   }

	   for (j=0; j<shellLength; j++, basisfxn++) {
	   
		 /*
		  *  update/create the basis function's properties in the
		  *  basis function object class.
		  */
		 if ((rtn_code = csu_AddObjVal (msPtr, STOBasisFxnID, BasisFxnAngID, (basisfxn+1),
						  MOPAC_SRC, CSU_NAME, 1, NoUnit, 0, 
						  (char*)&angtype[j], 0, BY_ID)) < 0) {
		   sprintf (errs,"AddBasisSet: csu_AddObjVal rtn_code %d for BasisFxnAngID\n",
					 rtn_code);
		   alert_user(errs);
		 }
   
		 if ((rtn_code = csu_AddObjVal (msPtr, STOBasisFxnID, ContractLengthID, (basisfxn+1),
						  MOPAC_SRC, CSU_INTEGER, 1, NoUnit, 0, 
						  (char*)&contrlen, 0, BY_ID)) < 0) {
		   sprintf (errs,"AddBasisSet: csu_AddObjVal rtn_code %d for ContractLengthID\n",
					 rtn_code);
		   alert_user(errs);
		 }
						
		 if ((rtn_code = csu_AddObjVal (msPtr, STOBasisFxnID, PrinQuantID, (basisfxn+1), 
						  MOPAC_SRC, CSU_INTEGER, 1, NoUnit, 0, 
						  (char*)&Nquant, 0, BY_ID)) < 0) {
		   sprintf (errs,"AddBasisSet: csu_AddObjVal rtn_code %d for PrinQuantID\n",
				   rtn_code);
		   alert_user(errs);
		 }
						
   
		 if ((rtn_code = csu_AddObjVal (msPtr, STOBasisFxnID,
									   STOExpID, (basisfxn+1), 
									   MOPAC_SRC, CSU_FLOATING, 1, NoUnit, 6, 
									   (char*)&exponents[atom + nAtoms*shellType], 0,
									   BY_ID)) < 0) {
		   sprintf (errs,"AddBasisSet: csu_AddObjVal rtn_code %d for STOExpID\n",
				   rtn_code);
		   alert_user(errs);
		 }
   
		 if ((rtn_code = csu_AddObjVal (msPtr, STOBasisFxnID, ShellNumID, (basisfxn+1), 
						 MOPAC_SRC, CSU_INTEGER, 1, NoUnit, 0, (char*)&shellnum, 0,
						 BY_ID)) < 0) {
		   sprintf (errs,"AddBasisSet: csu_AddObjVal rtn_code %d for ShellNumID\n",
				   rtn_code);
		   alert_user(errs);
		 }
		 
		 
		 /*
		  *  update/create the connector between this 
		  *  basis function and its atom.
		  */
   
		 if ((rtn_code = csu_AddConnectorVal (msPtr, AtomID, atomLocation[atom], STOBasisFxnID,
										 (basisfxn), dflagval)) < 0) {
		   sprintf (errs,"csu_AddBasisSet AddConnectorVal rtn_code %d\n", rtn_code);
		   alert_user(errs);
		 }
   
	   }
	   
	 }
   }
 }
}
