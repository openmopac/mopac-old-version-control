/* CACheMacros.h -- place for putting all miscellaneous CAChe macros */
#ifndef _CACHE_MACROS_H_
#define _CACHE_MACROS_H_

/* The following macros are used to convert character constants to a long word constant
 * in a compiler/machine independent manner.
 * Example:  CM_C4TOLONG('M','E','C','H')
 */
#define CM_C4TOLONG(a,b,c,d) 	((unsigned long)((((a*256UL) + b)*256UL + c)*256UL + d))
#define CM_C3TOLONG(a,b,c) 	((unsigned long)(((a*256UL) + b)*256UL + c))
#define CM_C2TOLONG(a,b) 	((unsigned long)((a*256UL) + b))

#endif /* _CACHE_MACROS_H_ */
