#include  <compat.h>
#include  <cpu.h>
#include <stdlib.h>
#include  <memory.h>
#include  <MOPACDriver.h>

/***************************************************************************************
 *
 *  Add_BondOrderComp
 *
 *  This routine adds the bond orders calculated in a MOPAC calculation to the
 *  MolStruct.
 *
 *  To do this, it gets a list of bonds using the cpu function getBondList
 *  then it fills a rectangular array called bondOrderDefined 
 *  with true if the there is a bond between two atoms and false if there isn't.
 *  Then it checks each element of the bondorder array. If the bond order is
 *  greater than 0.3 and the corresponding bond does not exist (i.e. the 
 *  corresponding element in bondOrderDefined is false), a new bond is 
 *  added.  The bond type is based upon the magnitude of the bondorder.
 *
 **************************************************************************************/

int  AddBondOrderComp (MolStruct *msPtr, DoubleH bondOrdersComp, long *i_sig_bonds_i,
     long *i_sig_bonds_j, long nLinear, long nAtoms, long atomLocation[], NameNID source,
     DoubleH coord)
{
 double   (*bondOrders)[12]  = NULL;
 long      *nbondOrders      = NULL;
 long     (*ibondOrders)[12] = NULL;
 long	  Idx, Jdx, atom1, atom2;
 long     bond, numberBonds;
 ObjclsID bond_offset, conn_offset;
 PropID   bondpropi, connpropi, numconnprops, numbondprops;
 long	  i, j, k, l;
 short    bondType;
 long     objectnum;
 PropH	  connpropsH, bondpropsH;
 char	  errs[256];
 char	  (*bondOrderDefined)[12] = NULL;

 short	  errorCode = 0;
 ObjectID (*bondList)[2] = NULL;
 CelErr   rtn_code;

  /*
   *  Get the properties for the connector object class to
   *  set up the search for bonds.
   */
   

  if (!csu_ExistsObjclsID (msPtr, BondID, &bond_offset)) {
     if ((rtn_code = csu_AddObjcls (msPtr, BondID, &bond_offset, nAtoms)) < 0)	{
	   sprintf (errs,"addBondOrder: csu_AddObjcls BondID rtn_code %d\n", rtn_code);
	   alert_user(errs);
	   return (MOPACerrors);
	 }
  }
    

  if (!csu_ExistsObjclsID (msPtr, ConnectorID, &conn_offset)) {
     if ((rtn_code = csu_AddObjcls (msPtr, ConnectorID, &conn_offset, nAtoms)) < 0)	{
	   sprintf (errs,"addBondOrder: csu_AddObjcls ConnectorID rtn_code %d\n", rtn_code);
	   alert_user(errs);
	   return (MOPACerrors);
	 }
  }
    
  connpropsH   = (GetPtr(msPtr->objclsH) + conn_offset)->propsH;
  bondpropsH   = (GetPtr(msPtr->objclsH) + bond_offset)->propsH;
  numconnprops = (GetPtr(msPtr->objclsH) + conn_offset)->num_props;
  numbondprops = (GetPtr(msPtr->objclsH) + bond_offset)->num_props;
  
  if (!csu_ExistsPropID(connpropsH, Objcls1ID, numconnprops, &connpropi)) {
	  if ((rtn_code = csu_InstProp(msPtr->objclsH, conn_offset, Objcls1ID,
								   1, source, CSU_NAME, NoUnit, 0, &connpropi)) < 0) {
		sprintf (errs,"addBondOrder: csu_InstProp Objcls1ID rtn_code %d\n", rtn_code);
		alert_user(errs);
		return (MOPACerrors);
	  }
  }
  connpropsH   = (GetPtr(msPtr->objclsH) + conn_offset)->propsH;

  if (!csu_ExistsPropID(connpropsH, Obj1ID, numconnprops, &connpropi)) {
	  if ((rtn_code = csu_InstProp(msPtr->objclsH, conn_offset, Obj1ID,
								   1, source, CSU_INTEGER, NoUnit, 0, 
								   &connpropi)) < 0) {
		sprintf (errs,"addBondOrder: csu_InstProp Obj1ID rtn_code %d\n", rtn_code);
		alert_user(errs);
		return (MOPACerrors);
	  }
  }
  connpropsH   = (GetPtr(msPtr->objclsH) + conn_offset)->propsH;

  if (!csu_ExistsPropID(connpropsH, Objcls2ID, numconnprops, &connpropi)) {
	  if ((rtn_code = csu_InstProp(msPtr->objclsH, conn_offset, Objcls2ID,
								   1, source, CSU_NAME, NoUnit, 0, &connpropi)) < 0) {
		sprintf (errs,"addBondOrder: csu_InstProp Objcls2ID rtn_code %d\n", rtn_code);
		alert_user(errs);
		return (MOPACerrors);
	  }
  }
  connpropsH   = (GetPtr(msPtr->objclsH) + conn_offset)->propsH;

  if (!csu_ExistsPropID(connpropsH, Obj2ID, numconnprops, &connpropi)) {
	  if ((rtn_code = csu_InstProp(msPtr->objclsH, conn_offset, Obj2ID,
								   1, source, CSU_INTEGER, NoUnit, 0, &connpropi)) < 0) {
		sprintf (errs,"addBondOrder: csu_InstProp Obj2ID rtn_code %d\n", rtn_code);
		alert_user(errs);
		return (MOPACerrors);
	  }
  }
  connpropsH   = (GetPtr(msPtr->objclsH) + conn_offset)->propsH;


  if (!csu_ExistsPropID(connpropsH, DflagID, numconnprops, &connpropi)) {
	  if ((rtn_code = csu_InstProp(msPtr->objclsH, conn_offset, DflagID,
								   1, source, CSU_HEX, NoUnit, 0, &connpropi)) < 0) {
		sprintf (errs,"addBondOrder: csu_InstProp DflagID rtn_code %d\n", rtn_code);
		alert_user(errs);
		return (MOPACerrors);
	  }
  }
  connpropsH   = (GetPtr(msPtr->objclsH) + conn_offset)->propsH;
  numconnprops = (GetPtr(msPtr->objclsH) + conn_offset)->num_props;
  (GetPtr(connpropsH) + connpropi)->srcN = source;

  if (!csu_ExistsPropID(bondpropsH, ID_ID, numbondprops, &bondpropi)) {
	  if ((rtn_code = csu_InstProp(msPtr->objclsH, bond_offset, ID_ID,
								   1, source, CSU_NAME, NoUnit, 0, &bondpropi)) < 0) {
		sprintf (errs,"addBondOrder: csu_InstProp ID_ID rtn_code %d\n", rtn_code);
		alert_user(errs);
		return (MOPACerrors);
	  }
  }
  bondpropsH   = (GetPtr(msPtr->objclsH) + bond_offset)->propsH;
  numbondprops = (GetPtr(msPtr->objclsH) + bond_offset)->num_props;

 /*
  *  Allow for up to 12 bonds to each atom
  */
  if ((bondOrderDefined = (char(*)[12]) NewHandle(12*nAtoms*sizeof(char))) == NULL) {
	sprintf (errs,"addBondOrderComp: bondOrderDefined memory request %ld too large\n",
			 12*nAtoms*sizeof(char));
	alert_user(errs);
	return (MOPACerrors);	 
  }
  if ((bondOrders = (double(*)[12]) NewHandle(12*nAtoms*sizeof(double))) == NULL) {
	sprintf (errs,"addBondOrderComp: bondOrder memory request %ld too large\n",
			 12*nAtoms*sizeof(double));
	alert_user(errs);
	return (MOPACerrors);	 
  }
  if ((nbondOrders = (long(*)) NewHandle(nAtoms*sizeof(long))) == NULL) {
	sprintf (errs,"addBondOrderComp: nbondOrder memory request %ld too large\n",
			 nAtoms*sizeof(long));
	alert_user(errs);
	return (MOPACerrors);	 
  }
  if ((ibondOrders = (long(*)[12]) NewHandle(12*nAtoms*sizeof(long))) == NULL) {
	sprintf (errs,"addBondOrderComp: ibondOrder memory request %ld too large\n",
			 12*nAtoms*sizeof(long));
	alert_user(errs);
	return (MOPACerrors);	 
  }
  HLock((Handle) bondOrderDefined);
  for (i = 0; i < nAtoms; i++) 
      for (j = 0; j < 12; j++)
          (GetPtr(bondOrderDefined))[i][j] = false;
/*
 *   Expand compressed bond orders into a rectangular array.
 */
      for (i = 0; i < nAtoms; i++) nbondOrders[i] = -1;
      for  (i = 0; i < nLinear; i++)
      {
          j = i_sig_bonds_i[i] - 1;
          k = i_sig_bonds_j[i] - 1;
          if (nbondOrders[j] < 11)
          {
            l = ++nbondOrders[j];
             bondOrders[j][l] = bondOrdersComp[i];
            ibondOrders[j][l] = k;
          }
      }

  /* build the list of bonds */
  if ((numberBonds = cpu_getBondList(msPtr, &bondList)) > 0) {
	long *bondListPointer;
	
    /* Add the bond order to each bond and mark the bondOrderDefined
	   array to indicate that the bond order has already been filled
	   in.
	*/
	for (bond=0; bond<numberBonds; bond++) 
    {
	  bondListPointer = bondList[bond];
	  atom1 = whichAtomIndex(bondListPointer[0], nAtoms, atomLocation);
	  if (atom1 >= 0) 
      {
		 atom2 = whichAtomIndex(bondListPointer[1], nAtoms, atomLocation);
         Idx = (atom1 > atom2) ? (atom1) : (atom2);
         Jdx = (atom1 > atom2) ? (atom2) : (atom1);
         for (i = 0; i <= nbondOrders[Idx]; i++)
             if (ibondOrders[Idx][i] == Jdx)
             {
		      if((rtn_code = csu_AddObjVal (msPtr, BondID, Bond_OrderID,
						bond, source, CSU_FLOATING, 1, NoUnit, 4, 
						(char*)&((GetPtr(bondOrders))[Idx][i]),
						0, BY_INDEX)) < 0) 
                {
		         sprintf (errs,"AddBondOrder: csu_AddObjVal rtn_code %d\n", rtn_code);
		        alert_user(errs);
                }
		     (GetPtr(bondOrderDefined))[Idx][i] = true; /* indicate that this bond order is already updated */
	         }
      }
	}
    if (bondList != NULL) free(bondList);
  }

  /*
   *  For each bond order greater than 0.3, search the
   *  connector array for a bond between the pair of atoms
   *  defining the bond, if the bond exists, insert a value for the
   *  bond order, otherwise, create a bond and add the appropriate connectors.
   */
    for (i=0; i<nAtoms; i++) 
  	for (k=0; k <= nbondOrders[i]; k++) {
        j = ibondOrders[i][k];
		if ((!(GetPtr(bondOrderDefined))[i][k]) && ((GetPtr(bondOrders))[i][k] > 0.3)) {
/*
 *  Deliberatly exclude long-range bonds, of the type generated 
 *  by periodic boundary conditions.
 */
            if (pow((coord[i] - coord[j]),2.0) +
                pow((coord[i + nAtoms] - coord[j + nAtoms]),2.0) +
                pow((coord[i + 2*nAtoms] - coord[j + 2*nAtoms]),2.0) < 10.0)
            {
  		  getUniqueID (msPtr, BondID, &objectnum);
    		  if((rtn_code = csu_AddObjVal (msPtr, BondID, Bond_OrderID,
    						 objectnum, source, CSU_FLOATING, 1, NoUnit, 4, 
    						 (char*)&((GetPtr(bondOrders))[i][k]),
    						 0, BY_ID)) < 0) {
    			sprintf (errs,"AddBondOrder: csu_AddObjVal Bond_OrderID rtn_code %d\n", rtn_code);
    			alert_user(errs);
    			errorCode = MOPACerrors;
    			goto errorReturn2;
    		  }
    		  bondType = 0x7005;
    		  if((rtn_code = csu_AddObjVal (msPtr, BondID, RflagID,
    						 objectnum, source,
    						 CSU_HEX, 1, NoUnit, 0, (char *) &bondType,
    						 0, BY_ID)) < 0) {
    			sprintf (errs,"AddBondOrder: csu_AddObjVal RflagID rtn_code %d\n", rtn_code);
    			errorCode = MOPACerrors;
    			alert_user(errs);
    			goto errorReturn2;
    		  }
    		  if ((rtn_code = csu_AddConnectorVal (msPtr,
    									  AtomID, 
    									  atomLocation[i],
    		  							  BondID,
    		  							  csu_ObjectIDtoIndex(msPtr, BondID, objectnum),
    									  (csu_Delete2if1 | csu_Delete2ifC | 1))) < 0) {
    			  sprintf (errs,"addBondOrder: csu_AddConnectorVal BondID rtn_code %d\n",
    				   rtn_code);
    			  alert_user(errs);
    			  errorCode = MOPACerrors;
    			  goto errorReturn2;
    		  }
    
    		  if ((rtn_code = csu_AddConnectorVal (msPtr, 
    									  AtomID, 
    									  atomLocation[j],
    		  							  BondID,
    		  							  csu_ObjectIDtoIndex(msPtr, BondID, objectnum),
    									  (csu_Delete2if1 | csu_Delete2ifC | 1))) < 0) {
    			  sprintf (errs,"addBondOrder: csu_AddConnectorVal BondID rtn_code %d\n",
    				   rtn_code);
    			  alert_user(errs);
    			  errorCode = MOPACerrors;
    			  goto errorReturn2;
    		  }
    
    		  if ((GetPtr(bondOrders))[i][k] > 2.6) bondType = TRIPLE_B;
    		    else if ((GetPtr(bondOrders))[i][k] > 1.6) bondType = DOUBLE_B;
    		      else if ((GetPtr(bondOrders))[i][k] > .6) bondType = SINGLE_B;
    		        else bondType = WEAK_B;
    		  
    		  if((rtn_code = csu_AddObjVal (msPtr, BondID, TypeID,
    						 objectnum, source,
    						 CSU_NAME, 1, NoUnit, 0, (char *) &bondType,
    						 0, BY_ID)) < 0) {
    			sprintf (errs,"AddBondOrder: csu_AddObjVal TypeID rtn_code %d\n", rtn_code);
    			alert_user(errs);
    			errorCode = MOPACerrors;
    			goto errorReturn2;
              }
           }			
		}
	}


errorReturn2:
  if (bondOrderDefined != NULL) {
      HUnlock((Handle) bondOrderDefined);
      DisposHandle((Handle) bondOrderDefined);
  }
  return (errorCode);
}

