#include "compat.h"
#include "ZINDODriver.h"

void GetZINDODefaults (ZINDOControl *Control)
{
	int i;
	/*
	 *  Set all parameters to default values.
	 */
/*	 bzero(Control, sizeof(ZINDOControl)); */
	
	 memset(Control, 0, sizeof(ZINDOControl));

	 Control->calculate = 1;
	 Control->multiplicity = 1;
	 Control->parameters = 4;
	 Control->geometrySearch = 1;
	 Control->geometryConvergence = 1;
	 Control->title[0] = 0;
	 Control->spaceSymmetry = 1;
	 Control->SCFtype = 1;
	 Control->netCharge = 0;
	 Control->maxSCFiterations = 200;
	 Control->maxGeometrySteps = 100;
	 Control->CIlevel = 9;
	 Control->extraKeyWords[0] = 0;
	 Control->scfConvergence = 3;
	 Control->cavityRadiusMeaning = RADIUS_EXTEND;
	 Control->cavityRadiusExtend = 0.5;
	 Control->cavityRadiusTotal = 5.;
	 Control->dielectric = 78.5;
	 Control->refractiveIndex = 1.33287;
	 Control->spectraCutoff = 190.0;
	 Control->printAmount = PRINT_MIN;
	 Control->metalConfigMixing = 1;
	 Control->controlRestart = FALSE;
	 Control->detailsSCRxnF = FALSE;
	 Control->detailsMap = TRUE;
	 Control->saveBasis = TRUE;
	 Control->saveVectors = TRUE;
	 Control->saveGraphics = TRUE;
	 Control->saveInput = TRUE;
	 Control->saveOutput = TRUE;
	 Control->saveCon = TRUE;
	 Control->saveOpt = TRUE;
	 Control->saveSummary = TRUE;
	 Control->saveLog = TRUE;
	 for (i=0; i < ZINDOlimit; i++) Control->atomLocation[i] = i;
 }
