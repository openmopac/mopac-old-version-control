#include "compat.h"
#include <stdio.h>

#if defined(_WIN32)
#include <string.h>
#else
#include <strings.h>
#endif

#include <CACheFileLib.h>
#include "ZINDODriver.h"

/* For compatibility with CAChe 2 */
#define detailsLowCheckBoxIN		5
#define detailsHiCheckBoxIN		   10
#define detailsVectorsCB			5
#define detailsBasisCB				6
#define detailsGraphicsCB			7
#define detailsRestartCB			8
#define detailsSelfConsReactFieldCB	9
#define mapOptimizationCB		   10

/*************************************************************************************
 *
 *  GetZINDOParams			programmer George D. Purvis III 8/20/89
 *
 *  This function reads in the input control parameters from the controlfile. This
 *  information is put into the Control data structure
 *
 *	parameters		:		Control		;pointer to ZINDOControl data structure.
 *							controlfile ;file to read control parameters from.
 *
 *	calls			:		printf, fscanf, PrintControlOpts.
 *
 *	returns			:		0 if successful; return codes defined
 *					:		in ZINDODriver.h.
 *
 *	caveat			:		controlfile must already be open for reading when this
 *							routine is called.  The controlfile is NOT closed at the 
 *							end of this routine.
 *
 *							Assertion: the file is assumed to be positioned at 
 *							either the startSettings or startMOPAC line.
 *
 ***********************************************************************************/
 
long GetZINDOParams (ZINDOControl *Control, FILE *controlfile)
{
	static  char    buff1[80];
	int	itemp, i;
	double temp;
	short	detailsDialogCheckBoxes[detailsHiCheckBoxIN+1];
	
	/* Set the default values for the control*/
	GetZINDODefaults(Control);
	
	for (i = 0; i <= detailsHiCheckBoxIN; i++) 
		detailsDialogCheckBoxes[i] = false;
	
	/*
	*  Continue processing strings until error or end of file.
	*/
	   
	if (controlfile != NULL) {
	
		long file_position;
	 
		/* First check on the magic string.  This could be a binary file. */
		file_position = ftell(controlfile);
		cfl_fgets(buff1, 11, controlfile);
		if (strncmp("startZINDO", buff1, 10) != 0)
			return (ZINDO_SETTINGS_ZINDOSET);
		fseek(controlfile, file_position, SEEK_SET);

		while (fscanf(controlfile,"%s",buff1) != EOF) {
		
			if (strcmp("startZINDO", buff1) == 0) {	/* ZINDO options */
				if (fscanf (controlfile, "%s", buff1) == EOF) 
				   return (ZINDO_SETTINGS_ZINDOSET);
				while (strcmp("endZINDO", buff1) != 0) {
					if (strcmp("calculate", buff1) == 0) {
						if (fscanf (controlfile, "%s", buff1) != EOF) {
						  if (sscanf(buff1, "%ld", &itemp) == 1) 
							  Control->calculate = itemp;
						}
					} else if (strcmp ("multiplicity", buff1) == 0) {
						if (fscanf (controlfile, "%s", buff1) != EOF) {
						  if (sscanf(buff1, "%ld", &itemp) == 1) 
							  Control->multiplicity = itemp;
						}
					} else if (strcmp ("parameters", buff1) == 0) {
						if (fscanf (controlfile, "%s", buff1) != EOF) {
						  if (sscanf(buff1, "%ld", &itemp) == 1) 
							  Control->parameters = itemp;
						}
					} else if (strcmp ("geometrySearch", buff1) == 0) {
						if (fscanf (controlfile, "%s", buff1) != EOF) {
						  if (sscanf(buff1, "%ld", &itemp) == 1) 
							  Control->geometrySearch = itemp;
						}
					} else if (strcmp ("geometryConvergence", buff1) == 0) {
						if (fscanf (controlfile, "%s", buff1) != EOF) {
						  if (sscanf(buff1, "%ld", &itemp) == 1) 
							  Control->geometryConvergence = itemp;
						}
					} else if (strcmp ("spaceSymmetry", buff1) == 0) {
						if (fscanf (controlfile, "%s", buff1) != EOF) {
						  if (sscanf(buff1, "%ld", &itemp) == 1) 
							  Control->spaceSymmetry = itemp;
						}
					} else if (strcmp ("maxSCFiterations", buff1) == 0) {
						if (fscanf (controlfile, "%s", buff1) != EOF) {
						  if (sscanf(buff1, "%ld", &itemp) == 1) 
							  Control->maxSCFiterations = itemp;
						}
					} else if (strcmp ("SCFtype", buff1) == 0) {
						if (fscanf (controlfile, "%s", buff1) != EOF) {
						  if (sscanf(buff1, "%ld", &itemp) == 1) 
							  Control->SCFtype = itemp;
						}
					} else if (strcmp ("scfConvergence", buff1) == 0) {
						if (fscanf (controlfile, "%s", buff1) != EOF) {
						  if (sscanf(buff1, "%ld", &itemp) == 1) 
							  Control->scfConvergence = itemp;
						}
					} else if (strcmp ("maxGeometrySteps", buff1) == 0) {
						if (fscanf (controlfile, "%s", buff1) != EOF) {
						  if (sscanf(buff1, "%ld", &itemp) == 1) 
							  Control->maxGeometrySteps = itemp;
						}
					/* subtract one from C.I. level to be compatible with CAChe 2 */
					} else if (strcmp ("CIlevel", buff1) == 0) {
						if (fscanf (controlfile, "%s", buff1) != EOF) {
						  if (sscanf(buff1, "%ld", &itemp) == 1) 
							  Control->CIlevel = itemp - 1;
						}
					} else if (strcmp ("printAmount", buff1) == 0) {
						if (fscanf (controlfile, "%s", buff1) != EOF) {
						  if (sscanf(buff1, "%ld", &itemp) == 1) 
							  Control->printAmount = itemp;
						}
					} else if (strcmp ("metalConfigMixing", buff1) == 0) {
						if (fscanf (controlfile, "%s", buff1) != EOF) {
						  if (sscanf(buff1, "%ld", &itemp) == 1) 
							  Control->metalConfigMixing = itemp;
						}
					} else if (strcmp ("spectraCutoff", buff1) == 0) {
						if (fscanf (controlfile, "%s", buff1) != EOF) {
						  if (sscanf(buff1, "%lf", &temp) == 1)
							  Control->spectraCutoff = temp;
						}
					} else if (strcmp ("cavityRadius", buff1) == 0) {
						if (fscanf (controlfile, "%s", buff1) != EOF) {
						  if (sscanf(buff1, "%lf", &temp) == 1) { 
							  Control->cavityRadiusTotal = temp;
							  Control->cavityRadiusMeaning = RADIUS_TOTAL;
						  }
						}
					} else if (strcmp ("cavityRadiusMeaning", buff1) == 0) {
						if (fscanf (controlfile, "%s", buff1) != EOF) {
						  if (sscanf(buff1, "%ld", &itemp) == 1)
							  Control->cavityRadiusMeaning = itemp;
						}
					} else if (strcmp ("cavityRadiusTotal", buff1) == 0) {
						if (fscanf (controlfile, "%s", buff1) != EOF) {
						  if (sscanf(buff1, "%lf", &temp) == 1)
							  Control->cavityRadiusTotal = temp;
						}
					} else if (strcmp ("cavityRadiusExtend", buff1) == 0) {
						if (fscanf (controlfile, "%s", buff1) != EOF) {
						  if (sscanf(buff1, "%lf", &temp) == 1)
							  Control->cavityRadiusExtend = temp;
						}
					} else if (strcmp ("dielectric", buff1) == 0) {
						if (fscanf (controlfile, "%s", buff1) != EOF) {
						  if (sscanf(buff1, "%lf", &temp) == 1) 
							  Control->dielectric = temp;
						}
					} else if (strcmp ("refractiveIndex", buff1) == 0) {
						if (fscanf (controlfile, "%s", buff1) != EOF) {
						  if (sscanf(buff1, "%lf", &temp) == 1) 
							  Control->refractiveIndex = temp;
						}
					} else if (strcmp ("controlRestart", buff1) == 0) {
						if (fscanf (controlfile, "%s", buff1) != EOF) {
						  if (sscanf(buff1, "%lf", &temp) == 1) 
							  Control->controlRestart = (Boolean)temp;
						}
					} else if (strcmp ("detailsSCRxnF", buff1) == 0) {
						if (fscanf (controlfile, "%s", buff1) != EOF) {
						  if (sscanf(buff1, "%lf", &temp) == 1) 
							  Control->detailsSCRxnF = (Boolean)temp;
						}
					} else if (strcmp ("detailsMap", buff1) == 0) {
						if (fscanf (controlfile, "%s", buff1) != EOF) {
						  if (sscanf(buff1, "%ld", &itemp) == 1) 
							  Control->detailsMap = itemp;
						}
					} else if (strcmp ("saveBasis", buff1) == 0) {
						if (fscanf (controlfile, "%s", buff1) != EOF) {
						  if (sscanf(buff1, "%ld", &itemp) == 1) 
							  Control->saveBasis = itemp;
						}
					} else if (strcmp ("saveVectors", buff1) == 0) {
						if (fscanf (controlfile, "%s", buff1) != EOF) {
						  if (sscanf(buff1, "%ld", &itemp) == 1) 
							  Control->saveVectors = itemp;
						}
					} else if (strcmp ("saveGraphics", buff1) == 0) {
						if (fscanf (controlfile, "%s", buff1) != EOF) {
						  if (sscanf(buff1, "%ld", &itemp) == 1) 
							  Control->saveGraphics = itemp;
						}
					} else if (strcmp ("saveInput", buff1) == 0) {
						if (fscanf (controlfile, "%s", buff1) != EOF) {
						  if (sscanf(buff1, "%ld", &itemp) == 1) 
							  Control->saveInput = itemp;
						}
					} else if (strcmp ("saveOutput", buff1) == 0) {
						if (fscanf (controlfile, "%s", buff1) != EOF) {
						  if (sscanf(buff1, "%ld", &itemp) == 1) 
							  Control->saveOutput = itemp;
						}
					} else if (strcmp ("saveCon", buff1) == 0) {
						if (fscanf (controlfile, "%s", buff1) != EOF) {
						  if (sscanf(buff1, "%ld", &itemp) == 1) 
							  Control->saveCon = itemp;
						}
					} else if (strcmp ("saveOpt", buff1) == 0) {
						if (fscanf (controlfile, "%s", buff1) != EOF) {
						  if (sscanf(buff1, "%ld", &itemp) == 1) 
							  Control->saveOpt = itemp;
						}
					} else if (strcmp ("saveSummary", buff1) == 0) {
						if (fscanf (controlfile, "%s", buff1) != EOF) {
						  if (sscanf(buff1, "%ld", &itemp) == 1) 
							  Control->saveSummary = itemp;
						}
					} else if (strcmp ("saveLog", buff1) == 0) {
						if (fscanf (controlfile, "%s", buff1) != EOF) {
						  if (sscanf(buff1, "%ld", &itemp) == 1) 
							  Control->saveLog = itemp;
						}
					} else if (strcmp ("netCharge", buff1) == 0) {
						if (fscanf (controlfile, "%s", buff1) != EOF) {
						  if (sscanf(buff1, "%ld", &itemp) == 1) 
							  Control->netCharge = itemp;
						}
					} else if (strcmp ("title", buff1) == 0) {
						cfl_fgets (Control->title, 256, controlfile);
						cfl_fgets (Control->title, 256, controlfile);
					} else if (strcmp ("extraKeyWords", buff1) == 0) {
						cfl_fgets (Control->extraKeyWords, 256, controlfile);
						cfl_fgets (Control->extraKeyWords, 256, controlfile);
					} else if (strcmp ("detailsDialogCheckBoxes", buff1) == 0) {
						for (i=0; i <= detailsHiCheckBoxIN; i++) {
							if (fscanf (controlfile, "%s", buff1) != EOF) {
								if (sscanf(buff1, "%ld", &itemp) == 1) 
									detailsDialogCheckBoxes[i] = itemp;
							}
						}
		
						if (detailsDialogCheckBoxes[detailsRestartCB])
							Control->controlRestart = TRUE;
						else
							Control->controlRestart = FALSE;
					  
						if (detailsDialogCheckBoxes[detailsSelfConsReactFieldCB])
							Control->detailsSCRxnF = TRUE;
						else
							Control->detailsSCRxnF = FALSE;
					  
						if (detailsDialogCheckBoxes[mapOptimizationCB])
							Control->detailsMap = TRUE;
						else
							Control->detailsMap = FALSE;
					  
						if (detailsDialogCheckBoxes[detailsGraphicsCB])
							Control->saveGraphics = TRUE;
						else
							Control->saveGraphics = FALSE;
					  
						if (detailsDialogCheckBoxes[detailsBasisCB])
							Control->saveBasis = TRUE;
						else
							Control->saveBasis = FALSE;
					  
						if (detailsDialogCheckBoxes[detailsVectorsCB])
							Control->saveVectors = TRUE;
						else
							Control->saveVectors = FALSE;
					}
					/* 
					* Keep on driving if the keyword is not recognized.
					* This allows settings files to be forward-compatible.
					*/
					fscanf (controlfile, "%s", buff1);
				}
		   }
		  
		}

	} /* controlfile != NULL */ 

	return (0L);   
}
