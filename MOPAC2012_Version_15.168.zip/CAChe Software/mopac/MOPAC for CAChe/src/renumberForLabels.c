#include "compat.h"
#include <ctype.h>
#include "MOPACDriver.h"

void renumberSearchLabels(SearchLabel searchLabels[], long numSearchLabels,
		long NAtom, long atomLocation[])
{
	long i, j, k, l;

  if (numSearchLabels > 0) {
    /* fill out the search labels with -1 */
	for (j=searchLabels[0].atomList[0]+1; j < 5; j++) 
		searchLabels[0].atomList[j] = -1;
	if (numSearchLabels > 1) 
		for (j=searchLabels[1].atomList[0]+1; j < 5; j++) 
			searchLabels[1].atomList[j] = -1;

    /* assign new atom numbers to the search label */
	for (i=0; i < numSearchLabels; i++) { 
		for (j=searchLabels[i].atomList[0]; j > 0; j--) {
			 searchLabels[i].atomList[j] = 
						 findAtom(searchLabels[i].atomList[j],
								  atomLocation, NAtom);
		} 
	}
	/*
		If a search calculation is to be performed, then makeMOPACInput
		alters the z-matrix connections for the moving atom in
		the first label by copying nonmoving atom numbers
		in the search label into the A, B, C positions
		in the z-matrix.  Depending upon the reordered number of the
		moving atom, the search label may not contain enough atom
		numbers.  For example, if the first search label is an atom
		distance, but the moving atom is numbered 6, then unique
		lower numbered atoms must be specified for the A, B, and
		C positions.  The following code fills out the label with
		appropriate lower numbered atoms.
		
	*/
		for (j=MOPAC_MAX(searchLabels[0].atomList[0], 
					MOPAC_MIN(4,searchLabels[0].atomList[1]+1));
		     j > 1; j--) {
			if (searchLabels[0].atomList[j] == -1) {
				for (k=0; k<searchLabels[0].atomList[1]; k++) {
					for (l=1;
					     l <= MOPAC_MAX(searchLabels[0].atomList[0], 
						 		MOPAC_MIN(4,searchLabels[0].atomList[1]+1));
						 l++) {
						 if (searchLabels[0].atomList[l] == k) goto alreadyUsedFirst;
					}
					searchLabels[0].atomList[j] = k;
					break;
  alreadyUsedFirst:;
				}
			}
		}
	if (numSearchLabels > 1) {
	/*
		If a grid calculation is to be performed, then makeMOPACInput
		alters the z-matrix connections for the moving atom in
		the second label by copying nonmoving atom numbers
		in the search label into the A, B, C positions
		in the z-matrix.  Depending upon the reordered number of the
		moving atom, the search label may not contain enough atom
		numbers.  For example, if the second search label is an atom
		distance, but the moving atom is numbered 6, then unique
		lower numbered atoms must be specified for the A, B, and
		C positions.  The following code fills out the label with
		appropriate lower numbered atoms.
		
		If the moving atom in each both search labels is the same, and the first label is
		longer than the first one, fill in the atoms necessary for Z-matrix creation in
		the second label with atoms from the first label.
	*/
	    if (searchLabels[0].atomList[1] == searchLabels[1].atomList[1] &&
			searchLabels[0].atomList[0] > searchLabels[1].atomList[0])
			for (j=searchLabels[1].atomList[0]+1; j <= searchLabels[0].atomList[0]; j++)
				searchLabels[1].atomList[j] = searchLabels[0].atomList[j];
		for (j=MOPAC_MAX(searchLabels[1].atomList[0], 
					MOPAC_MIN(4,searchLabels[1].atomList[1]+1));
		     j > 1; j--) {
			if (searchLabels[1].atomList[j] == -1) {
				for (k=0; k<searchLabels[1].atomList[1]; k++) {
					for (l=1;
					     l <= MOPAC_MAX(searchLabels[1].atomList[0], 
						 			MOPAC_MIN(4,searchLabels[1].atomList[1]+1));
						 l++) {
						 if (searchLabels[1].atomList[l] == k) goto alreadyUsed;
						 /*  If k is the moving atom for label number 1, try not to use it
						     to fill-in here */
						 if (searchLabels[0].atomList[1] == k) goto alreadyUsed;
					}
					searchLabels[1].atomList[j] = k;
					break;
  alreadyUsed:;
				}
			}
			if (searchLabels[1].atomList[j] == -1) {
			    /* the previous attempt to fill-in label[1] was restricted
				   not to allow the moving atom in label[0], but there weren't 
				   enough atoms available to left to fill-in.  So repeat the
				   search, but allow searchLabels[0].atom[1].
				 */
				for (k=0; k<searchLabels[1].atomList[1]; k++) {
					for (l=1;
					     l <= MOPAC_MAX(searchLabels[1].atomList[0], 
						 			MOPAC_MIN(4,searchLabels[1].atomList[1]+1));
						 l++) {
						 if (searchLabels[1].atomList[l] == k) goto alreadyUsed2;
					}
					searchLabels[1].atomList[j] = k;
					break;
  alreadyUsed2:;
				}
			}
		}
			
	}
  }
}

void renumberLockedLabels(LockedLabel lockedLabels[], long numLockedLabels,
		long NAtom, long atomLocation[])
{
	long i, j, k, l;
	
  if (numLockedLabels > 0 ) { /* don't do any of this if there are no locked labels */
	
    /* fill out the locked labels with -1 */
	for (i=0; i< numLockedLabels; i++){
		for (j=lockedLabels[i].atomList[0]+1; j < 5; j++) 
			lockedLabels[i].atomList[j] = -1;
	}

    /* assign new atom numbers to the locked label */
	for (i=0; i < numLockedLabels; i++) { 
		for (j=lockedLabels[i].atomList[0]; j > 0; j--) {
			 lockedLabels[i].atomList[j] = 
						 findAtom(lockedLabels[i].atomList[j],
								  atomLocation, NAtom);
		} 
	}
	
	/*
		Depending upon the reordered number of the first atom in the
		locked label, the label may not contain enough atom
		numbers.  For example, if the locked label is an atom
		distance, but the first atom is numbered 6, then unique
		lower numbered atoms must be specified for the A, B, and
		C positions.  The following code fills out the label with
		appropriate lower numbered atoms.
	*/
		
	for (i=0; i < numLockedLabels; i++) {
		for (j=MOPAC_MAX(lockedLabels[i].atomList[0], 
					MOPAC_MIN(4,lockedLabels[i].atomList[1]+1));
		     j > 1; j--) {
			if (lockedLabels[i].atomList[j] == -1) {
				for (k=0; k<lockedLabels[i].atomList[1]; k++) {
					for (l=1;
					     l <= MOPAC_MAX(lockedLabels[i].atomList[0], 
						 		MOPAC_MIN(4,lockedLabels[i].atomList[1]+1));
						 l++) {
						 /* don't add an atom that is already in the label */
						 if (lockedLabels[i].atomList[l] == k) goto alreadyUsed;
					}
					lockedLabels[i].atomList[j] = k;
					break;
  alreadyUsed:;
				}
			}
		}
	}
  } /* number of locked labels > 0 */
}

void renumberForMovingAtom(int i, SearchLabel searchLabels[], long numSearchLabels,
		long NAtom, long atomLocation[], double coords[][3], long numDummyAtoms)
{
	long j, k, m;

	/* If atom i is an atom in a search label, it must not be behind the moving
				   atoms in the search label.  If it is, switch these atoms.  If it is the
				   moving atom, then none of the other atoms in the label must be after it.
	*/
	for (k=0; k<numSearchLabels; k++) { /* check all search labels */
		if ( atomLocation[i] == searchLabels[k].atomList[1]) {
			/* Atom i is a moving atom */
			for (m=i+1; m<NAtom; m++) { /* check all atoms after i */
				for (j=searchLabels[k].atomList[0]; j > 1; j--) {
					/* compare with other atoms in the label */
					if (searchLabels[k].atomList[j] == 
						atomLocation[m]) {
						swapAtoms(i, m, coords, atomLocation, numDummyAtoms);

					}
				}
			}
		} else {
			for (j=searchLabels[k].atomList[0]; j > 1; j--) {
				if ( atomLocation[i] == searchLabels[k].atomList[j]) {
					/* Atom i is in a label, but is not the moving atom in the label */
					for (m=i+1; m>2; m--) { /* check all atoms between i and 2 */
						/* see if the atom is the moving atom for the label */
						if (searchLabels[k].atomList[1] == 
							atomLocation[m]) {
							swapAtoms(i, m, coords, atomLocation, numDummyAtoms);

						}
					}
				}
			}
		}
	}
}

void renumberForFirstAtom(int i, LockedLabel lockedLabels[], long numLockedLabels,
		long NAtom, long atomLocation[], double coords[][3], long numDummyAtoms)
{
	long j, k, m;
	/* If atom i is an atom in a locked label, it must not be behind the first
				   atom in the locked label.  If it is, switch these atoms.  If it is the
				   first atom, then none of the other atoms in the label must be after it.
	*/
	for (k=0; k<numLockedLabels; k++) { /* check all locked labels */
		if ( atomLocation[i] == lockedLabels[k].atomList[1]) {
			/* Atom i is a first atom */
			for (m=i+1; m<NAtom; m++) { /* check all atoms after i */
				for (j=lockedLabels[k].atomList[0]; j > 1; j--) {
					/* compare with other atoms in the label */
					if (lockedLabels[k].atomList[j] == 
						atomLocation[m]) {
						swapAtoms(i, m, coords, atomLocation, numDummyAtoms);

					}
				}
			}
		} else {
			for (j=lockedLabels[k].atomList[0]; j > 1; j--) {
				if ( atomLocation[i] == lockedLabels[k].atomList[j]) {
					/* Atom i is in a label, but is not the first atom in the label */
					for (m=i+1; m>2; m--) { /* check all atoms between i and 2 */
						/* see if the atom is the first atom for the label */
						if (lockedLabels[k].atomList[1] == 
							atomLocation[m]) {
							swapAtoms(i, m, coords, atomLocation, numDummyAtoms);

						}
					}
				}
			}
		}
	}
}

int reorderMovingAtomsInLabels(SearchLabel searchLabels[], 
									Boolean switchedSearchLabel[])
{
	Boolean all_atoms_the_same, first_has_second, second_has_first;
	int i;

	/* 
		If two search labels have the same moving atom, but the two labels don't
		have the same order of atoms (e.g., 1-2-3 for angle, 1-2-3-4 for dihedral),
		then the connectivity for the moving atom cannot be specified for one
		of the labels.  The solution is to interchange the order of one of the
		search labels.
	*/
	if (searchLabels[0].atomList[1] == searchLabels[1].atomList[1]) {
		all_atoms_the_same = true;
		for (i=2; 
			 i<=MOPAC_MIN(searchLabels[0].atomList[0],searchLabels[1].atomList[0]); 
			 i++) {
			 if (searchLabels[0].atomList[i] != searchLabels[1].atomList[i]) {
			 	all_atoms_the_same = false;
				break;
			 }
		}
		
		if (!all_atoms_the_same) { /* reverse one of the labels */
			if (!switchedSearchLabel[0]) {
				reverseSearchOrder(searchLabels, 0);
				switchedSearchLabel[0] = true;
			} else if (!switchedSearchLabel[1]) {
				reverseSearchOrder(searchLabels, 1);
				switchedSearchLabel[1] = true;
			} else {
				alert_user("Unable to resolve conflicts between search labels.  "
						   "It may help to choose the atoms in one of the search "
						   "labels in opposite order.");
				return (-1);
			}
		}
	} else {
	/*
		If each label has the moving atom of the other, then both labels can't
		be expressed in the same z-matrix.  Switch one of the labels.
	*/
		
		/* See if the first label contains the moving atom of the second label */
		first_has_second = second_has_first = false;
		for (i=1; i<=searchLabels[0].atomList[0]; i++) {
			if (searchLabels[0].atomList[i] == searchLabels[1].atomList[1]) {
				first_has_second = true;
				break;
			}
		}
		/* See if the second label contains the moving atom of the first label */
		for (i=1; i<=searchLabels[1].atomList[0]; i++) {
			if (searchLabels[1].atomList[i] == searchLabels[0].atomList[1]) {
				second_has_first = true;
				break;
			}
		}
		
		/* Switch one of the labels if both have each other's moving atom */
		if (first_has_second && second_has_first) {
			if (!switchedSearchLabel[1]) {
				reverseSearchOrder(searchLabels, 1);
				switchedSearchLabel[1] = true;
				
			} else if (!switchedSearchLabel[0]) {
				reverseSearchOrder(searchLabels, 0);
				switchedSearchLabel[0] = true;
			} else {
				alert_user("Unable to resolve conflicts between search labels.  "
						   "It may help to choose the atoms in one of the search "
						   "labels in opposite order.");
				return (-1);
			}
		
		}
		
		/* Verify that the switch worked */
		first_has_second = second_has_first = false;
		for (i=1; i<=searchLabels[0].atomList[0]; i++) {
			if (searchLabels[0].atomList[i] == searchLabels[1].atomList[1]) {
				first_has_second = true;
				break;
			}
		}
		/* See if the second label contains the moving atom of the first label */
		for (i=1; i<=searchLabels[1].atomList[0]; i++) {
			if (searchLabels[1].atomList[i] == searchLabels[0].atomList[1]) {
				second_has_first = true;
				break;
			}
		}
		
		if (first_has_second && second_has_first) {
			/* Couldn't resolve conflict */
			alert_user("Unable to resolve conflicts between search labels.  "
					   "It may help to choose the atoms in one of the search "
					   "labels in opposite order.");
			return (-1);
		}

		
	}

  	 /* 
	 	Reorder angle search label if it is connected to a distance label.
		When the two atoms in the distance label are the same two and are in opposite
		order as the first and second atoms in the angle label, the Z matrix produced
		will cause the wrong distance (i.e., the other leg of the angle label) to be
		varied.  The fix is to interchange the two outside atoms of the angle label.
	 */
	if (searchLabels[0].atomList[0] == 2 &&
		searchLabels[1].atomList[0] == 3) {
		if (searchLabels[0].atomList[1] == 
			searchLabels[1].atomList[2] &&
			searchLabels[0].atomList[2] ==
			searchLabels[1].atomList[1]) {
			/* switch the outside atoms in the angle search label */
			if (!switchedSearchLabel[1]) {
				reverseSearchOrder(searchLabels, 1);
				switchedSearchLabel[1] = true;
			} else {
				alert_user("Unable to resolve conflicts between search labels.  "
						   "It may help to choose the angle search label atoms "
						   "in opposite order.");
				return (-1);
			}
		}
	} else if (searchLabels[0].atomList[0] == 3 &&
				searchLabels[1].atomList[0] == 2) {
		if (searchLabels[1].atomList[1] == 
			searchLabels[0].atomList[2] &&
			searchLabels[1].atomList[2] ==
			searchLabels[0].atomList[1]) {
			/* switch the outside atoms in the search label */
			if (!switchedSearchLabel[0]) {
				reverseSearchOrder(searchLabels, 0);
				switchedSearchLabel[0] = true;
			} else {
				alert_user("Unable to resolve conflicts between search labels.  "
						   "It may help to choose the angle search label atoms "
						   "in opposite order.");
				return (-1);
			}
		}

  	 /* 
	 	Reorder angle search label if it is connected to a dihedral label.  When the
		three atoms in the angle label are the same as the first three in the dihedral
		label, but they appear in opposite order, it is impossible to produce a Z-matrix. 
		The fix is to interchange the two outside atoms of the angle label.
	 */
	 } else if (searchLabels[0].atomList[0] == 3 &&
		searchLabels[1].atomList[0] == 4) {
		if (searchLabels[0].atomList[1] == 
			searchLabels[1].atomList[3] &&
			searchLabels[0].atomList[3] ==
			searchLabels[1].atomList[1] &&
			searchLabels[0].atomList[2] ==
			searchLabels[1].atomList[2]) {
			/* switch the outside atoms in the angle search label */
			if (!switchedSearchLabel[0]) {
				reverseSearchOrder(searchLabels, 0);
				switchedSearchLabel[0] = true;
			} else {
				alert_user("Unable to resolve conflicts between search labels.  "
						   "It may help to choose the angle search label atoms "
						   "in opposite order.");
				return (-1);
			}
		}
	} else if (searchLabels[0].atomList[0] == 4 &&
			searchLabels[1].atomList[0] == 3) {
		if (searchLabels[1].atomList[1] == 
			searchLabels[0].atomList[3] &&
			searchLabels[1].atomList[3] ==
			searchLabels[0].atomList[1] &&
			searchLabels[1].atomList[2] ==
			searchLabels[0].atomList[2]) {
			/* switch the outside atoms in the angle search label */
			if (!switchedSearchLabel[1]) {
				reverseSearchOrder(searchLabels,1);
				switchedSearchLabel[1] = true;
			} else {
				alert_user("Unable to resolve conflicts between search labels.  "
						   "It may help to choose the angle search label atoms "
						   "in opposite order.");
				return (-1);
			}
		}

  	 /* 
	 	Reorder dihedral search label if it is connected to a distance label.
		When the two atoms in the distance label are the same two and are in opposite
		order as the first and second atoms in the dihedral label, a Z matrix cannot be
		produced.  The fix is to interchange the two outside atoms of the dihedral label.
	 */
	} else if (searchLabels[0].atomList[0] == 2 &&
		searchLabels[1].atomList[0] == 4) {
		if (searchLabels[0].atomList[1] == 
			searchLabels[1].atomList[2] &&
			searchLabels[0].atomList[2] ==
			searchLabels[1].atomList[1]) {
			/* switch the outside atoms in the dihedral search label */
			if (!switchedSearchLabel[1]) {
				reverseSearchOrder(searchLabels, 1);
				switchedSearchLabel[1] = true;
			} else {
				alert_user("Unable to resolve conflicts between search labels.  "
						   "It may help to choose the dihedral angle search "
						   "label atoms in opposite order.");
				return (-1);
			}
  	 /* 
	 	Reorder dihedral search label if it is connected to a distance label.
		When the moving atom is the same in both labels, and the non-moving atom
		in the distance label is the same as the third atom in the dihedral label,
		a Z matrix cannot be produced.  The fix is to interchange the two outside 
		atoms of the dihedral label.
	 */
		} else if (searchLabels[0].atomList[1] == 
			searchLabels[1].atomList[1] &&
			searchLabels[0].atomList[2] ==
			searchLabels[1].atomList[3]) {
			/* switch the outside atoms in the dihedral search label */
			if (!switchedSearchLabel[1]) {
				reverseSearchOrder(searchLabels, 1);
				switchedSearchLabel[1] = true;
			} else {
				alert_user("Unable to resolve conflicts between search labels.  "
						   "It may help to choose the dihedral angle search "
						   "label atoms in opposite order.");
				return (-1);
			}
		}
	} else if (searchLabels[0].atomList[0] == 4 &&
			searchLabels[1].atomList[0] == 2) {
		if (searchLabels[1].atomList[1] == 
			searchLabels[0].atomList[2] &&
			searchLabels[1].atomList[2] ==
			searchLabels[0].atomList[1]) {
			/* switch the outside atoms in the dihedral search label */
			if (!switchedSearchLabel[0]) {
				reverseSearchOrder(searchLabels, 0);
				switchedSearchLabel[0] = true;
			} else {
				alert_user("Unable to resolve conflicts between search labels.  "
						   "It may help to choose the dihedral angle search "
						   "label atoms in opposite order.");
				return (-1);
			}
		} else if (searchLabels[1].atomList[1] == 
			searchLabels[0].atomList[1] &&
			searchLabels[1].atomList[3] ==
			searchLabels[0].atomList[1]) {
			/* switch the outside atoms in the dihedral search label */
			if (!switchedSearchLabel[0]) {
				reverseSearchOrder(searchLabels, 0);
				switchedSearchLabel[0] = true;
			} else {
				alert_user("Unable to resolve conflicts between search labels.  "
						   "It may help to choose the dihedral angle search "
						   "label atoms in opposite order.");
				return (-1);
			}
		}
	}

	return(0);
}	
