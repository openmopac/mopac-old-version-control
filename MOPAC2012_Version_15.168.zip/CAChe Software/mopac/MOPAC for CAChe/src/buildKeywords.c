#include "compat.h"
#include <ctype.h>
#include "csu.h"
#include "MOPACDriver.h"

int buildKeywords(char keywords[], MOPACControl *controlPanel, 
					MoleculeInfo *moleculeInfo)
{
    char string[256], buf[64];

    enterBusyState();

   if (controlPanel->calculate == CALCTYPE_CI)
   {

		controlPanel->calculate = CALCTYPE_OPTGEOM;
		controlPanel->CIroot = 1;
		controlPanel->CItype = CITYPE_SD;

   }

	string[0] = 0;
	if (controlPanel->calculate == CALCTYPE_CHECKINP)
		strncat(string,"0SCF",4);
	else if (controlPanel->calculate == CALCTYPE_SCF)
		strncat(string,"1SCF",4);
/*
	else if (controlPanel->calculate == CALCTYPE_CI)
		strncat(string,"C.I.",4);
*/
	else if (controlPanel->calculate == CALCTYPE_VIBSPEC)
		strncat(string,"FORCE",5);
	else if (controlPanel->calculate == CALCTYPE_RIGIDSRCH)
		strncat(string,"RigidSearch",11);
	else if (controlPanel->calculate == CALCTYPE_OPTSRCH)
		strncat(string,"OptimizedSearch",15);
	else if (controlPanel->calculate == CALCTYPE_SADDLE)
		strncat(string,"SADDLE XYZ",10);
	else if (controlPanel->calculate == CALCTYPE_MINGRAD)
		strncat(string,"Minimization",12);
	else if (controlPanel->calculate == CALCTYPE_IRC)
		strncat(string,"IRC",3);
	else if (controlPanel->calculate == CALCTYPE_DRC)
		strncat(string,"DRC",3);
	else if (controlPanel->calculate == CALCTYPE_CROSS)
		strncat(string,"CROSS",5);
	else
		string[0] = 0;

	if (string[0] != 0) {
		if (((strcmp(string,"RigidSearch") == 0) || 
	       (strcmp(string,"OptimizedSearch") == 0)) 
		   && (controlPanel->searchType == SRCHTYPE_RXN)) {
		   if (moleculeInfo->numSearchLabels < 1) {
				leaveBusyState();

				alert_user("You have requested a reaction coordinate"
						  " calculation, but have not defined a"
						  " proper search label.  Use the Editor"
						  " to define the search label.");
				return (-1);
			}
		   moleculeInfo->numSearchLabels = 1; /* only one of the search labels should be used */
		/* Generation of a map file requires xyz coordinates be
		   printed in the output file, so force generation of the
		   coordinates here.  Cannot use XYZ for a reaction coordinate calculation.
		   Cannot use cartesian coordinate input for reaction coordinate calculation.
		   */
		   controlPanel->detailsXYZCoord = true;
		   controlPanel->detailsUseXYZ = false;
		   controlPanel->detailsGeoType = INTERNAL_COORD;
/*
		   if ((strstr(controlPanel->extraKeyWords,"C.I.") == NULL)) {
			   if (controlPanel->CIlevel > 1) {
				  sprintf(buf," C.I.=%d",controlPanel->CIlevel - 1);
				  strcat(keywords, buf);
			   }
		   }
*/
		} else if (((strcmp(string,"RigidSearch") == 0) || 
	       (strcmp(string,"OptimizedSearch") == 0)) 
		   && (controlPanel->searchType == SRCHTYPE_GRID)) {
			 if (moleculeInfo->numSearchLabels < 2) {
				leaveBusyState();
				alert_user("You have requested a grid"
						   " calculation, but have not defined enough"
						   " search labels.  Use the Editor to define"
						   " more search labels.");
				return (-1);
		     }
		   moleculeInfo->numSearchLabels = 2;  /* make sure we never try to deal with more than 2 search labels */
		/* Generation of a map file requires xyz coordinates be
		   printed in the output file, so force generation of the
		   coordinates here.  Cannot use XYZ for a grid calculation.
		   Cannot use cartesian coordinate input for a grid calculation.
		   */
		   controlPanel->detailsXYZCoord = true;
		   controlPanel->detailsUseXYZ = false;
		   controlPanel->detailsGeoType = INTERNAL_COORD;
/*
	       if ((strstr(controlPanel->extraKeyWords,"C.I.") == NULL)) {
			   if (controlPanel->CIlevel > 1) {
				  sprintf(buf," C.I.=%d",controlPanel->CIlevel - 1);
				  strcat(keywords, buf);
			   }
		   }
*/
		} else if (strcmp(string,"IRC") == 0) {
	   	 /* Cannot use cartesin coordinates for IRC */
		   controlPanel->detailsUseXYZ = false;
		   controlPanel->detailsGeoType = INTERNAL_COORD;
		 /* Cannot use dummy atoms for IRC */

         /* If the keyword has been specified in the extraKeyWords don't write it here.*/
	     if (strstr(controlPanel->extraKeyWords,string) == NULL) {
			if (controlPanel->ircMode == 0) {
				sprintf(buf," IRC");
				strcat(keywords, buf);
			} else {
				sprintf(buf,"IRC=%d",controlPanel->ircMode);
				strcat(keywords, buf);
			}
			if ((controlPanel->addKEforIRC != 0) &&
				(strstr(controlPanel->extraKeyWords,"KINETIC") == NULL)) {
				sprintf(buf," KINETIC=%f",controlPanel->addKEforIRC);
				strcat(keywords, buf);
			}
		  } else {
			if ((controlPanel->addKEforIRC != 0) && 
				(strstr(controlPanel->extraKeyWords,"KINETIC") == NULL)) {
				sprintf(buf," KINETIC=%f",controlPanel->addKEforIRC);
				strcat(keywords, buf);
			}
		  }
/*
		  if ((strstr(controlPanel->extraKeyWords,"C.I.") == NULL)) {
			  if (controlPanel->CIlevel > 1) {
				  sprintf(buf," C.I.=%d",controlPanel->CIlevel - 1);
				  strcat(keywords, buf);
			  }
		  }
*/
		} else if (strcmp(string,"DRC") == 0) { 
	   	 /* Cannot use cartesin coordinates for DRC */
		   controlPanel->detailsUseXYZ = false;
		   controlPanel->detailsGeoType = INTERNAL_COORD;

         /* If the keyword has been specified in the extraKeyWords don't write it here.*/
	     if (strstr(controlPanel->extraKeyWords,string) == NULL) {
			if (controlPanel->drcIrcMode == 0) {
				if (!controlPanel->DRCdampKinetic) {
					sprintf(buf," DRC");
					strcat(keywords, buf);
				} else {
					sprintf(buf," DRC=%f",controlPanel->halfLifeForDRC);
					strcat(keywords, buf);
				}
			} else {
				if (!controlPanel->DRCdampKinetic) {
					if (strstr(controlPanel->extraKeyWords,"IRC") == NULL) {
						sprintf(buf," DRC IRC=%d",controlPanel->drcIrcMode);
						strcat(keywords, buf);
					}
				} else {					
					if (strstr(controlPanel->extraKeyWords,"IRC") == NULL) {
						sprintf(buf," DRC=%f IRC=%d",
							controlPanel->halfLifeForDRC,controlPanel->drcIrcMode);
						strcat(keywords, buf);
					} else {
					        sprintf(buf," DRC=%f",controlPanel->halfLifeForDRC);
						strcat(keywords, buf);
					}
				}
			}
			if ((controlPanel->addKEforDRC != 0) &&
				(strstr(controlPanel->extraKeyWords,"KINETIC") == NULL)) {
				sprintf(buf," KINETIC=%f",controlPanel->addKEforDRC);
				strcat(keywords, buf);
			}
			if (controlPanel->DRChPrio) {
				if (strstr(controlPanel->extraKeyWords,"H-PRIO") == NULL) {
					sprintf(buf," H-PRIORITY=%f",controlPanel->hPrioStep);
					strcat(keywords, buf);
				}
			}
			if (controlPanel->DRCtPrio) {
				if (strstr(controlPanel->extraKeyWords,"T-PRIO") == NULL) {
					sprintf(buf," T-PRIORITY=%f",controlPanel->tPrioStep);
					strcat(keywords, buf);
				}
			}
			if (controlPanel->DRCxPrio) {
				if (strstr(controlPanel->extraKeyWords,"X-PRIO") == NULL) {
					sprintf(buf," X-PRIORITY=%f",controlPanel->xPrioStep);
					strcat(keywords, buf);
				}
			}
		  } else {
			if (strstr(controlPanel->extraKeyWords,"IRC") == NULL) {
				sprintf(buf," DRC IRC=%d",controlPanel->drcIrcMode);
				strcat(keywords, buf);
			}
			if ((controlPanel->addKEforDRC != 0) &&
				(strstr(controlPanel->extraKeyWords,"KINETIC") == NULL)) {
				sprintf(buf," KINETIC=%f",controlPanel->addKEforDRC);
				strcat(keywords, buf);
			}
			if (controlPanel->DRChPrio) {
				if (strstr(controlPanel->extraKeyWords,"H-PRIO") == NULL) {
					sprintf(buf," H-PRIORITY=%f",controlPanel->hPrioStep);
					strcat(keywords, buf);
				}
			}
			if (controlPanel->DRCtPrio) {
				if (strstr(controlPanel->extraKeyWords,"T-PRIO") == NULL) {
					sprintf(buf," T-PRIORITY=%f",controlPanel->tPrioStep);
					strcat(keywords, buf);
				}
			}
			if (controlPanel->DRCxPrio) {
				if (strstr(controlPanel->extraKeyWords,"X-PRIO") == NULL) {
					sprintf(buf," X-PRIORITY=%f",controlPanel->xPrioStep);
					strcat(keywords, buf);
				}
			}
		  }
/*
		  if ((strstr(controlPanel->extraKeyWords,"C.I.") == NULL)) {
			  if (controlPanel->CIlevel > 1) {
				  sprintf(buf," C.I.=%d",controlPanel->CIlevel - 1);
				  strcat(keywords, buf);
			  }
		  }
*/
		} else if (strcmp(string,"Minimization") == 0) {
	      /* don't write a keyword for gradient minimizations */
	   	  strcat(keywords," ");
/*
		  if ((strstr(controlPanel->extraKeyWords,"C.I.") == NULL)) {
			  if (controlPanel->CIlevel > 1) {
				  sprintf(buf," C.I.=%d",controlPanel->CIlevel - 1);
				  strcat(keywords, buf);
			  }
		  }
*/
	   } else {
         /* If the keyword has been specified in the extraKeyWords don't 
		 	write it here. */

		   if (strstr(controlPanel->extraKeyWords,string) == NULL) {
	   	   strcat(keywords," ");
		   strcat(keywords, string);		   
		/*   if (strncmp(string,"C.I.",4) == 0) {
			  if ((strstr(controlPanel->extraKeyWords,"C.I.") == NULL)) {
				 if (controlPanel->CIlevel > 1) {
					  sprintf(buf," C.I.=%d",controlPanel->CIlevel - 1);
					  strcat(keywords, buf);
				 } 
			  }
		   } else {
			  if ((strstr(controlPanel->extraKeyWords,"C.I.") == NULL)) {
				 if (controlPanel->CIlevel > 1) {
					  sprintf(buf," C.I.=%d",controlPanel->CIlevel - 1);
					  strcat(keywords, buf);
				 }
		      }
		   }
		  */ 
		 } else {
/*
			if ((strstr(controlPanel->extraKeyWords,"C.I.") == NULL)) {
			   if (controlPanel->CIlevel > 1) {
				  sprintf(buf," C.I.=%d",controlPanel->CIlevel - 1);
				  strcat(keywords, buf);
			   }
			}
*/
		 }
		}
    } else {
/*
		if ((strstr(controlPanel->extraKeyWords,"C.I.") == NULL)) {
		   if (controlPanel->CIlevel > 1) {
			  sprintf(buf," C.I.=%d",controlPanel->CIlevel - 1);
			  strcat(keywords, buf);
		   }
		}
*/
	}

	/* 
	 * If we are doing something that is a geometry optimization or 
	 * gradient minimization, then it is ok to set the geometry search 
	 * strategy.
	 * Do not put in the geometry optimization strategy if there is
	 * already a geometry optimization keyword in the extra keywords.
	 */
	if ((strstr(string,"DRC") == NULL) &&
		(strstr(string,"IRC") == NULL) &&
		(strstr(string,"FORCE") == NULL) &&
		(strstr(string,"SADDLE") == NULL) &&
	    ((strstr(string,"1SCF") == NULL) ||  /* Write optimization method for 1SCF restarts */
				(controlPanel->controlRestart == true)) &&
	    (strstr(string,"RigidSearch") == NULL ) &&  /* Searches use FLEPO */
	    (strstr(controlPanel->extraKeyWords," TS") == NULL) && /* needs leading blank to be unique */
	    (strstr(controlPanel->extraKeyWords,"NLLSQ") == NULL) &&
	    (strstr(controlPanel->extraKeyWords,"SIGMA") == NULL) &&
	    (strstr(controlPanel->extraKeyWords,"DFP") == NULL) &&
	    (strstr(controlPanel->extraKeyWords,"EF") == NULL) &&
	    (strstr(controlPanel->extraKeyWords,"1SCF") == NULL) &&
	    (strstr(controlPanel->extraKeyWords,"SADDLE") == NULL) &&
	    (strstr(controlPanel->extraKeyWords,"FORCE") == NULL) &&
	    (strstr(controlPanel->extraKeyWords,"IRC") == NULL) &&
	    (strstr(controlPanel->extraKeyWords,"MODE=") == NULL) &&
	    (strstr(controlPanel->extraKeyWords,"KINETIC") == NULL) &&
	    (strstr(controlPanel->extraKeyWords,"H-PRIO") == NULL) &&
	    (strstr(controlPanel->extraKeyWords,"T-PRIO") == NULL) &&
	    (strstr(controlPanel->extraKeyWords,"X-PRIO") == NULL) &&
		(strstr(controlPanel->extraKeyWords,"DRC") == NULL)) {
		string[0] = 0;
		if (controlPanel->calculate == minimizeGradientMN)  { 
			/* get search type from minimization menu */
			if (controlPanel->minimizeGradient == MINGRADMETH_NLLSQ)
				strncat(string,"NLLSQ",5);
			else if (controlPanel->minimizeGradient == MINGRADMETH_SIGMA)
				strncat(string,"SIGMA",5);
			else if (controlPanel->minimizeGradient == MINGRADMETH_EF)
				strncat(string,"TS",2);
		} else if (controlPanel->calculate == optSearchMN) {
			/* reaction coordinate and grid calculations can use EF */
			if (controlPanel->geometrySearch == GEOMETH_EF)
				{};
//				strncat(string,"EF",2);
		} else {
			/* get search type from optimization menu */
			if (controlPanel->geometrySearch == GEOMETH_NLLSQ)
				strncat(string,"NLLSQ",5);
			else if (controlPanel->geometrySearch == GEOMETH_DFP)
				strncat(string,"DFP",3);
			else if (controlPanel->geometrySearch == GEOMETH_SIGMA)
				strncat(string,"SIGMA",5);
			else if (controlPanel->geometrySearch == GEOMETH_EF)
			{};
//				strncat(string,"EF",2);
		}
		/* if the string is not empty and it does not appear in the extra keywords
		   then add it */
		if (string[0] != 0 && 
			(strstr(controlPanel->extraKeyWords,string) == NULL)) {
			strcat(keywords," ");
			strcat(keywords, string);
		}
	}

	string[0] = 0;
	/* 
	 * Only add multiplicity-related keyword if a multiplicity is
	 * not specified in the extra key words.
	 */
	if ((strstr(controlPanel->extraKeyWords,"SINGLET") == NULL) &&
		(strstr(controlPanel->extraKeyWords,"DOUBLET") == NULL) &&
		(strstr(controlPanel->extraKeyWords,"TRIPLET") == NULL) &&
		(strstr(controlPanel->extraKeyWords,"QUARTET") == NULL) &&
		(strstr(controlPanel->extraKeyWords,"QUINTET") == NULL) &&
		(strstr(controlPanel->extraKeyWords,"SEXTET") == NULL) &&
		(strstr(controlPanel->extraKeyWords,"SEPTET") == NULL) &&
		(strstr(controlPanel->extraKeyWords,"OCTET") == NULL) &&
		(strstr(controlPanel->extraKeyWords,"NONET") == NULL) &&
		(strstr(controlPanel->extraKeyWords,"EXCITED") == NULL) &&
		(strstr(controlPanel->extraKeyWords,"BIRAD") == NULL)) {
			if (controlPanel->multiplicity == SPINMULT_SINGLET)
				strncat(string,"SINGLET",7);
			else if (controlPanel->multiplicity == SPINMULT_DOUBLET)
				strncat(string,"DOUBLET",7);
			else if (controlPanel->multiplicity == SPINMULT_TRIPLET)
				strncat(string,"TRIPLET",7);
			else if (controlPanel->multiplicity == SPINMULT_TRIPLETUHF)
				strncat(string,"UHF TRIPLET",11);
			else if (controlPanel->multiplicity == SPINMULT_EXCSINGLET)
				strncat(string,"EXCITED SINGLET",15);
			else if (controlPanel->multiplicity == SPINMULT_QUARTET)
				strncat(string,"QUARTET",7);
			else if (controlPanel->multiplicity == SPINMULT_QUINTET)
				strncat(string,"QUINTET",7);
			else if (controlPanel->multiplicity == SPINMULT_SEXTET)
				strncat(string,"SEXTET",6);
			else if (controlPanel->multiplicity == SPINMULT_SEPTET)
				strncat(string,"SEPTET",6);
			else if (controlPanel->multiplicity == SPINMULT_OCTET)
				strncat(string,"OCTET",5);
			else if (controlPanel->multiplicity == SPINMULT_NONET)
				strncat(string,"NONET",5);
			else if (controlPanel->multiplicity == SPINMULT_BIRADICAL)
				strncat(string,"BIRADICAL",9);
			else if (controlPanel->multiplicity == SPINMULT_UHF)
				strncat(string,"UHF",3);
	}

    if (string[0] != 0 && 
		(strstr(controlPanel->extraKeyWords,string) == NULL)) {
	   strcat(keywords," ");
	   strcat(keywords, string);
	}

#if 0
	/* Add necessary C.I. keyword for high spin states */
	if ((strstr(controlPanel->extraKeyWords,"C.I.") == NULL) &&
		(strstr(keywords,"C.I.") == NULL)) {
		string[0] = 0;
		if (controlPanel->multiplicity == SPINMULT_TRIPLET)
			strncat(string,"C.I.=2",6);
		else if (controlPanel->multiplicity == SPINMULT_QUARTET)
			strncat(string,"C.I.=3",6);
		else if (controlPanel->multiplicity == SPINMULT_QUINTET)
			strncat(string,"C.I.=4",6);
		else if (controlPanel->multiplicity == SPINMULT_SEXTET)
			strncat(string,"C.I.=5",6);
		if (string[0] != 0) {
		   strcat(keywords," ");
		   strcat(keywords, string);
		}
	}
#endif






if (controlPanel->CItype != CITYPE_NONE) {

	if ((strstr(controlPanel->extraKeyWords,"CIS") == NULL) &&
		(strstr(controlPanel->extraKeyWords,"CISD") == NULL) &&
		(strstr(controlPanel->extraKeyWords,"CISDT") == NULL) &&
		(strstr(controlPanel->extraKeyWords,"PECI") == NULL) &&
		(strstr(controlPanel->extraKeyWords,"MICROS") == NULL)) {
			string[0] = 0;
			if (controlPanel->CItype == CITYPE_S)
				strncat(string,"CIS",3);
			else if (controlPanel->CItype == CITYPE_SD)
				strncat(string,"CISD",4);
			else if (controlPanel->CItype == CITYPE_DEFAULT)
				strncat(string,"CISD",4);
			else if (controlPanel->CItype == CITYPE_SDT)
				strncat(string,"CISDT",5);
			else if (controlPanel->CItype == CITYPE_PECI)
				strncat(string,"PECI",4);
			else
				string[0] = 0;
			strcat(keywords," ");				  
			strcat(keywords, string);
	}
	if ((strstr(controlPanel->extraKeyWords,"C.I.") == NULL)) {
			if (controlPanel->CIlevel-1 > 0) {
				sprintf(buf," C.I.=%d",controlPanel->CIlevel - 1);
				strcat(keywords, buf);
			}
			else
				strcat(keywords," C.I.=4");
		}
	if ((strstr(controlPanel->extraKeyWords,"ROOT") == NULL)) {
			sprintf(buf," ROOT=%d",controlPanel->CIroot);
			strcat(keywords, buf);
	}
	
	if ((strstr(controlPanel->extraKeyWords,"MECI") == NULL)) {
			sprintf(buf," MECI");
			strcat(keywords, buf);
	}
	


}













	string[0] = 0;
	if (controlPanel->parameters == PARAM_AM1)
		strncat(string,"AM1",3);
	else if (controlPanel->parameters == PARAM_MINDO3)
		strncat(string,"MINDO/3",7);
	else if (controlPanel->parameters == PARAM_PM3)
		strncat(string,"PM3",3);
	else if (controlPanel->parameters == PARAM_MNDOd)
		strncat(string,"MNDOD",5);
	else if (controlPanel->parameters == PARAM_PM5)
		strncat(string,"PM5",5);
	else
		string[0] = 0;

	/* 
	 * Parameters conflict with each other.  Do not add the parameter
	 * keyword if there is a parameter keyword in the extra keywords
	 */
	if (string[0] != 0 && 
		(strstr(controlPanel->extraKeyWords,"AM1") == NULL) &&
		(strstr(controlPanel->extraKeyWords,"MINDO/3") == NULL) &&
		(strstr(controlPanel->extraKeyWords,"PM3") == NULL) &&
		(strstr(controlPanel->extraKeyWords,"PM5") == NULL) &&
		(strstr(controlPanel->extraKeyWords,"MNDOD") == NULL)) {
	   strcat(keywords," ");
	   strcat(keywords, string);
	}

	string[0] = 0;
	if (controlPanel->scfConverger == SCF_PULAY)
		strncat(string,"PULAY",5);
	else if (controlPanel->scfConverger == SCF_SHIFT)
		strncat(string,"SHIFT=15",8);
	else
		string[0] = 0;

	if (string[0] != 0 && 
		(strstr(controlPanel->extraKeyWords,string) == NULL)
		&& (strstr(controlPanel->extraKeyWords,"SHIFT=") == NULL)) {
	   strcat(keywords," ");
	   strcat(keywords, string);
	}

	if (controlPanel->controlRestart) {
		strncpy(string,"RESTART",8);
		if (string[0] != 0 && 
			(strstr(controlPanel->extraKeyWords,string) == NULL)) {
	   		strcat(keywords," ");
	   		strcat(keywords, string);
		}
	}

	if (controlPanel->detailsMMOK) {
		strncpy(string,"MMOK",5);
		/* check for the existence of either MMOK or NOMM in extra keywords */
		if (string[0] != 0 && 
			(strstr(controlPanel->extraKeyWords,"MMOK") == NULL) &&
			(strstr(controlPanel->extraKeyWords,"NOMM") == NULL)) {
	   		strcat(keywords," ");
	   		strcat(keywords, string);
		}
	} else if (!controlPanel->detailsMMOK) {
		strncpy(string,"NOMM",5);
		if (string[0] != 0 && 
			(strstr(controlPanel->extraKeyWords,"MMOK") == NULL) &&
			(strstr(controlPanel->extraKeyWords,"NOMM") == NULL)) {
	   		strcat(keywords," ");
	   		strcat(keywords, string);
		}
	}
	if (controlPanel->detailsEnergyPart) {
		strncpy(string,"ENPART",7);
		if (string[0] != 0 && 
			(strstr(controlPanel->extraKeyWords,string) == NULL)) {
	   		strcat(keywords," ");
	   		strcat(keywords, string);
		}
	}
	if (controlPanel->detailsESR) {
		strncpy(string,"ESR",4);
		if (string[0] != 0 && 
			(strstr(controlPanel->extraKeyWords,string) == NULL)) {
	   		strcat(keywords," ");
	   		strcat(keywords, string);
		}
	}	
	if (controlPanel->detailsLocalize) {
		strncpy(string,"LOCALIZE",9);
		if (string[0] != 0 && 
			(strstr(controlPanel->extraKeyWords,string) == NULL)) {
	   		strcat(keywords," ");
	   		strcat(keywords, string);
		}
	}	
	if (controlPanel->detailsMulliken) {
		strncpy(string,"MULLIK",7);
		if (string[0] != 0 && 
			(strstr(controlPanel->extraKeyWords,string) == NULL)) {
	   		strcat(keywords," ");
	   		strcat(keywords, string);
		}
	}	
	if (controlPanel->detailsPI) {
		strncpy(string,"PI",3);
		if (string[0] != 0 && 
			(strstr(controlPanel->extraKeyWords,string) == NULL)) {
	   		strcat(keywords," ");
	   		strcat(keywords, string);
		}
	}	
	if (controlPanel->detailsPolar) {
		strncpy(string,"POLAR",6);
		if (string[0] != 0 && 
			(strstr(controlPanel->extraKeyWords,string) == NULL)) {
	   		strcat(keywords," ");
	   		strcat(keywords, string);
		}
	}	
	if (controlPanel->detailsBondOrder) {
		strncpy(string,"BONDS",6);
		if (string[0] != 0 && 
			(strstr(controlPanel->extraKeyWords,string) == NULL)) {
	   		strcat(keywords," ");
	   		strcat(keywords, string);
		}
	}	
	if (controlPanel->detailsDensity) {
		strncpy(string,"DENSITY",8);
		if (string[0] != 0 && 
			(strstr(controlPanel->extraKeyWords,string) == NULL)) {
	   		strcat(keywords," ");
	   		strcat(keywords, string);
		}
	}	
	if (controlPanel->detailsFock) {
		strncpy(string,"FOCK",5);
		if (string[0] != 0 && 
			(strstr(controlPanel->extraKeyWords,string) == NULL)) {
	   		strcat(keywords," ");
	   		strcat(keywords, string);
		}
	}	
	if (controlPanel->detailsGradients) {
		strncpy(string,"GRADIENTS",10);
		if (string[0] != 0 && 
			(strstr(controlPanel->extraKeyWords,string) == NULL)) {
	   		strcat(keywords," ");
	   		strcat(keywords, string);
		}
	}	
/*
	if (!controlPanel->detailsInterADist) {
		strncpy(string,"NOINTER",8);
		if (string[0] != 0 && 
			(strstr(controlPanel->extraKeyWords,string) == NULL)) {
	   		strcat(keywords," ");
	   		strcat(keywords, string);
		}
	}	

    MOPAC 2000 doesn't support keyword NOINTER
	Checkbox "interatomic distances" was removed from MOPAC settings dialog
	without altering sources. It should be done for next release
  */
	if (!controlPanel->detailsXYZCoord) {
		strncpy(string,"NOXYZ",6);
		if (string[0] != 0 && 
			(strstr(controlPanel->extraKeyWords,string) == NULL)) {
	   		strcat(keywords," ");
	   		strcat(keywords, string);
		}
	}	
	if (controlPanel->detailsSpin) {
		strncpy(string,"SPIN",5);
		if (string[0] != 0 && 
			(strstr(controlPanel->extraKeyWords,string) == NULL)) {
	   		strcat(keywords," ");
	   		strcat(keywords, string);
		}
	}	
	if (controlPanel->detailsVectors) {
		strncpy(string,"VECTORS",8);
		if (string[0] != 0 && 
			(strstr(controlPanel->extraKeyWords,string) == NULL)) {
	   		strcat(keywords," ");
	   		strcat(keywords, string);
		}
	}	
	if (controlPanel->detailsPrecise) {
		strncpy(string,"PRECISE",8);
		if (string[0] != 0 && 
			(strstr(controlPanel->extraKeyWords,string) == NULL)) {
	   		strcat(keywords," ");
	   		strcat(keywords, string);
		}
	}	
	if (controlPanel->accessoryDensity) {
		strncpy(string,"DENOUT",7);
		if (string[0] != 0 && 
			(strstr(controlPanel->extraKeyWords,string) == NULL)) {
	   		strcat(keywords," ");
	   		strcat(keywords, string);
		}
	}	
	if (controlPanel->accessoryIsotope) {
		strncpy(string,"ISOTOPE",8);
		if (string[0] != 0 && 
			(strstr(controlPanel->extraKeyWords,string) == NULL)) {
	   		strcat(keywords," ");
	   		strcat(keywords, string);
		}
	}	
	if (controlPanel->detailsLarge) {
		strncpy(string,"LARGE",6);
		if (string[0] != 0 && 
			(strstr(controlPanel->extraKeyWords,string) == NULL)) {
	   		strcat(keywords," ");
	   		strcat(keywords, string);
		}
	}	
	if (controlPanel->detailsAnalytGrad) {
		strncpy(string,"ANALYT",7);
		if (string[0] != 0 && 
			(strstr(controlPanel->extraKeyWords,string) == NULL)) {
	   		strcat(keywords," ");
	   		strcat(keywords, string);
		}
	}	
	if ((strstr(controlPanel->extraKeyWords, "EXTERNAL=") == NULL) &&
		controlPanel->detailsExternParam) {
		strncpy(string,"EXTERNAL=MOPAC_Params",22);
		if (string[0] != 0) {
	   		strcat(keywords," ");
	   		strcat(keywords, string);
		}
	}
#if defined(_WINDOWS) || defined(_WIN32)
    if ((strstr(controlPanel->extraKeyWords, "EXTERNAL=") != NULL))  {
		char *start;
		start = strstr(controlPanel->extraKeyWords, "EXTERNAL=");
            if (start[10]  != ':' && start[11] != ':') {
	   		leaveBusyState();

				alert_user("\nKeyword 'EXTERNAL' requires the complete path to be used,"
						  " for example, 'EXTERNAL=E:\\test\\parameters' or"
						  " 'EXTERNAL=\"E:\\test data\\parameters\"'.\n");
					return (-2);
		}
	}
#endif
	if (controlPanel->detailsUseXYZ) {
		strncpy(string,"XYZ",4);
		if (string[0] != 0 && 
			(strstr(controlPanel->extraKeyWords,string) == NULL)) {
	   		strcat(keywords," ");
	   		strcat(keywords, string);
		}
	}	
	if (controlPanel->MOZYME) {
		strncpy(string,"MOZYME",7);
		if (string[0] != 0 && 
			(strstr(controlPanel->extraKeyWords,string) == NULL)) {
	   		strcat(keywords," ");
	   		strcat(keywords, string);
		}
	}	
	if (!controlPanel->detailsDIIS) {
		strncpy(string,"NODIIS",7);
		if (string[0] != 0 && 
			(strstr(controlPanel->extraKeyWords,string) == NULL)) {
	   		strcat(keywords," ");
	   		strcat(keywords, string);
		}
	}	
	/* Always write the MOPAC Graphics file so that the CAChe info can be updated */

		strncpy(string,"GRAPH",6);
		if (string[0] != 0 && 
			(strstr(controlPanel->extraKeyWords,string) == NULL)) {
			strcat(keywords," ");
			strcat(keywords, string);
		}

	if (controlPanel->detailsThermo) {
		string[0] = 0;
		temperatureParens(controlPanel->temperature,32,string);
		if (string[0] != 0 && 
			(strstr(controlPanel->extraKeyWords,"THERMO") == NULL)) {
		   strcat(keywords," ");
		   strcat(keywords, string);
		}
		string[0] = 0;
/* Keyword ROT=n is not supported by MOPAC
		if (controlPanel->rotationalSymmetry == ROTSYM_C1)
			strncat(string,"ROT=1",5);
		else if (controlPanel->rotationalSymmetry == ROTSYM_C2)
			strncat(string,"ROT=2",5);
		else if (controlPanel->rotationalSymmetry == ROTSYM_C3)
			strncat(string,"ROT=3",5);
		else if (controlPanel->rotationalSymmetry == ROTSYM_C4)
			strncat(string,"ROT=4",5);
		else if (controlPanel->rotationalSymmetry == ROTSYM_C6)
			strncat(string,"ROT=6",5);
		else if (controlPanel->rotationalSymmetry == ROTSYM_D2)
			strncat(string,"ROT=4",5);
		else if (controlPanel->rotationalSymmetry == ROTSYM_D3)
			strncat(string,"ROT=6",5);
		else if (controlPanel->rotationalSymmetry == ROTSYM_D4)
			strncat(string,"ROT=8",5);
		else if (controlPanel->rotationalSymmetry == ROTSYM_D6)
			strncat(string,"ROT=12",6);
		else if (controlPanel->rotationalSymmetry == ROTSYM_S6)
			strncat(string,"ROT=3",5);
		else if (controlPanel->rotationalSymmetry == ROTSYM_CinfV)
			strncat(string,"ROT=1",5);
		else if (controlPanel->rotationalSymmetry == ROTSYM_DinfH)
			strncat(string,"ROT=2",5);
		else if (controlPanel->rotationalSymmetry == ROTSYM_T)
			strncat(string,"ROT=12",6);
		else if (controlPanel->rotationalSymmetry == ROTSYM_Oh)
			strncat(string,"ROT=24",6);
		else
			string[0] = 0;
*/
		if (string[0] != 0 && 
			(strstr(controlPanel->extraKeyWords,"ROT=") == NULL)) {
		   strcat(keywords," ");
		   strcat(keywords, string);
		}
	}

	if (controlPanel->maxSCFiterations != 200
		&& (strstr(controlPanel->extraKeyWords,"ITRY=") == NULL)) 
		sprintf(keywords,"%s ITRY=%d",keywords,
				controlPanel->maxSCFiterations);

	if (controlPanel->controlUseCosmo) {
		if (strstr(controlPanel->extraKeyWords, "EPS=") == NULL)
			sprintf(keywords, "%s EPS=%f", keywords,
					controlPanel->cosmoDielectric);
		if (strstr(controlPanel->extraKeyWords, "RSOLV=") == NULL)
			sprintf(keywords, "%s RSOLV=%f", keywords,
					controlPanel->cosmoRadius);
	}

	return (0);
}

int temperatureParens(char string[], int length, char newstring[])
{
/*	Routine to put the temperature specification for a THERMO calculation into the
	proper form. If no temperature is given, then just write THERMO.  Else, 
	it should have a leading parenthesis and a trailing parenthesis, and no 
	spaces anywhere.  */
	
	int i,j,newlength, commas;
	char c;
	Boolean in_number, found_period;
		
	/* Go through the string and remove all the blanks, left and right parentheses;
	   remove all the nulls too */
	   
	 commas = 0;
	 in_number = found_period = false;
	 for (i=0, j=0 ; i < length; i++) {
		c = string[i];
		if (found_period && c != ',' && c != ' ')
			continue; /* ignore digits after decimal point */
		if (c == ',' || c == ' ') {
			found_period = false; /* okay to start reading numbers again */
			if (!in_number) /* only write a comma after a number */
				continue;
			in_number = false; /* comma terminates number */
			if (++commas > 2)
				break;
			string[j++] = ',';
		}
		else if (c == '.')
			found_period = true;
		else if (c >= '0' && c <= '9') {
			string[j++] = c;
			in_number = true;
		}
		if (!c)
			break;
	}
	if (j >= length)
		j = length-1;
	string[j] = 0;
	newlength = j;
	
	if (newlength <= 0) {  /* no temperature given */
		strncpy(newstring,"THERMO",6);
		newstring[6] = 0;
	} else {  /* temperature given; wrap in parentheses */

		/* Slide the characters one to the right and insert "THERMO(" at the
	 	  begining */
	   
		strncpy(newstring,"THERMO(",7);
	   
		for (i=0; i<newlength ; i++) newstring[i+7] = string[i];
	
		/* Insert a right paren at the end of the string and null-terminate it */
	
		strncpy(newstring+newlength+7,")",1);
	
		newstring[newlength+8] = 0;
	}
	return(newlength+1);
}
