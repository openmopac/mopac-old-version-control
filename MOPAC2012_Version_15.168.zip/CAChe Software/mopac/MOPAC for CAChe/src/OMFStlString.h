#ifndef _OMFStlString
#define _OMFStlString

#include <string>
#include <vector>

typedef std::string					OMFStlString;
typedef	std::vector<OMFStlString>	OMFStlStringList;

#endif // _OMFStlString
