#if defined(_WIN32)
#include <windows.h>
#endif
#include <compat.h>
#include <time.h>
#include <cul.h>
#include <CACheVersion.h>

#define LOCAL_STRING_LENGTH  128

cul_CPMsgChannel msgChannel1;
cul_CPMsgChannel msgChannel2;
cul_CPMsgChannel msgChannel3;

static time_t time_since_message = 0;
static time_t current_clock;

#if defined(_WIN32)
#define MESSAGE_RETRIES  1
#else
#define MESSAGE_RETRIES  10
#endif

#define MESSAGE_ONE   1
#define MESSAGE_TWO   2
#define MESSAGE_THREE 4
#define MESSAGE_FOUR  8

void MOPAC(void);
void ce_mopac_wait_for_continue(void);
void ce_mopac_send_process_flag(void);
void ce_mopac_exit(long exit_code);
long ce_mopac_shutdown(void);        // returns 0 if stop_evt is not set, 1 if set.

void setmsgbufc(long *length, char *string, long *number);
long shutdownc(long *i);

void DbgBreak()
{
    DebugBreak();
}

void ce_ApplMain(char *programName, long processOutputFile, void *CompEng)
{
    char tbuf[64], buf[256];
    long length, channel_number;
    double t0 = 0.0, t1 = 0.0;

    cul_initCPMessageChannel(&msgChannel1, 1, CompEng);
    cul_initCPMessageChannel(&msgChannel2, 2, CompEng);
    cul_initCPMessageChannel(&msgChannel3, 3, CompEng);

    // Check to see if processing an output file.

    if ( processOutputFile != 0 )
    {
        // Tell the ApplReqServer to process output.
        sprintf(buf, "Calculation done.");
        length = strlen(buf);
        channel_number = MESSAGE_FOUR;
        setmsgbufc(&length, buf, &channel_number);

        sprintf(buf,"All done");
        length = strlen(buf);
        channel_number = MESSAGE_TWO;
        setmsgbufc(&length, buf, &channel_number);

    } else {

        t0 = cul_seconds();

	//	 DebugBreak();
        MOPAC(); // Call the MOPAC FORTRAN main subroutine
        t1 = cul_seconds();

        cul_elapsedtime(t0,t1,tbuf);
        sprintf(buf, "Computation time: %s\n",tbuf);
        length = strlen(buf);
        channel_number = MESSAGE_ONE;
        setmsgbufc(&length, buf, &channel_number);
    }
}


void setmsgbufc(long *length, char *string, long *number)
{
    char buf[LOCAL_STRING_LENGTH];
    FILE *fp = NULL;
    short n;

   // Fortran strings are not necessarily NULL terminated so copy and then null
   // terminate the new string.  Add a line feeds to string as well.

    if ( *length < LOCAL_STRING_LENGTH - 2 )
    {
        memcpy(buf, string, *length);
        buf[(*length)] = '\n';
        buf[(*length) + 1] = 0;

    } else {

        memcpy(buf, string, LOCAL_STRING_LENGTH - 2);
        buf[LOCAL_STRING_LENGTH - 2] = '\n';
        buf[LOCAL_STRING_LENGTH - 1] = 0;
    }
    
    // Put the message into the appropriate message buffer

    // MESSAGE_ONE   goes to the scrolling status
    // MESSAGE_TWO   goes to the Current operation area of the MOPAC Status dialog
    // MESSAGE_THREE goes to the Current calculation area of the MOPAC Status dialog
    // MESSAGE_FOUR  goes to the scrolling status AND signals the application request
    //               server that the output file is to be processed

    switch (*number)
    {
        case MESSAGE_ONE:

            for ( n = 0 ; n < MESSAGE_RETRIES; n++ )
                if ( cul_sendCPMessageWait(&msgChannel3, buf, 0) == CUL_MSGS_SENT )
                    break;

            break;

        case MESSAGE_TWO:

            // This is the least critical message.  OK to drop on the floor. 
            // NOTE!!! Only send at most one message per second.

            current_clock = time(NULL);

            if ( difftime(current_clock,time_since_message) >= 1.0 )
            {
                // More than a second has elapsed.
                cul_sendCPMessage(&msgChannel2, buf);
                time_since_message = time(NULL);
            }

            break;

        case MESSAGE_THREE:

            for ( n = 0 ; n < MESSAGE_RETRIES; n++ )
                if ( cul_sendCPMessageWait(&msgChannel1, buf, 0) == CUL_MSGS_SENT )
                    break;

            break;

        case MESSAGE_FOUR:

            // This is a critical message.

            // Wait for the server to set the 'ready' flag to be sure that the
            // server will see the message.

            // Put the message into the scrolling status channel.

            cul_sendCPMessageWait(&msgChannel3, buf, 0);

            // Make the message string available to Do_Processing.

            fp = fopen("ProcessBufferFile", "w");

            if ( fp != NULL )
            {
                fprintf(fp, "%s", buf);
                fclose(fp);
                fp = NULL;
            }

            ce_mopac_send_process_flag();

            // Wait for the server to indicate that it is ready and then set the
            // client flag to 'ready'.

            ce_mopac_wait_for_continue();

            break;
    }
}


void __stdcall GETCACHEVERSION(char *string, unsigned int length)
{
    strncpy(string, "Version:1.4", length-1);
    string[length-1] = '\0';
}


long shutdownc(long *i)
{  
    return (ce_mopac_shutdown());
}

void fortranexitc(long *m)
{
    ce_mopac_exit(*m);
}

void touchm(void)
{
}
