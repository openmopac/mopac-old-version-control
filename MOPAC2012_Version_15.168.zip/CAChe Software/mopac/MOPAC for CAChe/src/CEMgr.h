/*
 * CEMgr.h -- public include file
 */

#ifndef _CEMGR_H_
#define _CEMGR_H_

#include <ChannelMgr.h>
#include <UnixEventMgr.h>
#include <ServerStepQueue.h>
#include <ccl_Event.h>
#include <ccl_Msgs.h>
 
enum cem_State {
    CEM_STATE_CREATING,
    CEM_STATE_INITING,
    CEM_STATE_RUNNING,
    CEM_STATE_DONE,
    CEM_STATE_TERMINATED
};

enum cem_Err {
    cem_Err_None = 0,
    cem_Err_Operation_Failed,
    cem_Err_LogMgr_Creation_Failed,
    cem_Err_CE_Control_Creation_Failed,
    cem_Err_CE_Creation_Failed,
    cem_Err_CE_Connection_Creation_Failed,
    cem_Err_CE_Recv_Creation_Failed,
    cem_Err_CE_Recv_Comm_Failure,
    cem_Err_Main_Creation_Failed,
    cem_Err_DoWaitForStartSignal_Failed,
    cem_Err_CM_Recv_Creation_Failed,
    cem_Err_Send_Status_Failed,
    cem_Err_BuildOutputFileList_Failed,
    cem_Err_GetApplRunStatusSize_Failed,
    cem_Err_PostProcessing_Failed,
    cem_Err_PreProcessingInput_Failed,
    cem_Err_Do_Proc_Creation_Failed,
    cem_Err_DoProcessing_Failed,
    cem_Err_Handle_PreStart_Failed,
    cem_Err_Disconnect_Msg,
    cem_Err_Bad_Msg,
    cem_Err_Dummy
};

enum cem_Boolean {
    cem_Boolean_False = 0,
    cem_Boolean_True,
    cem_Boolean_Err
};

enum cem_DebugFlags {
    CEM_MAIN_DEBUG = (1 << 0),
    CEM_CHM_DEBUG = (1 << 1),
    CEM_UEM_DEBUG = (1 << 2),
};

#if defined(DBPRINTF)
    #undef DBPRINTF
#endif
#if defined(_DEBUG)
    #define DBPRINTF(xargs) (cem_DebugPrintf xargs )
#else
    #define DBPRINTF(xargs) ((void) 0)
#endif

#if defined(_WIN32)
    const char CEM_PATH_SEPARATOR = '\\';
    const char* const CEM_CE_SUFFIX = ".exe";
    typedef HANDLE CEM_PORTHANDLE;
    typedef HANDLE cem_Thread;
    typedef unsigned cem_ThreadID;
    typedef HANDLE cem_Process;
    typedef DWORD cem_ProcessID;
    typedef HANDLE cem_StartSignal;
#elif defined(unix)
    const char CEM_PATH_SEPARATOR = '/';
    const char* const CEM_CE_SUFFIX = "";
    typedef int CEM_PORTHANDLE;
    typedef int cem_Thread;
    typedef int cem_ThreadID;
    typedef int cem_Process;
    typedef int cem_ProcessID;
    typedef int cem_StartSignal;
#else
#error "No platform selected."
#endif

const int CEM_FILE_NAME_SIZE = 256;
const int CEM_WAIT_FOR_CE_EXIT_TIMEOUT = 20*1000;
const double CEM_STATUS_MSG_FLUSH_DELAY = 1.0;

class CEMgr;

// cem_Main is an active object reponsible for the following actions:
//        Start the CM_Recv object
//        Preprocess the input and settings
//        Get the CE Pathname
//        Get the system resources needed to run the CE
//        Ask the CM if system resources are available
//        Start the CE_Control object
//        Wait for CE_Control to finish
//        Postprocess output files
//        Build the output file list
//        Send the CEM and CE completion status and output file list to the CM

typedef cem_State cem_Main_State;

class CEM_Main {

public:
    enum MAIN_EVTS {
        MAIN_OSTERM = 0,
        MAIN_CMRECVEXIT,
        MAIN_CECONTEXIT,
        MAIN_NUMBER_OF_EVTS
    };

    CEMgr *m_cemgr;
    cem_Err m_status;
    cem_Main_State  m_state;
    cem_Thread m_thread;
    cem_ThreadID m_threadID;
    ccl_Event *m_exit_evt;

    ccl_Event *m_MainEvents[MAIN_NUMBER_OF_EVTS];

    CEM_Main(void);
    ~CEM_Main(void);
    cem_Boolean Init(CEMgr *cemgr);
    void Term(void);
    void Run(void);
    void Exit(void);

private:

    // customizable functions
    cem_Boolean GetCEApplPathName(void);
    cem_Boolean GetCERequiredResources(void);
};

typedef cem_State cem_Do_Proc_State;

class CEM_Do_Proc {
public:
    CEMgr *m_cemgr;
    cem_Err m_status;
    cem_Do_Proc_State m_state;
    cem_Thread m_thread;
    cem_ThreadID m_threadID;
    ccl_Event *m_exit_evt;

    CEM_Do_Proc(void);
    ~CEM_Do_Proc(void);
    cem_Boolean Init(CEMgr *cemgr);
    void Term(void);
    void Run(void);
    void Exit(void);
};

// cem_CE_Recv is an active object responsible for the following actions:
//        Wait for messages from CE
//        Process Messages
//        If status message then send status message to CM
//        If do_proc message then set the do_proc_evt

typedef cem_State cem_CE_Recv_State;

class CEM_CE_Recv {
public:
    CEMgr *m_cemgr;
    cem_Err m_status;
    cem_CE_Recv_State m_state;
    cem_Thread m_thread;
    cem_ThreadID m_threadID;
    ccl_Event *m_exit_evt;

    ccl_MsgConnection *m_msg_connection;

    CEM_CE_Recv(void);
    ~CEM_CE_Recv(void);
    cem_Boolean Init(CEMgr *cemgr, ccl_MsgConnection *msgConnection);
    void Term(void);
    void Run(void);
    void Exit(void);
    ccl_Msg *GetNextMessage(void);
    cem_Err DispatchMessage(ccl_Msg *msg);
    void Disconnect(void);
};

// CEM_CE_Control is an active object responsibile for the following actions:

typedef cem_State cem_CE_Cont_State;
typedef DWORD  cem_CE_Status;

const cem_CE_Status CEM_CE_STATUS_INVALID = ~0;

class CEM_CE_Control {
public:

    enum CE_CONT_EVTS {
        CE_CONT_OSTERM = 0,
        CE_CONT_KILLAPP,
        CE_CONT_STOPAPP,
        CE_CONT_CEEXIT,
        CE_CONT_RECVEXIT,
        CE_CONT_STARTAPP,
        CE_CONT_DOPROC,
        CE_CONT_DOPROCEXIT,
        CE_CONT_NUMBER_OF_EVTS,
    };

    // member variables
    CEMgr *m_cemgr;
    cem_Err m_status;
    cem_CE_Cont_State m_state;
    cem_Thread m_thread;
    cem_ThreadID m_threadID;
    cem_Thread m_threadProcWatch;
    cem_ThreadID m_threadIDProcWatch;
    ccl_Event *m_exit_evt;
    
    ccl_Event *m_CE_Cont_Evts[CE_CONT_NUMBER_OF_EVTS];

    ccl_MsgConnection *m_ce_connection;

    CEM_Do_Proc *m_do_proc;
    CEM_CE_Recv *m_ce_recv;
    cem_Process m_ce_process;
    cem_CE_Status m_ce_status;
    char *m_cmdline;
    char *m_ce_applPathName;

    // member functions
    CEM_CE_Control(void);
    ~CEM_CE_Control(void);
    cem_Boolean Init(CEMgr *cemgr);
    void Term(void);
    void DoProc(void);
    void Run(void);
    void Exit(void);

private:
    cem_Boolean StartCE(void);
    cem_Boolean Send_CE_Continue(void);
    cem_Boolean Send_CE_Stop(void);
    cem_Boolean KillCE(void);
};

typedef cem_State cem_CM_Recv_State;

class CEM_CM_Recv {
public:
    CEMgr *m_cemgr;
    cem_Err m_status;
    cem_CM_Recv_State m_state;
    cem_Thread m_thread;
    cem_ThreadID m_threadID;
     ccl_Event *m_exit_evt;
    uem_UnixEventMgr *m_uem;
    chm_Channel *m_rchan;
    chm_Channel *m_schan;

    CEM_CM_Recv(void);
    ~CEM_CM_Recv(void);
    cem_Boolean Init(CEMgr *cemgr);
    void Term(void);
    void Run(CEM_CM_Recv *cm_recv);
    void Exit(void);
};


class CEMgr {
public:
    cem_Boolean m_standalone;
    cem_Process m_process;
    cem_ProcessID m_processID;
    cem_Thread m_thread;
    cem_ThreadID m_threadID;
    cem_Boolean m_debugFlag;
    cem_State m_state;
    cem_Err m_status;
    cem_CE_Status m_ce_status;

    char *m_copyright;
    char *m_version;

    // Variables passed in on the command line
    char *m_programName;
    chm_NetAddr m_rPeerAddr;
    chm_NetAddr m_sPeerAddr;
    chm_Boolean m_chmDebug;
    uem_Boolean m_uemDebug;
    cem_StartSignal m_startSignal; // signals CEMgr that CalcMgr is waiting for connection

    int m_argc;
    char **m_argv;
    HWND m_hWnd;

    // Variables set or created by cm_recv::HandlePreStartApp function
    ssq_FileTransferList *m_inputFileList;
    void *m_settings;
    ssq_StepID m_serverStepID;
    char *m_serverName;
    char *m_machineName;

    ssq_FileTransferList *m_outputFileList;
    ssq_TempOutputFileDest *m_outputFilesDest;
    cem_Boolean m_returnFilesFlag;

    // Initialized in the cem_main::Init function
    FILE *m_logFile;
    char *m_logFileBaseName;
    char m_logFileName[CEM_FILE_NAME_SIZE];
    
    // If running standalone then the status events are sent to the status file.
    FILE *m_statusFile;
    char m_statusFileName[CEM_FILE_NAME_SIZE];
    
    // compute engine program name and cmdline strings
    char m_ce_applPathName[CEM_FILE_NAME_SIZE];
    char *m_ce_cmdline;
    char *m_ComputeEngineSubdirectory;
    char *m_ComputeEngineBaseName;

    // compute engine resources
    long m_disk;
    long m_paging;
    long m_memory;

    // active objects
    CEM_Main *m_main;
    CEM_CE_Control *m_ce_control;
    CEM_CM_Recv *m_cm_recv;

    // events objects
    ccl_Event *m_os_term_evt;
    ccl_Event *m_cm_recv_exit_evt;
    ccl_Event *m_ce_control_exit_evt;
    ccl_Event *m_ce_recv_exit_evt;
    ccl_Event *m_do_proc_exit_evt;
    ccl_Event *m_do_proc_evt;
    ccl_Event *m_killapp_evt;
    ccl_Event *m_stopapp_evt;
    ccl_Event *m_startapp_evt;
    ccl_Event *m_ce_exit_evt;
             
    // member functions
    CEMgr(void);
    ~CEMgr(void);

    cem_Boolean Init(int argc, char **argv, HWND hWnd);
    void Term(void);
    void DebugPrintf(char *fmt, ...);
    cem_Boolean DoWaitForStartSignal();
    
    cem_Boolean BuildCECmdLine(void);
    void ResetLogFile(void);
    cem_Boolean SendFinalStatusToCM(void);
    cem_Boolean SendCEStatusMsgToCM(int channelID, const char *msg);
    cem_Boolean FlushCEStatusMsgToCM(int channelID);
    cem_Err Handle_PreStartApplEvent( ssq_StepID   serverStepID,
                                      char    *evtServerName,
                                      char    *evtMachineName,
                                      const char *const evtApplPath,
                                      ssq_FileTransferListPtr inputFiles,
                                      ssq_TempOutputFileDestPtr outputFileDest );

    cem_Boolean BuildOutputFileListWrapper(void);

    virtual cem_Boolean AllocateSettings(void);
    virtual cem_Boolean GetCEApplPathName(const char* const applName);
    virtual cem_Boolean GetCERequiredResources(void);
    virtual cem_Boolean ProcessSettings(void);
    virtual cem_Boolean PreProcessInput(void);
    virtual cem_Boolean PostProcessing(void);
    virtual cem_Boolean BuildOutputFileList(void);
    virtual cem_Boolean AddCustomCommandLineOptions(char *cmdline);
    virtual cem_Err Do_Proc(void);
    virtual void PreProcessStatusMsg(int channelID, const char *msg);

    /* windows message handlers */
    virtual LRESULT WmPaint(HWND hWnd, UINT message, WPARAM uParam, LPARAM lParam);
    virtual LRESULT WmCopyData(HWND hWnd, UINT message, WPARAM uParam, LPARAM lParam);

private:
    cem_Boolean SendCEStatusMsgToCM1(int channelID, const char *msg);
    ccl_Boolean AddInputFile(unsigned long cftype, char *fileName);
};

typedef CEMgr* CEMgrPtr;

// Function prototypes

void cem_DebugPrintf(char *fmt, ...);
void cem_SetThreadTag(char* tag);

BOOL cem_InitApplication( HINSTANCE hInstance,
                          const char* szAppName,
                          int iconId );

BOOL cem_InitInstance( HINSTANCE hInstance,
                       int nCmdShow,
                       const char* szAppName,
                       const char* szTitle,
                       CEMgr* ce_mgr,
                       HWND* hWnd );

int cem_WinMain( HINSTANCE hInstance,
                 HINSTANCE hPrevInstance,
                 LPSTR lpCmdLine,
                 int nCmdShow );

#endif
