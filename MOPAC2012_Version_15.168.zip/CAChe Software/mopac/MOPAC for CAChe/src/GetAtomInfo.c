#include <compat.h>
#include <csu.h>

extern void 	alert_user_watch(char *errs);

int GetAtomInfo(
	int			NumberOfAtoms,
	MolStruct	*molStruct,
	double		*coordinates,
	short		*AtomicNumbers,
	double		*AtomMasses
)
{
	static	char functionName[] = "GetAtomInfo";
	char	errs[256]; 
	char	(*atsymbol)[2] = NULL;
	ObjclsID offset;
	short	*atomic_number = NULL;
	CelErr	rtn_code;
	int		return_code = 0;
	long	i, j,
			NAtom,
			numberWithoutDummies = 0;
	double 	*tmpcoord = NULL;
	double	massTable[] = {1.00790,  4.00260,  6.94000,  9.01218,
				10.81000, 12.01100, 14.00670, 15.99940, 18.99840,
     			20.17900, 22.98977, 24.30500, 26.98154, 28.08550,
				30.97376, 32.06000, 35.45300, 39.94800, 39.09830,
				40.08000, 44.95590, 47.90000, 50.94150, 51.99600,
				54.93800, 55.84700, 58.93320, 58.71000, 63.54600,
				65.38000, 69.73500, 72.59000, 74.92160, 78.96000,
				79.90400, 83.80000, 85.46780, 87.62000, 88.90590,
				91.22000, 92.90640, 95.94000, 98.90620, 101.0700,
				102.9055, 106.4000, 107.8680, 112.4100, 114.8200,
				118.6900, 121.7500, 127.6000, 126.9045, 131.3000,
				132.9054, 137.3300, 138.9055, 140.1150, 140.9077,
				144.2400, 145.0000, 150.3600, 151.9650, 157.2300,
				158.9253, 162.5000, 164.9303, 167.2600, 168.9342,
				173.0400, 174.9670, 178.4900, 180.9479, 183.8500, 
				186.2070, 190.2000, 192.2200, 195.0900, 196.9665, 
				200.5900, 204.3700, 207.2000, 208.9804, 209.0000,
				210.0000, 222.0000, 223.0000, 226.0000, 227.0000, 
				232.0381, 231.0000, 238.0289, 237.0000, 244.0000, 
				243.0000, 247.0000, 251.0000, 252.0000, 257.0000, 
				258.0000, 259.0000, 1.0079,  
				100000000., 100000000., 100000000., 100000000., 0.0};
	
	if (csu_ExistsObjclsID (molStruct, AtomID, &offset))
		NAtom = (long) ((GetPtr(molStruct->objclsH) + offset)->num_objs);
	else {
		sprintf(errs, "%s: Unable to locate AtomID index.",
			functionName);
		return_code = -1;
		alert_user_watch(errs);
		goto return_now;
	}

	if ((rtn_code = csu_GrabVal (molStruct, AtomID, AnumID, (char **)&atomic_number)) < 0) {
		sprintf(errs,"%s: csu_GrabVal Anum, errno %d", functionName, rtn_code);
		return_code = -1;
		alert_user_watch(errs);
		goto return_now;
	}

	if ((rtn_code = csu_GrabVal (molStruct, AtomID, SymID, (char **)&atsymbol)) < 0) {
 		sprintf(errs,"%s: csu_GrabVal Sym, errno %d", functionName, rtn_code);
		alert_user_watch(errs);
		goto return_now;
	}

	if ((rtn_code = csu_GrabVal (molStruct, AtomID, XYZID, (char **)&(tmpcoord))) < 0) {
		return_code = -1;
 		sprintf(errs,"%s: csu_GrabVal XYZ, errno %d", functionName, rtn_code);
		alert_user_watch(errs);
		goto return_now;
	}
      
	for (i = 0; i < NAtom; i++) {
		if (atsymbol[i] != "Fm") {

			AtomMasses[numberWithoutDummies] = massTable[atomic_number[i] - 1];

			AtomicNumbers[numberWithoutDummies] = atomic_number[i];

			for (j = 0; j < 3; j++) 
				coordinates[numberWithoutDummies*3 + j] = tmpcoord[i*3 + j];

			numberWithoutDummies++;
			if (numberWithoutDummies > NumberOfAtoms) {
				return_code = -1;
				sprintf(errs,"%s: number of atoms %d larger than expected %d", 
					functionName, numberWithoutDummies, NumberOfAtoms);
				alert_user_watch(errs);
				goto return_now;
			}
		}
	}

return_now:
	return(return_code);
} /* GetAtomInfo */

