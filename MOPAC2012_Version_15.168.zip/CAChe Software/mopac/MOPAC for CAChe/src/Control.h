/* Values for input coordinate types in detailsGeoType */
#define	INTERNAL_COORD	1
#define	CARTESIAN_COORD	2

/* Values for geometry search type */
#define	SRCHTYPE_RXN	1
#define	SRCHTYPE_GRID	2

/* Calculation types */
enum calcType {
	CALCTYPE_OPTGEOM=1,
	CALCTYPE_CHECKINP,
	CALCTYPE_SCF,
	CALCTYPE_CI,          // this one is no longer supported! plonkaw june2000
	CALCTYPE_VIBSPEC,
	CALCTYPE_RIGIDSRCH,
	CALCTYPE_OPTSRCH,
	CALCTYPE_SADDLE,
	CALCTYPE_MINGRAD,
	CALCTYPE_IRC,
	CALCTYPE_DRC,
	CALCTYPE_CROSS, //plonkaw june2000
	CALCTYPE_DUMMY
};

/* Values for the spin multiplicity */
enum spinMult {
	SPINMULT_DEFAULT=0, //plonkaw july2000
	SPINMULT_SINGLET,
	SPINMULT_DOUBLET,
	SPINMULT_TRIPLET,
	SPINMULT_TRIPLETUHF,
	SPINMULT_EXCSINGLET,
	SPINMULT_QUARTET,
	SPINMULT_QUINTET,
	SPINMULT_SEXTET,
	SPINMULT_BIRADICAL,
	SPINMULT_UHF,
	SPINMULT_SEPTET, //plonkaw june2000
	SPINMULT_OCTET,//plonkaw june2000
	SPINMULT_NONET,//plonkaw june2000
	SPINMULT_DUMMY
};

/* Values for the MOPAC Hamiltonian type */
enum paramType {
	PARAM_AM1=1,
	PARAM_MNDO,
	PARAM_MINDO3,
	PARAM_PM3,
	PARAM_MNDOd, //plonkaw june2000
	PARAM_PM5, //plonkaw may 2001
	PARAM_DUMMY
};

/* Values for configuration-interaction level */
enum ConfIntLev {
	CILVL_DEFAULT=1,
	CILVL_1,
	CILVL_2,
	CILVL_3,
	CILVL_4,
	CILVL_5,
	CILVL_6,
	CILVL_7,
	CILVL_8,
	CILVL_9,
	CILVL_10,
	CILVL_DUMMY
};

// plonkaw
enum ConfIntType {
	CITYPE_NONE=1,
	CITYPE_DEFAULT=2,
	CITYPE_S,
	CITYPE_SD,
	CITYPE_SDT,
	CITYPE_PECI,
	CITYPE_DUMMY
};

/* Values for SCF converger in scfConverger */
enum scfConv {
	SCF_DEFAULT=1,
	SCF_PULAY,
	SCF_SHIFT,
	SCF_DUMMY
};

/* Values for rotational symmetry type in THERMO calculation */
enum rotSym {
	ROTSYM_C1=1, ROTSYM_C2, ROTSYM_C3, ROTSYM_C4, 
	ROTSYM_C6, ROTSYM_D2, ROTSYM_D3, ROTSYM_D4, 
	ROTSYM_D6, ROTSYM_S6, ROTSYM_CinfV, ROTSYM_DinfH, 
	ROTSYM_T, ROTSYM_Oh,
	ROTSYM_DUMMY
};

/* Values for Optimize Geometry method */
enum geoMethod {
	GEOMETH_BFGS=1,
	GEOMETH_NLLSQ,
	GEOMETH_DFP,
	GEOMETH_SIGMA,
	GEOMETH_EF,
	GEOMETH_DUMMY
};

/* Values for Minimize Gradient method */
enum minGradMethod {
	MINGRADMETH_NLLSQ=1,
	MINGRADMETH_SIGMA,
	MINGRADMETH_EF,
	MINGRADMETH_DUMMY
};

/* Units for time limits */
enum timeLimUnits {
	TIMELIM_SEC=1,
	TIMELIM_MIN,
	TIMELIM_HOUR,
	TIMELIM_DAY,
	TIMELIM_DUMMY
};


typedef struct  {
	double		dummy;				/* insure double word alignment */
	char		title[256];
	enum calcType calculate; /* Type of calculation */
	enum spinMult multiplicity; /* Spin multiplicity of molecule */
	enum paramType parameters; /* MOPAC Hamiltonian type */
	enum ConfIntLev CIlevel; /* Configuration-interaction level */
	enum ConfIntType CItype; /* Configuration-interaction type plonkaw june2000 */
	enum geoMethod geometrySearch; /* Method for Optimize geometry calculations */
	enum minGradMethod minimizeGradient; /* Method for Minimize gradient calculations */
	enum rotSym rotationalSymmetry;	/* Rotational symmetry type for THERMO calculations */
	enum scfConv scfConverger;	/* SCF converger method */
	enum timeLimUnits timeLimitUnits; /* Units for time limit */
	short maxSCFiterations;
	union productMol_loc {
		char UI_name[256];
		char AM_name[256];
	} productMolecule;
	char		extraKeyWords[256];
	long		timeLimit;
	short		saveHOMO;
	short		saveLUMO;
	char		temperature[32];
	char		cosmoSolvent[32];	/* COSMO solvent name */
	short		ircMode;
	short		drcIrcMode;
	float		addKEforIRC;
	float		addKEforDRC;
	float		halfLifeForDRC;
	float		hPrioStep;
	float		tPrioStep;
	float		xPrioStep;	
								
	Boolean		controlRestart;		/* Run calculation as a restart? */

	Boolean		detailsMMOK;		/* Mechanics correction for peptide linkages */
	Boolean		detailsEnergyPart;	/* energy partitioned for analysis */
	Boolean		detailsESR;			/* print unpaired spin density matrix */
	Boolean		detailsLocalize;	/* localize molecular orbitals */
	Boolean		detailsMulliken;	/* perform Mulliken population analysis */
	Boolean 	detailsPI;			/* analyze pi and sigma density matrix contributions */
	Boolean		detailsPolar;		/* calculate polarizability */
	Boolean		detailsThermo;		/* calculate thermodynamic properties */
	Boolean		detailsBondOrder;	/* print bond order matrix */
	Boolean		detailsDensity;		/* print density matrix */
	Boolean		detailsFock;		/* print Fock matrix */
	Boolean		detailsGradients;	/* calculate gradients for 1SCF */
	Boolean		detailsInterADist;	/* print interatomic distances */
	Boolean		detailsXYZCoord;	/* print Cartesian coordinates */
	Boolean		detailsSpin;		/* print spin difference matrix */
	Boolean		detailsVectors;		/* print eigenvectors */
	Boolean		detailsPrecise;		/* increase calculational precision */
	Boolean		detailsLarge;		/* print additional information for IRC or DRC */
	Boolean		detailsAnalytGrad;	/* calculate analytical gradients */
	Boolean		detailsExternParam;	/* read parameters from MOPAC_Params */
	Boolean		detailsUseXYZ;		/* use Cartesian coordinates within calculation */
	Boolean		detailsDIIS;		/* use geometry optimization DIIS - not recommended */
	Boolean		detailsKeepOrient;	/* add dummy atoms to maintain orientation; was UseDummy */

	Boolean		MOZYME;				/* plonkaw june2000*/

	short		detailsGeoType;		/* type of atom coordinate input: 
										INTERNAL_COORD or CARTESIAN_COORD */

	Boolean		controlUseCosmo;	/* apply COSMO solvent model */
	double		cosmoDielectric;	/* COSMO dielectric constant */
	double		cosmoRadius;		/* COSMO solvent radius */

	Boolean 	accessoryInput;		/* return MOPAC Input file */
	Boolean 	accessoryOutput;	/* return MOPAC Output file */
	Boolean 	accessoryRestart;	/* return MOPAC Restart file */
	Boolean		accessoryArchive;	/* return MOPAC Archive file */
	Boolean		accessoryGraphics;	/* return MOPAC Graphics file */
	Boolean		accessoryDensity;	/* return MOPAC Density file */
	Boolean		accessoryIsotope;	/* save force matrix to MOPAC Restart file */
	Boolean		accessoryLog;		/* save scrolling status to MOPAC Log file */
	
	Boolean		DRCdampKinetic;		/* damp kinetic energy in DRC calculation */
	Boolean		DRChPrio;			/* print based on energy change in DRC */
	Boolean		DRCtPrio;			/* print based on time change in DRC */
	Boolean		DRCxPrio;			/* print based on geometry change in DRC */
	
	short		searchType;			/* type of geometry search:
										SRCHTYPE_RXN or SRCHTYPE_GRID */
	short		molecularCharge;	/* Placed here so that Show Settings has
										the information */
	short       CIroot;             /*plonkaw june2000*/
 } MOPACControl;
