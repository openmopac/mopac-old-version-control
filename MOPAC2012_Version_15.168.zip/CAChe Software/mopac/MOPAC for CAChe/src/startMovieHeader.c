#include <compat.h>
#include <CACheFileLibAD.h>
#include <cul.h>
#include <ZINDODriver.h>
#include <CACheFileTypes.h>

extern FILE *movie_fp;
extern char mv_name[32];

int startMovieHeader(MolStruct *ms,char *suffix,long fileType)
{
	int i;

	/* write out ASCII header for movie file */
	if ((i = strlen(ms->ms_name)) > 27) i = 27;
	strncpy(mv_name, ms->ms_name, i);
	strcpy(mv_name+i, suffix);

	/* Version numbering the molstruct causes problems with creating
	   the .map file.  Since we have already saved the updated
	   molecule structure file, it is ok to destroy any previously
	   created .map files. */
	remove(mv_name);
	
	if (csu_SaveMolstructFile(ms, mv_name, "ZINDO", fileType, CFT_VISUALIZER) < 0)
		return -1;
	/* Decrease the molstruct version number so that it agrees with the
	one in the molecule file - as opposed to the .map file.  This is necessary
	so that successive executions of ZINDO88k which write a map file will not
	create new versions of the molecule file */
	ms->versionNo--;
	if ((movie_fp = cfl_MacFOpen(mv_name, "a+", CFT_VISUALIZER, fileType)) == NULL)
		return -1;

	/* divide between molstruct and movie */
	fprintf(movie_fp, "MovieFrames\n");

	/* introduce type of movie file */
	fprintf(movie_fp, "MovieType 1\n"); /* full array, regular intervals */

	if (CUL_INTFMT != CUL_INTFMT_BIGENDIEN || 
		CUL_FPFMT != CUL_FPFMT_IEEE754BIGENDIEN) {
		/* indicate the byte order and floating point format */
		fprintf(movie_fp, "numericFormat %d %d\n", CUL_INTFMT, CUL_FPFMT);
	}

	/* introduce section for driving variables */
	fprintf(movie_fp, "Axes\n");

	return 0;
}
