#include <compat.h>
#include <CACheFileLib.h>
#include <ZINDODriver.h>

Boolean isFileZINDOinput(char *inputFile, char *titleMol)
/* 
 * titleMol should be at least 32 characters long.
 *
 * if titleMol is NULL, then don't get the title.
 */
{
	FILE *stream = NULL;
	char *cptr;
	char buff[32], aString[256], bString[256];
	int i;
	
	if (titleMol)
		*titleMol = 0;

	if ((stream = fopen(inputFile, "r")) == NULL)
		return FALSE;

	/* Verify that this is a ZINDO Input file */
	cfl_fgets(buff, 10, stream);
	if (strncmp(" $TITLEI", buff, 8) != 0) {
		fclose(stream);
		return (FALSE);
	}

	/* Search for the "ONAME =" string */
	for (;;) {
		if (cfl_fgets(aString, sizeof(aString), stream) == 0) {
			fclose(stream);
			return (FALSE);
		}
		if ((cptr = strstr(aString, "ONAME")) != NULL) {
			cptr += 5; /* skip past ONAME */
			break;
		}
	}

	if (titleMol) {
	
		buff[0] = 0;
		if ((sscanf(cptr, "%s", bString) == 1) &&
			bString[0] && (strlen(bString) <= 31)) {
			strcpy(buff, bString);
			buff[31] = 0;
			if (buff[0] == '=') {  /* is there an = character? */
				/* Have an = character between ONAME and the file name */
				cptr = strstr(cptr, "="); /* find the = */
				cptr++; /* move past the = to scan for the filename */
				buff[0] = 0;
				if ((sscanf(cptr, "%s", bString) == 1) &&
					bString[0] && (strlen(bString) <= 31)) {
					strcpy(buff, bString);
					buff[31] = 0;
				}
			}
		}
	
		for (i=0; i < 31; i++) {
			if (buff[i] == ',' || buff[i] == '\n' || buff[i] == ' ')
				break;
			*titleMol++ = buff[i]; 
		}
		*titleMol = 0;
	}
	fclose(stream);
	
	return (TRUE);
}

Boolean titleFromZINDOinput(char *inputFile, char *title)
/*
 * Get the title line from a ZINDO Input file.
 *
 * title should be at least 256 characters long.
 *
 * if title is NULL, then don't get the title.
 */
{
	FILE *stream = NULL;
	char aString[256];

	if (title)
		*title = 0;
	else
		return FALSE;

	if ((stream = fopen(inputFile, "r")) == NULL) 
		return FALSE;

	/* Verify that this is a ZINDO Input file */
	cfl_fgets(aString, 9, stream);
	if (strncmp(" $TITLEI", aString, 8) != 0) {
		fclose(stream);
		return (FALSE);
	}

	/* Skip to the end of the line */
	if (cfl_fgets(aString, sizeof(aString), stream) == 0) {
		fclose(stream);
		return (FALSE);
	}

	/* The next line is the title */
	if (cfl_fgets(aString, sizeof(aString), stream) == 0) {
		fclose(stream);
		return (FALSE);
	}
	aString[255] = 0;

	strcpy(title, aString);


	fclose(stream);
	return (TRUE);
}

Boolean isZINDOInputRestart(char *inputFile)
/*
 * Decide whether a file that purports to be a ZINDO Input is a restart
 */
{
	FILE *stream = NULL;
	char buff[256];
	char *cpvec;
	size_t i;
	
	if (!isFileZINDOinput(inputFile, NULL))
		return (FALSE);

	/* look for the restart indicator */
	if ((stream = fopen(inputFile, "r")) == NULL) 
		return (FALSE);

	while (cfl_fgets(buff, 256, stream) != NULL) {
		if (strstr(buff, " $CONTRL") != NULL)
			break; /* found $CONTRL block */
	}

	while (cfl_fgets(buff, 256, stream) != NULL) {
		if (strstr(buff, " $END"))
			break; /* VEC not in $CONTRL section */

		if ((cpvec = strstr(buff, " VEC")) != NULL) {
			cpvec += 4; /* advance past VEC */
			for (i = 0; i < strlen(cpvec); i++) {
				if (isalpha(*cpvec)) {
					/* Didn't find VEC in the $CONTRL block */
					fclose(stream);
					return (FALSE);
				}
				else if (isdigit(*cpvec)) {
					if (cpvec[0] == '8') {
						fclose(stream);
						return (TRUE);
					} else if (cpvec[0] == '1' && cpvec[1] == '0') {
						fclose(stream);
						return (TRUE);
					} else {
						/* Value of VEC is not 8 or 10 */
						fclose(stream);
						return (FALSE);
					}
				}
				cpvec++;
			}
		} /* found VEC */
	} /* getting lines from ZINDO Input */
	fclose(stream);
	return (FALSE);
}

int countAtomsInInput(
FILE *stream, 
int *num_atoms, 
int *num_bfn, 
int *num_ci
)
/*
 * Count the number of atoms and basis functions in a ZINDO Input
 */
{
	char 	buff[256];
	char	*cp, *cp2;
	int 	num_0, num_1, num_4, num_9, num_16, num_tmp, num_ci_tmp;
	Boolean trouble = true, have_NAT = false, have_DYNAL = false;
	
	num_0 = num_1 = num_4 = num_9 = num_16 = num_tmp = 0;

	*num_atoms = *num_bfn = *num_ci = 0;

	while (cfl_fgets(buff, 256, stream) != NULL) {
		if (strstr(buff, " $CONTRL") != NULL) {
			trouble = false;
			break; /* found $CONTRL block */
		}
	}
	
	if (trouble) { /* Did not find CONTRL block */
		alert_user("countAtomsInInput: unable to find control block in input.");
		return (-1);
	}

	while (cfl_fgets(buff, 256, stream) != NULL) {
		if (strstr(buff, " $END") != NULL) {

			break; /* end of CONTRL block */

		} else if (strstr(buff, " DYNAL") != NULL) {
		
			have_DYNAL = true;
	
			if ((cp = strstr(buff, "DYNAL")) == NULL) {
				alert_user("countAtomsInInput: DYNAL missing in input file.");
				return (-1);
			}
			
			cp += 5; /* looking for numbers beyond DYNAL */
			
			if ((cp2 = strstr(cp, ")")) != NULL) { /* Have DYNAL(1) form */
				cp2++;
				cp = cp2;
			}
			
			if ((cp2 = strstr(cp, "=")) != NULL) {/* Have DYNAL = form */
				cp2++;
				cp = cp2;
			}
			/* Now pick up number of s, p, d, f atoms */
				
			sscanf(cp,"%d %d %d %d %d %d", &num_0, &num_1, &num_4, &num_9, &num_16, &num_ci_tmp);

		} else if (strstr(buff, " NAT") != NULL) {
		
			have_NAT = true;
	
			if ((cp = strstr(buff, "NAT")) == NULL) {
				alert_user("countAtomsInInput: NAT missing in input file.");
				return (-1);
			}
			
			cp += 3; /* looking for numbers beyond NAT */

			if ((cp2 = strstr(cp, "=")) != NULL) {/* Have NAT = form */
				cp2++;
				cp = cp2;
			}

			/* Now pick up number of atoms */
				
			if (sscanf(cp,"%d", &num_tmp) < 1) {
				alert_user("countAtomsInInput: number of atoms missing in input file.");
				return (-1);
			}

		}
	}
	
	if (have_DYNAL) {
		*num_bfn = num_1 + 4*num_4 + 9*num_9 + 16*num_16;
		*num_ci = num_ci_tmp;
	} else {
		alert_user("countAtomsInInput: DYNAL missing in input file.");
		return (-1);
	}
	
	if (have_NAT)
		*num_atoms = num_tmp;
	else {
		alert_user("countAtomsInInput: NAT missing in input file.");
		return (-1);
	}
	
	return (0);

}
