typedef struct  {
	char		version[32];		/* the date/time of compilation of this version */
	char		datetime[32];		/* the date and time string for the calculation */
	char		servername[32];		/* the server that runs the calculation */
} Appl_Info;
