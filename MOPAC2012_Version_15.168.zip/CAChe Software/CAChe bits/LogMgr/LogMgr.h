/*
 * LogMgr.h
 *
 * The LogMgr allows logging of messages to a file from multiple threads.
 * Messages are prefixed by a thread-specific "tag".
 * Logging may be enabled or disabled.
 * The log file may be rewound when it grows beyond a certain size.
 * Operations are thread-safe.
 *
 * The LogMgr uses the stdio library which is assumed to be thread safe.
 */

#ifndef	__LOG_MGR_H__
#define	__LOG_MGR_H__

#include <stdio.h>

class LogMgr {

public:

	enum State { Disabled, Enabled };
	enum { k_MaxLogSizeDefault = 200000 };

	LogMgr();										// Default constructor
	LogMgr(const char* name);						// Open log file by name
	LogMgr(FILE* fp);								// Use log file by file pointer
	~LogMgr();

	State	GetState();								// Enable/Disable logging
	void	SetState(State state);

	char*	GetTag();				 				// Thread-specific prefix string
	void	SetTag(const char* tag);

	FILE*	GetFile();								// Retrieve file pointer or NULL
	void	SetFile(FILE* fp);						// Set file pointer after default constructor 
	char*	GetFileName();							// Retrieve file name or NULL
 
	long	GetMaxLogSize();						// Size of file at which it is rewound
	void	SetMaxLogSize(long maxLogSize);

	void	Print(const char* fmt, ...);			// fprintf interface
	void	VPrint(const char* fmt, va_list argp);	// vfprintf interface

	void	Flush();								// fflush interface
	void	Rewind(const char* fmt, ...);			// Rewind file if size is more than max

private:
 
 	friend class LogMgrInit;				// Initialization class for the following variables
	static DWORD			g_tls;			// Thread local storage index
	static CRITICAL_SECTION	g_cs;			// Critical section for thread-safe operations

	State	m_state;					// Whether logging is enabled or disabled
	FILE*	m_fp;						// stdio file pointer
	char*	m_fileName;					// Name of log file if constructed with a name
	BOOL	m_shouldClose;				// Whether destructor should close file

	long	m_maxLogSize;				// Size of file at which it is rewound
	long	m_numRewinds;				// Number of times the log file has been rewound

	char*	GetTag1();					// Interfaces to Win32 thread local storage functions
	void	SetTag1(const char* tag);

	void	CriticalBegin();			// Interfaces to Win32 critical sections
	void	CriticalEnd();

};

#endif	__LOG_MGR_H__
