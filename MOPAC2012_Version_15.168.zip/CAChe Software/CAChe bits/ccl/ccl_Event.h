/*
 * ccl_Event.h
 *
 * Declarations for ccl_Events
 * Merlin R. Miller
 * Copyright 1995 CAChe Scientic,
 */

#ifndef	CCL_EVENT_H
#define	CCL_EVENT_H

#include <ccl.h>

typedef long ccl_EventTimeOut;	/* timeout period in milliseconds */
#define CCL_INFINITE_TIMEOUT	INFINITE

enum ccl_EventType {
	CCL_EVENTTYPE_UNDEFINED,
	CCL_EVENTTYPE_MANUAL,
	CCL_EVENTTYPE_AUTO

};

enum ccl_EventWait {
	CCL_EVENTWAIT_FAILED = -2,
	CCL_EVENTWAIT_TIMEDOUT = -1,
	CCL_EVENTWAIT_OBJECT0 = 0
};

class ccl_Event {


	/* ccl_WaitForMultipleEvents needs to get the hEvents for each of
	 * the EventArray elements.
	 */
	friend ccl_EventWait ccl_WaitForMultipleEvents(
		long numOfEvents,	   		// number of ccl_events in the array.
		ccl_Event *EventArray[],	// array of ccl_events
		ccl_Boolean WaitAll,	   	// if true, then wait for all events to be set
		ccl_EventTimeOut timeout); 	// timeout value in milliseconds

	public:
		ccl_Event();
		~ccl_Event();
		ccl_Boolean Init(ccl_EventType etype);
		ccl_Boolean Set();
		ccl_Boolean Reset();
		ccl_EventWait Wait(ccl_EventTimeOut timeout);

	private:
		ccl_EventType	m_Type;
		ccl_Err			m_status;
	#if defined(_WIN32)
		HANDLE			m_hEvent;
	#endif

}; /* ccl_Event */


#endif	/* CCL_EVENT_H */
