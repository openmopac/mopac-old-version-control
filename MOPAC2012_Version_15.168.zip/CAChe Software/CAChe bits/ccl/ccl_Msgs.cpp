/*
** ccl_Msg.cpp
*/

// System includes
#include <windows.h>
#include <stdio.h>

// CAChe includes
#include <SimpleExceptions.h>
#include <LogMgr.h>

#include "ccl.h"
#include "ccl_Msgs.h"

// Local includes

#if defined(DBPRINTF)
	#undef DBPRINTF
#endif
#ifdef _DEBUG
	#define DBPRINTF(xargs)	(DebugPrintf xargs )
#else
	#define DBPRINTF(xargs) ((void) 0)
#endif

#if defined(_WIN32)
#define ccl_MsgPipeHandle HANDLE
#endif

/*
 * ccl_Msg
 */

ccl_Msg::ccl_Msg(unsigned char type, unsigned char flags)
{
	m_type = type;
	m_flags = flags;
}

/*
 * ccl_Msg_Status
 */

ccl_Msg_Status::ccl_Msg_Status(
	unsigned char type,
	unsigned char flags,
	int channelID,
	unsigned long status_len,
	char *status) :
 		ccl_Msg(type,flags),
 		m_channelID(channelID),
 		m_status_len(status_len),
 		m_status(status)
{
}

ccl_Msg_Status::~ccl_Msg_Status()
{
}

/*
 * ccl_MsgPipe
 */

ccl_MsgPipe::ccl_MsgPipe(FILE *logfile)
{ 
	const char *my_name = "ccl_MsgPipe::ccl_MsgPipe";
	m_status = ccl_Err_None;

	m_logFile = logfile;
	m_logMgr = new LogMgr(m_logFile);

	m_readHandle = INVALID_HANDLE_VALUE;
	m_writeHandle = INVALID_HANDLE_VALUE;
	m_bufferSize = 0;	// default buffer size

#if defined(_WIN32)

	m_securityAttributes.nLength = sizeof(SECURITY_ATTRIBUTES);
	m_securityAttributes.lpSecurityDescriptor = NULL;
	m_securityAttributes.bInheritHandle = TRUE;
	
	if (!CreatePipe(&m_readHandle, &m_writeHandle, &m_securityAttributes, m_bufferSize))
		m_status = ccl_Err_Msg_Pipe_Create_Failed;

#endif

	DBPRINTF(("%s: r=%d w=%d\n", my_name, m_readHandle, m_writeHandle));
}

ccl_MsgPipe::ccl_MsgPipe(
	ccl_MsgPipeHandle readHandle,
	ccl_MsgPipeHandle writeHandle,
	FILE *logfile
)
{
	const char *my_name = "ccl_MsgPipe::ccl_MsgPipe";
	m_status = ccl_Err_None;

	m_logFile = logfile;
	m_logMgr = new LogMgr(m_logFile);

	m_readHandle = readHandle;
	m_writeHandle = writeHandle;
	m_bufferSize = 0;

#if defined(_WIN32)

	m_securityAttributes.nLength = sizeof(SECURITY_ATTRIBUTES);
	m_securityAttributes.lpSecurityDescriptor = NULL;
	m_securityAttributes.bInheritHandle = TRUE;

#endif

	DBPRINTF(("%s: r=%d w=%d\n", my_name, m_readHandle, m_writeHandle));
}

ccl_MsgPipe::~ccl_MsgPipe(void)
{
	Disconnect();
	delete m_logMgr;
}

ccl_Boolean ccl_MsgPipe::Valid(void)
{
	return ccl_Boolean(m_status == ccl_Err_None);
}

ccl_Boolean ccl_MsgPipe::Read(unsigned long len, unsigned char *buf)
{
	const char*		my_name = "ccl_MsgPipe::Read";
	unsigned long	len_read;

	if (!ReadFile(m_readHandle, buf, len, &len_read, NULL)) {
		return ccl_Boolean_False;
	}
	if (len_read != len)
		return ccl_Boolean_False;

	return ccl_Boolean_True;
}

ccl_Boolean ccl_MsgPipe::Write(unsigned long len, unsigned char *buf)
{
	unsigned long len_written;

	if (!WriteFile(m_writeHandle, buf, len, &len_written, NULL)) {
		return ccl_Boolean_False;
	}
	if (len_written != len)
		return ccl_Boolean_False;

	return ccl_Boolean_True;

}

void ccl_MsgPipe::DebugPrintf(char *fmt, ...)
{
	va_list argp;

	if (m_logMgr == NULL) return;

	va_start(argp, fmt);
	m_logMgr->VPrint(fmt, argp);
	va_end(argp);
}

void ccl_MsgPipe::Disconnect()
{
	const char*		my_name = "ccl_MsgPipe::Disconnect";

	if (m_readHandle != INVALID_HANDLE_VALUE) {
		CloseHandle(m_readHandle);
		m_readHandle = INVALID_HANDLE_VALUE;
	}
	if (m_writeHandle != INVALID_HANDLE_VALUE) {
		CloseHandle(m_writeHandle);
		m_writeHandle = INVALID_HANDLE_VALUE;
	}
}

/*
 * ccl_MsgChannel
 */

ccl_MsgChannel::ccl_MsgChannel(FILE *logfile)
{
	m_status = ccl_Err_None;

	m_logFile = logfile;
	m_logMgr = new LogMgr(m_logFile);

	// Create data and ack pipes
	SPX_TRY {

		m_data_pipe = new ccl_MsgPipe(m_logFile);
		if (m_data_pipe == NULL || !m_data_pipe->Valid())
			SPX_THROW(err_pipe_creation_failed);

		m_ack_pipe = new ccl_MsgPipe(m_logFile);
		if (m_ack_pipe == NULL || !m_ack_pipe->Valid())
			SPX_THROW(err_pipe_creation_failed);

	}
	SPX_CATCH(err_pipe_creation_failed) {
		m_status = ccl_Err_Msg_Pipe_Create_Failed;
	}
}

ccl_MsgChannel::ccl_MsgChannel(
	ccl_MsgPipeHandle d_r_phandle,
	ccl_MsgPipeHandle d_w_phandle,
	ccl_MsgPipeHandle a_r_phandle,
	ccl_MsgPipeHandle a_w_phandle,
	FILE *logfile
)
{
	m_status = ccl_Err_None;

	m_logFile = logfile;
	m_logMgr = new LogMgr(m_logFile);

	SPX_TRY {

		// use given pipe handles to create the data and ack pipes 
		m_data_pipe = new ccl_MsgPipe(d_r_phandle, d_w_phandle, m_logFile);
		if (m_data_pipe == NULL || !m_data_pipe->Valid())
			SPX_THROW(err_pipe_creation_failed);
  	
  		m_ack_pipe = new ccl_MsgPipe(a_r_phandle, a_w_phandle, m_logFile);
		if (m_ack_pipe == NULL || !m_ack_pipe->Valid())
			SPX_THROW(err_pipe_creation_failed);

	}
	SPX_CATCH(err_pipe_creation_failed) {
		m_status = ccl_Err_Msg_Pipe_Create_Failed;
	}
}

ccl_MsgChannel::~ccl_MsgChannel(void)
{
	delete m_data_pipe;
	m_data_pipe = NULL;

	delete m_ack_pipe;
	m_ack_pipe = NULL;

	delete m_logMgr;
}

void ccl_MsgChannel::DebugPrintf(char *fmt, ...)
{
	va_list argp;

	if (m_logMgr == NULL) return;

	va_start(argp, fmt);
	m_logMgr->VPrint(fmt, argp);
	va_end(argp);
}

ccl_Boolean ccl_MsgChannel::Valid(void)
{
	return ccl_Boolean(m_status == ccl_Err_None);
}

ccl_Boolean ccl_MsgChannel::ReadData(unsigned long len, void *buf)
{
	if (!m_data_pipe->Read(len, (unsigned char *)buf)) {
		m_status = ccl_Err_Msg_Read_Failed;
		return ccl_Boolean_False;
	}
	return ccl_Boolean_True;
}

ccl_Boolean ccl_MsgChannel::WriteData(unsigned long len, void *buf)
{
	if (!m_data_pipe->Write(len, (unsigned char *)buf)) {
		m_status = ccl_Err_Msg_Write_Failed;
		return ccl_Boolean_False;
	}
	return ccl_Boolean_True;
} 

ccl_Boolean ccl_MsgChannel::SendAck()
{
	char *ack = "A";

	if (!m_ack_pipe->Write(1, (unsigned char *)ack)) {
		m_status = ccl_Err_Msg_Send_Ack_Failed;
		return ccl_Boolean_False;
	}
	return ccl_Boolean_True;
}

ccl_Boolean ccl_MsgChannel::WaitForAck()
{
	unsigned char ack;

	if (!m_ack_pipe->Read(1, &ack)) {
		m_status = ccl_Err_Msg_Recv_Ack_Failed;
		return ccl_Boolean_False;
	}
	return ccl_Boolean_True;
}

void ccl_MsgChannel::Disconnect()
{
	if (m_ack_pipe != NULL)
		m_ack_pipe->Disconnect();

	if (m_data_pipe != NULL)
		m_data_pipe->Disconnect();
}

/*
 * ccl_MsgConnection
 */

// This constructor is used by a parent process to create a new connection object.
ccl_MsgConnection::ccl_MsgConnection(FILE *logfile)
{
	const char *my_name = "ccl_MsgConnection::ccl_MsgConnection";

	SPX_TRY {

		m_status = ccl_Err_None;

		m_logFile = logfile;
		m_logMgr = new LogMgr(m_logFile);

		m_recv_channel= new ccl_MsgChannel(m_logFile);
		if (m_recv_channel == NULL || !m_recv_channel->Valid())
			SPX_THROW(err_channel_creation_failed);

		m_send_channel = new ccl_MsgChannel(m_logFile);
		if (m_send_channel == NULL || !m_send_channel->Valid())
			SPX_THROW(err_channel_creation_failed);

	}
	SPX_CATCH(err_channel_creation_failed) {
		m_status = ccl_Err_Msg_Channel_Create_Failed;
	}

	DBPRINTF(("%s: rd=%d,%d ra=%d,%d sd=%d,%d sa=%d,%d\n",my_name,
		m_recv_channel->m_data_pipe->m_readHandle, m_recv_channel->m_data_pipe->m_writeHandle,
		m_recv_channel->m_ack_pipe->m_readHandle, m_recv_channel->m_ack_pipe->m_writeHandle,
		m_send_channel->m_data_pipe->m_readHandle, m_send_channel->m_data_pipe->m_writeHandle,
		m_send_channel->m_ack_pipe->m_readHandle, m_send_channel->m_ack_pipe->m_writeHandle));

}


// This constructor is used by the child process to create a connection object based
// on the message pipe handles passed to it by it's parent process.
ccl_MsgConnection::ccl_MsgConnection(
	ccl_MsgPipeHandle rd_r_phandle,	// receive data read pipe handle
	ccl_MsgPipeHandle ra_w_phandle,	// receive ack write pipe handle
	ccl_MsgPipeHandle sd_w_phandle,	// send data write pipe handle
	ccl_MsgPipeHandle sa_r_phandle,	// send ack read pipe handle
	FILE *logfile
)
{
	const char *my_name = "ccl_MsgConnection::ccl_MsgConnection";

	SPX_TRY {

 		m_status = ccl_Err_None;

		m_logFile = logfile;
		m_logMgr = new LogMgr(m_logFile);

		m_recv_channel = new ccl_MsgChannel(rd_r_phandle, NULL, NULL, ra_w_phandle, m_logFile);
		if (m_recv_channel == NULL || !m_recv_channel->Valid())
			SPX_THROW(err_channel_creation_failed);

		m_send_channel = new ccl_MsgChannel(NULL, sd_w_phandle, sa_r_phandle, NULL, m_logFile);
		if (m_send_channel == NULL || !m_send_channel->Valid())
			SPX_THROW(err_channel_creation_failed);

	}
	SPX_CATCH(err_channel_creation_failed) {
		m_status = ccl_Err_Msg_Channel_Create_Failed;
	}

	DBPRINTF(("%s: rd=%d,%d ra=%d,%d sd=%d,%d sa=%d,%d\n",my_name,
		m_recv_channel->m_data_pipe->m_readHandle, m_recv_channel->m_data_pipe->m_writeHandle,
		m_recv_channel->m_ack_pipe->m_readHandle, m_recv_channel->m_ack_pipe->m_writeHandle,
		m_send_channel->m_data_pipe->m_readHandle, m_send_channel->m_data_pipe->m_writeHandle,
		m_send_channel->m_ack_pipe->m_readHandle, m_send_channel->m_ack_pipe->m_writeHandle));

}

ccl_MsgConnection::~ccl_MsgConnection(void)
{
	delete m_recv_channel;
	m_recv_channel = NULL;

	delete m_send_channel;
	m_send_channel = NULL;

	delete m_logMgr;
}

void ccl_MsgConnection::DebugPrintf(char *fmt, ...)
{
	va_list argp;

	if (m_logMgr == NULL) return;

	va_start(argp, fmt);
	m_logMgr->VPrint(fmt, argp);
	va_end(argp);
}

ccl_Boolean ccl_MsgConnection::Valid(void)
{
	return ccl_Boolean(m_status == ccl_Err_None);
}

ccl_Msg *ccl_MsgConnection::GetNextMessage(void)
{
	const char *my_name = "ccl_MsgConnection::GetNextMessage";
	ccl_Msg *msg = NULL;
	unsigned char type, flags;

	DBPRINTF(("%s: begin\n", my_name));

	SPX_TRY {
		
		// Read the header
		if (!m_recv_channel->ReadData(sizeof(type), &type))
			SPX_THROW(err_channel_read_failed);

		if (!m_recv_channel->ReadData(sizeof(flags), &flags))
			SPX_THROW(err_channel_read_failed);


		// Create a new message using the header read in.
		switch(type) {

		case CCL_MSG_TYPE_STATUS:

			int channelID;
			unsigned long status_len;
			char *status;

			// read the channelID
		  	if (!m_recv_channel->ReadData(sizeof(channelID), &channelID))
				SPX_THROW(err_channel_read_failed);

			// read the status length
		  	if (!m_recv_channel->ReadData(sizeof(status_len), &status_len))
				SPX_THROW(err_channel_read_failed);

			// create a new buffer for the status message
			status = new char[status_len];

			if (status == NULL)
				SPX_THROW(err_data_alloc_failed);

			// read the status message
			if (!m_recv_channel->ReadData(status_len, status))
				SPX_THROW(err_channel_read_failed);

			// create the ccl_Msg_Status object
			msg = new ccl_Msg_Status(type, flags, channelID, status_len, status);
			DBPRINTF(("%s:\n    '%s'\n", my_name, status));

			break;

		case CCL_MSG_TYPE_DO_PROC:
		case CCL_MSG_TYPE_INIT_DONE:
		case CCL_MSG_TYPE_CONTINUE:
		case CCL_MSG_TYPE_STOP:
		case CCL_MSG_TYPE_DISCONNECT:
			msg = new ccl_Msg(type, flags);
			break;

		default:
			break;

		}

		if (msg == NULL) SPX_THROW(err_msg_creation_failed);

		if (flags & CCL_MSG_FLAGS_BLOCKING)
			m_recv_channel->SendAck();
	}
	SPX_CATCH(err_channel_read_failed) {
		m_status = ccl_Err_Msg_Read_Failed;
	}
	SPX_CATCH(err_msg_creation_failed) {
		m_status = ccl_Err_Msg_Create_Failed;
	}
	SPX_CATCH(err_data_alloc_failed) {
		m_status = ccl_Err_Msg_Alloc_Failed;
	}
	DBPRINTF(("%s: end\n", my_name));

	return msg; 
}

ccl_Boolean ccl_MsgConnection::SendMessage(ccl_Msg_Status *msg)
{
	const char *my_name = "ccl_MsgConnection::SendMessage";

	DBPRINTF(("%s: begin\n",my_name));

	SPX_TRY {

		// send the message type
		if (!m_send_channel->WriteData(sizeof(msg->m_type), &msg->m_type))
			SPX_THROW(err_channel_write_failed);
		// send the message flags
		if (!m_send_channel->WriteData(sizeof(msg->m_flags), &msg->m_flags))
			SPX_THROW(err_channel_write_failed);
		// send the channelID
		if (!m_send_channel->WriteData(sizeof(msg->m_channelID), &msg->m_channelID))
			SPX_THROW(err_channel_write_failed);
		// send the status length
		if (!m_send_channel->WriteData(sizeof(msg->m_status_len), &msg->m_status_len))
			SPX_THROW(err_channel_write_failed);
		// send the status
		if (!m_send_channel->WriteData(msg->m_status_len, msg->m_status))
			SPX_THROW(err_channel_write_failed);
		// wait here for an acknowledgement if message is blocking
		if (msg->m_flags & CCL_MSG_FLAGS_BLOCKING)
			if (!m_send_channel->WaitForAck())
				SPX_THROW(err_ccl_Msg_Wait_For_Ack_Failed);

	}
	SPX_CATCH(err_channel_write_failed) {
		DBPRINTF(("%s: err_channel_write_failed\n",my_name));
		m_status = ccl_Err_Msg_Write_Failed;
	}
	SPX_CATCH(err_ccl_Msg_Wait_For_Ack_Failed) {
		DBPRINTF(("%s: err_ccl_Msg_Wait_For_Ack_Failed\n",my_name));
		m_status = ccl_Err_Msg_Recv_Ack_Failed;
	}

	DBPRINTF(("%s: end\n",my_name));

	return ccl_Boolean(m_status == ccl_Err_None);
}

ccl_Boolean ccl_MsgConnection::SendMessage(ccl_Msg *msg)
{
	const char *my_name = "ccl_MsgConnection::SendMessage";

	DBPRINTF(("%s: begin\n", my_name));

	SPX_TRY {

		// send the message type
		if (!m_send_channel->WriteData(sizeof(msg->m_type), &msg->m_type))
			SPX_THROW(err_channel_write_failed);
		// send the message flags
		if (!m_send_channel->WriteData(sizeof(msg->m_flags), &msg->m_flags))
			SPX_THROW(err_channel_write_failed);
		// wait here for an acknowledgement if message is blocking
		if (msg->m_flags & CCL_MSG_FLAGS_BLOCKING)
			if (!m_send_channel->WaitForAck())
				SPX_THROW(err_ccl_Msg_Wait_For_Ack_Failed);

	}
	SPX_CATCH(err_channel_write_failed) {
		DBPRINTF(("%s: err_channel_write_failed\n",my_name));
		m_status = ccl_Err_Msg_Write_Failed;
	}
	SPX_CATCH(err_ccl_Msg_Wait_For_Ack_Failed) {
		DBPRINTF(("%s: err_ccl_Msg_Wait_For_Ack_Failed\n",my_name));
		m_status = ccl_Err_Msg_Recv_Ack_Failed;
	}

	DBPRINTF(("%s: end\n", my_name));

	return ccl_Boolean(m_status == ccl_Err_None);
}

void ccl_MsgConnection::Disconnect(void)
{
	const char *my_name = "ccl_MsgConnection::Disconnect";

	DBPRINTF(("%s: begin\n", my_name));

	if (m_send_channel != NULL)
		m_send_channel->Disconnect();

	if (m_recv_channel != NULL)
		m_recv_channel->Disconnect();

	DBPRINTF(("%s: end\n", my_name));
}
