/*
 * cul_SpinCursor.c -- spinning cursor functions
 */

#include <Types.h>
#include "cul.h"
#include "cul_include.h"

#ifndef _WIN32
#pragma segment culSpinCursorSeg
#endif

/* THIS IS A DUMMY FUNCTION. */


void
cul_SpinCursor(void)
{
	return;
}
