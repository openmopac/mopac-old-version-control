/*
 * cul_Include.h -- private include file for cul
 */

#ifndef __CUL_INCLUDE_H__
#define __CUL_INCLUDE_H__

#if defined (_DEBUG)

	#define DBPRINTF(arg) cul_dbprintf arg

	#ifdef __cplusplus
	extern "C" {
	#endif

	void cul_dbprintf(const char *fmt, ...);

	#ifdef __cplusplus
	}
	#endif

#else
	#define DBPRINTF(arg)	/* null macro when not debugging */
#endif	/* _DEBUG */

#endif /* __CUL_INCLUDE_H__ */

