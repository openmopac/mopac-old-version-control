/*
** cul_Msgs.c -- Message passing routines
*/

#if !defined(_WINDOWS) && !defined(_WIN32)

#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>

#if defined(unix)
#include <sys/poll.h>
#include <sys/time.h>
#include <stddef.h>
#include <fcntl.h>
#include <errno.h>
#endif

#include "cul.h"
#include "cul_Include.h"

/* local function definitions (private to this file) */

static int cul_waitForEmptyBuffer( volatile struct cul_CPMsgChannel *const channel, Boolean (*giveUp)() );

static int cul_waitForExclusiveAccess( volatile struct cul_CPMsgChannel *const channel, Boolean (*giveUp)() );

static cul_messageStatus cul_writePipedMsg( volatile struct cul_CPMsgChannel *const channel,
                                            const char *const text,
                                            int nonBlocking );

static int cul_msgDataAvail( volatile struct cul_CPMsgChannel *const channel );

int cul_shouldDiscardMsg( volatile struct cul_CPMsgChannel *const channel );

/*
** cul_sendCPMessage() -- Send a message; unreliable delivery
**
**	cul_sendCPMessage() attempts to send a message to a
**	coprocess. If for any reason the message cannot be sent
**	immediately, cul_sendCPMesage() returns an error. Any
**	message currently awaiting delivery will be discarded.
*/

cul_messageStatus
cul_sendCPMessage(volatile struct cul_CPMsgChannel *const channel,
	const char *const text)
{
#if defined(unix)
	if (cul_shouldDiscardMsg(channel))
		return(CUL_MSGS_BUSY);

	return(cul_writePipedMsg(channel, text, 1));
#endif
}

/*
** cul_sendCPMessageWait() -- Send a message; reliable delivery
**
**	cul_sendCPMessageWait() attempts to send a message to a
**	coprocess. If the message cannot be sent immediately,
**	cul_sendCPMesageWait() blocks.
*/

cul_messageStatus
cul_sendCPMessageWait(volatile struct cul_CPMsgChannel
	*const channel, const char *const text,
	Boolean (*giveUp)())
{
	/* If the previous message hasn't been read, wait. */

	if (cul_waitForEmptyBuffer(channel, giveUp) != 0)
		return(CUL_MSGS_FAILED);

	/*
	** Attempt to gain exclusive access to the message buffer.
	** If unable to do so, return an error.
	*/

	if (cul_waitForExclusiveAccess(channel, giveUp) != 0)
		return(CUL_MSGS_FAILED);

#if defined(unix)
	return(cul_writePipedMsg(channel, text, 0));
#endif
}

/*
** cul_printCPMessage() -- Send a formatted message; unreliable delivery
**
**	cul_printCPMessage() attempts to send a message to a
**	coprocess. If for any reason the message cannot be sent
**	immediately, cul_printCPMesage() returns an error. Any
**	message currently awaiting delivery will be discarded.
**	The message to be sent is described using a format
**	string and arguments of the printf() function.
**
** Note:
**
**	The caller must take responsibility to ensure that the
**	message will not overrun the buffer previously allocated
**	for the channel.
*/

cul_messageStatus
cul_printCPMessage(volatile struct cul_CPMsgChannel *const channel,
	const char *const format, ...)
{
	va_list nextArg;	/* variable argument list ptr */
	char *msgBufP;
#if defined(unix)
	char msgBuf[CUL_MSG_BUF_SIZE];

	msgBufP = msgBuf;
#else
#error "No machine type defined."
#endif
	/* Set up for the message formatting operation */

	va_start(nextArg, format);

	/* Copy the data into the message buffer */

	(void) vsprintf(msgBufP, format, nextArg);

	/* Clean up after variable argument handling */

	va_end(nextArg);

#if defined(unix)
	if (cul_shouldDiscardMsg(channel))
		return(CUL_MSGS_BUSY);

	return(cul_writePipedMsg(channel, msgBuf, 1));
#endif
}

/*
** cul_vprintCPMessage() -- Send a formatted message; unreliable delivery
**
**	cul_vprintCPMessage() attempts to send a message to a
**	coprocess. If for any reason the message cannot be sent
**	immediately, cul_vprintCPMesage() returns an error. Any
**	message currently awaiting delivery will be discarded.
**	The message to be sent is described using a format
**	string and arguments of the printf() function.
**
** Note:
**
**	The caller must call the va_start() function to set
**	up the 'nextArg' parameter before calling this function
**	and the va_end() function after this function returns.
**
**	The caller must take responsibility to ensure that the
**	message will not overrun the buffer previously allocated
**	for the channel.
*/

cul_messageStatus
cul_vprintCPMessage(volatile struct cul_CPMsgChannel *const channel,
	const char *const format, va_list nextArg)
{
	char *msgBufP;
#if defined(unix)
	char msgBuf[CUL_MSG_BUF_SIZE];

	msgBufP = msgBuf;
#else
#error "No machine type defined."
#endif

	/* Copy the data into the message buffer */

	(void) vsprintf((char *) msgBufP, format, nextArg);

#if defined(unix)
	if (cul_shouldDiscardMsg(channel))
		return(CUL_MSGS_BUSY);

	return(cul_writePipedMsg(channel, msgBuf, 1));
#endif
}

/*
** cul_printCPMessageWait() -- Send a formatted message; reliable delivery
**
**	cul_printCPMessageWait() attempts to send a message to a
**	coprocess. If the message cannot be sent immediately,
**	cul_printCPMessageWait() blocks.
**
**	The message to be sent is described using a format
**	string and arguments of the printf() function.
**
** Note:
**
**	The caller must take responsibility to ensure that the
**	message will not overrun the buffer previously allocated
**	for the channel.
*/

cul_messageStatus cul_printCPMessageWait( volatile struct cul_CPMsgChannel *const channel,
                                          Boolean (*giveUp)(),
                                          const char *const format, ... )
{
	va_list nextArg;	/* variable argument list ptr */
	char *msgBufP;
#if defined(unix)
	char msgBuf[CUL_MSG_BUF_SIZE];

	msgBufP = msgBuf;
#else
#error "No machine type defined."
#endif
	/* If the previous message hasn't been read, wait. */

	if (cul_waitForEmptyBuffer(channel, giveUp) != 0)
		return(CUL_MSGS_FAILED);

	/*
	** Attempt to gain exclusive access to the message buffer.
	** If unable to do so, return an error.
	*/

	if (cul_waitForExclusiveAccess(channel, giveUp) != 0)
		return(CUL_MSGS_FAILED);

	/* Set up for the message formatting operation */

	va_start(nextArg, format);

	/* Copy the data into the message buffer */

	(void) vsprintf(msgBufP, format, nextArg);

	/* Clean up after variable argument handling */

	va_end(nextArg);

#if defined(unix)
	return(cul_writePipedMsg(channel, msgBuf, 0));
#endif
}

#ifdef DEADCODE

This function compiles with an error under Mac OS X (BSD) because it references va_start yet it has
a fixed argument list.  Furthermore, this function does not appear to be referenced by any code
under wincache/src/Standalone.  Therefore, I have wrapped this function with a "#ifdef 0" directive.
(MSS Oct. 2003)
/*
** cul_vprintCPMessageWait() -- Send a formatted message; reliable delivery
**
**	cul_vprintCPMessageWait() attempts to send a message to a
**	coprocess. If the message cannot be sent immediately,
**	cul_printCPMessageWait() blocks.
**
**	The message to be sent is described using a format
**	string and arguments of the vprintf() function.
**
** Notes:
**
**	The caller must call the va_start() function to set
**	up the 'nextArg' parameter before calling this function
**	and the va_end() function after this function returns.
**
**	The caller must take responsibility to ensure that the
**	message will not overrun the buffer previously allocated
**	for the channel.
*/

cul_messageStatus
cul_vprintCPMessageWait(volatile struct cul_CPMsgChannel
	*const channel, Boolean (*giveUp)(),
	const char *const format, va_list nextArg)
{
	char *msgBufP;
#if defined(unix)
	char msgBuf[CUL_MSG_BUF_SIZE];

	msgBufP = msgBuf;
#else
#error "No machine type defined."
#endif
	/* If the previous message hasn't been read, wait. */

	if (cul_waitForEmptyBuffer(channel, giveUp) != 0)
		return(CUL_MSGS_FAILED);

	/*
	** Attempt to gain exclusive access to the message buffer.
	** If unable to do so, return an error.
	*/

	if (cul_waitForExclusiveAccess(channel, giveUp) != 0)
		return(CUL_MSGS_FAILED);

	/* Set up for the message formatting operation */

	va_start(nextArg, format);

	/* Copy the data into the message buffer */

	(void) vsprintf(msgBufP, format, nextArg);

	/* Clean up after variable argument handling */

	va_end(nextArg);

#if defined(unix)
	return(cul_writePipedMsg(channel, msgBuf, 0));
#endif
}
#endif

/*
** cul_readCPMessage() -- Read a message
**
**	cul_readCPMessage() attempts to read a message from a
**	coprocess. If no message is currently available, or
**	if the buffer is currently in use by the coprocess,
**	cul_readCPMessage() returns immediately with an error
**	indication.
*/

cul_messageStatus
cul_readCPMessage(volatile struct cul_CPMsgChannel
	*const channel, char *const text)
{
#if defined(unix)
	int rc;
#endif
	/* If no data is available, return. */

	if (!cul_msgDataAvail(channel))
		return(CUL_MSGS_NOMSG);

#if defined(unix)
	(void) fcntl(channel->readFD, F_SETFL, O_NONBLOCK);

	*text = 0;

	if ((rc = read(channel->readFD, text, CUL_MSG_BUF_SIZE)) == -1)
	{
		if (errno == EAGAIN)
			return(CUL_MSGS_NOMSG);
		else
			return(CUL_MSGS_FAILED);
	}

	/* Handle special pipe case of end-of-file */

	if (rc == 0)
		return(CUL_MSGS_EOF);
#endif
	return(CUL_MSGS_MSGRCVD);
}

/*
** cul_initCPMessageChannel() -- Initialize a channel data structure
**
**	cul_initCPMessageChannel() must be called to initialize
**	an interprocessor channel data structure prior to its use.
**
** Returns 0 on success, -1 on error
**
** Note:
**
**	The channel structure and its associated message buffer
**	must reside in the same shared memory segment (or, the
**	message buffer must map to the same virtual address in
**	all related processes. Since this is somewhat tricky to
**	ensure in a portable manner, stick with the first
**	restriction.) Also, the shared memory segments should
**	reside in uncached memory.
*/

#if defined(unix)
int
cul_initCPMessageChannel(struct cul_CPMsgChannel *const channel,
	const unsigned char channelID)
{
	int pfd[2];

	if (pipe(pfd) == -1)
	{
		return(-1);
	}

	channel->readFD = pfd[0];
	channel->writeFD = pfd[1];
	channel->channelID = channelID;
	return(0);
}
#endif

/*
** cul_attachCPMessageChannel() -- Attach a msg channel to a process
**
**	cul_attachCPMessageChannel() is used to attach a message
**	channel to a process. It is typically used by a child process
**	to fill in the message channel data structure with the
**	file descriptor of the pipe which carries the messages.
*/

void
cul_attachCPMessageChannel(struct cul_CPMsgChannel *const channel,
	int readFD, int writeFD, const unsigned char channelID)
{
#if defined(unix)
	channel->readFD = readFD;
	channel->writeFD = writeFD;
	channel->channelID = channelID;
#endif
}

/*
** cul_destroyCPMessageChannel() -- Close a message channel
**
**	cul_destroyCPMessageChannel() must be called to close a
**	message channel. It waits for the buffer to empty, then
**	deletes all data structures/semaphores/whatever (implementation
**	dependent). Basically, it cleans up.
*/

void
cul_destroyCPMessageChannel(struct cul_CPMsgChannel *const channel)
{
#if defined(unix)
	(void) close(channel->readFD);
	(void) close(channel->writeFD);
#endif
}

/*
** cul_getCPMsg<Read/Write>FD() -- Get msg channel fd
*/

#if defined(unix)
int cul_getCPMsgReadFD(const struct cul_CPMsgChannel *const msgChannelP)
{
	return(msgChannelP->readFD);
}

int cul_getCPMsgWriteFD(const struct cul_CPMsgChannel *const msgChannelP)
{
	return(msgChannelP->writeFD);
}
#endif

/*
** cul_waitForEmptyBuffer() -- Wait until msg can be buffered.
**
**	cul_waitForEmptyBuffer() waits until there is room in the
**	message buffer/message pipe, or until the user signals
**	the desire to stop waiting via the giveUp() function.
**
** Returns:
**
**	0 on success, -1 on giveUp() or error.
**
*/

static int cul_waitForEmptyBuffer( volatile struct cul_CPMsgChannel *const channel, Boolean (*giveUp)() )
{
#if defined(unix)
	struct pollfd pfd[1];
	int rc;

	/* Wait until there is room in the pipe... */

	pfd[0].fd = channel->writeFD;
	pfd[0].events = POLLOUT;

	/*
	** Poll until the channel can accept data. Wake
	** up every so often to check whether the poll
	** should be prematurely terminated.
	*/

	while ((rc = poll(pfd, 1, 500)) == 0)
	{
		/* Check if wait should be aborted */

		if (giveUp)
			if ((*giveUp)())
				return(-1);
	}

	if (rc == -1)	/* handle errors during polling */
		return(-1);
#endif
	return(0);
}

/*
** cul_waitForExclusiveAccess() -- Acquire exclusive channel access
**
**	cul_waitForExclusiveAccess() acquires exclusive access
**	to the specified message channel. If access is not
**	immediately available, it waits until either it gets
**	exclusive access or the user signals a desire to give
**	up waiting via the giveUp() function.
**
** Returns:
**
**	0 on success, -1 on giveUp().
**
** This routine is a no-op under unix, always returning success.
*/

static int cul_waitForExclusiveAccess( volatile struct cul_CPMsgChannel *const channel, Boolean (*giveUp)() )
{
	return(0);
}

#if defined(unix)
/*
** cul_writePipedMsg() -- Write a message in an interprocess pipe
**
**	cul_writePipedMsg() consolidates the writing of messages
**	into a message pipe in one place.
*/

static cul_messageStatus cul_writePipedMsg( volatile struct cul_CPMsgChannel *const channel,
                                            const char *const text,
                                            int nonBlocking )
{
	cul_messageStatus msgStatus;
	char localBuf[CUL_MSG_BUF_SIZE];

	/* Set pipe blocking mode */

	if (nonBlocking)
		fcntl(channel->writeFD, F_SETFL, O_NONBLOCK);
	else
		fcntl(channel->writeFD, F_SETFL, 0);

	/*
	** Note: In order to be able to locate message
	** boundaries in the pipe, all messages are written
	** with a fixed length equal to the maximum msg.
	** buffer size. All reads on the pipe use this size
	** to extract messages. To actual size of the message
	** can be determined by passing it to the strlen() routine.
	** One alternative to this would be to read the message
	** from the pipe one byte at a time looking for the
	** null character, but the overhead involved would
	** be prohibitive. Another technique would be to put
	** a byte count on the beginning of the message, read
	** that, then read the specified number of bytes. Perhaps
	** when time permits that would be a good way to go.
	*/

	/*
	** Copy the data into a local buffer to prevent
	** any possibility of copying past the end of a short
	** message and straying outside of the address space
	** of the process.
	*/

	strncpy(localBuf, text, CUL_MSG_BUF_SIZE);
	localBuf[CUL_MAX_MSG_LENGTH] = 0;

	if (write(channel->writeFD, localBuf, CUL_MSG_BUF_SIZE) == -1)
	{
		switch (errno)
		{
			case EAGAIN:	/* pipe was full */

#if 0
				DBPRINTF(("cul_writePipedMsg(): Pipe was full, "
					"Msg channel %d\n", channel->channelID));
#endif

				msgStatus = CUL_MSGS_BUSY;
				break;

			default:	/* serious errors */

#if 0
				DBPRINTF(("cul_writePipedMsg(): Error writing pipe, "
					"Msg channel %d\n", channel->channelID));
#endif

				msgStatus = CUL_MSGS_FAILED;
				break;
		}
	}

	else
		msgStatus = CUL_MSGS_SENT;

	return(msgStatus);
}

#endif

/*
** cul_msgDataAvail() -- Returns true if msg is avail, false otherwise.
**
** Notes:
**
**	Also returns true of end-of-file.
*/

static int cul_msgDataAvail( volatile struct cul_CPMsgChannel *const channel )
{
#if defined(unix)
	struct pollfd pfd[1];

	/* Wait until there is room in the pipe... */

	pfd[0].fd = channel->readFD;
	pfd[0].events = POLLIN;

	if ((poll(pfd, 1, 0)) < 1)
		return(0);	/* Pipe will block on read attempts */

	return(1);	/* Data (or EOF) available */
#else
#error "No machine type defined."
#endif
}

/*
** cul_GetCPMsgChannelID() -- Returns the message channel ID
*/

unsigned long
cul_GetCPMsgChannelID(const struct cul_CPMsgChannel *const channel)
{
	return((unsigned long) (channel->channelID));
}

/*
** cul_shouldDiscardMsg() -- Returns non-zero if msg should be junked
**
**	cul_shouldDiscardMsg() returns true if insufficient time
**	has elapsed between the sending of messages on a discardable
**	channel. It is only used in the Unix environment.
*/

#if defined(unix)

static unsigned int cul_MinMsgInterval = 60;
#if defined(cache_aix)
#define CUL_CA_TIME_IN_TICKS(tp) (gettimer(TIMEOFDAY, &(tp)), \
	(tp.tv_sec * 60 + ((tp.tv_nsec >= 0 && tp.tv_nsec < 1000000000) \
	? ((tp.tv_nsec / 1000) * 60) / 1000000 : 0)))
#elif defined(cache_bsd) || defined(cache_irix)
struct timezone my_time_zome;
#define CUL_CA_TIME_IN_TICKS(tp) (gettimeofday(&tp, &my_time_zome), \
	(tp.tv_sec * 60 + ((tp.tv_usec >= 0 && tp.tv_usec < 1000000) \
	? ((tp.tv_usec / 1000) * 60) / 1000 : 0)))
#else
#error "CUL_CA_TIME_IN_TICKS not defined for this flavor of unix"
#endif


#define CUL_MSGS_INITIAL_CA_NUM 8
#define CUL_MSGS_INCR_CA_NUM 8

int
cul_shouldDiscardMsg(volatile struct cul_CPMsgChannel *const channel)
{
	struct ca
	{
		unsigned int numSlots;
		unsigned int numSlotsUsed;
		struct channelInfo
		{
			volatile struct cul_CPMsgChannel *channel;
			unsigned long lastMsgTime;
		} channelInfo[1]; /* number varies */
	};
	static struct ca *channelArray = 0;
	unsigned int i;
#if defined(cache_bsd) || defined(cache_irix)
	struct timeval tp;
#else
	struct timestruc_t tp;
#endif
	/* Does the channel array exist? */

	if (channelArray == 0)
	{
		/* No -- allocate and initialize it */

		channelArray = calloc(offsetof(struct ca,
			channelInfo[CUL_MSGS_INITIAL_CA_NUM]), 1);

		/*
		** If the channel array could not be allocated,
		** indicate that the message should be printed.
		*/

		if (channelArray == 0)
			return(0);

		channelArray->numSlots = CUL_MSGS_INITIAL_CA_NUM;
	}

	/* Is the caller's channel in the channel array? */

	for (i = 0; i < channelArray->numSlotsUsed; i++)
	{
		if (channelArray->channelInfo[i].channel == channel)
			break;
	}

	if (i == channelArray->numSlotsUsed)	/* no -- add it */
	{
		/* is there room? */

		if (channelArray->numSlots == channelArray->numSlotsUsed)
		{
#if defined(unix)
			channelArray = realloc(channelArray, ((CUL_MSGS_INCR_CA_NUM +
				channelArray->numSlots) * sizeof(struct ca)));
#else
			channelArray = realloc(channelArray, offsetof(struct ca,
				channelInfo[CUL_MSGS_INCR_CA_NUM +
				channelArray->numSlots]));
#endif
			/*
			** If the channel array could not be allocated,
			** indicate that the message should be printed.
			*/

			if (channelArray == 0)
				return(0);

			channelArray->numSlots = CUL_MSGS_INCR_CA_NUM +
					channelArray->numSlots;
		}

		/* Initialize channel timing info */

		channelArray->channelInfo[channelArray->numSlotsUsed].channel
			= channel;
		channelArray->channelInfo[channelArray->numSlotsUsed].lastMsgTime
			= CUL_CA_TIME_IN_TICKS(tp);
		channelArray->numSlotsUsed++;

		return(0);	/* Always print 1st msg. on a channel */
	}

	/* Found it -- has enough time elapsed to send another msg? */

	if (channelArray->channelInfo[i].lastMsgTime +
		cul_MinMsgInterval > CUL_CA_TIME_IN_TICKS(tp))
		return(1);

	channelArray->channelInfo[i].lastMsgTime
		= CUL_CA_TIME_IN_TICKS(tp);

	return(0);
}

#endif

#endif /* !_WINDOWS && !_WIN32 */
