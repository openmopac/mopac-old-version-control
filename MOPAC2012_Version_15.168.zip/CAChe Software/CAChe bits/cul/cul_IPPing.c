/*
** cul_IPPing.c -- ICMP Ping of specified host
*/

#include <stdio.h>
#include <string.h>
#include <Memory.h>
#include <Desk.h>
#include <Devices.h>
#include <AppleTalk.h>
/*
** The order of the following include files is due to
** Apple's failure to allow MacTCPCommonTypes.h to
** be included multiple times. It must be included in
** cul.h, and is also needed for MiscIPPB.h, so cul.h
** must precede MiscIPPB.h. Way to go Apple!
*/
#include "cul.h"
#include <MiscIPPB.h>

void compProc(struct ICMPParamBlock *iopb);

struct response
{
	volatile int replyReceived;
	volatile OSErr ioResult;
};

/*
** cul_IPPing() -- Ping a host on the IP network.
**
**	cul_IPPing() sends an ICMP 'Echo' request to the specified
**	host. If a reply is received, it returns 1 in the 'up'
**	parameter; otherwise, the 'up' parameter is set to zero.
**	The function return value is normally zero unless a serious
**	error is detected. In the case, the appropriate OS error code
**	is returned and the 'up' parameter is set to 0. The retryInfo
**	parameter can by used to set the retry count and timeout values.
**	If a null pointer is passed in for this parameter, compiled-in
**	defaults will be used. While waiting for a reply, the procedure
**	pointed to by the 'idleProc' parameter will be called. If a
**	null pointer is provided, the SystemTask() routine will be called.
*/

OSErr
cul_IPPing(const ip_addr dest,
	const cul_IPPing_retryInfo *const retryInfo,
	int *const up, void (*idleProc)())
{
	struct IPParamBlock iopb;
	short refNum;
	OSErr rc;
	volatile struct response *resp;
	unsigned int tryNum;

	*up = 0;	/* Assume failure */

	/* open the MacTCP driver */

	if ((rc = OpenDriver("\p.IPP", &refNum)) != noErr)
		return(rc);

	/*
	** Clear out then fill in the control block used
	** to make the ICMP Echo request.
	*/

	(void) memset(&iopb, 0, sizeof(iopb));

	iopb.csCode = ipctlEchoICMP;
	iopb.ioCRefNum = refNum;
	iopb.csParam.IPEchoPB.dest = dest;
	iopb.csParam.IPEchoPB.data.ptr = "ping\n";
	iopb.csParam.IPEchoPB.data.length
		= strlen(iopb.csParam.IPEchoPB.data.ptr);
	/* Note: System call takes secs rather than ticks */
	iopb.csParam.IPEchoPB.timeout = (((retryInfo == 0) ?
		CUL_IPP_TIMEOUT : retryInfo->timeOutTicks) + 59) / 60;
	iopb.csParam.IPEchoPB.icmpCompletion =
		(ICMPEchoNotifyProc) compProc;

	/*
	** Allocate structure used by asynchronous reply routine on
	** the heap. This allows this routine to be called by
	** multiple threads.
	*/

	if ((resp = (struct response *)
		NewPtr(sizeof(struct response))) == 0)
		return(MemError());

	iopb.csParam.IPEchoPB.userDataPtr = (unsigned long) resp;

	/* Ping the host repeatedly */

	for (tryNum = 0; tryNum < ((retryInfo == 0) ? CUL_IPP_RETRY_CNT
		: retryInfo->retryCount); tryNum++)
	{
		/* Initialize the reply structure */

		resp->replyReceived = 0;
		resp->ioResult = 0;

		/* Make the request */

		if ((rc = PBControl((ParmBlkPtr) &iopb, false)) != noErr)
		{
			DisposPtr((Ptr) resp);
			return(rc);
		}

		/* Wait for reply or timeout */

		while (!resp->replyReceived)
		{
			/* Call SystemTask(), or the caller-supplied idle proc */

			if (idleProc == 0)
				SystemTask();

			else
				idleProc();
		}

		/*
		** Stop retrying on any result other than a timeout error.
		** This exits the loop on both success and serious errors.
		*/

		if (resp->ioResult != icmpEchoTimeoutErr)
			break;
	}

	/* Done with the asynchronous response buffer */

	DisposPtr((Ptr) resp);

	/* Did the host reply? */

	if (resp->ioResult == 0)
		*up = 1;	/* yes! */

	return(0);
}

/*
** compProc -- asynchronous reply routine
**
**	This routine is called by the MacTCP driver on a successful
**	reply or timeout from the ICMP Echo request function.
*/

static void
compProc(struct ICMPParamBlock *replyPB)
{
	struct response *resp;

	resp = (struct response *) replyPB->icmpEchoInfo.userDataPtr;

	/* Copy the key fields into the asynchronous reply buffer */

	resp->ioResult = replyPB->ioResult;
	resp->replyReceived = 1;
}