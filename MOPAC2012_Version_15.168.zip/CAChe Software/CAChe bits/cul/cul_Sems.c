/*
** cul_Sems.c -- Coprocessor semaphore routines
*/

#ifdef unix
#include <errno.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#endif

#include "cul.h"

#define CUL_SEM_FIRST clientFlag
#define CUL_SEM_SECOND serverFlag

/*
** cul_AcquireSemaphore() -- Attempt to acquire a semaphore
**
**	cul_AcquireSemaphore() attempts to acquire the specified
**	semaphore. If it is already being held by another process,
**	cul_AcquireSemaphore() returns an error.
**
**	Note that the semaphore data structure must reside in
**	uncached (or snooped) shared memory.
*/

cul_semaphoreState cul_AcquireSemaphore(volatile cul_semaphore *sem)
{
#ifdef unix
	struct sembuf semBuf[1];

	semBuf[0].sem_num = 0;
	semBuf[0].sem_op = -1;
	semBuf[0].sem_flg = SEM_UNDO | IPC_NOWAIT;

	if (semop(sem->semID, semBuf, 1) == 0)
		return(CUL_SEMAPHORE_ACQUIRED);

	switch (errno)
	{
		case EAGAIN:	/* Recoverable errors */
		case EINTR:

			return(CUL_SEMAPHORE_BUSY);

		case EIDRM:		/* Resource access is no longer controlled */

			return(CUL_SEMAPHORE_ACQUIRED);

		default:		/* Fatal errors */

			/*
			** There is some debate on what the correct
			** return value should be in this case.
			*/
			return(CUL_SEMAPHORE_ACQUIRED); /* don't block on error */
	}
#else /* mac or 88K */
	if (sem->CUL_SEM_FIRST)
		return(CUL_SEMAPHORE_BUSY);

	sem->CUL_SEM_FIRST = TRUE;

	if (sem->CUL_SEM_SECOND)
		return(CUL_SEMAPHORE_BUSY);

	sem->CUL_SEM_SECOND = TRUE;

	return(CUL_SEMAPHORE_ACQUIRED);
#endif
}


/*
** cul_AcquireSemaphoreWait() -- Attempt to acquire a semaphore
**
**	cul_AcquireSemaphoreWait() attempts to acquire the specified
**	semaphore. If it is already being held by another process,
**	cul_AcquireSemaphore() keeps retrying the request.
**
**	Notes:
**
**	The semaphore data structure must reside in uncached
**	(or snooped) shared memory.
**
**	When run on the Macintosh, this routine must be used in
**	conjunction with the "threads" package.
*/

cul_semaphoreState cul_AcquireSemaphoreWait(volatile cul_semaphore *sem)
{
	cul_semaphoreState semState;

#ifdef unix
	struct sembuf semBuf[1];

	semBuf[0].sem_num = 0;
	semBuf[0].sem_op = -1;
	semBuf[0].sem_flg = SEM_UNDO;

	semState = CUL_SEMAPHORE_ACQUIRED;	/* Assume success */

	/*
	** Normally this call will block until it acquires the
	** semaphore. The loop is to retry the operation if
	** it interrupted by a signal.
	*/

	while (semop(sem->semID, semBuf, 1) == -1)
	{
		if (errno == EIDRM)	/* Don't hang on permanent error */
			break;

		if (errno != EINTR)	/* Break on fatal errors, retry on EINTR */
		{
			/* Should never happen */

			semState = CUL_SEMAPHORE_BUSY;
			break;
		}
	}
#else /* mac or 88K */
	while ((semState = cul_AcquireSemaphore(sem)) == CUL_SEMAPHORE_BUSY)
	{
		CUL_YIELD();	/* On the Mac, give up processor time */
	}
#endif
	return(semState);
}

/*
** cul_ReleaseSemaphore() -- Release the specified semaphore
**
**	cul_ReleaseSemaphore() releases the specified semaphore.
**
** Note:
**
**	This routine does not check to see if the caller has
**	acquired the semaphore.
*/

void cul_ReleaseSemaphore(cul_semaphore *sem)
{
#ifdef unix
	struct sembuf semBuf[1];

	semBuf[0].sem_num = 0;
	semBuf[0].sem_op = 1;
	semBuf[0].sem_flg = SEM_UNDO;

	semop(sem->semID, semBuf, 1);
#else /* mac or 88K */
	/* Order is important to avoid a race condition */
	sem->CUL_SEM_FIRST = FALSE;
	sem->CUL_SEM_SECOND = FALSE;
#endif
}

/*
** cul_InitSemaphore() -- Initialize the specified semaphore
**
**	cul_InitSemaphore() initializes the specified semaphore.
**
** Returns zero on success, -1 on error
*/

int cul_InitSemaphore(cul_semaphore *sem)
{
#ifdef unix
#if defined(cache_aix)
	if ((sem->semID = semget(IPC_PRIVATE, 1, IPC_R | IPC_W)) == -1)
		return(-1);
#else
	if ((sem->semID = semget(IPC_PRIVATE, 1, 0)) == -1)
		return(-1);
#endif
	if (semctl(sem->semID, 0, SETVAL, (int) 1) == -1)
	{
		/* destroy the semaphore */

		(void) semctl(sem->semID, 0, IPC_RMID);

		return(-1);
	}

#else	/* mac or 88K */
	sem->clientFlag = FALSE;
	sem->serverFlag = FALSE;
#endif
	return(0);
}

/*
** cul_DestroySemaphore() -- Destroys the specified semaphore
*/

void cul_DestroySemaphore(cul_semaphore *sem)
{
#ifdef unix
	(void) semctl(sem->semID, 0, IPC_RMID);
#endif
}
