/*
**	cul_TCPIOOps.c -- TCP I/O operations for the Mac
**
**	As always seems to be the case, the limitions of not having
**	an operating system on the Mac greatly increases the complexity
**	of performing even the most simple operation. The routines
**	in this file attempt to address the problem of a blocking
**	TCP network operation bringing the "system" to a halt. These
**	routines, cul_TCPRead() and cul_TCPWrite(), queue an asynchronous
**	network I/O operation, then block the current thread. Presumably
**	the main thread will then get to run, call WaitNextEvent(),
**	and the "system" will go merrily on its way. When the requested
**	I/O operation completes, the blocked thread will be awakened
**	somewhat indirectly by the asynchronous completion routine (the
**	specifics are described below), providing the illusion to the
**	caller of the "system" being able to intelligently handle blocking
**	I/O operations.
**
**	The process of waking the blocked I/O thread deserves a bit of
**	additional explaination. One might think that all that needs to
**	be done is to schedule the I/O operation with a completion routine
**	which will wake the thread, then put the thread to sleep. The
**	problem with this approach is that there is a window between
**	scheduling the I/O operation and putting the tread to sleep
**	in which the completion routine can fire off, attempt to wake
**	the not-yet-sleeping tread, and exit. The thread then puts itself
**	to sleep, with nothing around to ever wake it up. The solution
**	proposed by Apple to this problem is the spawn a second thread
**	in the blocked state whose only job is to wake the first thread.
**	So, it works like this: The first thread spawns a second thread
**	in the blocked state; this thread will, when executed, wake the
**	first thread. The first thread then schedules an asynchronous
**	network I/O operation, with a completion routine which will
**	attempt to wake both threads, with scheduling priority given
**	to the first thread. In the scenario where the first thread is
**	blocked (considered to be the normal case), the thread will wake
**	up, be given control, kill the second thread, and go on its way.
**	In the case where the first thread has not yet blocked, it will
**	eventually get around to doing so. The second thread will wait
**	for this to happen, then wake the first thread and exit. The first
**	thread will wake, attempt to kill the second thread (it's already
**	dead), and return to the caller. There are no situations in which
**	the first thread can fail to be awakened by the completion routine.
**
**	Notes:
**
**		This software requires Apple's ThreadManager to be installed.
**		For reasons of efficiency, it doesn't bother to check that is
**		is; that's the application's responsibility.
*/

#include <Events.h>
#include <Time.h>
#include <Devices.h>
#include <TCPPB.h>
#include <Threads.h>
#include "cul.h"
#include "cul_Include.h"

#define CUL_NO_TCP_DRIVER_ID 32767	/* driver IDs are small neg. numbers */

static short TCPDriverID = CUL_NO_TCP_DRIVER_ID;

/* Default values */

#define CUL_TCP_THREAD_STACK_SIZE	(16384uL)	/* stack size of helper threads */
#define CUL_TCP_DRAIN_BUF_SIZE		(8192uL)	/* Buffer size used by drainProc */
#define CUL_TCP_BUFSIZE				(8192uL)	/* size of TCP buffers(bytes) */
#define CUL_TCP_CONNECT_WAIT		45			/* time in secs */
#define CUL_TCP_LISTEN_WAIT			0			/* time in secs */
#define CUL_TCP_CLOSE_WAIT			45			/* time in secs */
#define CUL_TCP_READ_WAIT			0			/* time in secs */
#define CUL_TCP_WRITE_WAIT			0			/* time in secs */

struct ThreadsToWake
{
	ThreadID ioThread;
	ThreadID wakerThread;
};

struct cul_ExtendedDevCtlPB
{
	struct TCPiopb tcpiopb;
	ThreadTaskRef taskRef;
	struct ThreadsToWake threadsToWake;
};

/*
** Parameter structure for the kill routine
*/

struct cul_killInfo
{
	cul_StreamPtr streamPtr;
	unsigned long *done;
};

#define CUL_TCP_MAGIC_NUMBER 'TCPs'

/*
** State bits for cul_StreamPtr struct
**
**	Notes:	States progress from null to in-use, optionally
**			to listening, on to connected/readable/writable,
**			to connected/closing (on close), and finally null again.
**			The connected bit implies that a listen/connect operation
**			is not allowed. In-use means that this data structure
**			has a stream associated with it.
*/

#define CUL_TCPSTREAM_IN_USE	(1 << 0)	/* This cul_StreamPtr has a TCP Stream */
#define CUL_TCPSTREAM_CONNECTED	(1 << 1)	/* This cul_StreamPtr is connected */
#define CUL_TCPSTREAM_LISTENING (1 << 2)	/* This cul_StreamPtr is listening */
#define CUL_TCPSTREAM_READABLE	(1 << 3)	/* This cul_StreamPtr is readable */
#define CUL_TCPSTREAM_WRITEABLE	(1 << 4)	/* This cul_StreamPtr is writable */
#define CUL_TCPSTREAM_CLOSING	(1 << 5)	/* Close has been issued */

/* Local routine declarations */

static OSErr cul_TCPReadNoCheck(const cul_StreamPtr tcpStream,
	const void *const data, const unsigned long dataLen,
	unsigned long *const bytesRecd);

static OSErr cul_TCPHandleSpecialErrors(OSErr err, cul_StreamPtr tcpStream);

static void asyncWakeProc(struct cul_ExtendedDevCtlPB *extendedPB);
static pascal void wakerProc(ThreadID *const ioThIdP);
static pascal void drainProc(cul_StreamPtr tcpStream);
static void cul_WaitForThread(ThreadID thId);
static pascal void cul_killStream(struct cul_killInfo *info);

/* Head of linked list of cul_Streams */

static struct cul_Stream *cul_StreamPtrHdr = 0;

/* Mac segmentation directive */

#pragma segment Seg_CUL_IP

#ifdef CACHE_PPC
static RoutineDescriptor asyncWakeProcRD = BUILD_ROUTINE_DESCRIPTOR(uppTCPIOCompletionProcInfo, asyncWakeProc);
static TCPIOCompletionUPP asyncWakeProcUPP = (TCPIOCompletionUPP)&asyncWakeProcRD;
#else
static TCPIOCompletionUPP asyncWakeProcUPP = (TCPIOCompletionUPP)asyncWakeProc;
#endif

/*
** cul_prtThID() -- Convert a threadID into a printable string
**
**	This routine is provided to decouple the structure of a ThreadID
**	from its printable representation. If Apple decides at a later
**	date to change the underlieing representation of the ThreadID
**	only this routine needs to change, not all of the places in which
**	ThreadIDs get printed.
*/

const char *
cul_prtThID(const ThreadID thID)
{
	static char thIDStr[16];
	sprintf(thIDStr, "%lu", thID);
	return(thIDStr);
}

/*
** openTCPDriver() -- Get the refnum of the TCP driver
**
**	This routine obtains the driver reference number of the MacTCP
**	driver, which is needed for all TCP operation calls. The value
**	is stored in a static global variable, so that the other cul_TCP
**	routines can get it without excessive overhead.
*/

static OSErr
openTCPDriver(void)
{
	short refNum;
	OSErr err;
#if 0
	static char myName[] = "openTCPDriver";

	DBPRINTF(("Enter: %s\n", myName));
#endif

	if ((err = OpenDriver("\p.IPP", &refNum)) != noErr)
	{
		DBPRINTF(("openTCPDriver: Unable to open TCP Driver: %d\n",
			err));

		return(err);
	}

	/* Put driver ID in global variable */

	TCPDriverID = refNum;

#if 0
	DBPRINTF(("%s: Exit\n", myName));
#endif

	return(noErr);
}

/*
** TCPIOOp() -- Issue an asynchronous TCP operation
*/

static OSErr
cul_TCPIOOp(TCPiopb *const pb)
{
	struct cul_ExtendedDevCtlPB extendedPB;
	ThreadID wakerThId, ioThId;
	OSErr err;
	const char myName[] = "cul_TCPIOOp";

	/* Copy the I/O request into the local extended parameter block */

	(void) memcpy(&extendedPB.tcpiopb, pb, sizeof(*pb));

	GetCurrentThread(&ioThId);

	/* Initialize the taskRef field of the extended parameter block */

	if ((err = GetThreadCurrentTaskRef(&extendedPB.taskRef)) != noErr)
	{
		/* Report the error. Give up. */

		DBPRINTF(("%s[%s]: Unable to get taskRef: (%d)\n",
			myName, cul_prtThID(ioThId), err));

		pb->ioResult = err;

		return(err);
	}


	/* Initialize the ioThread field of the threadsToWake structure */

	extendedPB.threadsToWake.ioThread = ioThId;

	/*
	** Spawn the thread used to wake the thread making the I/O call.
	** This thread is just a backup, in case the asynchronous I/O
	** completion routine is executed before the I/O thread sleeps.
	** In the ideal case, the I/O thread will be awakened by the
	** completion routine and kill the backup thread.
	*/

	if ((err = NewThread(kCooperativeThread,
		(ThreadEntryProcPtr) wakerProc, &ioThId, 0,
		kNewSuspend | kUsePremadeThread | kCreateIfNeeded,
		(void **) 0, &wakerThId)) != noErr)
	{
		/* Report the error. Give up. */

		DBPRINTF(("%s[%s]: Unable to create waker thread: (%d)\n",
			myName, cul_prtThID(ioThId), err));

		pb->ioResult = err;

		return(err);
	}

	/*
	** Finish filling in the threadsToWake structure. These threads
	** will be awakened by the asynchronous I/O completion routine.
	*/

	extendedPB.threadsToWake.wakerThread = wakerThId;

	/* Set up the pointer to the completion routine */

	extendedPB.tcpiopb.ioCompletion = asyncWakeProcUPP;

	/* Make the asynchronous I/O call */

	if ((err = PBControl((ParmBlkPtr) &extendedPB, true)) != noErr)
	{
		/* Report the error. Give up. */

		DBPRINTF(("%s[%s]: Failed to initiate I/O operation: (%d)\n",
			myName, cul_prtThID(ioThId), err));

		/* Kill the waker thread */

		(void) DisposeThread(wakerThId, (void **) 0, true);

		pb->ioResult = err;

		return(err);
	}

	/* Wait for the I/O operation to complete */

	if ((err = SetThreadState(kCurrentThreadID, kStoppedThreadState,
		kNoThreadID)) != noErr)
	{
		/* Report the error. Give up. */

		DBPRINTF(("%s[%s]: Failed to suspend thread: (%d)\n",
			myName, cul_prtThID(ioThId), err));

		return(err);
	}

	/*
	** I/O Operation has completed. Attempt to kill waker thread.
	** It may have already died. That's OK.
	*/

	(void) DisposeThread(wakerThId, (void **) 0, true);

	/* Store the results in the original parameter block */

	(void) memcpy(pb, &extendedPB.tcpiopb, sizeof(*pb));

	return(pb->ioResult);
}

/*
** asyncWakeProc() -- Asynchronous I/O completion routine
**
**	asyncWakeProc() is used to wake the two sleeping threads
**	used in asynchronous I/O operations. Note that it is possible
**	the the I/O thread may not be sleeping if this routine is
**	executed very quickly after the I/O operation is completed.
**	This is OK; the waker thread will wait for the I/O thread
**	to go to sleep, then wake it.
**
** Notes:
**
**	Before making any changes, be sure you understand the restrictions
**	on code which runs in I/O completion routines. These routines are
**	executed in an interrupt context; the A5 world may not be valid.
*/

static void
asyncWakeProc(struct cul_ExtendedDevCtlPB *extendedPB)
{
	/* Wake the specified threads -- don't worry about errors */
	(void) SetThreadReadyGivenTaskRef(extendedPB->taskRef,
		extendedPB->threadsToWake.ioThread);
	(void) SetThreadReadyGivenTaskRef(extendedPB->taskRef,
		extendedPB->threadsToWake.wakerThread);
}

/*
** wakerProc() -- Wake I/O Thread
**
**	This procedure is a backup to the asynchronous I/O completion
**	routine for waking up the I/O thread. It is possible that the
**	asynchronous I/O completion routine will fire off before the
**	I/O thread has gone to sleep. If that's the case, the I/O thread
**	would then eventually sleep (forever). This routine is alway
**	awakened by the asynchronous I/O completion routine. It waits
**	for the I/O thread to sleep, then tries to wake it. Normally,
**	the I/O thread would have slept, been awakened by the
**	asynchronous I/O completion routine, then killed this thread.
*/

static pascal void
wakerProc(ThreadID *const ioThIdP)
{
	ThreadState ioThreadState;
	const char myName[] = "wakerProc";
	ThreadID wakerThId;
	OSErr err;

	GetCurrentThread(&wakerThId);

	/* Wait until I/O thread is sleeping */

	do
	{
		if ((err = GetThreadState(*ioThIdP, &ioThreadState)) != noErr)
		{
			/* Report the error. Give up. */
	
			DBPRINTF(("%s[%s]: I/O Thread not found!: (%d)\n",
				myName, cul_prtThID(wakerThId), err));
	
			/* Kill the waker thread */
	
			(void) DisposeThread(wakerThId, (void **) 0, true);

			/* Can never get here */

		}

		/* Is I/O thread sleeping? */

		if (ioThreadState == kStoppedThreadState)
		{
			/* Yes -- Wake the I/O thread */

			if ((err = SetThreadState(*ioThIdP, kReadyThreadState,
				*ioThIdP)) != noErr)
			{
				/* Report the error. Give up. */
		
				DBPRINTF(("%s[%s]: Unable to set state of I/O Thread: (%d)\n",
					myName, cul_prtThID(wakerThId), err));
		
				/* Kill the waker thread */
		
				(void) DisposeThread(wakerThId, (void **) 0, true);
	
				/* Can never get here */
	
			}

			else
				break;	/* Succeeded in waking I/O thread */
		}

		else
		{
			/* I/O Thread not sleeping -- wait */

			if ((err = YieldToThread(*ioThIdP)) != noErr)
			{
				/* Report the error. Give up. */
		
				DBPRINTF(("%s[%s]: Waker unable to yield: (%d)\n",
					myName, cul_prtThID(wakerThId), err));
		
				/* Kill the waker thread */
		
				(void) DisposeThread(wakerThId, (void **) 0, true);
	
				/* Can never get here */
	
			}
		}
	} while (1);

	(void) DisposeThread(wakerThId, (void **) 0, true);

	/* Can never get here */
}

/*
** cul_TCPOpen() -- Open a cul_Stream
**
**	cul_TCPOpen() opens a cul_Stream. This stream can later be
**	connected to a remote system or used to listen for incomming
**	connections from remote systems.
**
**	Note: This is a synchronous call.
*/

OSErr
cul_TCPOpen(cul_StreamPtr tcpStream)
{
	TCPiopb pb;
	OSErr err;
	char *myName = "cul_TCPOpen";
	ThreadID thID;
	if (GetCurrentThread(&thID) != noErr)
		thID = (ThreadID) kNoThreadID;

	DBPRINTF(("Enter: %s[%s]\n", myName, cul_prtThID(thID)));

	/* Make sure the cul_StreamPtr is not already in use */

	if ((tcpStream->magic == CUL_TCP_MAGIC_NUMBER)
		&& (tcpStream->state & CUL_TCPSTREAM_IN_USE))
	{
		DBPRINTF(("%s[%s]: Attempt to open busy cul_StreamPtr\n",
			myName, cul_prtThID(thID)));

		return(streamAlreadyOpen);
	}

	/* Clear out any garbage in the cul_StreamPtr passed in */

	memset(tcpStream, 0, sizeof(*tcpStream));

	/* Open the TCP Driver, if necessary */

	if (TCPDriverID == CUL_NO_TCP_DRIVER_ID)
		if ((err = openTCPDriver()) != noErr)
			return(err);

	/* Allocate memory for the TCP buffer */

	if ((tcpStream->TCPBuf = NewPtr(CUL_TCP_BUFSIZE)) == 0)
	{
		OSErr memErr;

		memErr = MemError();	/* Get reason for failure */
		
		DBPRINTF(("%s[%s]: Unable to allocate memory for TCP buffer (%d)\n",
			myName, cul_prtThID(thID), memErr));

		return(memErr);
	}

	/* Initialize the parameter block */

	memset(&pb, 0, sizeof(pb));

	/* Set up for TCPCreate call */

	pb.ioCRefNum = TCPDriverID;
	pb.csCode = TCPCreate;
	pb.csParam.create.rcvBuff = tcpStream->TCPBuf;
	pb.csParam.create.rcvBuffLen
		= tcpStream->TCPBufLen = CUL_TCP_BUFSIZE;

	/* Create the stream */

	if ((err = PBControl((ParmBlkPtr) &pb, false)) != noErr)
	{
		DBPRINTF(("%s[%s]: Error creating stream (%d)\n",
			myName, cul_prtThID(thID), err));

		/* Clean up before return */

		DisposePtr((Ptr) tcpStream->TCPBuf);

		memset(tcpStream, 0, sizeof(*tcpStream));

		return(err);
	}

	/* Set time-out parameters */

	tcpStream->TCPConnectWait = CUL_TCP_CONNECT_WAIT; /* time in secs */
	tcpStream->TCPListenWait = CUL_TCP_LISTEN_WAIT;   /* time in secs */
	tcpStream->TCPCloseWait = CUL_TCP_CLOSE_WAIT;	/* time in secs */
	tcpStream->TCPReadWait = CUL_TCP_READ_WAIT;		/* time in secs */
	tcpStream->TCPWriteWait = CUL_TCP_WRITE_WAIT;	/* time in secs */

	/* Note current state in tcpStream argument */

	tcpStream->magic = CUL_TCP_MAGIC_NUMBER;
	tcpStream->state |= CUL_TCPSTREAM_IN_USE;
	tcpStream->TCPStreamPtr = pb.tcpStream;

	/* Install the new stream ptr into the linked list of stream ptrs */

	ThreadBeginCritical();

	tcpStream->nextStream = cul_StreamPtrHdr;
	cul_StreamPtrHdr = tcpStream;

	ThreadEndCritical();

	DBPRINTF(("%s[%s]: Exit\n", myName, cul_prtThID(thID)));

	return(noErr);
}

/*
** cul_TCPClose() -- Close a cul TCP stream
**
**	cul_TCPClose() closes a TCP stream. It attempts to gracefully
**	shut down the connection to the remote host (if a connection
**	is open), then frees all resources associated with the stream.
**	In the event that the connection does not gracefully shut down
**	within the time limit, the connection will be forceably terminated.
*/

OSErr
cul_TCPClose(cul_StreamPtr tcpStream)
{
	TCPiopb pb;
	OSErr rlsErr;
	static char myName[] = "cul_TCPClose";
	ThreadID thID;
	if (GetCurrentThread(&thID) != noErr)
		thID = (ThreadID) kNoThreadID;

	DBPRINTF(("Enter: %s[%s]\n", myName, cul_prtThID(thID)));

	/* Is the tcpStream argument valid? */

	if ((tcpStream->magic != CUL_TCP_MAGIC_NUMBER)
		|| !(tcpStream->state & CUL_TCPSTREAM_IN_USE))
	{
		DBPRINTF(("Enter: %s[%s]tcpStream not in use\n",
			myName, cul_prtThID(thID)));

		return(invalidStreamPtr);
	}

	/* Does a close need to be issued on the stream? */

	if (tcpStream->state & CUL_TCPSTREAM_WRITEABLE)
	{
		OSErr err;
		long drainResult;
		ThreadID drainThId = kNoThreadID;

		/*
		** In order to close a stream, all data must be drained
		** from the pipeline. Spawn a child thread to handle this
		** task.
		*/

		if ((err = NewThread(kCooperativeThread,
			(ThreadEntryProcPtr) drainProc, tcpStream,
			CUL_TCP_THREAD_STACK_SIZE,
			kUsePremadeThread | kCreateIfNeeded, (void **) &drainResult,
			&drainThId)) != noErr)
		{
			/*
			** Report the error, but don't worry too much.
			** The release operation below will close the stream
			** even if some data has yet to be delivered. The
			** remote end might get an abort disconnect
			** message, however.
			*/

			DBPRINTF(("%s[%s]: Unable to create drain thread: (%d)\n",
				myName, cul_prtThID(thID), err));

			/* This is needed for the cul_WaitForThread() call, below */

			drainThId = kNoThreadID;	/* An invalid threadID */
		}

		/* Close the stream */

		if ((err = cul_TCPShutdown(tcpStream,
			CUL_TCP_SHUTDOWN_FOR_WRITING | CUL_TCP_SHUTDOWN_FOR_WRITING))
			!= noErr)
		{
			DBPRINTF(("%s[%s]: Error closing stream (%d)\n",
				myName, cul_prtThID(thID), err));

			/*
			** Note: The TCPRelease call which follows will
			** forceably close the stream with an abort operation.
			*/
		}

		/*
		** Wait for the drainer thread to terminate (it may
		** time out)
		*/

		if (drainThId != kNoThreadID)
			cul_WaitForThread(drainThId);
	}

	/* Dispose of the stream */

	memset(&pb, 0, sizeof(pb));

	/* Set up for TCPRelease call */

	pb.ioCRefNum = TCPDriverID;
	pb.csCode = TCPRelease;
	pb.tcpStream = tcpStream->TCPStreamPtr;

	if ((rlsErr = PBControl((ParmBlkPtr) &pb, false)) != noErr)
	{
		DBPRINTF(("%s[%s]: Error releasing stream (%d)\n",
			myName, cul_prtThID(thID), rlsErr));

		/*
		** This indicates a programming error. Attempting to
		** recover the resources used by this stream would
		** be dangerous, so just leave things are they are and
		** hope for the best.
		*/

		return(rlsErr);
	}

	/* Free the resources used by TCP */

	DisposePtr((Ptr) tcpStream->TCPBuf);

	/*
	** Remove the steam pointer from the linked list
	** of stream pointers
	*/

	ThreadBeginCritical();

	if (cul_StreamPtrHdr == tcpStream)	/* special case for list head */
	{
		cul_StreamPtrHdr = tcpStream->nextStream;
	}
	
	else
	{
		cul_StreamPtr streamPtr;

		streamPtr = cul_StreamPtrHdr;
	
		while (streamPtr->nextStream)
		{
			if (streamPtr->nextStream == tcpStream)
			{
				streamPtr->nextStream = tcpStream->nextStream;
			}
		}
	}

	ThreadEndCritical();

	/* Mark this cul_StreamPtr as free */

	memset(tcpStream, 0, sizeof(*tcpStream));

	DBPRINTF(("%s[%s]: Exit\n", myName, cul_prtThID(thID)));

	return(noErr);
}

/*
** drainProc() -- Routine to drain data out of TCP pipe
**
**	The semantics of the TCP close are that it signals the remote
**	machine that no more data will be sent down the pipe; the remote
**	machine receives EOF. From a programmer's perspective, close
**	usually means to completely shutdown a data stream, release the
**	resources, etc. This routine is a helper routine which allows
**	the cul_TCPClose() routine to present a more traditional version
**	of the close operation to programmers using TCP streams. It
**	simply reads and discards any incoming data until EOF is found.
**	The drainProc is called by an independent thread fired off by
**	the cul_TCPClose() routine, which has already signaled EOF to
**	the remote host. Presumably the remote host will act on receiving
**	EOF by closing its end of the TCP pipe, sending EOF back to the
**	local machine. This routine will then terminate the helper thread.
*/

static pascal void
drainProc(cul_StreamPtr tcpStream)
{
	OSErr err;
	char buf[CUL_TCP_DRAIN_BUF_SIZE];
	TCPiopb pb;
	unsigned long bytesRead;
	ThreadID curThreadID;
	long startTime;
	long timeRemaining;

	GetCurrentThread(&curThreadID);

	startTime = TickCount();

	memset(&pb, 0, sizeof(pb));

	/* Continue reading data until error, eof, or timeout */

	timeRemaining = tcpStream->TCPCloseWait -
		(TickCount() - startTime) / CLOCKS_PER_SEC;

	while ((timeRemaining = tcpStream->TCPCloseWait -
		(TickCount() - startTime) / CLOCKS_PER_SEC) > 0)
	{
		tcpStream->TCPReadWait = timeRemaining;

		/*
		** Attempt to read -- break out of loop on any error
		** except timeout.
		*/

		if (((err = cul_TCPReadNoCheck(tcpStream, buf, sizeof(buf),
			&bytesRead)) != noErr) && (err != commandTimeout))
			break;

		/* do nothing with received data */

	}

	/* Terminate drain thread */

	DisposeThread(kCurrentThreadID, 0, true);

	/* Can never get here */
}

/*
** cul_WaitForThread() -- Wait for a thread to terminate
**
**	cul_WaitForThread() uses a brute-force approach to wait for
**	a thread to terminate. It polls the state of the thread until
**	an error occurs, which will normally be threadNotFound.
*/

static void
cul_WaitForThread(ThreadID drainThId)
{
	ThreadState	state;

	while (GetThreadState(drainThId, &state) == noErr)
	{
		YieldToAnyThread();
	}
}

/*
** cul_TCPShutdown() -- Shut down a stream for reading and/or writing
**
**	cul_TCPShutdown() marks a stream as no longer available for
**	reading or writing, as specified by the mode parameter. There
**	doesn't appear to be much use for making a stream unreadable, 
**	but making it unwritable sends a close to the remote host, causing
**	the remote reader to receive EOF. This can be useful if it is
**	necessary to send some information, then receive an indeterminate
**	amount of data in response. The EOF causes the remote reader to
**	recognize the end of the initial request, but there is no limit
**	on the amount of data which can be received. This is in contrast
**	to a cul_TCPClose() operation, which sends the EOF but marks
**	the stream as being unreadable.
*/

OSErr
cul_TCPShutdown(cul_StreamPtr tcpStream, int mode)
{
	unsigned long streamState;
	TCPiopb pb;
	static char myName[] = "cul_TCPShutdown";
	ThreadID thID;
	if (GetCurrentThread(&thID) != noErr)
		thID = (ThreadID) kNoThreadID;

	DBPRINTF(("Enter: %s[%s]\n", myName, cul_prtThID(thID)));

	/* Is the tcpStream argument valid? */

	if ((tcpStream->magic != CUL_TCP_MAGIC_NUMBER)
		|| !(tcpStream->state & CUL_TCPSTREAM_IN_USE))
	{
		DBPRINTF(("Enter: %s[%s]tcpStream not in use\n",
			myName, cul_prtThID(thID)));

		return(invalidStreamPtr);
	}

	/*
	** Remember the state of the stream.
	*/

	streamState = tcpStream->state;

	/* Did the caller request a shutdown for reading? */

	if (mode & CUL_TCP_SHUTDOWN_FOR_READING)
	{
		tcpStream->state &= ~CUL_TCPSTREAM_READABLE;
	}

	/* Did the caller request a shutdown for writing? */

	if ((mode & CUL_TCP_SHUTDOWN_FOR_WRITING) &&
		(streamState & CUL_TCPSTREAM_WRITEABLE))
	{
		/* Yes -- issue a close on the stream */

		OSErr err;

		tcpStream->state &= ~CUL_TCPSTREAM_WRITEABLE;
		tcpStream->state |= CUL_TCPSTREAM_CLOSING;

		/* Initialize the parameter block */
	
		memset(&pb, 0, sizeof(pb));
	
		/* Set up for TCPClose call */
	
		pb.ioCRefNum = TCPDriverID;
		pb.csCode = TCPClose;
		pb.tcpStream = tcpStream->TCPStreamPtr;
		pb.csParam.close.ulpTimeoutValue = tcpStream->TCPCloseWait;
		pb.csParam.close.ulpTimeoutAction = 1;	/* abort */
		pb.csParam.close.validityFlags |=
			(timeoutValue | timeoutAction);

		/* Close the stream */

		if ((err = cul_TCPIOOp(&pb)) != noErr)
		{
			DBPRINTF(("%s[%s]: Error closing stream (%d)\n",
				myName, cul_prtThID(thID), err));

			/* Handle some special errors */

			err = cul_TCPHandleSpecialErrors(err, tcpStream);

			return(err);
		}
	}

	return(noErr);
}

/*
** cul_TCPConnect() -- Initiate a connection to a remote socket
**
**	cul_TCPConnect() attempts to connect a cul_Stream to a
**	remote socket.
*/

OSErr
cul_TCPConnect(cul_StreamPtr tcpStream, cul_IP_Addr *const localAddr,
	const cul_IP_Addr rmtAddr)
{
	TCPiopb pb;
	OSErr err;
	static char myName[] = "cul_TCPConnect";
	ThreadID thID;
	if (GetCurrentThread(&thID) != noErr)
		thID = (ThreadID) kNoThreadID;

	DBPRINTF(("Enter: %s[%s]\n", myName, cul_prtThID(thID)));

	/* Is the tcpStream argument valid? */

	if ((tcpStream->magic != CUL_TCP_MAGIC_NUMBER)
		|| !(tcpStream->state & CUL_TCPSTREAM_IN_USE))
	{
		DBPRINTF(("Enter: %s[%s]tcpStream not in use\n",
			myName, cul_prtThID(thID)));

		return(invalidStreamPtr);
	}

	if (tcpStream->state & CUL_TCPSTREAM_CONNECTED)
	{
		DBPRINTF(("Enter: %s[%s]tcpStream already connected\n",
			myName, cul_prtThID(thID)));

		return(connectionExists);
	}

	if (tcpStream->state & CUL_TCPSTREAM_LISTENING)
	{
		DBPRINTF(("Enter: %s[%s]tcpStream in listen mode\n",
			myName, cul_prtThID(thID)));

		return(invalidStreamPtr);
	}

	/*
	** Mark stream connected - this prevents other threads from
	** attempting to use it.
	*/
	
	tcpStream->state |= CUL_TCPSTREAM_CONNECTED;

	/* Set up for TCPActiveOpen call */

	memset(&pb, 0, sizeof(pb));

	pb.ioCRefNum = TCPDriverID;
	pb.csCode = TCPActiveOpen;
	pb.tcpStream = tcpStream->TCPStreamPtr;
	pb.csParam.open.ulpTimeoutValue = tcpStream->TCPConnectWait;
	pb.csParam.open.ulpTimeoutAction = 1;	/* abort */
	pb.csParam.open.validityFlags |=
		(timeoutValue | timeoutAction);
	pb.csParam.open.remoteHost = rmtAddr.addr;
	pb.csParam.open.remotePort = rmtAddr.port;
	pb.csParam.open.localPort = localAddr->port;

	/* Initiate the connect operation */

	if ((err = cul_TCPIOOp(&pb)) != noErr)
	{
		DBPRINTF(("%s[%s]: Error initiating connect operation (%d)\n",
			myName, cul_prtThID(thID), err));

		tcpStream->state &= ~CUL_TCPSTREAM_CONNECTED;

		return(err);
	}

	if (pb.ioResult)
	{
		DBPRINTF(("Unexpected non-zero result from call: %d\n", pb.ioResult));
	}

	{ int ii; for (ii = 0; ii < 256; ii++) YieldToAnyThread(); }
	/* Mark stream available for reading/writing */
	
	tcpStream->state |= (CUL_TCPSTREAM_READABLE | CUL_TCPSTREAM_WRITEABLE);

	/*
	** In case port was automatically assigned, pass it back to
	** the caller.
	*/

	localAddr->addr = pb.csParam.open.localHost;
	localAddr->port = pb.csParam.open.localPort;

	DBPRINTF(("%s[%s]: Exit\n", myName, cul_prtThID(thID)));

	return(noErr);
}

/*
** cul_TCPListen() --	Set up a cul_Stream to listen for
**						an incomming connection
*/

OSErr
cul_TCPListen(cul_StreamPtr tcpStream, cul_IP_Addr *const localAddr,
	cul_IP_Addr *const rmtAddr)
{
	TCPiopb pb;
	OSErr err;
	static char myName[] = "cul_TCPListen";
	ThreadID thID;
	if (GetCurrentThread(&thID) != noErr)
		thID = (ThreadID) kNoThreadID;

	DBPRINTF(("Enter: %s[%s]\n", myName, cul_prtThID(thID)));

	/* Is the tcpStream argument valid? */

	if ((tcpStream->magic != CUL_TCP_MAGIC_NUMBER)
		|| !(tcpStream->state & CUL_TCPSTREAM_IN_USE))
	{
		DBPRINTF(("Enter: %s[%s]tcpStream not in use\n",
			myName, cul_prtThID(thID)));

		return(invalidStreamPtr);
	}

	if (tcpStream->state & CUL_TCPSTREAM_CONNECTED)
	{
		DBPRINTF(("Enter: %s[%s]tcpStream already connected\n",
			myName, cul_prtThID(thID)));

		return(connectionExists);
	}

	/* Mark stream as "Listening" */

	tcpStream->state |= CUL_TCPSTREAM_LISTENING;

	/* Set up for TCPPassiveOpen call */

	memset(&pb, 0, sizeof(pb));

	pb.ioCRefNum = TCPDriverID;
	pb.csCode = TCPPassiveOpen;
	pb.tcpStream = tcpStream->TCPStreamPtr;
	pb.csParam.open.commandTimeoutValue = tcpStream->TCPListenWait;
	pb.csParam.open.ulpTimeoutValue = 0;	/* use default */
	pb.csParam.open.ulpTimeoutAction = 1;	/* abort */
	pb.csParam.open.validityFlags |=
		(timeoutValue | timeoutAction);
	pb.csParam.open.remoteHost = rmtAddr->addr;
	pb.csParam.open.remotePort = rmtAddr->port;
	pb.csParam.open.localPort = localAddr->port;

	/* Initiate the listen operation */

	if ((err = cul_TCPIOOp(&pb)) != noErr)
	{
		DBPRINTF(("%s[%s]: Error initiating connect operation (%d)\n",
			myName, cul_prtThID(thID), err));

		tcpStream->state &= ~CUL_TCPSTREAM_LISTENING;

		return(err);
	}

	/* Mark stream connected */
	
	tcpStream->state &= ~CUL_TCPSTREAM_LISTENING;
	tcpStream->state |= (CUL_TCPSTREAM_CONNECTED
		| CUL_TCPSTREAM_READABLE | CUL_TCPSTREAM_WRITEABLE);

	/* Pass the connection info back to the caller */

	rmtAddr->addr = pb.csParam.open.remoteHost;
	rmtAddr->port = pb.csParam.open.remotePort;
	localAddr->addr = pb.csParam.open.localHost;
	localAddr->port = pb.csParam.open.localPort;

	DBPRINTF(("%s[%s]: Exit\n", myName, cul_prtThID(thID)));

	return(noErr);
}

OSErr
cul_TCPRead(const cul_StreamPtr tcpStream, const void *const data,
	const unsigned long dataLen, unsigned long *const bytesRecd)
{
	OSErr rc;
	static char myName[] = "cul_TCPRead";
	ThreadID thID;

	if (GetCurrentThread(&thID) != noErr)
		thID = (ThreadID) kNoThreadID;

	DBPRINTF(("Enter: %s[%s]\n", myName, cul_prtThID(thID)));

	*bytesRecd = 0;	/* In case of failure */

	if ((tcpStream->magic != CUL_TCP_MAGIC_NUMBER)
		|| !(tcpStream->state & CUL_TCPSTREAM_IN_USE))
	{
		DBPRINTF(("%s[%s]:cul_StreamPtr not open\n",
			myName, cul_prtThID(thID)));

		return(invalidStreamPtr);
	}

	if (!(tcpStream->state & CUL_TCPSTREAM_READABLE))
	{
		DBPRINTF(("%s[%s]:cul_StreamPtr not valid for Read operation\n",
			myName, cul_prtThID(thID)));

		return((tcpStream->state & CUL_TCPSTREAM_CLOSING) ?
			connectionClosing : connectionDoesntExist);
	}

	/* Call the routine which actually reads the data */

	rc = cul_TCPReadNoCheck(tcpStream, data, dataLen, bytesRecd);

	DBPRINTF(("%s[%s]: Exit\n", myName, cul_prtThID(thID)));

	return(rc);
}

/*
** cul_TCPReadNoCheck() -- Read data without checking state
**
**	cul_TCPReadNoCheck() reads a stream without checking to see
**	if the state allows for reading. It is used by the close
**	routine to drain the pipe without allowing other threads to
**	attempt to read from the stream.
*/


static OSErr
cul_TCPReadNoCheck(const cul_StreamPtr tcpStream, const void *const data,
	const unsigned long dataLen, unsigned long *const bytesRecd)
{
	TCPiopb pb;
	OSErr err;
	static char myName[] = "cul_TCPReadNoCheck";
	ThreadID thID;
	if (GetCurrentThread(&thID) != noErr)
		thID = (ThreadID) kNoThreadID;

	DBPRINTF(("Enter: %s[%s]\n", myName, cul_prtThID(thID)));

	/* Note: cul_StreamPtr is validated by cul_TCPReadNoCheck() */

	/* Initialize the parameter block */

	memset(&pb, 0, sizeof(pb));

	/* Set up for TCPSend call */

	pb.ioCRefNum = TCPDriverID;
	pb.csCode = TCPRcv;
	pb.tcpStream = tcpStream->TCPStreamPtr;
	pb.csParam.receive.commandTimeoutValue = tcpStream->TCPReadWait;
	pb.csParam.receive.rcvBuffLen = dataLen;
	pb.csParam.receive.rcvBuff = data;

	*bytesRecd = 0;	/* In case of failure */

	/* Initiate the read operation */

	if ((err = cul_TCPIOOp(&pb)) != noErr)
	{
		DBPRINTF(("%s[%s]: Error in TCP recv operation (%d)\n",
			myName, cul_prtThID(thID), err));

		/* Handle some special errors */

		err = cul_TCPHandleSpecialErrors(err, tcpStream);
	}

	/* Return the number of bytes read to the user */

	*bytesRecd = pb.csParam.receive.rcvBuffLen;

	DBPRINTF(("%s[%s]: Exit\n", myName, cul_prtThID(thID)));

	return(err);
}

OSErr
cul_TCPWrite(const cul_StreamPtr tcpStream, const void *const data,
	const unsigned long dataLen)
{
	TCPiopb pb;
	OSErr err;
	wdsEntry wds[2];
	static char myName[] = "cul_TCPWrite";
	ThreadID thID;
	if (GetCurrentThread(&thID) != noErr)
		thID = (ThreadID) kNoThreadID;

	DBPRINTF(("Enter: %s[%s]\n", myName, cul_prtThID(thID)));

	/* Make sure the cul_StreamPtr is valid for writing */

	if ((tcpStream->magic != CUL_TCP_MAGIC_NUMBER)
		|| !(tcpStream->state & CUL_TCPSTREAM_IN_USE))
	{
		DBPRINTF(("%s[%s]:cul_StreamPtr not open\n",
			myName, cul_prtThID(thID)));

		return(invalidStreamPtr);
	}

	if (!(tcpStream->state & CUL_TCPSTREAM_WRITEABLE))
	{
		DBPRINTF(("%s[%s]:cul_StreamPtr not valid for Send operation\n",
			myName, cul_prtThID(thID)));

		return((tcpStream->state & CUL_TCPSTREAM_CLOSING) ?
			connectionClosing : connectionDoesntExist);
	}

	/* Initialize the parameter block */

	memset(&pb, 0, sizeof(pb));

	/* Set up for TCPSend call */

	pb.ioCRefNum = TCPDriverID;
	pb.csCode = TCPSend;
	pb.tcpStream = tcpStream->TCPStreamPtr;
	pb.csParam.send.ulpTimeoutValue = tcpStream->TCPWriteWait;
	pb.csParam.send.validityFlags = timeoutValue;
	pb.csParam.send.wdsPtr = (Ptr) wds;

	memset(wds, 0, sizeof(wds));
	wds[0].length = dataLen;
	wds[0].ptr = data;

	/* Initiate the write operation */

	if ((err = cul_TCPIOOp(&pb)) != noErr)
	{
		DBPRINTF(("%s[%s]: Error in TCP send operation (%d)\n",
			myName, cul_prtThID(thID), err));

		/* Handle some special errors */

		err = cul_TCPHandleSpecialErrors(err, tcpStream);
	}

	DBPRINTF(("%s[%s]: Exit\n", myName, cul_prtThID(thID)));

	return(err);
}

/*
** cul_TCPHandleSpecialErrors() -- Common error handler
**
**	Some errors are best handled by modifying the state of
**	a cul_Stream. Since the way in which this is done doesn't
**	vary based on the routine in which the error occurs, this
**	common code has been placed in a subroutine.
*/

static OSErr
cul_TCPHandleSpecialErrors(OSErr err, cul_StreamPtr tcpStream)
{
	switch (err)
	{
		case connectionDoesntExist:

			tcpStream->state = CUL_TCPSTREAM_IN_USE;
			break;

		case connectionTerminated:

			tcpStream->state = CUL_TCPSTREAM_IN_USE;
			break;
	}

	return(err);
}

/*
** cul_KillIP() -- Kill all TCP/IP operations for this process
**
**	Because the routines in this library employ asynchronous
**	completion procedures, and the Mac "OS" is too stupid to
**	abort pending asynchronous completion routines (or even
**	close TCP connections) when the associated application
**	terminates, there is a chance that the completion routines
**	can fire off and corrupt memory after the application has
**	terminated. This is generally considered to be a bad thing.
**	So, to work around YAF (yet another flaw) in the "system",
**	this routine is provided. It goes through the list of
**	cul_Streams, closing each one down.
*/

void
cul_TCPKill()
{
#define CUL_MAX_STREAMS_TO_KILL 16
	unsigned long i;
	unsigned long done = 0;
	OSErr err;
	ThreadID thID;
	cul_StreamPtr nextStream;
	char *myName = "cul_TCPKill";

	nextStream = cul_StreamPtrHdr;

	while (nextStream)
	{
		/*
		** The kill operations are initiated in a critical section
		** to prevent the linked list from being changed while it
		** is being traversed by the helper threads.
		*/

		ThreadBeginCritical();

		for (i = 0; i < CUL_MAX_STREAMS_TO_KILL && nextStream; i++)
		{
			struct cul_killInfo info;

			info.streamPtr = nextStream;
			info.done = &done;

			/* Create a thread to close the stream */

			if ((err = NewThread(kCooperativeThread,
				(ThreadEntryProcPtr) cul_killStream, &info, 0,
				kUsePremadeThread | kCreateIfNeeded,
				(void **) 0, &thID)) != noErr)
			{
				/* Report the error. Give up. */
		
				DBPRINTF(("%s: Unable to create killer thread: (%d)\n",
					myName, err));
			}

			nextStream = nextStream->nextStream;

			done++;	/* Bump up the count of active killers */

		}

		ThreadEndCritical();

		/*
		** Here's where we wait for the helper threads to kill
		** the IP connections
		*/

		while (done)
			YieldToAnyThread();

		/* Since linked list has been changed, start at the beginning */

		nextStream = cul_StreamPtrHdr;
	}

	ThreadEndCritical();
}

/*
** cul_killStream() -- Thread which closes a stream
**
**	cul_killStream() is the body of the thread which kills
**	a TCP stream. It calls the close routine to close down
**	the stream and release its resources. The process of releasing
**	the resources should cause any pending asynchronous completion
**	routines to return an error.
*/

static pascal void
cul_killStream(struct cul_killInfo *info)
{
	/* Close the stream */

	(void) cul_TCPClose(info->streamPtr);

	ThreadBeginCritical();

	(*(info->done))--;

	ThreadEndCritical();

	/* Our work is done. */

	DisposeThread(kCurrentThreadID, 0, true);
}
