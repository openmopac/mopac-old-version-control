/*
** eol.c -- Code to convert end of line characters between
**			network and native forms
*/

#ifndef _CACHE_LIMITS
#define _CACHE_LIMITS
#include <limits.h>
#endif /* _CACHE_LIMITS */

#include "cul.h"

/*
** Convert from host to net end of line
*/

void
cul_h2neol(char *buf)
{
	cul_h2nneol(buf, (unsigned long)ULONG_MAX);
}

/*
** Convert from host to net end of line with count.
**
** Note: If the count is exceeded, no trailing end of line
** will be added to the string.
*/

void
cul_h2nneol(char *buf, const unsigned long count)
{
	char *s, *d;	/* source and dest */
	unsigned long processed = 0;
	register char c;

	/* initialize buffer pointers */

	s = d = buf;

	while (processed < count)
	{
		c = *(s++);
		processed++;

		/*
		** If the character under consideration is an end of line
		** character, see if the other end of line character follows.
		** If so, assume that they signify a single end of line.
		*/

		if (c == '\n')
		{
			*(d++) = CUL_NETEOL;

			if (*s == '\r')
			{
				s++;
				processed++;
			}
		}
		
		else if (c == '\r')
		{
			*(d++) = CUL_NETEOL;

			if (*s == '\n')
			{
				s++;
				processed++;
			}
		}
		
		else	/* Not an end of line, just copy the data */
		{
			*(d++) = c;
		}

		/* Terminate processing on null character */

		if (c == '\0')
			break;
	}
}

/*
** Convert from network to host (native) end of line
*/

void
cul_n2heol(char *buf)
{
	cul_n2hneol(buf, (unsigned long)ULONG_MAX);
}

/*
** Convert from network to host (native) end of line
**
** Note: If the count is exceeded, no trailing end of line
** will be added to the string.
*/

void
cul_n2hneol(char *buf, const unsigned long count)
{
	register char c;
	unsigned long processed = 0;

	while (processed < count)
	{
		c = *buf;

		/*
		** If the character is the end of line marker, substitute
		** the native end of line character. Else, leave the data
		** alone.
		*/

		if (c == CUL_NETEOL)
			*buf = '\n';

		buf++;
		processed++;

		/* Terminate processing on null character */

		if (c == '\0')
			break;
	}
}
