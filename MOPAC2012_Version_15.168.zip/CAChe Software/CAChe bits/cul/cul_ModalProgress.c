/*
** cul_ModalProgress.c -- Routines to display a modal progress dialog
*/

#include "compat.h"
#include <Memory.h>
#include <Dialogs.h>
#include <Controls.h>
#include <Events.h>
#include <OSEvents.h>
#include <String.h>

#include "cul.h"
#include "cul_ResIDs.h"

/*
** cul_InitModalProgress() -- Put the modal progress dialog on the screen
*/

static DialogPtr cul_MP_DBox = 0;

int
cul_InitModalProgress(const char *const text)
{
	Rect sbox, box, Progress_rectH;
	short type;
	char local_text[256];
	ControlHandle whichControlH;
	GrafPtr savePort;

	/* Get the dialog describing the progress window */

	cul_MP_DBox = GetNewDialog(CUL_MP_ID, NULL, (WindowPtr) -1);

	/* Make it active */

	GetPort(&savePort);
	SetPort(cul_MP_DBox);

	/* Get the bounds of the progress bar and draw a frame around it */

	GetDItem(cul_MP_DBox, 2, &type, (Handle *)&Progress_rectH, &sbox);
	FrameRect(&sbox);

	/*
	** Insert the specified text, if any.
	**
	** If a non-null ptr to a non-null string was specified�
	*/

	if (text && *text)	
	{
		GetDItem(cul_MP_DBox, 1, &type, (Handle *)&whichControlH,
			&box);
		strncpy(local_text, text, sizeof(local_text));
		local_text[sizeof(local_text) - 1] = 0;
		SetIText((Handle)whichControlH, CTOPSTR(local_text));
	}

	/* Put it on the screen */

	DrawDialog(cul_MP_DBox);
	
	/* Use an arrow cursor */

	SetCursor(&qd.arrow);

	SetPort(savePort);
	return(noErr);
}

/*
** cul_ModalProgress() -- Set the % done of the modal progress dialog
**
**	cul_ModalProgress() is called to update the progress bar. It
**	checks to see if the user wants to abort processing by looking
**	for command-period or a click in the 'cancel' button. If the
**	user aborts, it automatically dismisses the dialog box.
*/

int
cul_ModalProgress(const double fraction_done)
{
	Rect sbox;
	long length;
	short type;
	ControlHandle Progress_rectH, whichControlH;
	EventRecord theEvent;
	Point eventPoint;
	short partcode;
	long endOfsbox;
	GrafPtr savePort;

	GetPort(&savePort);
	SetPort(cul_MP_DBox);

	/* Get the bounds of the progress bar and draw a frame around it */

	GetDItem(cul_MP_DBox, 2, &type, (Handle *)&Progress_rectH, &sbox);
	FrameRect(&sbox);

	/* Update the progress bar */

	InsetRect(&sbox, 1, 1);
	endOfsbox = sbox.right;
	length = sbox.right - sbox.left;
	sbox.right = sbox.left + (double)length * fraction_done;

	FillRect(&sbox, &qd.dkGray);

	sbox.left = sbox.right;
	sbox.right = endOfsbox;
	EraseRect(&sbox);

	/* Does the user want to stop? */

	if (GetNextEvent(mDownMask + mUpMask + keyDownMask + keyUpMask,
		&theEvent))
	{
		/* did the user to a command period? */

		if (theEvent.what == keyDown && (theEvent.modifiers & cmdKey))
		{
			if ((theEvent.message & keyCodeMask) >> 8 == 47)
			{
				/* Dismiss the dialog box */

				SetPort(savePort);
				DisposDialog(cul_MP_DBox);
				cul_MP_DBox = 0;

				/* Clear out any spurious clicks or keystrikes */

				FlushEvents(mDownMask + mUpMask + keyDownMask
					+ keyUpMask, 0);

				return -1;
			}
		}

		/* The user did a mouse click; Is it in the cancel button? */

		eventPoint = theEvent.where;
		GlobalToLocal(&eventPoint);
		if ((partcode = FindControl(PASSPT eventPoint,
			cul_MP_DBox, &whichControlH)) != 0)
		{
			if (TrackControl(whichControlH, PASSPT eventPoint, 0)
				== partcode)
			{
				/* Dismiss the dialog box */
	
				SetPort(savePort);
				DisposDialog(cul_MP_DBox);
				cul_MP_DBox = 0;
	
				/* Clear out any spurious clicks or keystrikes */
	
				FlushEvents(mDownMask + mUpMask + keyDownMask
					+ keyUpMask, 0);
	
				return -1;
			}
		}
	}

	SetPort(savePort);

	return(noErr);
}

/*
** cul_DismissModalProgress() -- Dismiss the modal-progress dialog
**
**	This routine is called to dismiss the modal progress dialog
**	when processing is complete. Note that the dialog is
**	automatically dismissed if the user cancels processing.
*/

void
cul_DismissModalProgress()
{
	if (cul_MP_DBox)
	{
		DisposDialog(cul_MP_DBox);
		cul_MP_DBox = 0;
	}
}

