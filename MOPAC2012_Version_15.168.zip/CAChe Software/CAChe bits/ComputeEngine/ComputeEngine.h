/*
** ComputeEngine.h
*/

#ifndef _COMPUTE_ENGINE_H_
#define _COMPUTE_ENGINE_H_

#include <windows.h>
#include <stdio.h>

#include <ServerStepQueue.h>
#include <ccl.h>
#include <ccl_Msgs.h>
#include <ccl_Event.h>

const char CE_PATH_SEPARATOR = '\\';

enum ce_State {
    CE_STATE_CREATING,
    CE_STATE_INITING,
    CE_STATE_RUNNING,
    CE_STATE_DONE,
    CE_STATE_TERMINATED
};

enum ce_Err {
    ce_Err_None = 0,
    ce_Err_CEM_Recv_Creation_Failed,
    ce_Err_CEM_Recv_Comm_Failure,
    ce_Err_Event_Creation_Failed,
    ce_Err_Msg_Connection_Creation_Failed,
    ce_Err_Main_Creation_Failed,
    ce_Err_LogMgr_Creation_Failed,
    ce_Err_Comp_Creation_Failed,
    ce_Err_Disconnect_Msg,
    ce_Err_Bad_Msg,
    ce_Err_Dummy
};

enum ce_Boolean {
    ce_Boolean_False = 0,
    ce_Boolean_True,
    ce_Boolean_Err
};

#if defined(DBPRINTF)
#undef DBPRINTF
#endif

#if defined(_DEBUG)
#define DBPRINTF(xargs) (ce_DebugPrintf xargs )
#else
#define DBPRINTF(xargs) ((void) 0)
#endif

const unsigned int CE_FILE_NAME_SIZE=256;
const unsigned long CE_DEFAULT_STACKSIZE=100*1024;

class ComputeEngine;

typedef HANDLE ce_Thread;
typedef unsigned ce_ThreadID;
typedef HANDLE ce_Process;
typedef DWORD ce_ProcessID;

typedef ce_State ce_Main_State;

class CE_Main {

    enum MAIN_EVTS {
        MAIN_OSTERM = 0,
        MAIN_CEMRECVEXIT,
        MAIN_STOP,
        MAIN_CECONTEXIT,
        MAIN_NUMBER_OF_EVTS
    };

    ccl_Event *m_MainEvents[MAIN_NUMBER_OF_EVTS];

public:
    ComputeEngine *m_ce;
    ce_Err m_status;
    ce_Main_State m_state;

    ce_Thread m_thread;
    ce_ThreadID m_threadID;

    ce_Thread m_threadComp;
    ce_ThreadID m_threadIDComp;
    unsigned long m_stacksize;

    ccl_Event *m_exit_evt;

    CE_Main(void);
    ~CE_Main(void);
    ce_Boolean Init(ComputeEngine *ce);
    void Term(void);
    void Run(void);
    void Exit(void);
    void StartComp(void);
    void WaitComp(void);
};

typedef ce_State ce_CEM_Recv_State;

class CE_CEM_Recv {

public:
    ComputeEngine *m_ce;
    ce_Err m_status;
    ce_CEM_Recv_State m_state;
    ce_Thread m_thread;
    ce_ThreadID m_threadID;
    ccl_Event *m_exit_evt;
    ccl_MsgConnection *m_msg_connection;
    
    CE_CEM_Recv(void);
    ~CE_CEM_Recv(void);
    ce_Boolean Init(ComputeEngine *ce, ccl_MsgConnection *msgConnection);
    void Term(void);
    void Run(void);
    void Exit(void);
    ccl_Msg *GetNextMessage(void);
    ce_Err DispatchMessage(ccl_Msg *msg);
    void Disconnect(void);
};
    
#if defined(_WIN32)
typedef HANDLE PORTHANDLE;
#elif defined(unix)
typedef int PORTHANDLE;
#endif

class ComputeEngine {

public:
    ce_Boolean m_standalone;
    ce_Process m_process;
    ce_ProcessID m_processID;
    ce_Thread m_thread;
    ce_ThreadID m_threadID;
    ce_Boolean m_debugFlag;
    ce_State m_state;
    long m_status;
    char *m_copyright;
    char *m_version;
    char m_programName[CE_FILE_NAME_SIZE];
    
    PORTHANDLE m_rPort;
    PORTHANDLE m_rPortAck;
    PORTHANDLE m_sPort;
    PORTHANDLE m_sPortAck;
    ccl_MsgConnection *m_msg_connection;
    int m_argc;
    char **m_argv;
    HWND m_hWnd;
    
    ssq_FileTransferList *m_inputFileList;
    
    FILE *m_logFile;
    char *m_logFileBaseName;
    char m_logFileName[CE_FILE_NAME_SIZE];
    
    // active objects
    CE_Main *m_main;
    CE_CEM_Recv *m_cem_recv;
    
    // events objects
    ccl_Event *m_os_term_evt;
    ccl_Event *m_cem_recv_exit_evt;
    ccl_Event *m_main_exit_evt;
    ccl_Event *m_continue_evt;
    ccl_Event *m_stop_evt;
    
    // member functions
    ComputeEngine(void);
    ~ComputeEngine(void);
    
    ce_Boolean Init(int argc, char **argv, HWND hWnd);
    int Term(void);
    
    ce_Boolean Send_CEM_Status(unsigned int channel, char *status, unsigned char flag);
    ce_Boolean Send_CEM_DoProc(unsigned char flag);
    void ResetLogFile(void);
    ce_Boolean AddInputFile(unsigned long cftype, char *fileName);
    virtual void ParseOtherFlags(char *p);
    virtual void DoComputation(void);
    virtual unsigned long StackSize(void);

    // windows message handlers
    virtual LRESULT WmPaint(HWND hWnd, UINT message, WPARAM uParam, LPARAM lParam);
    virtual LRESULT WmCopyData(HWND hWnd, UINT message, WPARAM uParam, LPARAM lParam);
};

//
// Function prototypes
//

#if defined(__cplusplus)
extern "C" {
#endif
 
BOOL ce_InitApplication( HINSTANCE hInstance,
                         const char* szAppName,
                         int iconId );

BOOL ce_InitInstance( HINSTANCE hInstance,
                      int nCmdShow,
                      const char* szAppName,
                      const char* szTitle,
                      ComputeEngine* ce,
                      HWND* hWnd );

int ce_WinMain( HINSTANCE hInstance,
                HINSTANCE hPrevInstance,
                LPSTR lpCmdLine,
                int nCmdShow );

void ce_DebugPrintf(char *fmt, ...);

void ce_SetThreadTag(char* tag);

void SpecificKillDumbCE(void);

#if defined(__cplusplus)
}
#endif

#endif /* _COMPUTE_ENGINE_H_ */
