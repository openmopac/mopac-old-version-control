Chemical detection & modification
