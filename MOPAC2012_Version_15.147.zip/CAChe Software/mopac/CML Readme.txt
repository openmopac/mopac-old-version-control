Hi Peter,

Anna and I really enjoyed your visit.  I'm sure the Eagans had a great time, too, at the B&E.
You must come back soon!

Here is a first draft of my message to you on how I think we should proceed.  Please look
it over, and edit it as you think fit.  Once we're both happy, I'll send you instructions 
on downloading the modified version of MOPAC that conforms with the message.

Best wishes,

Jimmy

(I've written this in a slightly formal style, as I expect you'll want to pass it on to Nick.)

From our discussion here on the CML work you're doing with MOPAC2007, we decided the issues were:

I want as little CML specific code in MOPAC as possible.
I don't want any preprocessor statements (ifdef) in the code.
You want to extract all useful information from a MOPAC run.
You want to be up-to-date with the top copy of MOPAC2007


After some discussion we decided that best course of action was as follows:

I would edit MOPAC2007 to add statements of the type "call to_screen("To_file: Start of reading in data")"
I would write a rough version of a subroutine called "to_screen" for you.
This would show the style we developed of how to communicate between MOPAC2007 and your CML software.

Essentially: 

At various points in MOPAC, it will call to_screen, and pass a single argument - a text string.
If the string starts with "To_file:" you will know that it is intended for you to process.
In to_screen, a series of "if ... then" statements would detect various options.
You would then add your own CML-specific code to to_screen, only.  That is, you would edit to_screen,
to do what you want it to do, and you would not send your copy of to_screen to me.
You would not need to edit any of the MOPAC source code.
All the quantities in MOPAC that you need are in the modules, specifically:

  common_arrays_C   
  molkst_C
  to_screen_C  (this is a new module, written to allow subroutine to_screen to have access to special data.)

These are now annotated alongs the lines suggested by you

I've written a draft version of to_screen for you. Because I don't have access to your CML code,
I've commented out the calls to that code.  To activate it, delete the three characters "!X!" from each line that contains them.

I've added enough types of call to to_screen to let you see how it should work.

Please edit to_screen to get it to do what you want it to do.
Please edit other parts of MOPAC as necessary, to add calls of "to_screen".  
Use the existing calls as a model.
The order in which I've put the parsed interception of the to_screen strings is clumsy - you might
want to re-sequence them to correspond with your own preferences.
Once you've made all the changes to MOPAC2007 source code, please send me the changed code, and 
I'll add it to the new top copy.  That way we'll stay in synch.

There were a couple of points I was not clear on:

In readmo.f90 there is a lot of code added to handle CML requirements.
But the only operation done is to write out the Cartesian coordinates.
Could this operation be moved to just after "call readmo" in "run_mopac"?

Every time "matou1.f90" is called, the array contents are written to CML.
But there is no indication of what is being written.
Do you need to know what is being written out in matou1?



