#include <compat.h>
#include <cpu.h>
#include "MOPACDriver.h"
#include "MOPACLib_Protos.h"

void alert_user_watch(char *errs)
{
	/*  ASSUMES that we are currently in the busy state */
	leaveBusyState();
	alert_user(errs);
	enterBusyState();
}

void inform_user_watch(char *errs)
{
	/*  ASSUMES that we are currently in the busy state */
	leaveBusyState();
	inform_user(errs);
	enterBusyState();
}

void instruct_user_watch(char *errs)
{
	/*  ASSUMES that we are currently in the busy state */
	leaveBusyState();
	instruct_user(errs);
	enterBusyState();
}
