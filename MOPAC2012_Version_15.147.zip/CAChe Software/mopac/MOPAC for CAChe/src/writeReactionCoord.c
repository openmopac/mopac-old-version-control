#include <compat.h>

#if defined(_WIN32)
#include <windows.h>
#endif

#include <math.h>
#include <ServerStepQueue.h>

#if defined(unix)
#include <UnixAppMgr.h>
#endif

#include <CACheFileLibAD.h>
#include <CACheFileLib.h>
#include <cpu.h>
#include <MOPACDriver.h>
#include <CACheFileTypes.h>

extern FILE *movie_fp;
extern char mv_name[32];
int UpdateBondOrders(MolStruct *molStruct,  FILE *MOPACoutput, long NAtoms,
                     MoleculeInfo *moleculeInfo, float *bond_order, long numberBonds,
                     bool first);

int writeReactionCoord( MolStruct *molStruct, MoleculeInfo *moleculeInfo, 
                        int numSearchLabels, double coord_shift[], 
                        short outputCalcNumber, Boolean ProcessMOPACoutput )
{
    int i, j, n, units, rtn_code;
    long istep, lastFrame;
    FILE *MOPACoutput = NULL;
    char string[256];
    double (*tmpcoord)[3] = NULL;
    float *pcharge = NULL;
    float *pchrg = NULL, zero;
    float *bond_order = NULL;
    float (*xyz)[3] = NULL;
    float low_value, high_value;
    int NAtoms, NAtoms_in_output, NAtoms_incl_dummy;
    ObjclsID offset;
    Zmatrix *zMatrix = NULL;
    double *temp_coord = NULL;
    long *nuclearNumber = NULL, numberBonds;
    long *indexWithoutDummy = NULL;
    Boolean cartesianCoords = false, first;
    int num_steps;
    char errs[256];
    ObjectID (*bondList)[2] = NULL;

    MOP_YIELD();

    if ((MOPACoutput = fopen(MOPACOutputFile, "r")) == NULL) {
        alert_user("writeReactionCoord: Unable to open MOPAC Output.");
        goto errorReturn;
    }
 DebugBreak();
    for (;;) { /* find the reaction coordinate listing */
        if (cfl_fgets(string, sizeof(string), MOPACoutput) == 0) break;
        if (strncmp(string, "           POINTS ON REACTION COORDINATE", 40) == 0)
            break;
    }
    /* Get the number of steps from the output file */
    for (num_steps=0, j=0;;j++) {
        float values[8];
        if (cfl_fgets(string, sizeof(string), MOPACoutput) == 0) 
            break;
        i = sscanf(string,"%f %f %f %f %f %f %f %f\n",
                &values[0],&values[1],&values[2],&values[3],
                &values[4],&values[5],&values[6],&values[7]);
        if (i > 0) {
            num_steps += i;
            if (j == 0)
                low_value = values[0];
            high_value = values[i-1];
        } else
            break;
    }
    if (num_steps == 0) {
        alert_user("writeReactionCoord:  output file does not correspond to a reaction coordinate.");
        goto errorReturn;
    }
    
    /* Determine the true number of atoms in the output so that dummy
       atoms will be handled correctly */
    for (;;) { /* find beginning of first Z-matrix listing */
        if (cfl_fgets(string, sizeof(string), MOPACoutput) == 0) break;
        if (strncmp(string,
             "   (I)                   NA:I          NB:NA:I       NC:NB:NA:I",
             63) == 0)
            break;
    }
    for (NAtoms_in_output=0,NAtoms_incl_dummy=0;;) {
        if (cfl_fgets(string, sizeof(string), MOPACoutput) == 0) break;
        if (strlen(string) > 2) {
            NAtoms_incl_dummy++;
            if (strncmp(&string[11],"XX",2) != 0) /* don't count dummy atoms */
                NAtoms_in_output++;
        }
        else
            break;
    }
    if (NAtoms_in_output == 0) {
        alert_user("writeReactionCoord: no atoms in MOPAC Output file.");
        goto errorReturn;
    }

    cartesianCoords = true;
    ProcessMOPACoutput = true;

    if ( (indexWithoutDummy = (long *) malloc(sizeof(long)*NAtoms_incl_dummy)) == NULL )
    {
        alert_user("writeReactionCoord: Unable to allocate indexWithoutDummy array");
        goto errorReturn;
    }

    if ( (nuclearNumber = (long *) malloc(sizeof(long)*NAtoms_incl_dummy)) == NULL )
    {
        alert_user("writeReactionCoord: Unable to allocate nuclearNumber array");
        goto errorReturn;
    }

    // Initialize the search labels

    for ( i=0; i < numSearchLabels; i++ )
    {
        moleculeInfo->searchLabels[i].objclsID = -1;
        moleculeInfo->searchLabels[i].atomList[0] = 0;
    }

    moleculeInfo->searchLabels[0].numSteps = num_steps - 1;

    fseek(MOPACoutput,0,0);

    while ( cfl_fgets(string, sizeof(string), MOPACoutput) != NULL )
    {
        if ( sscanf(string, " FINAL HEAT OF FORMATION %[=]", errs) == 1 )
            break;
    }

    for ( n=0; n < num_steps; n++ )
    {
        int na, nb, nc;
        double va, vb, vc;
        char sym[3], sa, sb, sc;

        Boolean foundZMatrix = false;

        while ( cfl_fgets(string, sizeof(string), MOPACoutput) != NULL )
        {
            if ( sscanf(string, " (I) NA:I NB:NA:I NC:NB:NA:I NA NB N%[C]", errs) == 1 )
            {
                foundZMatrix = true;
                break;
            }
        }

        if ( !foundZMatrix )
            break;

        for ( i=0, j=0; i < NAtoms_incl_dummy; i++ )
        {
            if ( cfl_fgets(string, sizeof(string), MOPACoutput) == NULL )
                break;

            memset(sym,0,3);

            sa = sb = sc = '?';

            switch (i) // Read various lines of the Z-matrix
            {
                case 0: // 1st line
                    sscanf(string, " %*d %[A-Za-z] ( %*d ) %lf %lf %lf",
                                    sym, &va, &vb, &vc );
                    break;
                case 1: // 2nd line
                    sscanf(string, " %*d %[A-Za-z] ( %*d ) %lf %c %lf %lf %d",
                                    sym, &va, &sa, &vb, &vc, &na );
                    break;
                case 2: // 3rd line
                    sscanf(string, " %*d %[A-Za-z] ( %*d ) %lf %c %lf %c %lf %d %d",
                                    sym, &va, &sa, &vb, &sb, &vc, &na, &nb );
                    break;
                default: // all other lines
                    sscanf(string, " %*d %[A-Za-z] ( %*d ) %lf %c %lf %c %lf %c %d %d %d",
                                    sym, &va, &sa, &vb, &sb, &vc, &sc, &na, &nb, &nc );
                    break;
            }

            if ( n == 0 ) // first frame
            {
                nuclearNumber[i] = determineAtomicNumber(sym);

                if ( nuclearNumber[i] == 54 )
                    indexWithoutDummy[i] = -1;
                else
                    indexWithoutDummy[i] = moleculeInfo->locationWithoutDummies[j++];

                if ( sa == '+' ) // distance label
                {
                    moleculeInfo->searchLabels[0].atomList[0] = 2;
                    moleculeInfo->searchLabels[0].objclsID = Atom_distID;
                    moleculeInfo->searchLabels[0].atomList[1] = indexWithoutDummy[i];
                    moleculeInfo->searchLabels[0].atomList[2] = indexWithoutDummy[na-1];
                    moleculeInfo->searchLabels[0].lowValue = va;
                    moleculeInfo->searchLabels[0].highValue = va;
                } else if ( sb == '+' ) /* angle label */ {
                    moleculeInfo->searchLabels[0].atomList[0] = 3;
                    moleculeInfo->searchLabels[0].objclsID = Bond_angID;
                    moleculeInfo->searchLabels[0].atomList[1] = indexWithoutDummy[i];
                    moleculeInfo->searchLabels[0].atomList[2] = indexWithoutDummy[na-1];
                    moleculeInfo->searchLabels[0].atomList[3] = indexWithoutDummy[nb-1];
                    moleculeInfo->searchLabels[0].lowValue = vb;
                    moleculeInfo->searchLabels[0].highValue = vb;
                } else if ( sc == '+' ) /* dihedral label */ {
                    moleculeInfo->searchLabels[0].atomList[0] = 4;
                    moleculeInfo->searchLabels[0].objclsID = DihedralID;
                    moleculeInfo->searchLabels[0].atomList[1] = indexWithoutDummy[i];
                    moleculeInfo->searchLabels[0].atomList[2] = indexWithoutDummy[na-1];
                    moleculeInfo->searchLabels[0].atomList[3] = indexWithoutDummy[nb-1];
                    moleculeInfo->searchLabels[0].atomList[4] = indexWithoutDummy[nc-1];
                 // Do NOT use the value of the search label, if it is a dihedral.
                 // The angle might be out by 360 degrees.
                 // moleculeInfo->searchLabels[0].lowValue = vc;
                 // moleculeInfo->searchLabels[0].highValue = vc;
                }

            } else {

                if ( sa == '+' )
                    moleculeInfo->searchLabels[0].highValue = va;
                else if ( sb == '+' )
                    moleculeInfo->searchLabels[0].highValue = vb;
             // Do NOT use the value of the search label, if it is a dihedral.
             // The angle might be out by 360 degrees.
             // else if ( sc == '+' )
             //     moleculeInfo->searchLabels[0].highValue = vc;
            }
        }
    }

    if ( moleculeInfo->searchLabels[0].lowValue == moleculeInfo->searchLabels[0].highValue )
    {
        /* use values from begining of output file */
        moleculeInfo->searchLabels[0].lowValue = (double) low_value;
        moleculeInfo->searchLabels[0].highValue = (double) high_value;
    }

    // Don't attempt to create search labels that have dummy atoms

    for ( n=0; n < moleculeInfo->searchLabels[0].atomList[0]; n++ )
    {
        if ( moleculeInfo->searchLabels[0].atomList[n+1] < 0 )
        {
            moleculeInfo->searchLabels[0].atomList[0] = 0;
            break;
        }
    }

    // And finally, put the search label in the molstruct

    if ( moleculeInfo->searchLabels[0].atomList[0] > 0 )
    {
        CSUObj objs[4];
        ObjectID index;

        for ( n=0; n < moleculeInfo->searchLabels[0].atomList[0]; n++ )
        {
            objs[n].oci = AtomID;
            objs[n].obi = moleculeInfo->searchLabels[0].atomList[n+1];
        }

        if ( cpu_CreateSearchLabel( molStruct, moleculeInfo->searchLabels[0].objclsID, objs,
                                    &index,    moleculeInfo->searchLabels[0].lowValue,
                                               moleculeInfo->searchLabels[0].highValue, 
                                               moleculeInfo->searchLabels[0].numSteps) < 0 )
            alert_user("Unable to create search label for map file.");

    } else {

        alert_user("Unable to create search label for map file.  "
                   "Your molecule may contain dummy atoms.");
    }

    if (!cartesianCoords) { /* will need to convert internal
                                coordinates to cartesians */
        if ((zMatrix = (Zmatrix *) malloc(sizeof(Zmatrix)*NAtoms_incl_dummy)) == NULL) {
            alert_user("writeReactionCoord: Unable to allocate zMatrix array");
            goto errorReturn;
        }
        for (i=0; i<NAtoms_incl_dummy; i++) { /* initialize Z matrix info */
            zMatrix[i].distance = 0.0;
            zMatrix[i].angle = 0.0;
            zMatrix[i].dihedral = 0.0;
            zMatrix[i].atomA = 0;
            zMatrix[i].atomB = 0;
            zMatrix[i].atomC = 0;
            zMatrix[i].varyDistance = 0;
            zMatrix[i].varyAngle = 0;
            zMatrix[i].varyDihedral = 0;
        }
        if ((temp_coord = (double *) 
                malloc(sizeof(double)*3*NAtoms_incl_dummy)) == NULL) {
            alert_user("writeReactionCoord: Unable to allocate temp_coord array");
            goto errorReturn;
        }
    }
/*
*  Force all partial charges to zero, to ensure that they are defined
*/
    zero = 0.0;
    pchrg = &zero;
    for (i = 0; i < NAtoms_incl_dummy; i++) {
        if ((rtn_code = csu_AddObjVal (molStruct, AtomID, PchrgID, 
                                       (moleculeInfo->locationWithoutDummies[i]),
                                       MOPAC_SRC, CSU_FLOATING, 1, Charge_AU, 
                                       4, (char*)pchrg, 0,
                                       BY_INDEX)) < 0) {

          alert_user(errs);
          goto errorReturn;
        }

      }
      if ((numberBonds = cpu_getBondList(molStruct, &bondList)) > 0) {
        for (i=0; i<numberBonds; i++) {
         if((rtn_code = csu_AddObjVal (molStruct, BondID, Bond_OrderID,
                        i, MOPAC_SRC, CSU_FLOATING, 1, NoUnit, 4, 
                        (char*)pchrg,0, BY_INDEX)) < 0) {
           sprintf (errs,"AddBondOrder: csu_AddObjVal rtn_code %d\n", rtn_code);
           alert_user(errs);
         }
         
      }

    if (startMovieHeader(molStruct,".Map",CFT_EMAP) < 0) {
        alert_user("Unable to save the results because the disk may be full"
                   " or the file file may be locked.");
        return -1;
    }
      }

    if ( outputCalcNumber >= 0 ) {
        char buff[32];

        /* echo map file name  so user will know where the results got put */
        if ((i = strlen(moleculeInfo->molStructName)) > 27) 
            i = 27;
        strncpy(buff, moleculeInfo->molStructName, i);
        strcpy(buff+i, ".Map");
        sprintf(string,"Writing energy map in %s\n", buff);
        mam_SendStatus(MOPAC_STATUS_SCROLL, string);
    }

   /*
    *  Find out how many of each object class there are.
    */
    
   if (csu_ExistsObjclsID (molStruct, AtomID, &offset))
     NAtoms = (long) ((GetPtr(molStruct->objclsH) + offset)->num_objs);
   else {
     alert_user ("writeReactionCoord: Error attempting to locate AtomID index.");
   }

    /* get original coordinates from molStruct to have coordinates for dummy atoms */
    if ((rtn_code = csu_GrabVal (molStruct, AtomID, XYZID, (char **)&(tmpcoord))) < 0) {
         sprintf (errs,"writeReactionCoord: csu_GrabVal XYZ, errno %d", rtn_code);
        alert_user(errs);
        goto errorReturn;
    }

    /* Write out driver header */
    for (i=0; i < numSearchLabels; i++) {
        j=(GetPtr(DataDict.objclsdictH) + 
            moleculeInfo->searchLabels[i].objclsID)->objclsN;
        if (moleculeInfo->searchLabels[i].objclsID == Atom_distID) 
            units = Angstrom_U;
        else units = Degree_U;
        fprintf(movie_fp, "%s%d %s %f %f %d\n",
            GetPtr(DataDict.namesH)[j],  /* object class name */
            i,                             /* label index */
            GetPtr(DataDict.namesH)[units],  /* units */
            moleculeInfo->searchLabels[i].lowValue, 
            moleculeInfo->searchLabels[i].highValue,
            moleculeInfo->searchLabels[i].numSteps + 1);
    }
    
    /* Write out dependent header */
    /* end of Axes, introduce start of calculated values */
    fprintf(movie_fp, "Dependents\n");

    /* total energy */
    if (dependentHeader(molStruct, CalcHistID, CalcEnergyID, 4, 1, 3,
                        Energy_Kcal_mole, -1, NULL) < 1) {
        alert_user("depend_hdr returned wrong number of energies\n");
        goto errorReturn;
    }

    /* Energy gradient */
    fprintf(movie_fp, "not_objcls Energy_Gradient 4 1 3 kcal/mole/Angstrom 1\n");
    fprintf(movie_fp, "-1\n");

    /* Ionization potential */
    fprintf(movie_fp, "not_objcls I.P. 4 1 3 eV 1\n");
    fprintf(movie_fp, "-1\n");

    /* atom coordinates */
    if (NAtoms != dependentHeader(molStruct, AtomID, XYZID, 4, 3, 3, Angstrom_U, 0, NULL)) {
        sprintf(errs,"writeReactionCoord: depend_hdr returned wrong number of atoms\n");
        alert_user(errs);
        goto errorReturn;
    }
        /* partial charges */
    if (NAtoms != dependentHeader(molStruct, AtomID, PchrgID, 4, 1, 3, Charge_AU, 0, NULL)) {
        alert_user("writeEnergyTable: depend_hdr returned wrong number of partial charges");
        goto errorReturn;
    }
        /* bond orders */
    numberBonds = cpu_getBondList(molStruct, &bondList);
    if (numberBonds != dependentHeader(molStruct, BondID, Bond_OrderID, 4, 1, 3, NoUnit, 0, NULL)) {
        alert_user("writeEnergyTable: depend_hdr returned wrong number of bond-orders");
        goto errorReturn;
    }
    if (NAtoms < NAtoms_in_output) {
        sprintf(errs,"writeReactionCoord: number of atoms in molstruct and "
                "output file disagree %d  %d\n",NAtoms,NAtoms_in_output);
        alert_user(errs);
        goto errorReturn;
    }

    /* mark end of ASCII movie header and start of binary movie data */
    fprintf(movie_fp, "StartFrames\n");
#if defined(_WIN32)
    /*  change to binary mode */
    cfl_MacFClose(movie_fp);
    if ((movie_fp = cfl_MacFOpen(mv_name, "rb+", 0, 0)) == NULL) {
        alert_user("Unable to re-open movie file in binary mode.");
        goto errorReturn;
    }
    /* start at the end of the movie header */
    if (fseek(movie_fp, 0, 2)) {
        fclose(movie_fp);
        alert_user("Unable to fseek to the end of the movie file.");
        goto errorReturn;
    }
#endif
    /* start writing the frame information */

    MOP_YIELD();

    fseek(MOPACoutput,0,0);

    if ((xyz = (float (*)[3]) 
            malloc(sizeof(float)*3*NAtoms)) == NULL) {
        alert_user("writeReactionCoord: Unable to allocate xyz array");
        goto errorReturn;
    }
    if ((pcharge = (float *) malloc(sizeof(float))) == NULL) {
        alert_user("writeEnergyTable: Unable to allocate partial charge array");
        goto errorReturn;
    }
    if ((pchrg = (float *) malloc(sizeof(float)*NAtoms)) == NULL) {
        alert_user("writeEnergyTable: Unable to allocate partial charge array");
        goto errorReturn;
    }
    if ((bond_order = (float *) 
            malloc(sizeof(float)*numberBonds)) == NULL) {
        alert_user("writeEnergyTable: Unable to allocate bond order array");
        goto errorReturn;
    }
    /* put original molstruct xyz coordinates into present coordinates */
    for (i=0; i<NAtoms ; i++)
        for (j=0; j<3; j++)
            xyz[i][j] = (float)tmpcoord[i][j];

    lastFrame = (moleculeInfo->searchLabels[0].numSteps+1);
    for (istep=0; istep < lastFrame; istep++) {

        float float_val;
    
        MOP_YIELD();
        /* write the frame number */
        if (fwrite(&istep, 4, 1, movie_fp) < 1) {
            alert_user("writeReactionCoord:  movie write failed");
            break;
        } 

        /* write out the dependent values */
            
        /* total energy */
        for (;;) {
            if (cfl_fgets(string, sizeof(string), MOPACoutput) == 0) goto endOfFile;
            if (strncmp(string,"          FINAL HEAT OF FORMATION =", 35)
                == 0) break;
        }
        if (strlen(string) > 35) {
            sscanf(&string[35],"%f", &float_val);        
            /* write out value as binary float */
            if (fwrite(&float_val, 4, 1, movie_fp) < 1) {
                alert_user("writeReactionCoord:  movie write failed");
                break;
            } 
        } else 
            alert_user("writeReactionCoord:  error reading heat of formation");
        for (;;) {
            if (cfl_fgets(string, sizeof(string), MOPACoutput) == 0) goto endOfFile;
            if (strncmp(string,"          REACTION GRADIENT       =", 35)
                == 0) break;
        }
        if (strlen(string) > 35) {
            sscanf(&string[35],"%f", &float_val);        
                /* write out value as binary float */
            if (fwrite(&float_val, 4, 1, movie_fp) < 1) {
                alert_user("writeReactionCoord:  movie write failed");
                break;
            } 
        } else 
            alert_user("writeReactionCoord:  error reading gradient");

        for (;;) {
            if (cfl_fgets(string, sizeof(string), MOPACoutput) == 0) goto endOfFile;
            if (strncmp(string,"          IONIZATION POTENTIAL    =", 35)
                == 0) break;
        }
        if (strlen(string) > 35) {
            sscanf(&string[35],"%f", &float_val);        
            /* write out value as binary float */
            if (fwrite(&float_val, 4, 1, movie_fp) < 1) {
                alert_user("writeReactionCoord:  movie write failed");
                break;
            } 
        } else 
            alert_user("writeReactionCoord:  error reading ionization potential");
/*
   Read in the charges
*/
        for (;;) {
                if (cfl_fgets(string, sizeof(string), MOPACoutput) == 0) goto endOfFile;
                if (strncmp(string,"  ATOM NO.   TYPE", 17)
                    == 0) break;
            }
        for (i=0; i < NAtoms_in_output; i++) {
                if (cfl_fgets(string, sizeof(string), MOPACoutput) == 0) goto endOfFile;
                if (strlen(string) > 26) {
                    sscanf(&string[26],"%f", pcharge);
                    pchrg[moleculeInfo->locationWithoutDummies[i]] = *pcharge;
                } else {
                    alert_user("writeReactionCoord:  error reading partial charges");
                    goto errorReturn;
                }
            }
        if (cartesianCoords) { /* read in Cartesian coordinates */
            for (;;) {
                if (cfl_fgets(string, sizeof(string), MOPACoutput) == 0) goto endOfFile;
                if (strncmp(string,"          CARTESIAN COORDINATES", 31)
                    == 0) break;
            }
            
            for (i=0; i < 3; i++) {
                if (cfl_fgets(string, sizeof(string), MOPACoutput) == 0) goto endOfFile;
            }

            for (i=0; i < NAtoms_in_output; i++) {
                float x[3];
                if (moleculeInfo->locationWithoutDummies[i] > NAtoms) {
                    sprintf(errs,"writeReactionCoord: atoms out of range %d %d %d",
                        i,moleculeInfo->locationWithoutDummies[i],NAtoms);
                    alert_user(errs);
                    goto errorReturn;
                }
                if (cfl_fgets(string, sizeof(string), MOPACoutput) == 0) goto endOfFile;
                if (strlen(string) > 20) {
                    sscanf(&string[20],"%f %f %f", &x[0], &x[1], &x[2]);
                    for (j=0; j<3; j++) 
                        xyz[moleculeInfo->locationWithoutDummies[i]][j] = 
                            (float)(x[j] + coord_shift[j]);
                            /* Such a term may need to be added in order to preserve
                               properly a position of the molecule in a CAChe window.
                               However this term is wrong because it breaks molecule
                               geometry in case of dummy atoms presented. So better
                               do not add this term now and just think how such a 
                               correction should be done properly.
                            - xyz[moleculeInfo->locationWithoutDummies[0]][j];
                            */
                } else {
                    alert_user("writeReactionCoord:  error reading coordinates");
                    goto errorReturn;
                }
            }
        } else { /* Read in internal coordinates and convert to Cartesians.  */
            /* This part will be never invoked for MOPAC, top copy, output parsing. */
            /* Also it is not appropriate for MOPAC, top copy, output and should be */
            /*    either corrected or simply removed.                        */
            for (;;) { /* locate first line of internal coordinates */
                if (cfl_fgets(string, sizeof(string), MOPACoutput) == 0) break;
                if (strlen(string) > 55) {
                    if (strncmp(&string[55], "0    0    0    0", 16) == 0)
                        /* found first atom */
                        break;
                }
            }
            for (i=1; i < NAtoms_incl_dummy; i++) {
                if (cfl_fgets(string, sizeof(string), MOPACoutput) == 0) break;
                if (strlen(string) > 65) {
                    sscanf(&string[19],"%lf",&zMatrix[i].distance);
                    sscanf(&string[65],"%d",&j);
                    zMatrix[i].atomA = j - 1;
                } else {
                    alert_user("writeReactionCoord:  error reading coordinates");
                    goto errorReturn;
                }
                if (i>1) {
                    if (strlen(string) > 70) {
                        sscanf(&string[33],"%lf",&zMatrix[i].angle);
                        sscanf(&string[70],"%d",&j);
                        zMatrix[i].atomB = j - 1;
                    } else {
                        alert_user("writeReactionCoord:  error reading coordinates");
                        goto errorReturn;
                    }
                }
                if (i>2) {
                    if (strlen(string) > 75) {
                        sscanf(&string[50],"%lf",&zMatrix[i].dihedral);
                        sscanf(&string[75],"%d",&j);
                        zMatrix[i].atomC = j - 1;
                    } else {
                        alert_user("writeReactionCoord:  error reading coordinates");
                        goto errorReturn;
                    }
                }
            }

            if (internalToCartesian (temp_coord, NAtoms_incl_dummy, 
                    zMatrix, NULL) < 0) {
                 alert_user("writeReactionCoord: error converting internal coordinates");
                 goto errorReturn;     
            }
            /* remove dummy atoms from list */
            for (i=0, n=0; i < NAtoms_incl_dummy; i++) {
                if (nuclearNumber[i] != 54) {
                    for (j=0; j<3; j++) 
                        xyz[moleculeInfo->locationWithoutDummies[n]][j] = 
                            (float)(temp_coord[i*3 + j] + coord_shift[j]);
                    n++;
                }
            }
        } /* end of reading Cartesian or internal coordinates for given reaction point */ 
/*
*   Read in Bond Orders  FIXME: This was copied more-or-less verbatim from "updateMolStruct.c"
*/
//    DebugBreak();
                    first = (istep == 0);
        UpdateBondOrders(molStruct, MOPACoutput, NAtoms,
                 moleculeInfo, bond_order, numberBonds, first );
        /* write out value as binary float */
        if (fwrite(xyz, 4, 3*NAtoms, movie_fp) < 1) {
            alert_user("writeReactionCoord:  movie write failed");
            break;

        }
         /* write out partial charges as binary float */
        if (fwrite(pchrg, 4, NAtoms, movie_fp) < 1) {
            alert_user("writeReactionCoord: pchrge map write failed");
            break;
        } 
         /* write out bond orders as binary float */
        if (fwrite(bond_order, 4, numberBonds, movie_fp) < 1) {
            alert_user("writeReactionCoord: bond order map write failed");
            break;
        } 
    }

errorReturn:
    if (MOPACoutput != NULL) fclose(MOPACoutput);

    MOP_YIELD();
    
    if (movie_fp != NULL) fflush(movie_fp);
    if (movie_fp != NULL) cfl_MacFClose(movie_fp);
    
    if (temp_coord != NULL) free(temp_coord);
    if (nuclearNumber != NULL) free(nuclearNumber);
    if (indexWithoutDummy != NULL) free(indexWithoutDummy);
    if (zMatrix != NULL) free(zMatrix);
    if (xyz != NULL) free(xyz);
    return -1;

endOfFile:
    if (MOPACoutput != NULL) fclose(MOPACoutput);

    MOP_YIELD();
    
    if (movie_fp != NULL) fflush(movie_fp);
    if (movie_fp != NULL) cfl_MacFClose(movie_fp);

    if (temp_coord != NULL) free(temp_coord);
    if (nuclearNumber != NULL) free(nuclearNumber);
    if (indexWithoutDummy != NULL) free(indexWithoutDummy);
    if (zMatrix != NULL) free(zMatrix);
    if (xyz != NULL) free(xyz);
    if (bondList != NULL) free(bondList);
    return 0;
}
