#include "compat.h"
#include "csu.h"
#include "MOPACDriver.h"

long getNumberDummyAtoms(MolStruct *molStruct, int NAtom)
{
	char	(*atsymbol)[2];
	char	errs[256];
	int		rtn_code;
	long 	numDummyAtoms;
	long	i;
	
	if ((rtn_code = csu_GrabVal (molStruct, AtomID, SymID, (char **)&atsymbol)) < 0) {
 		sprintf (errs,"getNumberDummyAtoms: csu_GrabVal Sym, errno %d", rtn_code);
		alert_user(errs);
		return(-1);
	}
	for (i=0, numDummyAtoms=0; i<NAtom; i++) {
		if (strncmp(atsymbol[i],"Xe",2) == 0) 
			numDummyAtoms++;
	}
	return (numDummyAtoms);
}
