#ifndef OMFCACheLicenseAPI__ 
#define OMFCACheLicenseAPI__ 

// Define symbol which controls DLL import/export on Windows platforms
//
#ifdef macintosh

#define _CACHE_LIC_IMPEXP

#else

#ifdef _CACHE_DLL
#ifndef _CACHE_LIC_IMPEXP
#ifdef _CACHE_LIC_DLL
#define _CACHE_LIC_IMPEXP _declspec(dllexport)
#else
#define _CACHE_LIC_IMPEXP _declspec(dllimport)
#endif
#endif
#endif

#endif

// 
// File: OMFCACheLicenseAPI.h 
// 
// Class: OMFCACheLicenseAPI 
// 
// Description: the licensing interface for all CAChe products 
// 
// Intended usage: 
// Outline the function of the class, and how it should be 
// used by the programmer, here. Note if this is an abstract 
// base class. 
// 
// Design notes: 
// 
// (1) Any further detailed design information can go here. 
// (2) This is a good place to explain how to subclass a class 
//     which is intended as a base class. 
// (3) TODO: this is one way to add notes as placeholders for future enhancements. 
// 
// Created: dd/mm/yy Anne Programmer, Oxford Molecular 
// 
// Modification history: 
// Who When What 
// JAW 01/02/96 Put comments here in this format for minor changes 
// 
// Defines 
// 
// use const static data members instead 
// 

// Includes 
//
#include "OMFBool.h"
#include "OMFStlString.h"
#include "OMFCACheULD.h"
#include <map>

#ifndef macintosh
#pragma warning( disable : 4786 )	// This is ok since we the variable is private
#endif

// Class declaration - OMFCACheLicenseAPI 
// 
class _CACHE_LIC_IMPEXP OMFCACheLicenseAPI
{ 
	
public: 
	// Constructor 1
	//
	OMFCACheLicenseAPI(void); 
	
	// Destructor
	//
	
	// Virtual Destructor 
	//
	virtual ~OMFCACheLicenseAPI(void); 
	
	// Other public member functions and typedefs 
	
	// Asynchronous event handler
	//
	typedef void (*HANDLER)( void* data, const char *);
	
	// API errors
	//
	enum ERRORCODE
	{
		STATUS_OK = 0,
			NO_LICENSE_AVAILABLE
	};
	
	// Static system initialiser & terminator
	static bool Initialise(void);
	static bool Terminate(void);
	
    struct SPLASH_STRING_SET
    {
		OMFStlString		theProduct;
		OMFStlString		theApplication;
		OMFStlString		theOwner;
		OMFStlString		theCustomerID;
		OMFStlString		theWarning;
		OMFStlString		theCopyrightText;
    };
	
	static void			GetOwnerAndCompany( OMFStlString& theOwner, OMFStlString& theCompany );
	static void			SetOwnerAndCompany( const char* theOwner, const char* theCompany );
	static bool          QueryFeature( OMFCACheULD::FEATURE theFeature );
	static bool          FetchFeature( OMFCACheULD::FEATURE theFeature );
	static bool	         ReturnFeature( OMFCACheULD::FEATURE theFeature );
	static void          HandleSysTimeChange( OMFCACheULD::FEATURE theFeature );
	static const char*   GetCustomText( OMFCACheULD::FEATURE theFeature );
	static const char*   GetBookedFeatureName( OMFCACheULD::FEATURE theFeature );
	static const char*   GetCopyrightText( void );
	static void			GetSplashStrings( OMFCACheULD::FEATURE theAppFeature, SPLASH_STRING_SET& theSet );
	static void			GetOptionalFeatureText( OMFStlString& theText );
	static void	         GetLastError( OMFCACheLicenseAPI::ERRORCODE& theCode, OMFStlString& theText );
	static void			SubstituteULD( const char* theName, OMFCACheULD* theULD );

	static void			RemoveKeys( OMFStlStringList& theKeys );
	static void			ConvertKeys311_41( OMFStlStringList& oldKeys, OMFStlStringList& newKeys, OMFCACheULD**& pULDs );

#ifndef macintosh
	static void			ConvertKeys_pre311( OMFStlStringList& oldKeys, OMFStlStringList& newKeys, OMFCACheULD**& pULDs );
#endif

	static void          RegisterHandler( OMFCACheULD::HANDLED_EVENT theEvent, 
		OMFCACheLicenseAPI::HANDLER theHandler, void*	theHandlerData );
	static bool          LookupHandler( OMFCACheULD::HANDLED_EVENT theEvent, 
		OMFCACheLicenseAPI::HANDLER& theHandler, void*&  theHandlerData );
	static OMFCACheULD::CUSTOMERID GetCustomerID( OMFCACheULD::FEATURE theFeature );
		
	protected: 
		
		// Class representing a stored record of features
		//
		class FeatureRecord
		{
		public:
			FeatureRecord(void);
			FeatureRecord( OMFCACheULD::FEATURE theULDFeature, OMFCACheULD* theULD );
			~FeatureRecord(void);
			
			OMFCACheULD*	GetULD(void) const;
			OMFCACheULD::FEATURE	GetFeature(void) const;
			bool			FetchFeature(void);
			bool			ReturnFeature(void);
			bool        QueryFeature(void);
			OMFCACheULD::CUSTOMERID  GetCustomerID(void);
			
		private:
			OMFCACheULD::FEATURE	itsFeature;
			OMFCACheULD*			itsULD;
		};
		
		OMFCACheULD*		FindULDfromRegistry( const char* keyRoot, bool& foundKey );
		OMFCACheULD*		FindULDfromRegistry2( const char* keyRoot, bool& foundKey );
		FeatureRecord*		InsertFeatureMapRecord( OMFCACheULD::FEATURE theIndexFeature, OMFCACheULD::FEATURE theULDFeature, OMFCACheULD* theULD );
		FeatureRecord*		LookupCompositeFeatures( OMFCACheULD::FEATURE theFeature );
		FeatureRecord*		LookupFeature( OMFCACheULD::FEATURE theFeature, bool create = true );
		void				LoadStandardKeys();
		virtual void		SetLastError( OMFCACheLicenseAPI::ERRORCODE theCode, const char* theText );
		
		int              IncULDAccessCount( OMFCACheULD * theULD );
		int              DecULDAccessCount( OMFCACheULD * theULD );
		
		private: 
			
			OMFCACheULD*	FindULDfromRegistryBase( OMFStlString& keyRoot, bool& foundKey );
			void			LoadUpMaps( OMFStlString& theName, OMFCACheULD* theULD );
			OMFCACheULD*	GetULDfromFeature( OMFCACheULD::FEATURE theFeature );
			
			// Class representing asynchronous event handler record
			//
			class EventHandler
			{
			public:
				EventHandler();
				
				void     Initialise( HANDLER, void* );
				HANDLER  GetHandler( void ) const;
				void *   GetHandlerData( void ) const;
				
			private:
				HANDLER	itsHandler;
				void*	itsHandlerData;
			};
			
			// Protect copy constructor and operator= - these are not allowed 
			// for this class. 
			// 
			OMFCACheLicenseAPI(const OMFCACheLicenseAPI& ); 
			OMFCACheLicenseAPI& operator=(const OMFCACheLicenseAPI& ); 

			// Loaded standard keys?
			bool				itsLoadedStandardKeys;

			// Data members
			// 
			ERRORCODE			itsLastErrorCode;
			OMFStlString		itsLastErrorText;

#ifndef macintosh
#pragma warning( disable : 4251 )	// This is ok since we the variable is private
#endif

			// Map from persistent store key name to ULD record
			typedef std::map<OMFStlString,OMFCACheULD*>					STRING_ULD_MAP;
			STRING_ULD_MAP		itsRegistryMap;

			// Map from ULD record to access count
			typedef std::map<OMFCACheULD*,int*>							ULD_INT_MAP;
			ULD_INT_MAP			itsULDAccessMap;

			// Map from FEATURE to feature record
			typedef std::map<OMFCACheULD::FEATURE,FeatureRecord*>		FEATURE_FREC_MAP;
			FEATURE_FREC_MAP	itsFeatureMap;

			// Map from HANDLED_EVENT to feature record
			typedef std::map<OMFCACheULD::HANDLED_EVENT,EventHandler*>	EVENT_HANDLER_MAP;
			EVENT_HANDLER_MAP	itsHandlerMap;

#ifndef macintosh
#pragma warning( default : 4251 )
#endif
			// Static data members
			//
			static OMFCACheLicenseAPI*	theOneInstance;
			static OMFStlString			theCopyrightText;
}; // class OMFCACheLicenseAPI 

// 
// Related global functions needed for the access via LoadLibrary
// 
//_CACHE_LIC_IMPEXP bool InitialiseOMFCACheLicenseAPI(void);
EXTERN_C _CACHE_LIC_IMPEXP bool OMFCACheLicenseAPI_Initialise(void);
EXTERN_C _CACHE_LIC_IMPEXP bool OMFCACheLicenseAPI_FetchFeature( OMFCACheULD::FEATURE theFeature );
EXTERN_C _CACHE_LIC_IMPEXP bool OMFCACheLicenseAPI_QueryFeature( OMFCACheULD::FEATURE theFeature );
EXTERN_C _CACHE_LIC_IMPEXP void OMFCACheLicenseAPI_GetLastError( OMFCACheLicenseAPI::ERRORCODE& theCode, OMFStlString& theText );
EXTERN_C _CACHE_LIC_IMPEXP bool OMFCACheLicenseAPI_Terminate(void);

// Prototypes to allow callers to GetProcAddress() from the DLL
typedef bool __declspec(dllexport) (*LICAPI_INITIALISER_FUNC)(void); // "Initialise"
typedef bool __declspec(dllexport) (*LICAPI_FETCH_FUNC) ( OMFCACheULD::FEATURE theFeature ); // "FetchFeature"
typedef bool __declspec(dllexport) (*LICAPI_QUERY_FUNC) ( OMFCACheULD::FEATURE theFeature ); // "QueryFeature"
typedef bool __declspec(dllexport) (*LICAPI_TERMINATOR_FUNC)(void);  // "Terminate
typedef void __declspec(dllexport) (*LICAPI_ERRMSG_FUNC)  (OMFCACheLicenseAPI::ERRORCODE& theCode, OMFStlString& theText );	// "GetLastError"
								

#endif // OMFCACheLicenseAPI__ 
