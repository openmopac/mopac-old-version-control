#include <windows.h>
#include <iostream.h>
#include <stdio.h>
#include <CACheFileTypes.h>
#include <cul.h>
#include "ComputeEngine_MOPAC.h"
#include "Resource.h"

const char* const CE_APP_NAME = CUL_STRING(CACHE_MY_NAME);

static ComputeEngine_MOPAC my_TheCE;

int CALLBACK WinMain( HINSTANCE hInstance,
                      HINSTANCE hPrevInstance,
                      LPSTR lpCmdLine,
                      int nCmdShow )
{
    int argc;
    char **argv;
    HWND hWnd;
    int result;

	  
    argv = cul_CommandLineToArgv(GetCommandLine(), &argc);

    if ( argv == NULL )
        return (FALSE);
// DebugBreak();
    if ( !ce_InitApplication(hInstance, CE_APP_NAME, IDI_COMPUTE_ENGINE) )
        return(FALSE);

    if ( !ce_InitInstance(hInstance, nCmdShow, CE_APP_NAME, CE_APP_NAME, &my_TheCE, &hWnd) )
        return(FALSE);

    if ( !my_TheCE.Init(argc, argv, hWnd) )
        return(FALSE);

    result = ce_WinMain(hInstance, hPrevInstance, lpCmdLine, nCmdShow);
 
    result = my_TheCE.Term();

    return (result);
 
    lpCmdLine; // This will prevent 'unused formal parameter' warnings
}

ComputeEngine_MOPAC::ComputeEngine_MOPAC(void)
{
    m_ProcessOutputFile = 0;
//	DebugBreak(); 
    m_logFileBaseName = (char*) CE_APP_NAME;
    m_version = CUL_STRING(CACHE_MY_NAME) " " CUL_STRING(CACHE_VERS) " " __DATE__ " "  __TIME__;
}

void ComputeEngine_MOPAC::ParseOtherFlags(char *p)
{
    if ( strncmp(p, "-p", 2) == 0 )
        m_ProcessOutputFile = 1;
}

void ComputeEngine_MOPAC::DoComputation(void)
{
    ce_ApplMain(m_programName, m_ProcessOutputFile, this);
}

unsigned long ComputeEngine_MOPAC::StackSize(void)
{
    return (4*1024*1024); // 4 Meg stack
}

extern "C"
{

void ce_mopac_wait_for_continue(void)
{
    ccl_Event *evt = my_TheCE.m_continue_evt;

    evt->Wait(CCL_INFINITE_TIMEOUT);
    evt->Reset();
}

void ce_mopac_send_process_flag(void)
{
    my_TheCE.Send_CEM_DoProc(CCL_MSG_FLAGS_NONE);
}

void ce_mopac_exit(long exit_code)
{
    cul_Exit(exit_code);
}

long ce_mopac_shutdown(void)
{
    ccl_Event *evt = my_TheCE.m_stop_evt;

    if (evt->Wait(0) == CCL_EVENTWAIT_OBJECT0)
        return(1);
    else
        return(0);
}

} /* extern "C" */
