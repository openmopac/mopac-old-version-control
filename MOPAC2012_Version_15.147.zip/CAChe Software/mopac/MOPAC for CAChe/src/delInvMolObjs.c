#include "compat.h"
#include <ctype.h>
#include "csu.h"
#include "MOPACDriver.h"

void deleteInvalidMolstructObjs(MolStruct *molStruct)
{
    int i;
    ObjclsID offset;
    PropID propi, numprops;
    ObjectID num_valloc;
    BitH XYZ_hasValueH;
    PropH propsH;
    
    /* Since we don't move electrons during a geometry optimization,
       better invalidate the coordinates of the lone pairs now. */
       
   if (csu_ExistsObjclsID (molStruct, OrbitalID, &offset))
   {
      propsH   = (GetPtr(molStruct->objclsH) + offset)->propsH;
      numprops = (GetPtr(molStruct->objclsH) + offset)->num_props;
      num_valloc = (GetPtr(molStruct->objclsH) + offset)->num_valloc;
      if (csu_ExistsPropID(propsH, XYZID, numprops, &propi))
      {
          XYZ_hasValueH  = (GetPtr(propsH) + propi)->has_valueH;
          for (i=0; i<num_valloc; i++) 
             csu_ClearBit (XYZ_hasValueH, i);    /* now has a invalid value */
      }
   }
}
