#include <compat.h>
#include <CACheFileLib.h>
#include <ZINDODriver.h>

int appendToFile(char *inputFile, char *outputFile)
/*
	Simple routine to transfer the contents of a file onto the end of another.
	If the output file does not exist, then it is created.
	Return values:   0 ==> success!
	                -1 ==> unable to open input file
					-3 ==> unable to open output file
					-5 ==> unable to copy from the input file to the output file
*/
{
	FILE *OUTPUT = NULL;
	FILE *INPUT = NULL;
	char string[256];

	string[0] = 0; /* null-terminate string */

    strcat(string,inputFile);
	if ((INPUT = fopen(string,"r")) == NULL) {
		sprintf(string,"appendToFile: Unable to open input file '%s'.\n",
				inputFile);
		alert_user(string);
		return -1;
	}

	string[0] = 0; /* null-terminate string */

    strcat(string,outputFile);
	if ((OUTPUT = fopen(string,"a")) == NULL) {
		sprintf(string,"appendToFile: Unable to open output file '%s'.\n",
				outputFile);
		alert_user(string);
		if (INPUT != NULL) fclose(INPUT);
		return -3;
	}
	for (;;) {
		if (fgets(string, sizeof(string), INPUT) == 0) break;
		if (fputs(string, OUTPUT) == EOF) {
			sprintf(string,"appendToFile: Unable to write in output file.\n");
			alert_user(string);
			if (INPUT != NULL) fclose(INPUT);
			if (OUTPUT != NULL) fclose(OUTPUT);
			return -5;
		}
	}
	if (OUTPUT != NULL) fflush (OUTPUT);
	if (OUTPUT != NULL) fclose(OUTPUT);
	if (INPUT != NULL) fclose(INPUT);
	return 0;
}
