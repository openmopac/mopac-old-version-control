#include  <compat.h>
#include  <ZINDODriver.h>

/***************************************************************************************
 *
 *  Add_BasisSet			George D. Purvis III			8/28/89
 *
 *  This function adds the Basis Set information to the MolStruct.  The explicit
 *  basis functions are printed out from the shell description contained in the
 *  BasisSet structure.
 *
 *	parameters:	msPtr		-pointer to a MolStruct structure.
 *			exponents	-array of doubles containing STO exponents
 *			nOrbitals	-not used
 *			nAtoms		-number of Atoms
 *			orbitalRange	-start and end of shell
 *			nuclearNumber	-an array of atomic numbers
 *								
 *
 *	calls:		csu_AddObjVal, ExitToShell, printf.
 *
 *	returns:	nothing.
 *
 ***************************************************************************************/
short NPQ[] = {1,1, 2,2,2,2,2,2,2,2, 3,3,3,3,3,3,3,3, 4,4,4,4,4,4,4,4,
      		 4,4,4,4,4,4,4,4,4,4, 5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5};
 
void ZINDOaddBasisSet (MolStruct *msPtr, double *exponents,
					   long nAtoms, long atomLocation[],
					   long valenceType[],long NPQ[], short source)
{
 long	j;
 short	contrlen, shellType, shellLength, shellnum, angtype[16], Nquant;
 PropID contractionsID;
 long   numShells, basisfxn;
 long   atom;
 u_char dflagval=(csu_Delete2if1 | csu_Delete2ifC);
 char	errs[256];
 CelErr	rtn_code;

 	
  if ((rtn_code = csu_GetPropertyID("contractions", &contractionsID)) < 0) {
	sprintf (errs,"setupBasis: csu_GetPropertyID contractions rtn_code %d\n",
			rtn_code);
	alert_user(errs);
  }

  /*
   *  Put the basis function objects and their properties into 
   *  the basis function object class.
   */

  for (basisfxn=0, shellnum=1, atom=0; atom < nAtoms; atom++) {
  
    contrlen = 6;
    
	numShells = valenceType[atom];
	if (numShells > 3) numShells--;
	
	for (shellType = 0; shellType < numShells; shellType++, shellnum++) {

    Nquant   = (short)NPQ[basisfxn];

	switch (shellType) {
      case ZINDO_S :
        angtype[0] = Stype;
		shellLength = 1;
        break;
        
      case ZINDO_P :
        angtype[0] = Pxtype; angtype[1] = Pytype; angtype[2] = Pztype;
		shellLength = 3;
        break;
        
      case ZINDO_D :
/* Since ZINDO tells us the principal quantum number of the basis
   functions actually used, we do not have the adjust for the 
   different type of basis sets.
 */
#if 0
        if (valenceType[atom] == 4) Nquant = Nquant-1;
#endif
        angtype[0] = Dx2y2type;  angtype[1] = Dz2type; angtype[2] = Dxytype;
        angtype[3] = Dxztype;    angtype[4] = Dyztype;
		shellLength = 5;
        break;
        
      case ZINDO_F :
        angtype[0] = Fx3type;    angtype[1] = Fy3type;   angtype[2] = Fz3type;
        angtype[3] = Fy2z2type;  angtype[4] = Fz2x2type; angtype[5] = Fx2y2type;
        angtype[6] = Fxyztype;
		shellLength = 7;
        break;
        
      default :
        sprintf (errs,"AddBasisSet: unrecognized shell->type %ld\n",
                (long)shellType);
        alert_user(errs);
        break;
    }

    for (j=0; j<shellLength; j++, basisfxn++) {
    
      /*
       *  update/create the basis function's properties in the
       *  basis function object class.
       */

      if ((rtn_code = csu_AddObjVal (msPtr, STOBasisFxnID, BasisFxnAngID, (basisfxn+1),
                       source, CSU_NAME, 1, NoUnit, 0, (char*)&angtype[j], 0, BY_ID)) < 0) {
        sprintf (errs,"AddBasisSet: csu_AddObjVal rtn_code %d for BasisFxnAngID\n",
                  rtn_code);
        alert_user(errs);
      }

      if ((rtn_code = csu_AddObjVal (msPtr, STOBasisFxnID, ContractLengthID, (basisfxn+1),
                       source, CSU_INTEGER, 1, NoUnit, 0, (char*)&contrlen, 0, BY_ID)) < 0) {
        sprintf (errs,"AddBasisSet: csu_AddObjVal rtn_code %d for ContractLengthID\n",
                  rtn_code);
        alert_user(errs);
      }
                     
      if ((rtn_code = csu_AddObjVal (msPtr, STOBasisFxnID, PrinQuantID, (basisfxn+1), 
                       source, CSU_INTEGER, 1, NoUnit, 0, (char*)&Nquant, 0, BY_ID)) < 0) {
        sprintf (errs,"AddBasisSet: csu_AddObjVal rtn_code %d for PrinQuantID\n",
                rtn_code);
        alert_user(errs);
      }
                     
      if ((rtn_code = csu_AddObjVal (msPtr, STOBasisFxnID, STOExpID, (basisfxn+1), 
                      			source, CSU_FLOATING, 2, NoUnit, 6,
					(char*)&exponents[basisfxn*6 + 1], 1, BY_ID)) < 0) {
        sprintf (errs,"AddBasisSet: csu_AddObjVal rtn_code %d for STOExpID\n",
                rtn_code);
        alert_user(errs);
      }

      /* Note that expnents is a [][6] array */
	  if ((rtn_code = csu_AddObjVal (msPtr, STOBasisFxnID, contractionsID, (basisfxn+1), 
                      				source, CSU_FLOATING, 2, NoUnit, 6,
					  	(char*)&exponents[basisfxn*6 + 4], 1, BY_ID)) < 0) {
        sprintf (errs,"AddBasisSet: csu_AddObjVal rtn_code %d for STOExpID\n",
                rtn_code);
        alert_user(errs);
      }

      if ((rtn_code = csu_AddObjVal (msPtr, STOBasisFxnID, ShellNumID, (basisfxn+1), 
                      source, CSU_INTEGER, 1, NoUnit, 0, (char*)&shellnum, 0, BY_ID)) < 0) {
        sprintf (errs,"AddBasisSet: csu_AddObjVal rtn_code %d for ShellNumID\n",
                rtn_code);
        alert_user(errs);
      }
      
      /*
       *  update/create the connector between this 
       *  basis function and its atom.
       */

      if ((rtn_code = csu_AddConnectorVal (msPtr, AtomID, atomLocation[atom], STOBasisFxnID,
                                      basisfxn, dflagval)) < 0) {
        sprintf (errs,"csu_AddBasisSet AddConnectorVal rtn_code %d\n", rtn_code);
        alert_user(errs);
      }

    }
    
  }

}
}
