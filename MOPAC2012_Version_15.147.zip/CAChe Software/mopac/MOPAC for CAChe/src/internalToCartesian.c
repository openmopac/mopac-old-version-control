/*
 *	08/Aug/2000	IL: Bug fix, use fabs, not abs to compare floating point numbers
 */
#include <compat.h>
#include <math.h>
#include <MOPACDriver.h>

int internalToCartesian (double xyz[], int natoms,
                     Zmatrix geo[], int labels[])
{
  double ccos;  
  double xb, yb, zb, rbc, cosa, xpa, xpb, xyb, yza, ypa;
  double coskh, sinkh, sina, sind, cosd;
  double xd, yd, zd;
  double xpd, ypd, zpd;
  double sinph, cosph;
  double sinth, costh;
  double xa, ya, za;
  double zqa;
  double xqd, yqd, zqd;
  double xrd;
  int ma, mc, mb, i, k;
  char errs[256];

/*
    InternalToCartesian computes coordinates from bond-angles and lengths.
 	*** it is adapted from the program written by m.j.s. dewar as it
	    appears in ZINDO V5.0.

  on input:
         geo    = array of internal coordinates.
         natoms = number of atoms, including dummies.

  on output:
         xyz  = array of cartesian coordinates ordered [atom][coord]
*/

      xyz[0]=0.0; /* atom 0, x */
      xyz[1]=0.0; /* atom 0, y */
      xyz[2]=0.0; /* atom 0, z */
      xyz[3]=geo[1].distance; /* atom 1, x */
      xyz[4]=0.0; /* atom 1, y */
      xyz[5]=0.0; /* atom 1, z */
      if (natoms > 2) {
	 ccos=cos(geo[2].angle*DegreeToRadian);
	 if (geo[2].atomA >= 2) {
	    	alert_user("InternalToCartesian:  Inconsistent internal coordinates.");
		return (-1);
	 }
	 if (geo[2].atomA == 0) 
	 	xyz[6]=xyz[00]+geo[2].distance*ccos; /* atom 2, x */
	 else 
	 	xyz[6]=xyz[3]-geo[2].distance*ccos;
	 xyz[7]=geo[2].distance*sin(geo[2].angle*DegreeToRadian); /* atom 2, y */
	 xyz[8]=0.0; /* atom 2, z */

	 for (i=3; i<natoms; i++) {
	    cosa=cos(geo[i].angle*DegreeToRadian);
	    mb=geo[i].atomB;
	    if (mb >= i) {
	    	alert_user("InternalToCartesian:  Inconsistent internal coordinates.");
		return (-1);
	    }
	    mc=geo[i].atomA;
	    if (mc >= i) {
	    	alert_user("InternalToCartesian:  Inconsistent internal coordinates.");
		return (-1);
	    }
	    xb=xyz[mb*3]-xyz[mc*3];
	    yb=xyz[mb*3 + 1]-xyz[mc*3 + 1];
	    zb=xyz[mb*3 + 2]-xyz[mc*3 + 2];
	    rbc=1.0/sqrt(xb*xb+yb*yb+zb*zb);
	    if (fabs(1.0e00 - fabs(cosa)) <= 1.e-12) {
/*
     atoms mc, mb, and (i) are collinear
 */
	       rbc=geo[i].distance*rbc*cosa;
	       xyz[i*3]=xyz[mc*3]+xb*rbc;
	       xyz[i*3 + 1]=xyz[mc*3 + 1]+yb*rbc;
	       xyz[i*3 + 2]=xyz[mc*3 + 2]+zb*rbc;
/*
         the atoms are not collinear
 */
	    } else {
               ma=geo[i].atomC;
	       if (ma >= i) {
			alert_user("InternalToCartesian:  Inconsistent internal coordinates.");
			return (-1);
	       }
	       xa=xyz[ma*3]-xyz[mc*3];
	       ya=xyz[ma*3 + 1]-xyz[mc*3 + 1];
	       za=xyz[ma*3 + 2]-xyz[mc*3 + 2];

/*
         rotate about the z-axis to make yb=0, and xb positive.  if xyb is
         too small, first rotate the y-axis by 90 degrees.
 */
	    xyb=sqrt(xb*xb+yb*yb);
	    k = -1;
	    if (xyb <= 0.1e00) {
	       xpa=za;
	       za=-xa;
	       xa=xpa;
	       xpb=zb;
	       zb=-xb;
	       xb=xpb;
	       xyb=sqrt(xb*xb+yb*yb);
	       k = +1;
	    }
/*
    rotate about the y-axis to make zb vanish
*/
	    costh=xb/xyb;
	    sinth=yb/xyb;
	    xpa=xa*costh+ya*sinth;
	    ypa=ya*costh-xa*sinth;
	    sinph=zb*rbc;
	    cosph=sqrt(1.0e00-(sinph*sinph));
	    zqa=za*cosph-xpa*sinph;
	/*
	rotate about the x-axis to make za=0, and ya positive.
	*/
	    yza=sqrt(ypa*ypa + zqa*zqa);
	    if (yza >= 1.0e-4) {
	       if (yza < 2.0e-2) {
		  sprintf(errs," Calculation abandoned.  Three atoms used to"
			       " define the coordinates of a fourth whose"
			       " bond-angle is not zero or 180 degres are"
			       " in a nearly straight line");
	       }
	       coskh=ypa/yza;
	       sinkh=zqa/yza;
	    } else {
	/*
	angle too small to be important
	*/
	       coskh=1.0e00;
	       sinkh=0.0e00;
	    }
	/*
	 coordinates :- a=(xqa,yza,0),   b=(rbc,0,0),  c=(0,0,0)
	 none are negative.
	 the coordinates of i are evaluated in the new frame.
	*/
	    sina=sin(geo[i].angle*DegreeToRadian);
	    sind=-sin(geo[i].dihedral*DegreeToRadian);
	    cosd=cos(geo[i].dihedral*DegreeToRadian);
	    xd=geo[i].distance*cosa;
	    yd=geo[i].distance*sina*cosd;
	    zd=geo[i].distance*sina*sind;
	/*
	transform the coordinates back to the original system.
	*/
	    ypd=yd*coskh-zd*sinkh;
	    zpd=zd*coskh+yd*sinkh;
	    xpd=xd*cosph-zpd*sinph;
	    zqd=zpd*cosph+xd*sinph;
	    xqd=xpd*costh-ypd*sinth;
	    yqd=ypd*costh+xpd*sinth;
	    if (k >= 1) {
	       xrd=-zqd;
	       zqd=xqd;
	       xqd=xrd;
	    }
	    xyz[i*3]=xqd+xyz[mc*3];
	    xyz[i*3 + 1]=yqd+xyz[mc*3 + 1];
	    xyz[i*3 + 2]=zqd+xyz[mc*3 + 2];
      }
   }
 }


#if 0
/*
    *** now remove the translation vectors, if any, from the array coor
 */
      k=natoms;
      for (k=natoms-1; labels[k] == 107; k--);

      if (k < natoms) {
      	int j;
/*
    system is a solid, of dimension natoms+1-k
*/
      	l=0;
      	for (i=k; i<natoms; i++) {
		 l=l+1;
		 mc=geo[i].atomA;
		 for (j=0; j < 3; j++) 
		    tvec[l][j]=xyz[i*3 + j]-xyz[mc*3 + j];
      	}
      	j=0

      	for (i=0; i < natoms; i++) {
         if (labels[i] == 99  || labels[i] == 107) continue;
         j=j+1;
	 for (k=0; k<3; k++) xyz[j*3 + k]=xyz[i*3 + k];
      	}
      }
#endif
      return (0);
}
