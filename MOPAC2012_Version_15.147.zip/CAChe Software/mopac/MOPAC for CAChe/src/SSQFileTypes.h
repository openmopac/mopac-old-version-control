#ifndef __SSQFileTypes__
#define __SSQFileTypes__

/* CAChe file transfer types */
#define ssq_ASCII		0
#define ssq_Binary		1
#define ssq_Map			2

/* CAChe file types */
#define ssq_file_settings	0
#define ssq_file_molecule	1
#define ssq_file_assemblage	2
#define ssq_file_surface	3
#define ssq_file_output		4
//
// The following five defines were extracted from the Standalone/ServerStepQueue version
// of this file.  They conflict with the set defined in CommonLibs/Utility/ExternInclude
// since both ssq_file_output and ssq_file_input are defined to be "4".  In addition, it
// is necessary to (1) maintain the value of ssq_file_custom as "9" in order to maintain
// compatibility with previous versions of CAChe, and (2) reserve the values after
// "9" for (especially "10" see cachedir.c).  The following five defines were commented
// out since they did not seem to be necessary.  References to these defines were also
// commented out in the following files under wincache/src/Standalone:
//
// CEMgr/CEMgr.cpp
// ComputeEngine/CE.cpp
// MOPAC_Mgr/CEM_PreProcess.cpp
//
// (MSS Dec 2003)
//
// defines 4-8 added for ComputeEngineManager library
//#define ssq_file_input	4           // Primary input file
//#define ssq_file_input2	5           // Secondary input file
//#define ssq_file_datadict	6           // data dictionary file
//#define ssq_file_params	7           // Primary parameter file
//#define ssq_file_params2	8           // Secondary parameter file
#define ssq_file_custom		9           // Use for beginning enums in applications
#define ssq_file_dummy		0x12345678  // Use for terminating enums

/* CAChe folder types */
#define ssq_folder_molecule	0
#define ssq_folder_accessory	1
#define ssq_folder_assemblage	2
#define ssq_folder_surface	3

/* CAChe file disposition types */
#define ssq_KeepFile		0
#define ssq_DeleteFile		1

#endif
