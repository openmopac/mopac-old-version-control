/*
**
**	cmu.h -- header for Chemistry Math Utilities. The math routines are intended
**	to perform operations on n dimensional arrays, 2 dimensional matrices and 1
**	dimensional points and vectors.
**
**	Authors: Bill Hanks, Andy Spencer
**
**	Date:8-Jan-89
**  Last Modified 21-Sep-89
**
**	01/Aug/2000 IL:	Merged PC client and Standalone code
**	Functions: See Math Library Specification
**
*/

#ifndef __CMU__
#define __CMU__

#ifndef RC_INVOKED     	// Do only error #defines if compiling resources

/* #define _ERRORCHECK_ */
#include <math.h>
#include <compat.h>

#include "cel.h"	/* define CAChe error return codes */

typedef double REAL;

#define INDEX(I,J,C) (I * C + J)
#define SIGN(a,b) ((b)<0 ? -fabs(a) : fabs(a))
#define CMU_RADIANS_TO_DEGREES(r)	((r) * 180.0 / PI)
#define CMU_DEGREES_TO_RADIANS(d)	((d) * PI / 180.0)

/* stuff used by geo.c */
#define MAX_CONNECTED 30 /* maximum number of vertices (atoms connected to central atom */
#define PROXIMITY .0001
typedef struct {
	double point[3];  /* the central point scaled in the direction of the
	                     central atom */
	double point1[3]; /* used to draw edge away from face so it will be
						 visible. */
} Vertices;

typedef struct {
	long length;
	double face_coefficients[4];
	long *poly_list;
} PolyhedronFace;

typedef PolyhedronFace *PolyhedronFaceH;

#endif	// RC_INVOKED     	// Do only error #defines if compiling resources

/* errors */
#define CMUEigenIter	-200 /* more than 50 iterations */
#define CMUInvert		-201 /* could not invert a 4 by 4 matrix */
#define CMUZeroVec		-202 /* a zero length vector was encountered */
#define CMUInvalidDim	-203 /* dimension less than 1 or
								dimensions of matrices don't match */
#define CMUInvalidLen	-204 /* less than 1 element was passed */
#define CMUAllocFailed  -205 /* memory allocation error */

#ifndef RC_INVOKED     	// Do only error #defines if compiling resources


#define CMU_SmallDist 1.0E-10 /* compare two doubles for equality */
#define CMU_SmallAng 1.0E-4 /* compare two angles in radians */

/* prototypes */

#ifdef __cplusplus	/* For type-safe linkage */
extern "C" {		/* Specify "C"-style linkage */
#endif

CelErr cmu_EigenDiagonalRS(
	long n,
	REAL *A,
	REAL *values
);

void cmu_EigenTridiagonal2(
	REAL *A,
	long n,
	REAL *d,
	REAL *e
);

CelErr cmu_EigenTridiagBoth(
	REAL *d,
	REAL *e,
	long n,
	REAL *Z
);

CelErr cmu_Invert4by4(double t[4][4], double tinv[4][4]);
CelErr cmu_Invert3by3(double t[3][3], double tinv[3][3]);
void cmu_MatrixPostMult(double tm[4][4], double m[4][4]);
double cmu_DiheAngle(double p1[3], double p2[3], double p3[3], double p4[3]);
void cmu_Vnormal(double vn[3]);
double cmu_Vdot(double v1[3], double v2[3]);
void cmu_Vcross(double v1[3], double v2[3], double vcr[3]);
double cmu_Vangle(double v1[3], double v2[3]);
double cmu_Vrot(double v1[3], double v2[3], double raxis[3]);
double cmu_Vmag(double v[3]);
void cmu_PointOnPlane(double p1[3], double p2[3], double p3[3],
				double p[3], double pp[3]);
double cmu_MaxFval(double ax, double bx, double cx,
				double (*f)(), double tol, double *xmax);
double cmu_ImproperTorsionAngle(double *, double *, double *, double *);
CelErr cmu_ImpTorAlphaRotAxis(double *, double *, double *, double *, double *R);
void cmu_Vsub(double vsub[3], double vfrom[3], double vres[3]);
double cmu_Pdist(double p1[3], double p2[3]);
void cmu_Identity3d(double t[4][4]);
long cmu_GetRotXform(double rt[4][4], double angle, double axis[3],
  double pt[3]);
void cmu_XformPoint(double p[3], double t[4][4], double r[3]);
void cmu_RTSPoint(double p[3], double t[4][4], double r[3]);
CelErr cmu_MatrixTranspose(double *m, double *mt, long r, long c);
CelErr cmu_BestVRotation(
	double (*v1)[3],	/* first vector set */
	double (*v2)[3],	/* second vector set */
	double rot[3][3],	/* output rotation matrix will rotate v1 to v2 */
	long num,		/* the number of vectors */
	double *w			/* relative weights for num vectors */
);
CelErr cmu_MatrixMultiply(double *m1, double *m2, double *m1m2,
  long r, long cr, long c);
CelErr cmu_BestRotation(double (*p1)[3], double (*p2)[3], double rt[3][3],
  long num_p);
CelErr cmu_BuildPolyhedron(
	Vertices v[], /* all vertices from which convex polyhedron will be formed */
	long num_v, /* the length of v (total number of vertices) */
	double c[], /* center point */
	PolyhedronFaceH *polyhedron_listH /* list of polygons faces to be allocated by this routine */
);

void cmu_FormPolygon(
	Vertices v[], /* (input) vertices in polyhedra */
	double N[], /* (input) normal vector to face for "possible" vertice */
	long *num_p, /* (input/output) number of vertices indexes in list */
	long list[] /* (input/output) list of indexes v array. */
);

void cmu_DisposePolyhedron(
	PolyhedronFaceH polyhedron_listH /* list of polygons faces allocated by
										this routine cmu_BuildPolyhedron */
);

void cmu_BuildEllipse(
	double	u[3],		/* u axis vector IN */
	double	v[3],		/* v axis vector IN */
	double	theta0_d,	/* start angle (degrees) IN */
	double	theta1_d,	/* end angle (degrees) IN */
	long	n,		/* number of vertices in polygon IN */
	double	a[][3]		/* array of n vertices OUT */
);

Boolean cmu_EquivalentArrays(
    /* the length in terms of number of doubles of arrays A and B.
	** For multi dimensional arrays n is the product of the dimensions */
	long n,
	double *A,
	double *B,
	double eps /* proximity epsilon */
);

#ifdef __cplusplus	/* For type-safe linkage */
}
#endif

#endif 	// RC_INVOKED     	// Do only error #defines if compiling resources

#endif /* __CMU__ */
