#include "compat.h"
#include <stdio.h>
#include <string.h>
#include <CACheFileLib.h>
#include "MOPACDriver.h"

/*************************************************************************************
 *
 *  getmopacsettings		programmer Sam Cole 3/12/92
 *
 *  This function reads in the input control settings from a settings file. This
 *  information is put into an array of Control data structures
 *
 *	parameters		:		Control		; address of pointer to MOPACControl 
 *										data structure(s). If *Control == NULL,
 *										*Control is set to address of MOPACControl
 *										array allocated by this function (using malloc).
 *							controlfile ;file to read control parameters from.
 *							numControls ;used to return the number of controls.
 *							currentControl ; index of the current control in the
 *											 Control array (>= 0 if *Control != NULL)
 *											 if *Control == NULL or currentControl < 0.
 *
 *	calls			:		malloc, fscanf, GetDefaultParams, GetMOPACParams.
 *
 *	returns			:		0 if successful; other return values given as
 *					:		MOPAC_SETTINGS_* in MOPACDriver.h.
 *
 *	caveats			:		This routine must be able to deal with old-style
 *							(CAChe version 2.n) settings files.
 *
 *							Control must not be NULL, but *Control can be.
 *
 *							If *Control is not NULL and currentControl < 0,
 *							the array pointed to by *Control must be large
 *							enough to receive each control in controlfile.
 *
 *							If the values of the accessory file disposition
 *							settings are set in the final Control block, this
 *							value will be set for the entire set of Controls.
 *
 *							If the pointer to the Control structure(s) is
 *							not null, then only the currentControl member
 *							of the array of Controls is changed.  It receives
 *							the last set of parameters found in the settings file.
 *							However, if the currentControl number is negative,
 *							then Controls up to numControls are filled in. If
 *							the settings file does not contain enough Controls,
 *							default values are placed in the remaining Controls.
 *
 *							Assertion: the file is assumed to be positioned at 
 *							either the startSettings or startMOPAC line.
 *
 ***********************************************************************************/
 
long getmopacsettings(FILE *controlfile, MOPACControl **Control, 
		long *numControls, long currentControl)
{
	extern  FILE *output;
	static  char    buff1[80];
	int		itemp, i, j, whichControl;
	long	file_position;

	Boolean putInSpecificControl;

	/*
	 * Place the last Control in the settings file in the currentControl
	 * if the Control already exists and currentControl is a valid index.
	 */

	putInSpecificControl = ((*Control != NULL) && (currentControl >= 0));

	*numControls = 1; /* at least until more than one is encountered
						 and putInSpecificControl is false */

	if (controlfile == NULL) { 
		/* If there is no input file, set defaults */

		if (*Control == NULL) {
			/* Allocate space for Control */

			if ((*Control = (MOPACControl *) 
					malloc(sizeof(MOPACControl)*(*numControls))) == NULL)
				return(MOPAC_SETTINGS_ALLOCATE);
		}

		if (putInSpecificControl)
			whichControl = currentControl;
		else
			whichControl = 0;

		GetDefaultParams(&(*Control)[whichControl]);
		return (0L);
	} else { 
		/*
		 *  Process strings until error or end of file.
		 */

		file_position = ftell(controlfile);

		/* First check on the magic string.  This could be a binary file. */
		/* Try the short string first */
		cfl_fgets(buff1, 11, controlfile);
		if (strncmp("startMOPAC", buff1, 10) != 0) {
			fseek(controlfile, file_position, SEEK_SET);
			cfl_fgets(buff1, 14, controlfile);
			if (strncmp("startSettings", buff1, 13) != 0)
				return(MOPAC_SETTINGS_EMPTY);
		}
		fseek(controlfile, file_position, SEEK_SET);

		if (fscanf(controlfile,"%s",buff1) == EOF)
			return(MOPAC_SETTINGS_EMPTY);

		if (strcmp("startMOPAC", buff1) == 0) { 
			/* CAChe 2.n settings file */
	
			if (*Control == NULL) {
				/* Allocate space for Control */
				
				if ((*Control = (MOPACControl *) 
						malloc(sizeof(MOPACControl)*(*numControls))) == NULL)
					return(MOPAC_SETTINGS_ALLOCATE);
			}

			if (putInSpecificControl)
				whichControl = currentControl;
			else
				whichControl = 0;

			/* Position the file at the "startMOPAC" line */
			fseek(controlfile, file_position, SEEK_SET);
			GetMOPACParams(controlfile, &(*Control)[whichControl]);

		}	/* end of CAChe 2.n settings file */

		else if (strcmp("startSettings", buff1) == 0) {	
			/* CAChe 3.n settings */

			Boolean	saveDensity = FALSE, saveOutput = FALSE, saveRestart = FALSE;
			Boolean	saveGraphics = FALSE, saveArchive = FALSE, saveIsotope = FALSE;
			Boolean saveInput = FALSE, saveLog = FALSE;
			short	saveCharge = 0;

			/* Verify that this is a MOPAC Settings file */
			if (fscanf (controlfile, "%s", buff1) == EOF) 
				return (MOPAC_SETTINGS_MOPACSET);
			if (strcmp("MOPAC", buff1) !=0) 
				return (MOPAC_SETTINGS_MOPACSET);

			/* Get the number of Control blocks and the accessory file settings */
			if (fscanf (controlfile, "%s", buff1) == EOF) 
				return (MOPAC_SETTINGS_MOPACSET);
			while (strcmp("startMOPAC", buff1) != 0) {
				if (strcmp("numParamBlocks", buff1) == 0) {
					if (fscanf (controlfile, "%s", buff1) != EOF) {
						if (sscanf(buff1, "%ld", &itemp) == 1) 
							*numControls = itemp;
					}
				} else if (strcmp ("accessoryDensity", buff1) == 0) {
					if (fscanf (controlfile, "%s", buff1) != EOF) {
						if (sscanf(buff1, "%ld", &itemp) == 1) 
							saveDensity = itemp;
					}
				} else if (strcmp ("accessoryIsotope", buff1) == 0) {
					if (fscanf (controlfile, "%s", buff1) != EOF) {
						if (sscanf(buff1, "%ld", &itemp) == 1) 
							saveIsotope = itemp;
					}
				} else if (strcmp ("accessoryLog", buff1) == 0) {
					if (fscanf (controlfile, "%s", buff1) != EOF) {
						if (sscanf(buff1, "%ld", &itemp) == 1) 
							saveLog = itemp;
					}
				} else if (strcmp ("accessoryGraphics", buff1) == 0) {
					if (fscanf (controlfile, "%s", buff1) != EOF) {
						if (sscanf(buff1, "%ld", &itemp) == 1) 
							saveGraphics = itemp;
					}
				} else if (strcmp ("accessoryInput", buff1) == 0) {
					if (fscanf (controlfile, "%s", buff1) != EOF) {
						if (sscanf(buff1, "%ld", &itemp) == 1) 
							saveInput = itemp;
					}
				} else if (strcmp ("accessoryOutput", buff1) == 0) {
					if (fscanf (controlfile, "%s", buff1) != EOF) {
						if (sscanf(buff1, "%ld", &itemp) == 1) 
							saveOutput = itemp;
					}
				} else if (strcmp ("accessoryRestart", buff1) == 0) {
					if (fscanf (controlfile, "%s", buff1) != EOF) {
						if (sscanf(buff1, "%ld", &itemp) == 1) 
							saveRestart = itemp;
					}
				} else if (strcmp ("accessoryArchive", buff1) == 0) {
					if (fscanf (controlfile, "%s", buff1) != EOF) {
						if (sscanf(buff1, "%ld", &itemp) == 1) 
							saveArchive = itemp;
					}
				} else if (strcmp ("molecularCharge", buff1) == 0) {
					if (fscanf (controlfile, "%s", buff1) != EOF) {
						if (sscanf(buff1, "%ld", &itemp) == 1) 
							saveCharge = itemp;
					}
				}
				file_position = ftell(controlfile);
				if (fscanf (controlfile, "%s", buff1) == EOF) 
					return(MOPAC_SETTINGS_MOPACSET);
			}

			if (*Control == NULL) {
				/* Allocate space for Control */
				
				if ((*Control = (MOPACControl *) 
						malloc(sizeof(MOPACControl)*(*numControls))) == NULL)
					return(MOPAC_SETTINGS_ALLOCATE);
			}

			/* Position the file at the "startMOPAC" line */
			fseek(controlfile, file_position, SEEK_SET);

			for (i = 0; i < *numControls; i++) {
				if (putInSpecificControl)
					whichControl = currentControl;
				else
					whichControl = i;
				if (!GetMOPACParams(controlfile, &(*Control)[whichControl]))
					break;
			}

			if ((!putInSpecificControl) && (i < *numControls)) {
				/* Didn't find all the Controls; fill in the rest with defaults */
				/* NOTE: the i'th control has already been set to defaults by
				   GetMOPACParams before it returned false */
				while (++i < *numControls)
					GetDefaultParams(&(*Control)[i]);
			}

			if (putInSpecificControl)
				j = 1;
			else
				j = *numControls;
			for (i = 0; i < j; i++) {
				if (putInSpecificControl)
					whichControl = currentControl;
				else
					whichControl = i;

				(*Control)[whichControl].accessoryDensity = saveDensity;
				(*Control)[whichControl].accessoryInput = saveInput;
				(*Control)[whichControl].accessoryOutput = saveOutput;
				(*Control)[whichControl].accessoryRestart = saveRestart;
				(*Control)[whichControl].accessoryGraphics = saveGraphics;
				(*Control)[whichControl].accessoryArchive = saveArchive;
				(*Control)[whichControl].accessoryIsotope = saveIsotope;
				(*Control)[whichControl].accessoryLog = saveLog;
				(*Control)[whichControl].molecularCharge = saveCharge;
			}
		}	/* end of CAChe 3.n settings */
		else {
			return (MOPAC_SETTINGS_MOPACSET); /* not a MOPAC settings file */
		}
				
		return (0L);
	}
}
