/*
 * CACheEventsSSQ.h
 */

#ifndef	CACHE_EVENTS_SSQ_H
#define	CACHE_EVENTS_SSQ_H

#include <CACheMacros.h>

#define cev_CoreEventClass	CM_C4TOLONG('a','e','v','t')
#define cev_AEAnswer		CM_C4TOLONG('a','n','s','r')
#define cev_SentIPDataID	CM_C4TOLONG('c','e','v','1')

struct cev_AddToSQueue {
	UEM_UNIX_EVENT_BASE

	/* MESSAGE */
	ssq_StepControlPtr					stepControl;
	ssq_UnixFileTransferListPtr			inputFiles;
	ssq_UnixPrimaryOutputFileListPtr	primOutputFiles;
	ssq_UnixOutputFolderListPtr			outputFolders;

	/* REPLY */

};

struct cev_AppCompleted {
	UEM_UNIX_EVENT_BASE

	/* MESSAGE */
	ssq_StepID					serverQStepID;
	long						finalStatus;
	ssq_UnixFileTransferListPtr	outputFiles;
	char						serverName[ssq_ServerNameSize];

	/* REPLY */
	ssq_Err						resultCode;

};

struct cev_AppCompletedError {
	UEM_UNIX_EVENT_BASE

	/* MESSAGE */
	ssq_StepID					serverQStepID;
	long						finalStatus;
	char						serverName[ssq_ServerNameSize];

	/* REPLY */
	ssq_Err						resultCode;

};

struct cev_DataTransferErr {
	UEM_UNIX_EVENT_BASE

	/* MESSAGE */
	ssq_StepID		userQStepID;
	ssq_Err			errorCode;

	/* REPLY */

};

struct cev_KillApp {
	UEM_UNIX_EVENT_BASE

	/* MESSAGE */
	long   			fileDisposition;

	/* REPLY */

};

struct cev_KillSQStep {
	UEM_UNIX_EVENT_BASE

	/* MESSAGE */
	char			serverName[ssq_ServerNameSize];
	ssq_StepID		serverQStepID;
	char			userName[ssq_UserNameSize];
	long			fileDisposition;
	long			optKillMod;

	/* REPLY */
	ssq_Err			resultCode;

};

struct cev_ModifySQueue {
	UEM_UNIX_EVENT_BASE

	/* MESSAGE */
	ssq_StepControlPtr	stepControl;
	/* ssq_UnixNetAddr*	server; */

	/* REPLY */

};

struct cev_NewStatus {
	UEM_UNIX_EVENT_BASE

	/* MESSAGE */
	ssq_StepID				serverQStepID;
	ssq_StatusMsgPtr		statusMsg;
	char					serverName[ssq_ServerNameSize];

	/* REPLY */

};

struct cev_PreStartApp {
	UEM_UNIX_EVENT_BASE

	/* MESSAGE */
	ssq_StepID						serverStepID;
	char							serverName[ssq_ServerNameSize];
	char							machineName[ssq_MachineNameSize];
	char							appPath[ssq_PathNameSize];
	ssq_UnixFileTransferListPtr		inputFiles;
	ssq_UnixTempOutputFileDestPtr	outputFilesDest;

	/* REPLY */
	long							disk;
	long							paging;
	long							memory;

};

struct cev_ProcTransition {
	UEM_UNIX_EVENT_BASE

	/* MESSAGE */
	ssq_StepID				userQStepID;
	char					appName[ssq_ApplNameSize];

	/* REPLY */

};

struct cev_QueuedReplies {
	UEM_UNIX_EVENT_BASE

	/* MESSAGE */
	ssq_StepID				serverQStepID;
	char					serverName[ssq_ServerNameSize];
	long					uqStepState;

	/* REPLY */

};

struct cev_QueueProc {
	UEM_UNIX_EVENT_BASE

	/* MESSAGE */
	ssq_StepControlPtr					stepControl;
	ssq_UnixFileTransferListPtr			inputFiles;
	ssq_UnixPrimaryOutputFileListPtr	primOutputFiles;
	ssq_UnixOutputFolderListPtr			outputFolders;
	ssq_ProcedureListPtr				procStepFiles;
	/* ssq_UnixNetAddr*					submitter; */
	char								serverName[ssq_ServerNameSize];

	/* REPLY */
	ssq_Err								resultCode;
	ssq_StepID							serverQStepID;
	ssq_Date							dateSubmitted;
	char								illegalAppName[ssq_ApplNameSize];

};

struct cev_QueueStep {
	UEM_UNIX_EVENT_BASE

	/* MESSAGE */
	ssq_StepControlPtr					stepControl;
	ssq_UnixFileTransferListPtr			inputFiles;
	ssq_UnixPrimaryOutputFileListPtr	primOutputFiles;
	ssq_UnixOutputFolderListPtr			outputFolders;
	/* ssq_UnixNetAddr*					submitter; */
	char								serverName[ssq_ServerNameSize];

	/* REPLY */
	ssq_Err								resultCode;
	ssq_StepID							serverQStepID;
	ssq_Date							dateSubmitted;

};

struct cev_ReceiveOutputData {
	UEM_UNIX_EVENT_BASE

	/* MESSAGE */
	/* ssq_UnixNetAddr*				target; */
	ssq_StepID						userQStepID;
	ssq_UnixFileTransferListPtr		xfrOutputFiles;
	ssq_UnixTempOutputFileDestPtr	outputFilesDest;

	/* REPLY */

};

struct cev_ReceivedOutputData {
	UEM_UNIX_EVENT_BASE

	/* MESSAGE */
	ssq_StepID		serverQStepID;
	char			serverName[ssq_ServerNameSize];
	ssq_Err			completionErr;

	/* REPLY */

};

struct cev_RemoveFromSQueue {
	UEM_UNIX_EVENT_BASE

	/* MESSAGE */
	ssq_StepID			stepID;
	/* ssq_UnixNetAddr*	server; */
	char				serverName[ssq_ServerNameSize];
	long				finalState;

	/* REPLY */

};

struct cev_RemoveStep {
	UEM_UNIX_EVENT_BASE

	/* MESSAGE */
	ssq_StepID			userQStepID;
	ssq_MsgReasonPtr	msgReason;
	uem_Boolean			quitFlag;

	/* REPLY */

};

struct cev_RetrySendingDataSQ {
	UEM_UNIX_EVENT_BASE

	/* MESSAGE */
	ssq_StepID		serverQStepID;
	char			serverName[ssq_ServerNameSize];

	/* REPLY */
	ssq_Err			resultCode;

};

struct cev_SendInputData {
	UEM_UNIX_EVENT_BASE

	/* MESSAGE */
	/* ssq_UnixNetAddr*				target; */
	ssq_StepID						userQStepID;
	ssq_UnixTempOutputFileDestPtr	outputFilesDest;

	/* REPLY */

};

struct cev_SentInputData {
	UEM_UNIX_EVENT_BASE

	/* MESSAGE */
	ssq_StepID		serverQStepID;
	char			serverName[ssq_ServerNameSize];
	ssq_Err			completionErr;

	/* REPLY */

};

struct cev_ServerAlive {
	UEM_UNIX_EVENT_BASE

	/* MESSAGE */
	/* ssq_UnixNetAddr*	requester; */
	char				serverName[ssq_ServerNameSize];

	/* REPLY */
	ssq_Err			resultCode;

};

struct cev_StartApp {
	UEM_UNIX_EVENT_BASE

	/* MESSAGE */
	/* ssq_UnixNetAddr* serverQueueAddr; */
	ssq_StepID serverStepID;
	char serverName[ssq_ServerNameSize];
	char machineName[ssq_MachineNameSize];
	char appPath[ssq_PathNameSize];
	ssq_UnixFileTransferListPtr inputFiles;
	ssq_UnixTempOutputFileDestPtr outputFilesDest;

	/* REPLY */
};

struct cev_StepCompleted {
	UEM_UNIX_EVENT_BASE

	/* MESSAGE */
	ssq_StepID			userQStepID;
	long				finalStatus;

	/* REPLY */

};

struct cev_StepCompletedError {
	UEM_UNIX_EVENT_BASE

	/* MESSAGE */
	ssq_StepID		userQStepID;
	char			outputFilesPath[ssq_PathNameSize];
	long			finalStatus;

	/* REPLY */

};

struct cev_StepExecuting {
	UEM_UNIX_EVENT_BASE

	/* MESSAGE */
	ssq_StepID		userQStepID;
	ssq_Date		dateStarted;

	/* REPLY */

};

struct cev_StepPending {
	UEM_UNIX_EVENT_BASE

	/* MESSAGE */
	ssq_StepID			userQStepID;

	/* REPLY */

};

struct cev_StopApp {
	UEM_UNIX_EVENT_BASE

	/* MESSAGE */
	long   			fileDisposition;

	/* REPLY */

};

struct cev_StopSQStep {
	UEM_UNIX_EVENT_BASE

	/* MESSAGE */
	char			serverName[ssq_ServerNameSize];
	ssq_StepID		serverQStepID;
	char			userName[ssq_UserNameSize];
	long			fileDisposition;
	long			optKillMod;

	/* REPLY */
	ssq_Err			resultCode;

};

struct cev_SubscribeSQ {
	UEM_UNIX_EVENT_BASE

	/* MESSAGE */
	/* ssq_UnixNetAddr*	subscriberID; */
	char				serverName[ssq_ServerNameSize];

	/* REPLY */
	ssq_Err			resultCode;

};

struct cev_SubscribeSQStatus {
	UEM_UNIX_EVENT_BASE

	/* MESSAGE */
	ssq_StepID			serverQStepID;
	/* ssq_UnixNetAddr*	subscriberID; */
	char				serverName[ssq_ServerNameSize];

	/* REPLY */
	ssq_Err			resultCode;

};

struct cev_SynchQueue {
	UEM_UNIX_EVENT_BASE

	/* MESSAGE */
	/* ssq_UnixNetAddr*	requester; */
	char				serverName[ssq_ServerNameSize];

	/* REPLY */
	ssq_Err					resultCode;
	ssq_StepControlListPtr	stepControlList;

};

struct cev_UnsubscribeSQ {
	UEM_UNIX_EVENT_BASE

	/* MESSAGE */
	/* ssq_UnixNetAddr*	subscriberID; */
	char				serverName[ssq_ServerNameSize];

	/* REPLY */

};

struct cev_UnsubscribeSQStatus {
	UEM_UNIX_EVENT_BASE

	/* MESSAGE */
	ssq_StepID			serverQStepID;
	/* ssq_UnixNetAddr*	subscriberID; */
	char				serverName[ssq_ServerNameSize];

	/* REPLY */

};

struct cev_UpdateStatus {
	UEM_UNIX_EVENT_BASE

	/* MESSAGE */
	ssq_StepID			userQStepID;
	ssq_StatusMsgPtr	statusMsg;
	char				appName[ssq_ApplNameSize];

	/* REPLY */

};

#endif	/* CACHE_EVENTS_SSQ_H */

