/*
 * FileXferMgr.h
 */

#ifndef	FILE_XFER_MGR_H
#define	FILE_XFER_MGR_H

#define FTM_MAX_CLIENTS		16
#define FTM_MAX_REQUESTS	512

#define FTM_PATH_NAME_SIZE	1024
#define FTM_FILE_NAME_SIZE	256
#define FTM_FULL_NAME_SIZE	(FTM_PATH_NAME_SIZE /* + FTM_FILE_NAME_SIZE */ )

#define FTM_FILE_BUFSIZ		32768

enum ftm_Boolean {
	ftm_BooleanFalse,
	ftm_BooleanTrue,
	ftm_BooleanDummy = 0x12345678
};
typedef enum ftm_Boolean ftm_Boolean;

enum ftm_Err {
	ftm_ErrNone = 0,

	ftm_ErrUnknown = -8899,
	ftm_ErrOperationFailed,
	ftm_ErrOutOfMemory,
	ftm_ErrTooManyClients,
	ftm_ErrTooManyServers,
	ftm_ErrNoSuchClient,
	ftm_ErrNoSuchServer,
	ftm_ErrBadArgument,
	ftm_ErrTimeout,
	ftm_ErrQueueFull,
	ftm_ErrBadAck,
	ftm_ErrReqFailed,
	ftm_ErrPutFailed,
	ftm_ErrGetFailed,
	ftm_ErrAbtFailed,
	ftm_ErrClientStopped,
	ftm_ErrNoSuchRequest,
	ftm_ErrXferAborted,

	ftm_ErrServerIOError,
	ftm_ErrClientIOError,
	ftm_ErrServerDiskFull,
	ftm_ErrClientDiskFull,
	ftm_ErrServerFileNotFound,
	ftm_ErrClientFileNotFound,
	ftm_ErrServerDirNotFound,
	ftm_ErrClientDirNotFound,
	ftm_ErrServerFileBusy,
	ftm_ErrClientFileBusy,

	/* error codes set in forked server */
	ftm_ErrChildSigActionFailed,
	ftm_ErrChildEndCriticalFailed,
	ftm_ErrChildWaitForConnectionFailed,
	ftm_ErrChildIoctlFailed,
	ftm_ErrChildOpenFailed,
	
	/* error codes set in file filter */
	ftm_ErrCFFUnknownXferDir,
	ftm_ErrCFFUnknownXferMode,
	ftm_ErrCFFBadKeyword,
	ftm_ErrCFFTimeout,
	ftm_ErrCFFBadSize,
	ftm_ErrCFFReadFailed,
	ftm_ErrCFFWriteFailed,
	ftm_ErrCFFEndOfFile,
	
	/* error codes set in server parent */
	ftm_ErrNoServer,
	ftm_ErrServerBusy,
	ftm_ErrBadRequest,
	ftm_ErrCreatFailed,
	ftm_ErrOpenFailed,
	ftm_ErrFstatFailed,
	ftm_ErrCreateChannelFailed,
	ftm_ErrBeginCriticalFailed,
	ftm_ErrEndCriticalFailed,
	ftm_ErrForkFailed,
	ftm_ErrRegistrationFailed,
	ftm_ErrKillFailed,
	ftm_ErrSuspendFailed,
	ftm_ErrNoSuchChild,
	ftm_ErrUnexpectedExitOfChild,
	
	ftm_ErrWaitForConnectionFailed,
	ftm_ErrIoctlFailed,
	ftm_ErrDup2Failed,
	ftm_ErrExecFailed,
	
	/* error codes set in ftm_CvtExitStatusToFtmErr */
	ftm_ErrStopped,
	ftm_ErrSignaled,
	ftm_ErrBadExitStatus,

	ftm_ErrDummy = 0x12345678
};
typedef enum ftm_Err ftm_Err;

#if		defined(unix)
	/*
	 * Signal sent by parent to abort child (using kill()).
	 */
	#define FTM_ABORT_XFER_SIGNAL SIGTERM

	/*
	 * Macros to convert error codes to and from exit codes.
	 * Exit codes start at 1.
	 */
	#define FTM_ERROR_TO_EXIT(err_code)		\
		(err_code == ftm_ErrNone ? ftm_ErrNone : err_code - ftm_ErrUnknown + 1)
	#define FTM_EXIT_TO_ERROR(exit_code)	\
		(exit_code == ftm_ErrNone ? ftm_ErrNone : exit_code + ftm_ErrUnknown - 1)
#endif

enum ftm_XferMode {
	ftm_XferModeBinary,
	ftm_XferModeText,
	ftm_XferModeSpecial1,	/* for map files (1/2 text, 1/2 binary) */
	ftm_XferModeSpecial2,	/* compressed? */
	ftm_XferModeCount,
	ftm_XferModeDummy = 0x12345678
};
typedef enum ftm_XferMode ftm_XferMode;

enum ftm_XferDir {
	ftm_XferDirUnknown,
	ftm_XferDirPut  = 1,	/* Client */
	ftm_XferDirRecv = 1,	/* Server */
	ftm_XferDirGet  = 2,	/* Client */
	ftm_XferDirSend = 2,	/* Server */
	ftm_XferDirCount,
	ftm_XferDirDummy = 0x12345678
};
typedef enum ftm_XferDir ftm_XferDir;

/* Forward references. */
typedef struct ftm_Client ftm_Client;
typedef struct ftm_Server ftm_Server;


/* Client-Server messages */

/* Abort a file transfer (Client->Server). */
struct ftm_AbtMsg {
	long   			ftmID;
	long   			reqID;
};
typedef struct ftm_AbtMsg ftm_AbtMsg;

struct ftm_AbtReply {
	long   			xxx;
};
typedef struct ftm_AbtReply ftm_AbtReply;

/* Ack file transfer (Server->Client). */
struct ftm_AckMsg {
	long   			ftmID;
	long   			reqID;
	ftm_Err			ftm_err;
	long			exit_status;	/* exit status of server (from exit call on Unix) */
};
typedef struct ftm_AckMsg ftm_AckMsg;

struct ftm_AckReply {
	long   			xxx;
};
typedef struct ftm_AckReply ftm_AckReply;

/* Request file transfer (Client->Server). */
struct ftm_ReqMsgFileItem {
	long   			fileID;
	char			name[FTM_FULL_NAME_SIZE];
	ftm_XferMode	mode;
	long   			size;	/* for Put */
};
typedef struct ftm_ReqMsgFileItem ftm_ReqMsgFileItem;
	
struct ftm_ReqMsgFileList {
	long			numItems;
	ftm_ReqMsgFileItem	item[1];
};
typedef struct ftm_ReqMsgFileList  ftm_ReqMsgFileList;
typedef struct ftm_ReqMsgFileList* ftm_ReqMsgFileListPtr;

struct ftm_ReqMsg {
	long   			ftmID;
	long   			reqID;
	ftm_XferDir		dir;
};
typedef struct ftm_ReqMsg ftm_ReqMsg;

/* Reply to file transfer request (Server->Client). */
struct ftm_ReqReplyFileItem {
	long   			fileID;
	long   			size;	/* for Get */
};
typedef struct ftm_ReqReplyFileItem ftm_ReqReplyFileItem;
	
struct ftm_ReqReplyFileList {
	long					numItems;
	ftm_ReqReplyFileItem	item[1];
};
typedef struct ftm_ReqReplyFileList  ftm_ReqReplyFileList;
typedef struct ftm_ReqReplyFileList* ftm_ReqReplyFileListPtr;

struct ftm_ReqReply {
	long   			ftmID;
	long   			reqID;
	ftm_Err			ftm_err;
	chm_NetAddr		server;
};
typedef struct ftm_ReqReply ftm_ReqReply;

/* File lists */

struct ftm_FileItem {
	char			srcPath[FTM_PATH_NAME_SIZE];		/* path of src file */
	char			srcFileName[FTM_FILE_NAME_SIZE];	/* just src filename */
	char			dstPath[FTM_PATH_NAME_SIZE];		/* path of dst file */
	char			dstFileName[FTM_FILE_NAME_SIZE];	/* just dst filename */
	ftm_XferMode	mode;
};
typedef struct ftm_FileItem  ftm_FileItem;
typedef struct ftm_FileItem* ftm_FileItemPtr;

struct ftm_FileList {
	long				numItems;
	ftm_FileItem		item[1];
};
typedef struct ftm_FileList  ftm_FileList;
typedef struct ftm_FileList* ftm_FileListPtr;


/* Request class */ 

struct ftm_RequestClass {
	char	*name;
};
typedef struct ftm_RequestClass ftm_RequestClass;

struct ftm_Request {
	ftm_RequestClass	*classp;
	long				id;
	
	ftm_FileList		*fileList;
	ftm_XferDir   		dir;
	
	void				(*userHdlr)(void *userData, ftm_Err ftm_err);	/* completion handler may be NULL */
	ftm_Boolean			(*userMatch)(void *userData1, void *userData2);	/* matching function may be NULL */
	void				*userData;

	ftm_Boolean			haveAck;	/* ack for this request has arrived */
	ftm_Err				ftm_err;	/* error code from ack */
	ftm_Boolean			shouldAbt;	/* tells FTM thread whether to abort xfer */
};
typedef struct ftm_Request ftm_Request;

#ifdef __cplusplus
extern "C" {
#endif

/* Request class operations */

ftm_Err
ftm_RequestClass_Init(
void
);

ftm_Err
ftm_RequestClass_Term(
void
);


/* Request operations */

ftm_Err
ftm_Request_Create(
ftm_Request		**newRequest,	/* ptr to new request OUT */
long			numFiles,
ftm_XferDir   	dir,
void			(*userHdlr)(void *userData, ftm_Err ftm_err),	/* completion handler may be NULL */
ftm_Boolean		(*userMatch)(void *userData1, void *userData2),	/* matching function may be NULL */
void			*userData										/* may be NULL */
);

ftm_Err
ftm_Request_Delete(
ftm_Request	*request
);

#ifdef __cplusplus
}
#endif

/* Client class */ 

enum ftm_ClientState {
	ftm_ClientStateStart,
	ftm_ClientStateIdle,
	ftm_ClientStateBusy,
	ftm_ClientStateStop,
	ftm_ClientStateExit,
	ftm_ClientStateDummy = 0x12345678
};
typedef enum ftm_ClientState ftm_ClientState;

struct ftm_ClientClass {
	char				*name;
	int					num_clients;				/* num clients */
	ftm_Client			*client[FTM_MAX_CLIENTS];	/* client list */
};
typedef struct ftm_ClientClass ftm_ClientClass;

struct ftm_Client {

	ftm_ClientClass		*classp;
	long				id;

	ftm_ClientState		state;
	
	uem_UnixEventMgr	*uem;					/* Unix event mgr */
	int					num_reqs;				/* num items in queue */
	ftm_Request			*req[FTM_MAX_REQUESTS];	/* request queue */
	ftm_Request			*curReq;				/* current request (this is not in req) */
};
/* typedef struct ftm_Client ftm_Client; */

/* Client class operations */

#ifdef __cplusplus
extern "C" {
#endif

ftm_Err
ftm_ClientClass_Init(
ftm_Boolean	debug,
FILE		*fp		/* logfile or NULL */
);

ftm_Err
ftm_ClientClass_Term(
void
);

ftm_Err
ftm_ClientClass_HandleAck(
uem_UnixEvent	*evt,
ftm_AckMsg		*msg
);


/* Client operations */

ftm_Err
ftm_Client_Create(
ftm_Client			**newClient,	/* ptr to new client OUT */
uem_UnixEventMgr	*uem			/* Unix event mgr */
);

ftm_Err
ftm_Client_Delete(
ftm_Client				*client
);

ftm_Err
ftm_Client_Submit(
ftm_Client				*client,
ftm_Request				*request
);

ftm_Err
ftm_Client_Abort(
ftm_Client				*client,
ftm_Request				*request	/* NULL means request at head of queue */
/*	long					reqId ??? */
/*	void					*userData ??? */
);

ftm_Err
ftm_Client_AbortByUserData(
ftm_Client				*client,
void					*userData
);

void
ftm_Client_ChannelEventHdlr(
ftm_Client				*ftm,		/* channel client */
chm_ChannelEventDesc	*ceDesc
);

void
ftm_Client_IdleProc(
ftm_Client				*ftm		/* channel client */
);

#ifdef __cplusplus
}
#endif

/* Server class */ 

enum ftm_ServerState {
	ftm_ServerStateIdle,
	ftm_ServerStateBusy,
	ftm_ServerStateDummy = 0x12345678
};
typedef enum ftm_ServerState ftm_ServerState;

struct ftm_ServerClass {
	char				*name;
	ftm_Server			*server;	/* only one server */
};
typedef struct ftm_ServerClass ftm_ServerClass;

struct ftm_Server {

	ftm_ServerClass			*classp;
	long					id;

	ftm_ServerState			state;
	ftm_ReqMsg				msg;				/* most recent request msg */
	ftm_ReqReplyFileListPtr	replyFileList;		/* most recent reply fileList */
	
	uem_UnixEventMgr		*uem;				/* Unix event mgr */
	
#if		defined(unix)
	pid_t					pid;				/* process id of child */
#endif

};
/* typedef struct ftm_Server ftm_Server; */

/* Server class operations */

#ifdef __cplusplus
extern "C" {
#endif

ftm_Err
ftm_ServerClass_Init(
ftm_Boolean				debug,
FILE					*fp		/* logfile or NULL */
);

ftm_Err
ftm_ServerClass_Term(
void
);

ftm_Err
ftm_ServerClass_HandleReq(
uem_UnixEvent			*evt,
ftm_ReqMsg				*msg,
ftm_ReqMsgFileListPtr	msgFileList,
ftm_ReqReply			*reply,
ftm_ReqReplyFileListPtr	*replyFileList
);

ftm_Err
ftm_ServerClass_HandleAbt(
uem_UnixEvent	*evt,
ftm_AbtMsg		*msg
);

ftm_Err
ftm_ServerClass_Abort(
void
);


/* Server operations */

ftm_Err
ftm_Server_Create(
ftm_Server			**newServer,	/* ptr to new server OUT */
uem_UnixEventMgr	*uem			/* Unix event mgr */
);

ftm_Err
ftm_Server_Delete(
ftm_Server				*server
);

void ftm_Server_ChannelEventHdlr( ftm_Server *ftm, /* channel client */ chm_ChannelEventDesc *ceDesc );

void
ftm_Server_IdleProc(
ftm_Server				*ftm		/* channel client */
);

#ifdef __cplusplus
}
#endif

#endif	/* FILE_XFER_MGR_H */
