// CSUWIN.H
// some Windows specific utility functions for CSU
// These are used by the Molecule browser, 
// but might eventually be incorporated in CSU itself
// June 7, 1992
// Dan Weston
// __exports removed 5/1/96 JAS
//
// 14/Jun/2000 Ingvar Lagerstedt, Oxford Molecular
//				Removed 16-bit Windows support
//				Use _CACHE_DLL for CSU_IMPORT_EXPORT to allow sharing with static libs
// 27/Jun/2000	renamed from csuutils.h to csuWin.h
//  3/Jul/2000	Updated prototypes
// 
#ifndef _CSUWIN_
#define _CSUWIN_

#include "csu.h"


// define these macros so we can switch memory allocation schemes
// for molstructs as needed

#define ALLOC_MOLSTRUCT (MolStruct*)calloc(1, sizeof(MolStruct))
#define FREE_MOLSTRUCT(ms) { csu_DeleteMolstruct(ms,1,1); free(ms); }

#ifdef __cplusplus
	extern "C" {		/* Specify "C"-style linkage */
#endif 


CelErr CSU_IMPORT_EXPORT csu_GetConnProps(
	MolStruct *ms, 
	ConnProps *conn_props
);


CelErr CSU_IMPORT_EXPORT csu_DeleteObjclsNoAdd(
	MolStruct * msPtr, 
	u_char		del_flag
);

CelErr CSU_IMPORT_EXPORT csu_CompressConns(MolStruct* msPtr);

CelErr CSU_IMPORT_EXPORT csu_AddObjects(
	ObjclsH		objclsH_from, 
	ObjclsID	oc_from, 
	MolStruct	*msPtr_to, 
	LongH		*new_idHp, 
	BOOL		add_props
);

CelErr CSU_IMPORT_EXPORT csu_CopyValue(
	PropH		propsH_from,
	PropID		pi, 
	ObjectID	obi,
	PropH		propsH_to,
	PropID		pi2, 
	ObjectID	obi2
);

// clear a specified object value
CelErr CSU_IMPORT_EXPORT csu_ClearObjectValue(
	MolStruct * msPtr,
	ObjclsID objclsID,
	PropID propID,
	ObjectID objID
);

// get and set the locked and valid bits for a particular object
CelErr CSU_IMPORT_EXPORT csu_IsPropLocked(
	MolStruct * msPtr,
	ObjclsID objclsID,
	PropID propID,
	ObjectID objID,
	short* lockedVal
);
							
CelErr CSU_IMPORT_EXPORT csu_SetPropLocked(
	MolStruct * msPtr,
	ObjclsID objclsID,
	PropID propID,
	ObjectID objID,
	short lockedVal
);

CelErr CSU_IMPORT_EXPORT csu_IsPropValid(
	MolStruct * msPtr,
	ObjclsID objclsID,
	PropID propID,
	ObjectID objID,
	short* validVal
);
							
CelErr CSU_IMPORT_EXPORT csu_SetPropValid(
	MolStruct * msPtr,
	ObjclsID objclsID,
	PropID propID,
	ObjectID objID,
	short validVal
);

// convert an object index to its corresponding object ID
CelErr CSU_IMPORT_EXPORT csu_IndexToID(
	MolStruct * msPtr,
	ObjclsID objclsID,
	ObjectID index,
	ObjectID *id
);
							
// convert an object ID to its corresponding object index
CelErr CSU_IMPORT_EXPORT csu_IDToIndex(
	MolStruct * msPtr,
	ObjclsID objclsID,
	ObjectID id,
	ObjectID* index
);

CelErr CSU_IMPORT_EXPORT csu_GetNumObjects(
	MolStruct *msPtr,
	ObjclsID objclsID,
	ObjectID *numObjects
);

 
CelErr CSU_IMPORT_EXPORT csu_CopyMolstruct(
	MolStruct * msPtr1,
 	MolStruct * msPtr2
);
 							
 							
// Call this function to find out how many object classes in a molstruct. 
// It is typically called just before calling csu_GetObjectClassIDs to 
// know how big an array to allocate for that function.
CelErr CSU_IMPORT_EXPORT csu_GetNumObjectClasses(
	MolStruct * ms,
	ObjclsID * numObjClasses
);
							   

// This function fills in a caller-supplied array of ID numbers, one ID 
// for each object class in the molstruct.  Call csu_GetNumObjectClasses 
// to determine how big the array needs to be.
CelErr CSU_IMPORT_EXPORT csu_GetObjectClassIDs(
	MolStruct	* ms,
	ObjclsID	*idArray,
	ObjclsID	maxArraySize
);


// Call this function to find out how many properties are defined for a 
// particular object class. It is typically called just before calling 
// csu_GetObjectClassIDs to know how big an array to allocate for that function.
CelErr CSU_IMPORT_EXPORT csu_GetNumProperties(
	MolStruct * ms,
	ObjclsID objClassID,
	PropID  * numProperties
);

// This function fills in a caller-supplied array of ID numbers, one ID 
// for each property in the specified object class. Call 
// csu_GetNumProperties to determine how big the array needs to be
CelErr CSU_IMPORT_EXPORT csu_GetPropertyIDs(
	MolStruct * ms,
	ObjclsID objClassID,
	PropID  *idArray,
	PropID maxArraySize
);

// translate an objectclass ID to a object class name
CelErr CSU_IMPORT_EXPORT csu_GetObjectClassName(
	ObjclsID objClassID,
	char *buffer
);

// translate an objectclass ID to a object class name
CelErr CSU_IMPORT_EXPORT csu_GetPropertyName(
	PropID propertyID,
	char *buffer
);


// this function returns information about the specified object property
//     : size of array element
//     : number of array elements
//  Use it to determine how much memory
//    is necessary to hold data for value before calling csu_GetValueUser .
CelErr CSU_IMPORT_EXPORT csu_GetPropertySize(
	MolStruct  * ms,
	ObjclsID objClassID,
	PropID  propID,
	short  *arrayElementSize,
	long  *numberArrayElements
);

#ifdef __cplusplus
}
#endif 


#endif
							   							   
