#define MOPAC_FLGS_READY 1
#define MOPAC_FLGS_NOTREADY 0

typedef struct MOPAC_Environ
{
	long serverFlag;
	long clientFlag;
	long outputFile;
	long shutdownFlag;
	struct msgBuffers *msgBufVAddr;	/* VAddr in 88K address space */
} MOPAC_Environ, *MOPAC_EnvPtr;

typedef struct msgBuffers {
	cul_CPMsgChannel channel1; /* Optimization status */
	cul_CPMsgChannel channel2; /* Current operation */
	cul_CPMsgChannel channel3; /* Current calculation */
	cul_CPMsgChannel channel4; /* Message to the current operation AND
								signals the application request server 
								that the output file is to be processed */
	char message1[128];
	char message2[128];
	char message3[128];
	char message4[128];
} msgBuffers, *msgBuffersPtr; /* pointer to message channels for 88K (32-bit address) */

