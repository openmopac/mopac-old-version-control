#include  <CACheFileLib.h>
#include  <MOPACDriver.h>
int updateversion(MolStruct *outputMolStruct, Appl_Info *applInfo)
{
      return (0);
#ifdef NEEDSWORK
/*
 *  (A) Modify version number (6.1.001.001) to replace the first "001" with
 *  the Julian date of creation of the manager and the second "001" with
 *  the Julian date of the compute engine.
 *  (B) Add date-stamps for the creation dates of the compute engine and its manager.
 */
	{
	    char	aString[256], errs[256];
        char	Engine_Creation_Date[24],
	            Manager_Creation_Date[24];
		char	Month[36] = "JanFebMarAprMayJunJulAugSepOctNovDec";
		char	From_date[24];
		char	*ii;
		short	days[12] =  { 31,28,31,30,31,30,31,31,30,31,30,31};
		short	i, j, Julian;
		long    rtn_code;
	    FILE 		*input = NULL;
	    static char	functionName[] = "MOPACupdateMolstruct";
		PropID		 date_compute_engine_createdID, date_compute_manager_createdID;
/*
 *  Build Julian date
 */
		for (j = 0, i = 0; i < 12; i++)
		{
			j += days[i];
			days[i] = j - days[i];
		}   
		strcpy(Manager_Creation_Date,__TIMESTAMP__);
		strcpy(From_date,&Manager_Creation_Date[4]);
		From_date[3] = 0;
        ii = strstr( Month, From_date );
		if (ii != NULL)
		{
			Julian = days[(ii - Month)/3] + Manager_Creation_Date[9] - '0';
			if (Manager_Creation_Date[8] != ' ')
			Julian = Julian + 10*(Manager_Creation_Date[8] - '0');
/*
 *  Convert Julian into text. Julian "1" becomes "001", "10" becomes "010", and 
 *  "100" becomes "100".
 */
			j = applInfo->version[7];
			if (Julian > 99) 
				i = 4;
			else if (Julian > 9)
				i = 5;
			else
				i = 6;
			_itoa( Julian, &applInfo->version[i], 10);
			applInfo->version[7] = (char)j;
			
		}

	if ((rtn_code = csu_GetPropertyID("Date_Compute_Manager_Created",&date_compute_manager_createdID)) < 0) {
    sprintf (errs,"%s: csu_GetPropertyID Date_Compute_manager_Created rtn_code %d\n",
            functionName, rtn_code);
	alert_user(errs);
    return (-1);
  }

	  if ((rtn_code = csu_GetPropertyID("Date_Compute_Engine_Created",&date_compute_engine_createdID)) < 0) {
    sprintf (errs,"%s: csu_GetPropertyID Date_Compute_Engine_Created rtn_code %d\n",
            functionName, rtn_code);
	alert_user(errs);
    return (-1);
  }
	if ((rtn_code = csu_AddObjVal(outputMolStruct, CalcHistID, date_compute_manager_createdID, 
  					calchist_objectnum, MOPAC_SRC, CSU_STRING, 
					(short)(strlen(Manager_Creation_Date)+1), NoUnit, 0,
                  (char*)Manager_Creation_Date, 1, BY_ID)) < 0) {
    sprintf (errs,"%s: csu_AddObjVal Manager_Creation_Date rtn_code %d\n",
            functionName, rtn_code);
	alert_user(errs);
	return(-1);
  }
/*
 *   Read in date of creation of MOPAC executable.
 */
/* Check availability of Output file */

	if (!(input = fopen(MOPACOutputFile,"r")))
		{
			sprintf(aString,"updateMolstruct: The file %s cannot be opened.",
					MOPACOutputFile);
			alert_user(aString);
			return(-1);
		}
/*
 *   The date of creation of the MOPACComputeEngine will be in the first few lines
 *   of the output, if it exists.  So only need to check the first 30 lines.
 */
	for (i = 0;i < 30; i++) 
		{
		if (cfl_fgets(aString, sizeof(aString), input) == NULL) 
			break;
		if ((strncmp(aString," * Date and time this executable was created:",44) == 0))
			{
/*
 *  Format of the line read in is:
 * Date and time this executable was created: Tue Dec 30 09:59:36 2003
          1         2         3         4         5         6         7
01234567890123456789012345678901234567890123456789012345678901234567890
 */

			strcpy(Engine_Creation_Date,&(aString[46]));
			Engine_Creation_Date[24] = 0;
			replaceBlanks(Engine_Creation_Date,'_');
		
			if ((rtn_code = csu_AddObjVal(outputMolStruct, CalcHistID, 
				date_compute_engine_createdID, calchist_objectnum, MOPAC_SRC, 
				CSU_STRING, (short)(strlen(Engine_Creation_Date)+1), NoUnit, 0,
                (char*)Engine_Creation_Date, 1, BY_ID)) < 0) 
				{
				sprintf (errs,"%s: csu_AddObjVal Engine_Creation_Date rtn_code %d\n",
				functionName, rtn_code);
				alert_user(errs);
				}

			for (; i < 30; i++)
				{
				if (cfl_fgets(aString, sizeof(aString), input) == NULL) 
					break;
				if ((strncmp(aString," * Julian date:",15) == 0)) 
					{
/*
 *  Format of the line read in is:
 * Julian date:  365
          1         2  <- Information for you, the reader.
012345678901234567890  <- Information for you, the reader.
 */
					strcpy(&(applInfo->version[8]),&(aString[17])); 
					if (applInfo->version[8] == ' ')applInfo->version[8] = '0';
					if (applInfo->version[9] == ' ')applInfo->version[9] = '0';
					if ((rtn_code = csu_AddObjVal(outputMolStruct, CalcHistID, VersionID, 
					calchist_objectnum,MOPAC_SRC, CSU_STRING, 10, NoUnit, 0,
					(char*)applInfo->version, 1, BY_ID)) < 0) 
						{
						sprintf (errs,"%s: csu_AddObjVal Version rtn_code %d\n",
						functionName, rtn_code);
						alert_user(errs);
						return (-1); 
						}
						
					}
				}	
			fclose(input);
			return(1);
			break;
			}
		}
	return(1);
	}
#endif
}
