#include <compat.h>

void replaceBlanks(char *s, char c)
{
	char *ss;
	
	for (ss = s; *ss != '\0'; ss++) {
	  if (*ss == ' ') *ss = c;
	}
}

void makeCompoundName(char *base, char *suffix, char *compound)
/*
 * compound is a character string at least 32 characters long.
 *
 * The resulting compound string will be at most 31 characters, and will
 * have all blanks replaced by underscores.
 */
{
	char str2[32];
	int lens, lenb;
	
	strncpy(str2, suffix, 31);
	str2[31] = 0;
	
	lens = strlen(str2);
	
	if (lens < 31) {
		strncpy(compound, base, 31-lens);
		lenb = strlen(base);
		if (lenb > (31 - lens)) 
			strcpy(compound + (31 - lens), str2);
		else
			strcpy(compound + lenb, str2);
	} else
		strcpy(compound, str2);
		
	replaceBlanks(compound, '_');

}
