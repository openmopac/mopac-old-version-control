#include <compat.h>
#include <cpu.h>
#include <MOPACDriver.h>
#include <csuServer.h>

long getNumberLockedLabels(MolStruct	*molStruct)
{
	static ObjclsID objectClass[] = {Atom_distID, Bond_angID, DihedralID};
	int i,j;
	long	 numLockedLabels, numberOfLabels;
	ObjectID objectID;
 	double	 lowValue;
	double	 highValue;
	long	 numSteps;
	ObjectID atomList[5];

	numLockedLabels = 0;
	numberOfLabels = 0;
	for (j=0; j<3; j++)
		numberOfLabels += csu_CountValidObjects(molStruct, (ObjclsID) objectClass[j]);

	for (j=0; j < 3; j++) {
		i=0;
		while (i < numberOfLabels) { /* number of atoms or labels */
			cpu_getLabelAtoms(molStruct, atomList,
							  objectClass[j], i);
			if (atomList[0] != 0) {
				if (cpu_LabelStatus(molStruct, atomList,objectClass[j], &objectID,
					&lowValue, &highValue, &numSteps) == 2) 
					/* returns 2 for a locked label */
					   numLockedLabels++;
			}
		i++;
		}
	}
	return (numLockedLabels);
}

void getLockedLabels(molStruct, lockedLabels)
MolStruct	*molStruct;
LockedLabel lockedLabels[];
{
	static ObjclsID objectClass[] = {Atom_distID, Bond_angID, DihedralID};
	static ObjclsID shortObjectClass[] = {Atom_distID, Bond_angID, DihedralID};
	long 	 numberOfLabels, numLockedLabels;
	long	 i,j,k;
 	double	 lowValue;
	double	 highValue;
	double 	 lockedValue;
	long	 numSteps;
	ObjectID objectID;
	ObjectID tempAtomList[5];
	
	numLockedLabels = 0;
	numberOfLabels = 0;

	for (j=0; j<3; j++)
		numberOfLabels += csu_CountValidObjects(molStruct, objectClass[j]);
	
	for (j=0; j < 3; j++) {
		i=0;
		while (i < numberOfLabels) { /* number of labels */
			cpu_getLabelAtoms(molStruct, tempAtomList, objectClass[j], i);
			if (tempAtomList[0] != 0) {
				if (cpu_LabelStatus(molStruct, tempAtomList, objectClass[j], &objectID,
					&lowValue, &highValue, &numSteps) == 2)
				{
					lockedAdjust(molStruct, tempAtomList, shortObjectClass[j], 
						&lockedValue);
					for (k=0; k<=tempAtomList[0]; k++)
						lockedLabels[numLockedLabels].atomList[k] = tempAtomList[k];
					lockedLabels[numLockedLabels].value = lockedValue;
					numLockedLabels++;
				}
			}
		i++;
		}
	}
}
