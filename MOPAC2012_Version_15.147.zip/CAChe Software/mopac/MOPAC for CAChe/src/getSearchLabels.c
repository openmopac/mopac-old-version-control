#include "compat.h"
#include "cpu.h"
#include "MOPACDriver.h"
#include <csuServer.h>

int getSearchLabels(MolStruct *molStruct, 
			SearchLabel searchLabels[2], int max_num_labels)
{
	static ObjclsID objectClass[] = {Atom_distID, Bond_angID, DihedralID};
	int i, j, k;
	int	numSearchLabels;
	long numberOfLabels;
	ObjectID objectID;
	CSUObj objs[4];
	cpu_NbrObjs nbr_objs;
	double value;


	if (max_num_labels > 2) {
		alert_user("getSearchLabels: too many labels requested.");
		return (0);
	}
	
	numSearchLabels = 0;
	numberOfLabels = 0;
	for (j=0; j<3; j++) {
		numberOfLabels += csu_CountValidObjects(molStruct, (ObjclsID) objectClass[j]);
	}

	for (i=0; i<2; i++) { /* initialize the complete search label */
		searchLabels[i].atomList[0] = 0;
		searchLabels[i].lowValue = 0;
		searchLabels[i].highValue = 0;
		searchLabels[i].numSteps = 0;
		for (j=1; j<5; j++) 
			searchLabels[i].atomList[j] = -1;
	}
	
	if (cpu_getNbrObjs(molStruct, &nbr_objs) < 0)
		return (0);

	objs[0].oci = objs[1].oci = objs[2].oci = objs[3].oci = AtomID;

	for (j=0; j < 3 && numSearchLabels < max_num_labels; j++) {
		i=0;
		while (numSearchLabels < max_num_labels && i < numberOfLabels) { /* number of atoms or labels */
			cpu_getLabelAtoms(molStruct, searchLabels[numSearchLabels].atomList,
							  objectClass[j], i);
			if (searchLabels[numSearchLabels].atomList[0] != 0) {
				if (cpu_LabelStatus(molStruct,
					searchLabels[numSearchLabels].atomList,
					objectClass[j], &objectID,
					&(searchLabels[numSearchLabels].lowValue),
					&(searchLabels[numSearchLabels].highValue),
					&(searchLabels[numSearchLabels].numSteps))) {
					
					if (searchLabels[numSearchLabels].numSteps > 0) {
						searchLabels[numSearchLabels].objclsID = objectClass[j];
						for (k = 0; k < searchLabels[numSearchLabels].atomList[0]; k++)
							objs[k].obi = searchLabels[numSearchLabels].atomList[k+1];

						/* Set the value of the label to its initial value */

						if (searchLabels[numSearchLabels].objclsID == Atom_distID)
							value = searchLabels[numSearchLabels].lowValue;
						else
							value = CMU_DEGREES_TO_RADIANS(searchLabels[numSearchLabels].lowValue);

						cpu_AdjustLabel(molStruct, searchLabels[numSearchLabels].objclsID, 
									objs, &nbr_objs, value);

						numSearchLabels++;
					}
				}
			}
		i++;
		}
	}
	cpu_freeNbrObjs(&nbr_objs);
	return (numSearchLabels);
}
