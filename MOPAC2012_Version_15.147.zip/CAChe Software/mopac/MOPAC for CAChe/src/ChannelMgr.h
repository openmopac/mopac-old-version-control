/*
 * ChannelMgr.h
 */

#ifndef	CHANNEL_MGR_H
#define	CHANNEL_MGR_H

#include <time.h>
#include <stdio.h>

#if defined(unix)

#if defined(cache_irix)
#include <arpa/nameser.h>
#include <resolv.h>
#endif

#include <sys/socket.h>
#include <sys/un.h>
#include <netinet/in.h>

#elif defined(_WIN32)

#include <wtypes.h>

#endif

#define CHM_MAX_CHANNELS		32
#define CHM_MAX_CHANNEL_BUFFERS	16
#define CHM_NET_ADDR_NAME_LEN	256

#define CHM_MAX_AGE_INFINITE	(-1)

#if defined(unix)

#define CHM_TIMEOUT_DEFAULT		60

typedef long	chm_SystemError;
typedef int	chm_Socket;
typedef int	chm_CriticalSection;

#elif defined(_WIN32)

#define CHM_TIMEOUT_DEFAULT		60

typedef unsigned long	chm_SystemError;
typedef SOCKET			chm_Socket;

#if !defined(CHM_USE_MUTEX)
	typedef CRITICAL_SECTION chm_CriticalSection;
#else
	typedef HANDLE chm_CriticalSection;
#endif

#endif

enum chm_Boolean {
	chm_BooleanFalse,
	chm_BooleanTrue,
	chm_BooleanDummy = 0x12345678
};
typedef enum chm_Boolean chm_Boolean;

typedef unsigned long chm_Age;

enum chm_Err {
	chm_ErrNone = 0,
	chm_ErrUnknown = -9099,
	chm_ErrOperationFailed,
	chm_ErrOutOfMemory,
	chm_ErrTransferIncomplete,
	chm_ErrTransferErr,
	chm_ErrAborted,
	chm_ErrTimeout,
	chm_ErrDisconnected,
	chm_ErrConnectionErr,
	chm_ErrBadChannelEvent,
	chm_ErrInitFailed,
	chm_ErrTermFailed,
	chm_ErrNoMorePrvPorts,
	chm_ErrBadPrvPort,
	chm_ErrNoMoreChannels,
	chm_ErrBadNetAddr,
	chm_ErrCreateFailed,
	chm_ErrBadChannel,
	chm_ErrConnectFailed,
	chm_ErrChannelNotConnected,
	chm_ErrNoMoreChannelBuffers,
	chm_ErrBadChannelBuffer,
	chm_ErrChannelDeleteFailed,
	chm_ErrChannelCloseFailed,
	chm_ErrChannelAbortFailed,
	chm_ErrCannotGetLocalName,
	chm_ErrCannotGetPeerName,
	chm_ErrCannotOpenMacTCP,
	chm_ErrSelectTimeout,
	chm_ErrSelectInterrupted,
	chm_ErrSelectFailed,
	chm_ErrBadState,
	chm_ErrCannotConvertNameToAddr,
	chm_ErrDummy = 0x12345678
};
typedef enum chm_Err chm_Err;

enum chm_ChannelState {
	chm_ChannelStateNotConnected,
	chm_ChannelStateWaitingForConnection,
	chm_ChannelStateInitiatingConnection,
	chm_ChannelStateConnected,
	chm_ChannelStateAborted,
	chm_ChannelStateDummy = 0x12345678
};
typedef enum chm_ChannelState chm_ChannelState;

enum chm_NetAddrType {
	chm_NetAddrUnknown,
	chm_NetAddrTypeIP,
	chm_NetAddrTypeUnixSocketName,
	chm_NetAddrTypeUnixSocketPair,
	chm_NetAddrTypeUnixSocketId,
	chm_NetAddrTypeWinUnnamedPipe,
	chm_NetAddrTypeWinHandle,
	chm_NetAddrTypeDummy = 0x12345678
};
typedef enum chm_NetAddrType chm_NetAddrType;

struct chm_NetAddr {
	chm_NetAddrType	type;
	
	union {
		struct {	/* IP address + IP port (both in host byte order) */
			unsigned long	addr;
			unsigned short	port;
		#if defined(_WIN32)
			unsigned short	doBind		:  1;	/* 1 enables bind on create, 0 is default */
			unsigned short	doListen	:  1;	/* 1 enables listen on create, 0 is default */
			unsigned short	pad1		: 14;
		#else
			unsigned short	pad1;	/* bring up to long word size (for cross platform compiling) */
		#endif
			char			name[CHM_NET_ADDR_NAME_LEN];	/* W.X.Y.Z or host.dom1.dom2 */
		} ip;
		
		struct {	/* Unix socket name */
			char *name;	/* pointer to NULL terminated name or NULL */
		} sn;
		
		struct {	/* Unix socket pair */
			int dummy;
		} sp;
		
		struct {	/* Unix socket id */
			int id;
		} si;
		
	#if defined(_WIN32)		

		struct {	/* Windows unnamed pipe */
			chm_Boolean	bInherit;
		} up;
		
		struct {	/* Windows handle */
			HANDLE	hSend;
			HANDLE	hRecv;
		} wh;

	#endif

	} u;
};
typedef struct chm_NetAddr chm_NetAddr;

#if defined(unix) || defined(_WIN32)
	/* Unix equivalent of chm_NetAddr used for bind, connect, accept. */
	union chm_SockAddr {
		struct sockaddr		a;	/* generic address (for sa_len, sa_family) */
		struct sockaddr_in	in;	/* internet address */
#if defined(unix)
		struct sockaddr_un	un;	/* unix address */
#endif
	};
typedef union chm_SockAddr chm_SockAddr;
#endif


/* Forward references */
typedef struct chm_ChannelBuffer chm_ChannelBuffer;
typedef struct chm_Channel chm_Channel;
typedef struct chm_ChannelEventDesc chm_ChannelEventDesc;


/* ChannelClient */

struct chm_ChannelClient {
	void (* eventHdlr)(void *data, chm_ChannelEventDesc *ceDesc);
	void (* idleProc)(void *data);
	void	*data;
};
typedef struct chm_ChannelClient chm_ChannelClient;

enum chm_ChannelEvent {
	chm_ChannelEventUnknown,
	chm_ChannelEventNone,
	
	chm_ChannelEventConnected,
	chm_ChannelEventDisconnected,
	chm_ChannelEventConnectionErr,
	
	chm_ChannelEventTransferDone,
	chm_ChannelEventTransferIncomplete,
	chm_ChannelEventTransferErr,
	
	chm_ChannelEventAborted,
	chm_ChannelEventTimeout,
	
	chm_ChannelEventDummy = 0x12345678
};
typedef enum chm_ChannelEvent chm_ChannelEvent;

struct chm_ChannelEventDesc {
	chm_Channel		*channel;	/* channel that had the event */
	chm_ChannelEvent	event;		/* the event */
	chm_SystemError		err;		/* a system specific error code if the event is an error */
	chm_ChannelBuffer	*chBuf;		/* channel buffer that had the event or null */
	chm_Err			chmErr;		/* error corresponding to event */
};
/* typedef struct chm_ChannelEventDesc chm_ChannelEventDesc; */


/* ChannelBuffer class */

enum chm_ChannelBufferState {
	chm_ChannelBufferStateIdle,
	chm_ChannelBufferStateTransferring,
	chm_ChannelBufferStateDone,
	chm_ChannelBufferStateExit,
	chm_ChannelBufferStateDummy =0x12345678
};
typedef enum chm_ChannelBufferState chm_ChannelBufferState;

enum chm_ChannelBufferDirection {
	chm_ChannelBufferDirectionNone,
	chm_ChannelBufferDirectionSend,
	chm_ChannelBufferDirectionRecv,
	chm_ChannelBufferDirectionDummy =0x12345678
};
typedef enum chm_ChannelBufferDirection chm_ChannelBufferDirection;

struct chm_ChannelBufferClass {
	char	*name;
	long	next_id; /* unique id of next ChannelBuffer to be created */
};
typedef struct chm_ChannelBufferClass chm_ChannelBufferClass;

struct chm_ChannelBuffer {
	chm_ChannelBufferClass		*classp;
	long						id;

	chm_ChannelBufferState		state;		/* idle or transferring */
	chm_ChannelBufferDirection	direction;	/* send or recv */
	chm_Boolean					urgent;		/* whether normal or urgent transfer */

	int				len;			/* length of buffer (size of data) */
	int				cur;			/* current position in buffer (dest on recv, src on send) */
	void			*data;			/* user's data */

	chm_Channel		*channel;		/* associated channel */

	chm_Boolean		notifyOnComplete;		/* on async operations, notification is optional */
	chm_Boolean		disposeOnComplete;		/* whether data should be deleted automatically */

	chm_Age			curAge;			/* age of buffer in seconds (reset on partial xfers) */
	chm_Age			maxAge;			/* age of buffer at which it times out */
	chm_Age			totAge;			/* total age of buffer */
	time_t			theTime;		/* last time buffer was examined */
	
#if defined(unix)
	chm_SystemError		lastError;		/* last value */
	int			n;			/* number of bytes transferred */
#elif defined(_WIN32)
	chm_SystemError		lastError;		/* result from GetLastError() or WSAGetLastError() */
	long			n;			/* number of bytes transferred */
#endif
	
};
/* typedef struct chm_ChannelBuffer chm_ChannelBuffer; */

#if defined(__cplusplus)
extern "C" {
#endif

/* ChannelBuffer class operations */

chm_Err
chm_ChannelBufferClass_Init(
void
);


chm_Err
chm_ChannelBufferClass_Term(
void
);

#if	defined(__cplusplus)
}
#endif

/* ChannelBuffer operations */

#if	defined(__cplusplus)
extern "C" {
#endif

chm_Err
chm_ChannelBuffer_Create(
chm_ChannelBuffer			**newChBuf,			/* ptr to new ChannelBuffer */
chm_Channel					*channel,			/* associated channel */
int							len,				/* length of data */
void						*data,				/* ptr to data */
chm_ChannelBufferDirection	direction,			/* whether send or recv */
chm_Boolean					urgent,				/* whether normal or urgent operation */
chm_Boolean					notifyOnComplete,	/* whether to call handler when complete */
chm_Boolean					disposeOnComplete,	/* whether to dispose of "data" when complete */
chm_Age						maxAge				/* maximum age of buffer before timeout (0==inf) */
);

chm_Err
chm_ChannelBuffer_Delete(
chm_ChannelBuffer	*chBuf
);

void chm_ChannelBuffer_Transfer( chm_ChannelBuffer *chBuf );

chm_Err
chm_ChannelBuffer_DoIdle(
chm_ChannelBuffer		*chBuf,
chm_ChannelEventDesc	*ceDescNew,
chm_Boolean				async
);

#if	defined(__cplusplus)
}
#endif

/* Channel class */

struct chm_ChannelClass {
	char			*name;

	chm_CriticalSection	cs;				/* synchs access to channel[] */

	int			num_channels;			/* number of channels used */
	chm_Channel		*channel[CHM_MAX_CHANNELS];	/* null means not used */
	long			next_id;			/* unique id of next Channel to be created */

	void 			(* eventHdlr)(void *,
				chm_ChannelEventDesc *);	/* default event handler */

	void 			(* idleProc)(void *);		/* default idle proc */

	chm_Boolean		debug;				/* turns debugging on & off */
	FILE			*fp;				/* logfile or NULL */
};
typedef struct chm_ChannelClass chm_ChannelClass;

struct chm_Channel {
	chm_ChannelClass	*classp;
	long				id;

	chm_ChannelState	state;

	chm_NetAddr			myAddr;
	chm_NetAddr			peerAddr;

	int					timeOut;	/* timeout for channel operations */

	/* In these lists, null means not in use */
	int	numRecvBuffers;		/* number of buffers in use */
	chm_ChannelBuffer	*recvBuffer[CHM_MAX_CHANNEL_BUFFERS];

	int	numSendBuffers;		/* number of buffers in use */
	chm_ChannelBuffer	*sendBuffer[CHM_MAX_CHANNEL_BUFFERS];

	int	numRecvUrgentBuffers;	/* number of buffers in use */
	chm_ChannelBuffer	*recvUrgentBuffer[CHM_MAX_CHANNEL_BUFFERS];

	int	numSendUrgentBuffers;	/* number of buffers in use */
	chm_ChannelBuffer	*sendUrgentBuffer[CHM_MAX_CHANNEL_BUFFERS];
	
	chm_ChannelClient	client;
	
#if defined(unix)

	chm_Socket	socket;		/* active socket (from socket or socketpair) */
	chm_Socket	socket1;	/* passive socket (from socketpair) */

	chm_SystemError	lastError;	/* last value */
	
#elif defined(_WIN32)

	HANDLE		hSend;		/* Win32 send handle */
	HANDLE		hRecv;		/* Win32 recv handle */
	HANDLE		hSend1;		/* Win32 send handle for peer */
	HANDLE		hRecv1;		/* Win32 recv handle for peer */

	chm_Socket	socket;		/* WinSockets socket */
	chm_Socket	socket1;	/* listen socket */

	chm_SystemError	lastError;	/* result from GetLastError() or WSAGetLastError() */

#endif

};
/* typedef struct chm_Channel chm_Channel; */


/* Channel class operations */

#if	defined(__cplusplus)
extern "C" {
#endif

chm_Err
chm_ChannelClass_Init(
chm_Boolean	debug,
FILE		*fp		/* logfile or NULL */
);

chm_Err
chm_ChannelClass_Term(
void
);

void
chm_ChannelClass_DoIdle(
void
);

chm_Err
chm_ChannelClass_GetPrvPort(
int	*prvPort
);

void
chm_ChannelClass_DisconnectAll(
chm_Channel	*ch1,
...
);

void
chm_ChannelClass_AbortAll(
void
);

#if		defined(unix)
void
chm_ChannelClass_CloseAll(
int	fd,
...
);
#endif

#if	defined(__cplusplus)
}
#endif

/* Channel operations */

#if	defined(__cplusplus)
extern "C" {
#endif

chm_Err
chm_Channel_Create(
chm_Channel					**newChannel,	/* ptr to new channel OUT */
chm_NetAddr					*peerAddr,		/* address of peer */
struct chm_ChannelClient	*client			/* channel's client, or null */
);

chm_Err
chm_Channel_Delete(
chm_Channel	*channel
);

chm_Err
chm_Channel_WaitForConnection(
chm_Channel	*channel,
chm_Boolean	async
);

chm_Err
chm_Channel_InitiateConnection(
chm_Channel	*channel,
chm_Boolean	async
);

chm_Err
chm_Channel_Disconnect(
chm_Channel	*channel,
chm_Boolean	async
);

chm_Err
chm_Channel_Send(
chm_Channel			*channel,
int					len,				/* length of data */
void				*data,				/* ptr to data */
chm_Boolean			urgent,				/* whether normal or urgent send */
chm_Boolean			notifyOnComplete,	/* whether to call handler when complete */
chm_Boolean			disposeOnComplete,	/* whether to dispose of "data" when complete */
chm_Age				maxAge,				/* maximum age of buffer before timeout (0==inf) */
chm_Boolean			async				/* asynchronous or synchronous operation */
);

chm_Err
chm_Channel_Recv(
chm_Channel			*channel,
int					len,				/* length of data */
void				*data,				/* ptr to data */
chm_Boolean			urgent,				/* whether normal or urgent recv */
chm_Boolean			notifyOnComplete,	/* whether to call handler when complete */
chm_Boolean			disposeOnComplete,	/* whether to dispose of "data" when complete */
chm_Age				maxAge,				/* maximum age of buffer before timeout (0==inf) */
chm_Boolean			async				/* asynchronous or synchronous operation */
);

chm_Err
chm_Channel_Abort(
chm_Channel			*channel
);

void
chm_Channel_DoIdle(
chm_Channel			*channel
);


/* Utility functions */

#if defined(_DEBUG)

void
chm_DumpData(
char			*s,	/* string prepended to each line (e.g. blanks) */
long			n,	/* number of bytes to dump */
unsigned char	*d	/* data to be dumped */
);

#endif

chm_Err
chm_ConvertChannelEventToChannelError(
chm_ChannelEventDesc	*ceDesc
);

chm_Err
chm_ConvertAddrToString(
unsigned long	addr,	/* host byte order IN */
char			*name	/* dotted string OUT */
);

chm_Err
chm_Channel_ConvertStringToAddr(
chm_Channel		*channel,	/* channel for idleProc (Mac only) IN */
char			*name,		/* machine name or dotted IP address IN */
unsigned long	*addr		/* IP address (host byte order) OUT */
);

char *
chm_StrError(
long	n
);

#if defined(__cplusplus)

/*
 * Convert an IP number in dot notation (x.y.z.w) to a binary IP address.
 */
inline
unsigned long
chm_ConvertIPNumberToIPAddr(
	unsigned char x,
	unsigned char y,
	unsigned char z,
	unsigned char w
) {
	return( x << 24 | y << 16 | z << 8 | w << 0 );
}

#endif

#if	defined(__cplusplus)
}
#endif

#endif	/* CHANNEL_MGR_H */
