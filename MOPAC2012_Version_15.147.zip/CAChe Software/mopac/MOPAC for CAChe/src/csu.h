/* W I N 32
**
**	csu.h -- Header file for csu.c Chemistry Structure Utilities. Perform operations
**			 on molecule structurs and molecule structure files.
**			 Also other usefull computations.
**
**	Author: Andy Spencer and Bill Hanks
**
**	Date: 5-Dec-88
**  Revised 2-Mar-89
**
**	See Chemistry Utility Specification for more information.
**
 *	15/Jun/2000 Ingvar Lagerstedt, Oxford Molecular
 *
 *		Merging WIN32, Mac, and Standalone versions
 *
 *	30/Jun/2000 IL:	Update types for structures and prototypes
 *	06/Jul/2000	IL:	Set ObjectID to long, removed ObjectIndex type
*/

#ifndef _csu_
#define _csu_

#if defined _CACHE_DLL
	#if defined _CSU
		#define CSU_IMPORT_EXPORT	__declspec(dllexport)
	#else
		#define CSU_IMPORT_EXPORT	__declspec(dllimport)
	#endif
#else
	#define CSU_IMPORT_EXPORT	//define as nothing for anything other than Win32
#endif

#include <limits.h>
#include "cel.h" /* define CAChe error return codes */
#include "compat.h"

/* The inclusion of windows.h below is only needed for the PC server side, where it
 * can not be included in compat.h
 */ 
#if defined (_WIN32)
#include <windows.h>
#endif

/* internal data types for property values. Used bye csu_GetObjectValue and
   csu_SetObjectValue */
#define CSU_CHAR 1
#define CSU_UCHAR 2
#define CSU_SHORT 3
/* a name is stored as a short (a name index), but written as a name (string) */
#define CSU_NAME 4
#define CSU_USHORT 5
#define CSU_LONG 6
#define CSU_ULONG 7
#define CSU_FLOAT 8
#define CSU_DOUBLE 9
/* file data types for property values */
#define CSU_INTEGER 1
#define CSU_FLOATING 2
#define CSU_STRING 3
// #define CSU_NAME 4 /* same as above */
#define CSU_HEX 5

/* define the maximum page width (in characters) for printing */
#define PAGE_WIDTH 80

#define NAMELEN 32		/* maximum name length for name array */
#define ATOMPDBNAMELEN 4	/* maximum string length for a PDB Atom Name array */
#define RESNAMELEN 3		/* maximum string length for Group PDB Name array */
#define MS_NAMELEN 80	/* maximum length for (file) name of molecule structure */
#define MS_RECLEN 256	/* maximum length for a molstruct or data dict record */
#define MAX_ID (LONG_MAX-1)		/* the maximum number of objects for an object class */
#define STACK_MAX_ID 6144	/* the maximum number of objects for an object class
							   in order to use the array allocated on the stack
							   in csu_GiveUniqueID */
/* completion codes */
#define CSUAllocFail 	-101L	/* Not enough memory for NewHandle */
#define CSUOpenFail		-102L	/* A failure occured for an fopen() */
#define CSUAbnormalEOF	-103L	/* Unexpected file termination on read or write */
#define CSUNameNotFound	-104L	/* a name was not found in the data dict */
#define	CSUStaRecLess	-105L	/* standard record has less than two tokens */
#define	CSUStaRecOrder	-106L	/* standard record comes after an object class record */
#define	CSUNstRecLess	-107L	/* non_standard record has less than 4 tokens */
#define	CSUNstRecOrderB	-108L	/* non _standard record has occured before
								   a standard record */
#define	CSUNstRecOrderA	-109L	/* non_standard  record has occured after
								   an object_class record */
#define	CSUPrpRecOrder	-110L	/* property record has occured before object_class */
#define	CSUPrpRecLess	-111L	/* property record has less than 4 tokens */
#define	CSUObjclsLess	-112L	/* object class record has less than 2 tokens */
#define CSUDictDataType	-113L	/* Unknown data type in data dictionary file */
#define CSUPropNotFound 	-115L	/* a property index was not found in the data dict */
#define CSUObjclsNotFound	-116L	/* an object class was not found */
#define CSUNoValues		-117L	/* no property values */
#define CSUInvalidID    -118L    /* an invalid ID was incountered */
#define CSUInvalidHdl   -119L    /* non-NULL handle with less than 1 item
								   or NULL handle with some items */
#define CSUInvalidMolStruct	-120L	/* molecule structure invalid */
#define CSUInvalidDataType	-121L	/* property data type invalid */
#define CSURemoveFail	-122L		/* remove utility failed */
#define CSURenameFail	-123L		/* rename utility failed */
#define CSUFcloseFail	-124L		/* error occured while closing a file */
#define CSUDictNotFound -125L		/* The data dictionary has not been loaded */
#define CSUOverflow		-126L		/* A caller supplied array did not provide
									   sufficient space to store results */
#define CSUValueProtected	-127L	/* An attempt was made to delete a protected
									   property*/
#define CSULockedHandle	-128L	/* A SetHandleSize failed and the handle was locked */
#define CSUInvalidField -129L	/* The field value is out of range */
#define CSUOutOfIDs		-130L	/* No more object IDs available within MAX_ID limit */
#define CSUFileConflict	-131L	/* An application has modified a molstruct file between
								   the last time this application did a GetMolstruct and
								   a SaveMolstruct */
#define CSUMsHeaderBusy	-132L	/* the molstruct header has already been initialized */
#define CSUPropRedefinition	-133L	/* Cannot redefine a property dictionary entry */
#define CSUFileLowerVersion	-134	/* The molstruct file being saved over has higher 
													version than file being saved */

/* quick access to common variables, defined in data dictionary file */

/*
** units (name indexes)
*/

/*
** properties (propdict indexes)
*/

/* predefined property sources (name indexes) */
#define Linus_SRC 17
#define Isaac_SRC 18
#define Quipu_SRC 19
#define Erich_SRC 88
#define Tabulator_SRC 127
#define Visualizer_SRC 128
#define MOPAC_SRC 142
#define MolEditor_SRC 151
#define ExtendedHuckel_SRC 152
#define	ZINDO_SRC 186
#define DOCK_SRC 463

/* predefined unit name (name index) for properties values without units */
#define NoUnit 20

#define ID_ID 0
/* every object class must have property 0 (ID) for chemistry routines to work */
/* NOTE: objID >= 1, an ID of 0 refers to all objects in an objcls */

/* other defined property IDs (propID = index into DataDict property array) */
#define Objcls1ID  1
#define Objcls2ID  2
#define Obj1ID  3
#define Obj2ID  4

#define DflagID  21
/* every object class must have property 21 (dflag) for deletion routines to work */
/* the lower four bits (0 thru 3) of dflag should be used as selection bits */
/* upper 4 bits (4 thru 7) are used in connector objects to define data dependencies */
#define csu_Delete1if2 0x10
/* if obj2 is deleted and (dflag & csu_Delete1if2), delete obj1 */
#define csu_Delete2if1 0x20
/* if obj1 is deleted and (dflag & csu_Delete2if1), delete obj2 */
#define csu_Delete1ifC 0x40
/* if connector is deleted and (dflag & csu_Delete1ifC), delete obj1 */
#define csu_Delete2ifC 0x80
/* if connector is deleted and (dflag & csu_Delete2ifC), delete obj2 */

#define AngleID 18

/* units for angles (name indexes) */
#define Degree_U 55
#define Radian_U 56

#define NameID 20

#define RflagID  5

#define TypeID  6

/* predefined bond types (name indexes) */
#define IONIC_B 11
#define SINGLE_B 12
#define DOUBLE_B 13
#define TRIPLE_B 14
#define WEAK_B 15
#define COORD_B 16
/* predefined bit values for bond types */
#define UNKNOWN_BT	0L
#define IONIC_BT	0x00000001L
#define SINGLE_BT	0x00000002L
#define DOUBLE_BT	0x00000004L
#define TRIPLE_BT	0x00000008L
#define WEAK_BT		0x00000010L
#define COORD_BT	0x00000020L

#define SymID  7
#define LabelID 91

#define AnumID  8

/* predefined unit name (name index) for values which are integer counts */
#define Unit 21

#define ChrgID  9
#define PchrgID 10
#define Bond_OrderID  22
#define EigValID  23
#define OccNumID 24
#define EigVecID 25
#define ContractLengthID 26
#define PrinQuantID 27
#define STOExpID 28
#define ShellNumID 29
#define BasisFxnAngID 30
#define CalcSourceID 31
#define VersionID 32
#define DateTimeID 33
#define CalcCommentID 34
#define CalcEnergyID 35
#define CalcServerID 98
#define ContractionsID 81
#define DockScoreID 230

#define cov_radID 82

#define ellipsoidID 92

/* predefined basis function angular names */
#define Stype  	 	 99
#define Pxtype  	100
#define Pytype  	101
#define Pztype  	102
#define Dz2type  	103
#define Dx2y2type   104
#define Dxytype  	105
#define Dxztype 	106
#define Dyztype  	107
#define Fx3type  	108
#define Fy3type  	109
#define Fz3type  	110
#define Fy2z2type 	111
#define Fz2x2type  	112
#define Fx2y2type 	113
#define Fxyztype 	114
#define Dx2type		192
#define	Dy2type		193
#define Coeffs_indID  226
#define EigVecCompID  227
#define NoCoefID      228
#define	Fx2ytype	428
#define	Fx2ztype	429
#define	Fy2ztype	430
#define	Fxy2type	431
#define	Fxz2type	432
#define	Fyz2type	433

/* predefined names for application programs */
/* that perform calculations on MolStructs   */
#define EHTID 121
#define MMID  135
#define MOPACID		142

/* predefined energy units (name index) */
#define Energy_AU  48
#define Energy_Kcal_mole 51
#define EV 52
#define Energy_KJ_mole 136
#define Energy_WaveNum 205

/* predefined charge units (name index) */
#define Charge_AU 45

#define MassID 11

/* predefined transition strength */
#define Dipole_AU 206
#define Debye   158

/* predefined mass unit (name index) */
#define Mass_AU 40

#define XYZID 12
#define RadiusID 14
#define VdWradID 15
#define DistanceID 19
#define BondStrainID 43
#define TableColorsID 48
#define TableThresholdID 49
#define GraphicFileTypeID 50
#define TableColorsIndexID 51
#define ModelID 52

/* Label properties */
#define LabelStrainID 44
#define DistanceRangeID 45
#define AngleRangeID 46
#define StepsID 47
#define distanceLabelTypeID 226
#define distanceLabel_R0ID  227
#define distanceLabel_epsilonID 228

/* predefined distance types (name indices) */
#define H_bondTypeID 458
#define bumpTypeID	459
#define distanceTypeID 475

/* predefined distance units (name indices) */
#define Length_AU 33
#define Bohr_U 34
#define Angstrom_U 35

/* predefined energy gradient units (name indexes) */
#define Kcal_mol_angstrom_U 273

/* predefined volume units (name indexes) */
#define AngstromCubic_U 182

#define ConfID 13

/* predefined atom configurations (name indexes) */
#define sCONF 0
#define spCONF 1
#define sp2CONF 2
#define sp3CONF 3
#define sd3CONF 4
#define d2sp3CONF 5
#define dzsp3CONF 6
#define dxysp3CONF 7
#define p3CONF 8
#define dsp2CONF 9
#define unCONF 10

/* transition names */
#define TransitionDipoleID    85
#define TransitionMomentID    86
#define LineWidthID           90
#define EnergyID              87
#define NormalModeID          89

/* graphic file type name indexes */
#define MOtype 146
#define DensityType 147
#define ElectrostaticType 148

#define OrboccID 16
#define CommentID 17

#define DLPNumberID 36
#define DLPNumbersID 43

#define GFfilenameID 37
#define XformID 39
#define GFtypeID 40
#define GFvalueID 41
#define GFcolorsID 42

#define	GrpIndexID 207
#define	IDIndexID 208
#define	RotationRMSID 209
#define	DistanceRMSID 231

/* crystal properties */
#define	 AxisAID 58
#define	 AxisBID 59
#define	 AxisCID 60
#define	 AlphaID 61
#define	 BetaID  62
#define	 GammaID 63
#define	 LatticeRangeID  0
#define	 SpaceGroupID  64
#define	 DescriptorID  79
#define	 AsyEdgeID  69
#define	 LatticeBoxID  80
#define	 UnitCellID  70


/* residue properties stored in molgroup class*/
#define GroupTypeID 216

/* predefined group types (name indexes) */
//#define UNDEFINED_GROUP 0
#define AA_GROUP          444
#define NA_GROUP		  445
#define HET_GROUP		  446
#define WATER_GROUP	      447
#define ACTIVESITE_GROUP  464
#define LIGAND_GROUP      465
//#define OTHER_GROUP  0

#define ResPDBNameID 217
#define AAcodeID 218
#define SeqnumID 219
#define iCodeID 220
#define ChainID 221
#define SS_pdbID 222

/* predefined Secondary Structure conformations (name indexes) */
#define SS_OTHER				456
#define SS_HELIX_RALPHA  	448            //Right-handed alpha (default)               
#define SS_HELIX_RPI 		449			//Right-handed pi                           
#define SS_HELIX_R310 		450           //Right-handed 310                          
#define SS_HELIX_LALPHA		451			//Left-handed alpha                         
#define SS_SHEET_ANTI		452		// anti paralel
#define SS_SHEET				453		// begin
#define SS_SHEET_PAR		   454		// paralel
#define SS_TURN				455

#define GapsCountID 223

#define tempFactorID 225
#define NoteSourceID 224

/* define the size of a block of memory to allocate when memory is needed for more
   objects. This block is a multiple of the memory required for one object
*/
#define CSUBlocksize 128

/* defines for the number of extra entries to allocate when reallocating memory
 * for the data dictionary structures
 */
#define PROP_PAD	10
#define NAME_PAD	10
#define OBJ_PAD		10
#define UNIT_PAD	10

/* defines for the sizes of the object id <-> index translation arrays */
/* Under the 16-bit CSU, static arrays of size MAX_ID were used.       */
#if defined (_DEBUG)
#define ID_TO_IDX_INIT_SIZE 1000
#define ID_TO_IDX_PAD       1000
#else
#define ID_TO_IDX_INIT_SIZE 10000
#define ID_TO_IDX_PAD       10000
#endif


/*
** object classes (objclsdict indexes)
**
** (objclsID = index into DataDict object class array)
*/

#define AtomID 0
#define ElementID 1
#define ConnectorID 2
#define OrbitalID 3
#define BondID 4
#define MolgroupID 5
#define Atom_distID 6
#define Bond_angID 7
#define DihedralID 8
#define MolecOrbitalID 9
#define STOBasisFxnID 10
#define CalcHistID 11
#define GraphicsFilesID 12
#define ImproperTorsionID 13
#define CrystalID 14
#define GTOBasisFxnID 15
#define ElectronicStateID 16
#define VibrationalLevelID 17
#define SuperpositionID 31
#define SuperpositionGroupID 32
#define NoteID 33

#define		BY_ID			0			/* store in MolStruct by absolute ID */
#define		BY_INDEX		1			/* store in MolStruct by index */


/* utility macros for accessing data types */
#if defined (_WIN32)
#define HRef FAR_PTR
#endif

#if defined(unix)
// The IBM RISC6000 xlc compiler complains about taking the
// address of a pointer that has been cast to a different type.
// See the SetHandleSize macro in compat.h
#define SETHANDLESIZE(h,size)   SetHandleSize(h,size);
#else
#define SETHANDLESIZE(h,size)   SetHandleSize((Handle)h,size)
#endif

/* 
 * typedef all the handle/pointers 
 */

typedef unsigned char _HNDL_PTR_* BitH;
typedef char _HNDL_PTR_* CharH;
typedef unsigned char _HNDL_PTR_* UCharH;
typedef short _HNDL_PTR_* ShortH;
typedef unsigned short _HNDL_PTR_* UShortH;
typedef long _HNDL_PTR_* LongH;
typedef unsigned long _HNDL_PTR_* ULongH;
typedef float _HNDL_PTR_* FloatH;
typedef double _HNDL_PTR_* DoubleH;
typedef char _HNDL_PTR_* ValueH;

/* object class, property and object ID's, ObjectIndex removed */
typedef short ObjclsID;
typedef short PropID;
typedef long ObjectID;

/* the ID of a name */
typedef short NameNID;

/* an integer number */
typedef int Number;

#if defined(_WIN32)
typedef unsigned char u_char;	/* typically used for flags */
typedef unsigned short u_short;	/* typically used for flags */
#endif

/* The following data types make up a Molecule Structure (molstruct).
   See Molecule Editor Functionality */

typedef struct {
	PropID ID_PID;
	PropID DflagPID;
	PropID Objcls1PID;
	PropID Objcls2PID;
	PropID Obj1PID;
	PropID Obj2PID;
	ObjclsID ConnectorOCID;
	NameNID srcN;
} CSUGlobal;

typedef struct {
	BitH has_valueH;	/* bit flags indicating which values are valid */
	BitH lock_valueH;	/* bit flags indicating which values are locked */	
	ValueH valuesH; 	/* handle to values array */
	PropID propID; 		/* index of prop in data dictionary */
	NameNID srcN; 		/* index to source name array */
	NameNID unitN;		/* name of measurement units for property values */
	long vec_len;		/* number of fields in the property values, for file
						   output and for variable width arrays */
	short file_Dtype;	/* value printing specification:
							CSU_INTEGER = decimal (base 10) integer
							CSU_HEX = hexadecimal (base 16) integer
							CSU_FLOATING = floating point
							CSU_STRING = character string
							CSU_NAME = name stored as index into dataDict names array */
	short file_precis;	/* number of digits after decimal in file representation */
} Prop;

typedef Prop _HNDL_PTR_* PropH;

typedef struct {
	NameNID unitN;		/* name of measurement units for property values */
	long vec_len;		/* number of fields in the property values, for file
						   output and for variable width arrays */
	short file_Dtype;	/* value printing specification:
							INTEGER = decimal (base 10) integer
							HEX = hexadecimal (base 16) integer
							FLOATING = floating point
							STRING = character string
							NAME = name stored as index into dataDict names array */
	short file_precis;	/* number of digits after decimal in file representation */
} PropHead;

typedef struct {
	PropH propsH; 			/* handle to property array */
	PropID num_props; 		/* number of properties for this object class */
	ObjectID num_valloc;	/* the number of values allocated where bytes allocated =
							   sizeof(data type)*(vector length) */
	ObjectID num_objs;	 	/* number of objects (num_objs <= num_valloc). */
	u_short flags;			/* editor status */
	ObjclsID objclsID; 		/* index of object class in data dictionary */
	ObjectID current_oi;	/* the index of the current valid object */
} Objcls; 					/* Object Class Structure */

typedef struct TempOC{
	struct TempOC _HNDL_PTR_* next;	/* handle to next temporary object class in list. NULL 
							   is end of list */
	ObjectID num_objs; 		/* number of objects = number of values per property */
	PropID num_props; 		/* number of properties for this object class */
} TempObjcls; 				/* Temporary object class structure. 
								Used for temporary storage
								of number of objects and number of 
								properties per object class
								so the arrays for properties and 
								values can be preallocated in
								contiguous blocks. */

typedef Objcls _HNDL_PTR_* ObjclsH;

typedef struct {
	double lxform[4][4];		/* local transform for xyz_coordinates */
	ObjclsH  objclsH; 		/* handle to object class array */
	char ms_name[MS_NAMELEN]; 	/* name of this molstruct */
	u_short		flags;
	ObjclsID	num_objcls; 	/* number of object classes */
	long ident;			/* indentifier for this molstruct */
	unsigned long versionNo;	/* a sequential number representing the number
					   of times the molstruct file has been modified */
} MolStruct; 				/* Molstruct structure */

#define MOLS_ID 0x6D6F6C73L /* 'mols' molstruct identifier */

/*
**
** The following datatypes form the Data Dictionary
**
*/

typedef struct{
	PropID propN; 		/* index in names array of property name */
	short std_unitN; 	/* the index in names array of standard unit of measure */
	short std_precis;	/* the number of digits precision after decimal point */
	short std_Dtype;	/* the internal representation of a value:
						CHAR - 				char
						UCHAR-  unsigned 	char
						SHORT- 				short
						NAME- 				short
						USHORT -unsigned 	short
						LONG -      		long
						ULONG - unsigned	long
						FLOAT -				float
						DOUBLE - 			double */
	long vec_len;		/* the number of fields stored per value, if vec_len > 0 */
						/* vec_len < 1 represents a variable length vector, the real
						vector length is stored in a molstruct Prop structure */
} PropDict;

typedef struct {
	ObjclsID	objclsN; 	/* the index in the name array of this object class */
	u_short		flags;		/* global object class flags */
} ObjclsDict;

/* define objcls flags */
#define csu_ObjclsNoAdd 1
#define csu_ObjclsNotSelectable 2

typedef struct {
	double multiplier;  	/* the multiplier and the offset are used to convert */
	double offset;			/*  from the standard unit to non-standard unit */                                                     
	short nstd_unitN; 		/* index into the names array for standard unit name */
} NstdUnitDict;				/* non-standard unit dictionary structure, for units
							   with the same dimensionality as the standard unit */

typedef NstdUnitDict _HNDL_PTR_* NstdUnitDictH;

typedef struct {
	NstdUnitDictH nstd_unitsH;	/* handle to the non-standard unit dictionary array 
								   for this standard unit */
	short num_nstd_units; 		/* the number of non standard units associated with
								   this standard unit */
	short std_unitN;			/* the index to the names array of a standard unit */			            
} UnitDict; 					/* Unit dictionary structure. Each standard unit
								   represents a unit category (a set of dimensionally
								   consistent units) */

typedef char (_HNDL_PTR_* NameH)[NAMELEN];
typedef UnitDict _HNDL_PTR_* UnitDictH;
typedef PropDict _HNDL_PTR_* PropDictH;
typedef ObjclsDict _HNDL_PTR_* ObjclsDictH;

typedef struct{
	char		date[NAMELEN];	/* a string representing creation date */
	NameH		namesH;			/* the array of names (NAMELEN characters each) */
	UnitDictH	unitdictH; 		/* the array of unit category structures */
	PropDictH	propdictsH;		/* the array of property dictionary structures */
	ObjclsDictH objclsdictH; 	/* the array of object class dictionary structures */
	NameNID		num_names ; 	/* the number of names in the array */
	short		size_names;		/* the size of the allocated names array */
	short		num_unitdicts;	/* the number of unit category structures */
	short		size_unitdicts;	/* the size of the allocated unitdicts array */
	PropID		num_props;		/* the number of property dictionary structures */
	short		size_props;		/* the size of property dictionary array */
	ObjclsID	num_objcls;		/* the number of object class header structures */
	short		size_objcls;	/* the size of object class header array */
} DataDictionary; 				/* data dictionary structure for molstructs */
			
typedef struct TempDOC{
	struct TempDOC _HNDL_PTR_* next;		/* handle to next tempory object 
								   in list. NULL is end of list */
	PropID num_props; 			/* number of properties for this object class */
} TempObjclsDict; 				/* Temporary object class dictionary structure.
								   Used for temporary storage
								   of number of properties per object class
								   so the arrays for properties may be preallocated in
								   contiguous blocks. */
	
typedef struct TempUD {
	struct TempUD _HNDL_PTR_* next;	/* handle to next temporary unit dictionary */
	short num_nstd_units;	/* number of nonstandard units */
} TempUnitDict;				/* Temporary unit dictionary structure */

typedef struct {
	ObjclsID oci;	/* object class ID or index */
	ObjectID obi;	/* object ID or index */
} CSUObj, *CSUObjP;	/* for low-level csu routines */

typedef struct {
	ObjclsID	oc_id;	/* object class ID */
	ObjectID	o_id;	/* object ID */
} CSUObject, *CSUObjectP;	/* for high-level csu routines */

typedef struct {
	CSUObj o1;
	CSUObj o2;
} csu_ObjPair; /* pair of low-level csu objects */

// moved from cpu.h  DW 5/23/94
typedef struct {
	ObjectID	num_valloc;	/* Amount of memory for one object, size * length of array */
							/* IL 06/Jul/2000: length of array is number of allocated objects */
	ShortH		objcls1H;	/* object class handle to 1st object */
	ShortH		objcls2H;	/* object class handle to 2nd object */
	LongH		obj1H;		/* 1st object */
	LongH		obj2H;		/* 2nd object */
	UCharH		dflagH;		/* flags */
	BitH		validH;		/* validity flag */
} ConnProps; /* basic connector properties */

typedef TempObjcls _HNDL_PTR_* TempObjclsH;
typedef MolStruct _HNDL_PTR_* MolStructH;
typedef TempObjclsDict _HNDL_PTR_* TempObjclsDictH;
typedef TempUnitDict _HNDL_PTR_* TempUnitDictH;


/*********** Locally used functions ***************/
CelErr csu_BuildDataDictionary ( const char[], const char *);
CelErr csu_DeleteDataDictionary( void );
char *csu_time( void );
double csu_VDot( double v1[3], double v2[3] );
double csu_VMag2( double v[3] );
void csu_CheckLXform( double lxform[4][4] );
CelErr csu_ConvConIndextoID( MolStruct  *msPtr );
CelErr stop_objcls_save(
	MolStruct  *msPtr,	/* Molecular structure */
	ObjclsID objclsID,	/* index into object class  dictionary */
	FILE *ms_fp			/* molstruct output file pointer */
);
char * csu_tempName( char *tmpNameXX, const unsigned bufSize );

/*** prototypes for csu interface routines ***/
#ifdef __cplusplus	/* For type-safe linkage */
extern "C" {		/* Specify "C"-style linkage */
#endif
CelErr CSU_IMPORT_EXPORT csu_SetStdUnits( short );

void CSU_IMPORT_EXPORT free_hdl(Handle handle);
CSUObj CSU_IMPORT_EXPORT csu_formObj(ObjclsID oci, ObjectID obi);
CSUObject CSU_IMPORT_EXPORT csu_formObject(ObjclsID oc_id, ObjectID o_id);

CelErr CSU_IMPORT_EXPORT	csu_SetInitialID(
	MolStruct *msPtr,	/* Pointer to the molstruct header structure. */
	ObjclsID oc_id 	/* Identifier of the object
		   					class. This is known as the
		   					Object class ID.*/
);

CelErr CSU_IMPORT_EXPORT	csu_PreviousID(
	MolStruct *msPtr,	/* Pointer to the molstruct header structure. */
	ObjclsID oc_id, 	/* Identifier of the object
		   					class. This is known as the
		   					Object class ID.*/
	ObjectID *o_id		/* The ID of the previously available object in this object class */
);

CelErr CSU_IMPORT_EXPORT csu_CurrentID(
	MolStruct *msPtr,	/* Pointer to the molstruct header structure. */
	ObjclsID oc_id, 	/* Identifier of the object
		   					class. This is known as the
		   					Object class ID.*/
	ObjectID *o_id		/* The ID of the previously available object in this object class */
);

CelErr CSU_IMPORT_EXPORT csu_ConnectObjects(
	MolStruct *msPtr,	/* molstruct header structure */
	ObjclsID oc_id1,	/* id of object class 1 */
	ObjectID ID1,		/* id of object 1 */
	ObjclsID oc_id2,	/* id of object class 2 */
	ObjectID ID2,		/* id of object 2 */
	u_char dflag		/* data dependency flag */
);

CelErr CSU_IMPORT_EXPORT csu_ConnectObjectsFast(
	MolStruct *msPtr,	/* molstruct header structure */
	ObjclsID oc_id1,	/* id of object class 1 */
	ObjectID ID1,		/* id of object 1 */
	ObjclsID oc_id2,	/* id of object class 2 */
	ObjectID ID2,		/* id of object 2 */
	u_char dflag		/* data dependency flag */
);

CelErr CSU_IMPORT_EXPORT  csu_CreateObject(
	MolStruct *msPtr,	/* Pointer to the molstruct header structure. */
	ObjclsID oc_id, 	/* Identifier of the object class. This is known as
							the object class ID */
	ObjectID *o_id 		/* The unique identifier for the object being created */
);

CelErr CSU_IMPORT_EXPORT csu_CreateObjectEx(
	MolStruct *msPtr,	/* Pointer to the molstruct header structure. */
	ObjclsID oc_id, 	/* Identifier of the object class. This is known as
							the object class ID */
	ObjectID *o_id, 		/* The unique identifier for the object being created */
	ObjectID *o_index, 		/* The index for the object being created */
	ObjectID *my_id 		
);

CelErr CSU_IMPORT_EXPORT csu_DeleteObj(
	MolStruct	*msPtr,		/* Pointer to the molstruct header structure. */
	ObjclsID	oc_id, 		/* Identifier of the object class. This is known as the
		   		       			Object class ID.*/
	ObjectID	oi, 		/* The index for the object being deleted */
	u_char		del_flag	/* low 4 bits used to flag objects for deletion */
);

CelErr CSU_IMPORT_EXPORT csu_DeleteObject(
	MolStruct *msPtr,	/* Pointer to the molstruct header structure. */
	ObjclsID oc_id, 	/* Identifier of the object class.This is known as the
		   		       		Object class ID.*/
	ObjectID o_id, 		/* The unique identifier for the object being deleted */
	u_char del_flag		/* low 4 bits used to flag used to flag objects for 
					  	 	deletion */
);

CelErr CSU_IMPORT_EXPORT csu_DeleteObjectValue(
	MolStruct *msPtr,	/* Pointer to the molstruct header structure. */
	ObjclsID oc_id, 	/* Identifier of the object class. This is known as the
		   			  	 	Object class ID.*/
	PropID p_id,		/* Identifier of a propert for an object. This is
	 	   			  		 known as the Property ID. */
	ObjectID o_id 		/* The unique identifier for the object value being deleted */
);

CelErr CSU_IMPORT_EXPORT csu_DeleteProperty(
MolStruct *msPtr,	/* Pointer to the molstruct header structure. */
ObjclsID oc_id, 	/* Identifier of the object class.This is known as the
		   			   Object class ID.*/
PropID p_id 		/* Identifier of a property for an object. This is
	 	   			   known as the Property ID. */
);

CelErr CSU_IMPORT_EXPORT csu_FindConnectedObjects(
	MolStruct	*msPtr,			/* Pointer to the molstruct header structure. */
	ObjclsID	ObjClsTo,		/* Objects will be connected to objects in this object class */
	ObjectID	IDTo,			/* Objects will be connected to objects with this ID */
	ObjclsID	ObjCls,			/* Objects in this object class are the ones being connected */
	ObjectID	*conn_list,		/* The list of connected objects */
	ObjectID	list_length,	/* The length of the conn_list that the caller is providing */
	ObjectID	*num_connected	/* The number of connected objects found. */
);

CelErr CSU_IMPORT_EXPORT csu_FindConnObjIndexes(
	MolStruct	*msPtr,			/* Pointer to the molstruct header structure. */
	ObjclsID	ObjClsTo,		/* Objects will be connected to objects in this object class */
	ObjectID	iTo,			/* Objects will be connected to objects with this index */
	ObjclsID	ObjCls,			/* Objects in this object class are the ones being connected */
	ObjectID	*conn_list,		/* The list of connected object indexes */
	ObjectID	list_length,	/* The length of the conn_list that the caller is providing */
	ObjectID	*num_connected 	/* The number of connected objects found. */
);

CelErr CSU_IMPORT_EXPORT csu_GetLocalTransform(
	MolStruct *msPtr,	/* Pointer to the molstruct header structure. */
	double t[4][4]		/* local transform */
);

CelErr CSU_IMPORT_EXPORT csu_GetNameIndex(
	char *name,	/* string representing the name in the Data Dictionary */
	NameNID *nameID /* The index of the name string in the Data Dictionary */
);

CelErr CSU_IMPORT_EXPORT csu_GetObjectClassID(
	char *name,			/* string representing the name of the object class */
	ObjclsID *oc_id 	/* object class id */
);

CelErr CSU_IMPORT_EXPORT 	csu_GetObjectValueUser(
	MolStruct *msPtr,	/* Pointer to the molstruct header structure. */
	ObjclsID oc_id, 	/* Identifier of the object
		   					class.This is known as the
		   					Object class ID.*/
	PropID	p_id, 		/* Identifier of a property
		   					for an object. This is
	 	  			 		known as the Property ID. */
	ObjectID ID, 		/* The unique identifier for
							the object value
							to retrieve */
	long field,		/* The value field to be printed. */
	short max_str,		/* The max string width. */
	char *string		/* The return string representing the value. */
);

CelErr CSU_IMPORT_EXPORT 	csu_GetObjectValue(
	MolStruct *msPtr,	/* Pointer to the molstruct header structure. */
	ObjclsID oc_id, 	/* Identifier of the object class.
							This is known as the Object class ID.*/
	PropID p_id, 		/* Identifier of a property
		   					for an object. This is
	 	   					known as the Property ID.*/
	ObjectID ID, 		/* The unique identifier for the object value to retrieve */
	short Dtype,		/* internal data types for property values. */
	char *value,		/* The value. Memory is allocated by the caller */
	long num_vals,		/* The length in words of value */
	long *vec_len		/* The actual veclen (number of numbers) */
);

CelErr CSU_IMPORT_EXPORT csu_GetPropertyHeader(
	MolStruct *msPtr,	/* Pointer to the molstruct header structure. */
	ObjclsID oc_id, 	/* Identifier of the object
		   					class. This is known as the
		   					Object class ID.*/
	PropID p_id, 		/* Identifier of a property
		   					for an object. This is
	 	   					known as the Property ID. */
	PropHead *p_headPtr	/* Pointer to property header containing file attributes */
);

CelErr CSU_IMPORT_EXPORT csu_GetPropertyID(
	const char *name,	 /* string representing the name of the property */
	PropID *p_id /* Identifier of a property
		   					for an object. This is
	 	   					known as the Property ID. */ 
);

CelErr CSU_IMPORT_EXPORT csu_Init(
	const char *path,			/* name of data dictionary file */
	const char *logfile,		/* log file name or NULL */
	const char  *source_name	/* default source for properties added to molstructs*/
);

CelErr CSU_IMPORT_EXPORT csu_InitMolstruct(
	MolStruct *msPtr,	/* Pointer to the molstruct header structure. */
	const char *ms_name		/* name of molstruct */
);

CelErr CSU_IMPORT_EXPORT 	csu_NextID(
	MolStruct *msPtr,	/* Pointer to the molstruct header structure. */
	ObjclsID oc_id, 	/* Identifier of the object
		   					class. This is known as the
		   					Object class ID.*/
	ObjectID *o_id		/* The ID of the next available object in this object class */
);

BOOL CSU_IMPORT_EXPORT  csu_ObjectExists(
	MolStruct *msPtr,	/* Pointer to the molstruct header structure. */
	ObjclsID oc_id, 	/* Identifier of the object
		   					class. This is known as the
		   					Object class ID. */
	ObjectID o_id 		/* The identifying number for the object value. */
);

BOOL CSU_IMPORT_EXPORT csu_ObjectValueExists(
	MolStruct *msPtr,	/* Pointer to the molstruct header structure. */
	ObjclsID oc_id, 	/* Identifier of the object
		   					class.This is known as the
		   					Object class ID.*/
	PropID p_id, 		/* Identifier of a property
							for an object. This is
							known as the Property ID. */
	ObjectID o_id 		/* The identifying number for
							the object whose object
							value is determined from p_id */
);

CelErr CSU_IMPORT_EXPORT csu_SetLocalTransform(
	MolStruct *msPtr,	/* Pointer to the molstruct header structure. */
	double t[4][4]		/* local transform */
);

CelErr CSU_IMPORT_EXPORT csu_SetPropertyHeader(
	MolStruct *msPtr,	/* Pointer to the molstruct header structure. */
	ObjclsID oc_id, 	/* Identifier of the object
		   					class.This is known as the
		   					Object class ID.*/
	PropID p_id, 		/* Identifier of a property
		   					for an object. This is
	 	   					known as the Property ID. */
	PropHead *p_headPtr	/* Pointer to property header structure */
);

CelErr CSU_IMPORT_EXPORT 	csu_SetObjectValue(
	MolStruct *msPtr,	/* Pointer to the molstruct header structure. */
	ObjclsID oc_id, 	/* Identifier of the object
		   					class.This is known as the
		   					Object class ID.*/
	PropID p_id, 		/* Identifier of a property
		   					for an object. This is
	 	   					known as the Property ID. */
	ObjectID o_id, 		/* The identifying number for the object value */
	long vec_len,		/* vec_len is the number of fields for the object value.
							If vec_len is longer than the standard vector
							length then it is used.*/
	short val_dtype,		/* the type of data passed in value */
	char *value 		/* Character pointer to the
		   					data for the property (a cell in the table).
							The data pointed to is
							stored as the appropriate
							standard data type for
							this object value */
);

CelErr CSU_IMPORT_EXPORT csu_SetObjectValueByIndex(
	MolStruct *msPtr,	/* Pointer to the molstruct header structure. */
	ObjclsID oc_id, 	/* Identifier of the object
		   					class.This is known as the
		   					Object class ID.*/
	PropID p_id, 		/* Identifier of a property
		   					for an object. This is
	 	   					known as the Property ID. */
	ObjectID o_id, 		/* The INDEX */
	long vec_len,		/* vec_len is the number of fields for the object value.
							If vec_len is longer than the standard vector
							length then it is used.*/
	short val_dtype,	/* the type of data passed in value */
	char *value 		/* Character pointer to the
		   					data for the property (a cell in the table).
							The data pointed to is
							stored as the appropriate
							standard data type for
							this object value */
);
/* prototypes for core csu routines*/
Handle CSU_IMPORT_EXPORT NewHandle(long);
unsigned char CSU_IMPORT_EXPORT MemError();	/* non Mac replacement for MemError */
void CSU_IMPORT_EXPORT HSetSize(Handle * hp, long size); /* non Mac replacement for SetHandleSize */

long	CSU_IMPORT_EXPORT csu_DataLength(
	short	std_Dtype, 
	long	vecLen
);
void		CSU_IMPORT_EXPORT csu_ftoa( 
	double	num,
	int		precis,
	char	*buffer
);
double		CSU_IMPORT_EXPORT csu_GetValueAtPrecision(
	double	value,
	short	file_precis
);
void		CSU_IMPORT_EXPORT csu_LogMessage(
	char *str
);
void		CSU_IMPORT_EXPORT csu_MaxField(
	PropH		propsH,
	PropID		p,
	BitH		valid_obj,
	long		m,
	ObjectID	num_vals,
	short		*width
);
void		CSU_IMPORT_EXPORT csu_GetFileField(
	PropH		propsH,
	PropID		prop_index,
	ObjectID	obj_index,
	long		field,
	short		width,
	char		*string
);
void		CSU_IMPORT_EXPORT csu_DeleteMolstruct(
	MolStruct	*msPtr,
	BOOL		del_objclass,
	BOOL		del_prop
);
void		 CSU_IMPORT_EXPORT csu_PrintableASCII(
	char		*string
);
void		CSU_IMPORT_EXPORT getUniqueID (
	MolStruct	*msPtr,
	ObjclsID	objclsID,
	ObjectID	*objectID
);

BOOL		CSU_IMPORT_EXPORT csu_SearchPropAry(
	char		*prop_name,
	PropH		propsH,
	PropID		prop_ary_len,
	PropID		*prop_index
);
BOOL		CSU_IMPORT_EXPORT csu_ExistPropDictName(
	const char	*prop_name,
	PropID		*prop_dict_index
);
BOOL		CSU_IMPORT_EXPORT csu_FindObjclsDictIndex(
	ObjclsID	objcls_name_index,
	ObjclsID	*objcls_dict_index
);
BOOL		CSU_IMPORT_EXPORT csu_FindPropDictIndex(
	PropID		prop_name_index,
	PropID		*prop_dict_index
);
BOOL		CSU_IMPORT_EXPORT csu_ExistObjclsDictName(
	const char	*objcls_name,
	ObjclsID	*objclsID
);
BOOL		CSU_IMPORT_EXPORT csu_GetNextToken(
	char		**token,
	int 		string_len,
	int 		*tokenlen,
	char		*string
);
BOOL		CSU_IMPORT_EXPORT csu_ExistsPropID(
	PropH		propsH,
	PropID		propID,
	PropID		num_props,
	PropID		*prop_index
);
BOOL		CSU_IMPORT_EXPORT csu_ExistsObjclsID(
	MolStruct	*msPtr,
	ObjclsID	objclsID,
	ObjclsID	*objcls_index
);
BOOL		CSU_IMPORT_EXPORT csu_SearchObjclsAry(
	char		*objcls_name,
	ObjclsH		objclsH,
	ObjclsID	objcls_ary_len,
	ObjclsID	*objcls_index
);
CelErr		CSU_IMPORT_EXPORT csu_GetMolstruct(
	char		*pathname,
	MolStruct	*msPtr,
	BOOL		add_new_objclass,
	BOOL		add_new_prop
);
CelErr		CSU_IMPORT_EXPORT csu_scanarg(
	char		*input_string,
	char		**token,
	int 		*tokenlength
);

int			CSU_IMPORT_EXPORT csu_strncmp(
	char		*input_string,
	char		*cmp_string,
	int			input_length
);
Number		CSU_IMPORT_EXPORT csu_LastToken(
	char		*string,
	char		**token
);
CelErr		CSU_IMPORT_EXPORT csu_AddTmpObjcls(
	TempObjclsH *hOld,
	PropID		num_properties,
	ObjectID	num_objs
);
CelErr		CSU_IMPORT_EXPORT csu_AddTmpUntDct(
	TempUnitDictH *hOld,
	short		num_nstd_units
);
CelErr		CSU_IMPORT_EXPORT csu_PrvwDictFile(
	FILE		*stream
);
CelErr		CSU_IMPORT_EXPORT csu_PrvnMolstructFile(
	FILE		*stream,
	ObjclsID	*num_object_classes,
	TempObjclsH *t_objclsH
);
CelErr		CSU_IMPORT_EXPORT csu_NewMolstruct(
	ObjclsID	num_object_classes,
	TempObjclsH	t_objclsH,
	MolStruct	*msPtr
);
CelErr		CSU_IMPORT_EXPORT csu_AllocVal(
	ObjectID	num_vals,
	short		data_type,
	long		vec_len,
	ValueH		*valHp
);
CelErr		CSU_IMPORT_EXPORT csu_SaveMolstruct(
	MolStruct	*msPtr,
	char		*pathname,
	char		*srcname
);
CelErr		CSU_IMPORT_EXPORT csu_SaveMolstructFile(
	MolStruct	*msPtr,
	char		*pathname,
	char		*srcname,
	long		ftype,
	long		fcreator
);
CelErr		CSU_IMPORT_EXPORT csu_GetVal(
	MolStruct	*msPtr,
	ObjclsID	objclsID,
	PropID		propID,
	long		val_index,
	char		**value,
	short		*file_dtype
);
CelErr		CSU_IMPORT_EXPORT csu_GrabVal(
	MolStruct	*msPtr,
	ObjclsID	objclsID,
	PropID		propID,
	char		**value
);
CelErr		CSU_IMPORT_EXPORT csu_ReleaseVal(
	MolStruct	*msPtr,
	ObjclsID	objclsID,
	PropID		propID
);
CelErr		CSU_IMPORT_EXPORT csu_InsertVal(
	PropH		propsH,
	PropID		prop_index,
	long		val_index,
	char		*string
);
CelErr		CSU_IMPORT_EXPORT csu_ValidateVal(
	PropH		propsH,
	PropID	prop_index,
	char		*string
);
CelErr		CSU_IMPORT_EXPORT csu_AddObjcls(
	MolStruct	*msPtr,
	ObjclsID	objclsID,
	ObjclsID	*objcls_index,
	ObjectID	num_objects
);
CelErr		CSU_IMPORT_EXPORT csu_AddProperty(
	ObjclsH		objclsH,
	ObjclsID	objclsi,
	PropID		propID,
	long		vec_len,
	PropID		*prop_index
);
CelErr		CSU_IMPORT_EXPORT csu_AllocAllPropVals(
	ObjclsH		objclsH,
	ObjclsID	objclsi,
	PropID		pdi,
	long		vec_len,
	PropID		prop_index
);
CelErr		CSU_IMPORT_EXPORT csu_SearchStringAry(
	NameH		hName,
	short		length,
	const char	*key,
	NameNID		*index
);
CelErr		CSU_IMPORT_EXPORT csu_GetUnitConv(
	NameNID		unitN_from,
	NameNID		unitN_to,
	double		*multiplier,
	double		*offset
);
CelErr		CSU_IMPORT_EXPORT csu_SetPropUnits(
	MolStruct	*msPtr,
	ObjclsID	objclsID,
	PropID		propID,
	short		*unitN_fromPtr,
	short		unitN_to
);
CelErr		CSU_IMPORT_EXPORT csu_ConvConIDtoIndex(
	MolStruct	*msPtr
);
CelErr		CSU_IMPORT_EXPORT csu_InitConIDtoIndex(
	MolStruct	*msPtr
);
CelErr		CSU_IMPORT_EXPORT csu_GetProp(
	MolStruct	*msPtr,
	ObjclsID	objclsID,
	PropID		propID,
	PropH		*propsH,
	PropID		*pi
);
CelErr		CSU_IMPORT_EXPORT csu_GetPropArrays(
	MolStruct	*msPtr,
	ObjclsID	objclsID,
	PropID		propID,
	BitH		*lock_valueH,
	BitH		*has_valueH,
	ValueH		*valuesH
);
CelErr		CSU_IMPORT_EXPORT csu_ConvToStdUnits(
	PropH		propsH,
	PropID		pi,
	double		*multiplier,
	double		*offset
);
CelErr		CSU_IMPORT_EXPORT csu_ConvToUserUnits(
	PropH		propsH,
	PropID		pi,
	double		*multiplier,
	double		*offset
);
CelErr		CSU_IMPORT_EXPORT csu_GiveUniqueID(
	LongH		valuesH,
	BitH		validH,
	ObjectID	num_vals,
	ObjectID	obj_index
);
CelErr		CSU_IMPORT_EXPORT csu_GiveUniqueIDEx(
	LongH		valuesH,
	BitH		validH,
	ObjectID	num_vals,
	ObjectID	obj_index,
	ObjectID    *my_id
);
CelErr		CSU_IMPORT_EXPORT csu_AddObject(
	ObjclsH		objclsH,
	ObjclsID	objcls_index
);
CelErr		CSU_IMPORT_EXPORT csu_AddConnectorObject(
	ObjclsH		objclsH,
	ObjclsID	objcls_index
);
CelErr		CSU_IMPORT_EXPORT csu_AddObjectEx(
	ObjclsH		objclsH,
	ObjclsID	objcls_index,
	ObjectID	*obj_index,
	ObjectID    *my_id
);
CelErr		CSU_IMPORT_EXPORT csu_ClearSelected(
	MolStruct	*msPtr,
	u_char		del_flag
);
CelErr		CSU_IMPORT_EXPORT csu_FlagObject(
	MolStruct	*wp,
	ObjclsID	objclsID,
	ObjectID	obj_index,
	u_char		flag
);
CelErr		CSU_IMPORT_EXPORT csu_UnflagObject(
	MolStruct	*wp,
	ObjclsID	objclsID,
	ObjectID	obj_index,
	u_char		flag
);
CelErr		CSU_IMPORT_EXPORT csu_FlagMolstruct(
	MolStruct	*msPtr,
	u_char		flags
);
CelErr		CSU_IMPORT_EXPORT csu_UnflagMolstruct(
	MolStruct	*msPtr,
	u_char		flags
);
CelErr CSU_IMPORT_EXPORT csu_CopyMolstructFlag(
	MolStruct	*msPtr,
	u_char		test_flags,	/* wherever ((dflag & test_flags) == test_flags), */
	u_char		mod_flags	/* set mod_flags, elsewhere clear mod_flags */
);

CelErr CSU_IMPORT_EXPORT csu_ToggleMolstructFlag(
	MolStruct	*msPtr,
	u_char		test_flags,	/* wherever ((dflag & test_flags) == test_flags), */
	u_char		mod_flags	/* clear mod_flags, elsewhere set mod_flags */
);

CelErr CSU_IMPORT_EXPORT csu_AddMolstructFlag(
	MolStruct	*msPtr,
	u_char		test_flags,	/* wherever ((dflag & test_flags) == test_flags), */
	u_char		mod_flags	/* set mod_flags */
);

CelErr CSU_IMPORT_EXPORT csu_RemoveMolstructFlag(
	MolStruct	*msPtr,
	u_char		test_flags,	/* wherever ((dflag & test_flags) == test_flags), */
	u_char		mod_flags	/* clear mod_flags */
);

CelErr		CSU_IMPORT_EXPORT csu_DeleteObjcls(
	MolStruct	*msPtr,
	ObjclsID	objclsID,
	u_char		del_flag
);

#define ed_GiveUniqueID csu_GiveUniqueID
#define ed_AddObject csu_AddObject
#define ed_ClearSelected csu_ClearSelected
#define ed_FlagObject csu_FlagObject
#define ed_UnflagObject csu_UnflagObject
#define ed_FlagMolstruct csu_FlagMolstruct
#define ed_UnflagMolstruct csu_UnflagMolstruct
#define ed_ToggleMolstructFlag csu_ToggleMolstructFlag
#define ed_CoFlagMolstruct csu_AddMolstructFlag
#define ed_DeleteObjcls csu_DeleteObjcls

CelErr		CSU_IMPORT_EXPORT csu_AddConnectorVal (
	MolStruct	*msPtr,
	ObjclsID	objcls1ID,
	ObjectID	obj1index,
	ObjclsID	objcls2ID,
	ObjectID	obj2index,
	u_char		dflagval
);

CelErr		CSU_IMPORT_EXPORT csu_AddConnectorValFast (
	MolStruct	*msPtr,
	ObjclsID	objcls1ID,
	ObjectID	obj1index,
	ObjclsID	objcls2ID,
	ObjectID	obj2index,
	u_char		dflagval
);


CelErr		CSU_IMPORT_EXPORT csu_AddObjVal (
	MolStruct	*msPtr,
	ObjclsID	objclsID,
	PropID		propID,
	ObjectID	objectID,
	NameNID		srcN,
	short		Dtype,
	long		veclen,
	short		unitN,
	short		precis,
	char		*value,
	long		offset,
	short		searchtype
);
CelErr		CSU_IMPORT_EXPORT csu_InstProp (
	ObjclsH		objclsH,
	ObjclsID	objclsi,
	PropID		propID,
	long		veclen,
	NameNID		srcN,
	short		Dtype,
	short		unitN,
	short		precis,
	PropID		*propi
);
ObjectID	CSU_IMPORT_EXPORT csu_ObjectIDtoIndex(
	MolStruct	*msPtr,
	ObjclsID	objclsID,
	ObjectID	objectID
);
short		CSU_IMPORT_EXPORT csu_Std_DtypeToNumber(
	char		*string
);
short		CSU_IMPORT_EXPORT csu_SdtToFdt(
	short		std_Dtype
);
short		CSU_IMPORT_EXPORT csu_File_DtypeToNumber(
	char		*string
);
double		CSU_IMPORT_EXPORT csu_HexToUnsigned(
	char		*string
);
Number		CSU_IMPORT_EXPORT csu_NumTokens(
	char		*string
);

CelErr CSU_IMPORT_EXPORT csu_DefineProperty(
	char *name,			/* Pointer to name of property to be defined */
	short std_unitN, 	/* the index in names array of standard unit of measure */
	short std_precis,	/* the number of digits precision after decimal point */
	short std_Dtype,	/* the internal representation of a value:
						CHAR - 				char
						UCHAR-  unsigned 	char
						SHORT- 				short
						NAME- 				short
						USHORT -unsigned 	short
						LONG -      		long
						ULONG - unsigned	long
						FLOAT -				float
						DOUBLE - 			double */
	long vec_len,		/* the number of fields stored per value, if vec_len > 0 */
						/* vec_len < 1 represents a variable length vector, the real
						vector length is stored in a molstruct Prop structure */
	PropID *p_id		/* Return the identifier of the property */
);

CelErr CSU_IMPORT_EXPORT csu_AddName(const char *name, NameNID *name_index);
CelErr CSU_IMPORT_EXPORT csu_AddNewStdUnit(char *name, NameNID *unit_index);
CelErr CSU_IMPORT_EXPORT csu_GetUnitNameIndex(char *unit_name,NameNID *unitN,NameNID *std_unitN);

CelErr CSU_IMPORT_EXPORT csu_AddNewObjcls(char *objcls_name,ObjclsID *objclsID);
CelErr CSU_IMPORT_EXPORT csu_DefineNewObjcls(const char *objcls_name,ObjclsID *objclsID,u_short flag);
CelErr CSU_IMPORT_EXPORT csu_AdjustPrecis(short *precis,NameNID unitN_from,NameNID unitN_to);

long CSU_IMPORT_EXPORT csu_GetStartMovie();
long CSU_IMPORT_EXPORT double_to_long(double d);
double CSU_IMPORT_EXPORT csu_GetEpsilonForPrecision(short filePrecision);

#ifdef _CACHE_DLL
	CSU_IMPORT_EXPORT DataDictionary DataDict; 
	CSU_IMPORT_EXPORT short csu_Src; /* name index for creator of property */
	CSU_IMPORT_EXPORT CSUGlobal csu_Globals;
#else
	extern DataDictionary DataDict;
	extern short csu_Src; /* name index for creator of property */
	extern CSUGlobal csu_Globals;
#endif

extern void (*csu_LogErr)(); /* function to log error strings from csu */
extern FILE *csu_logfile;
extern long csu_StartMovie; /* file offset in bytes to start of movie header */
							/* begins after the line with MovieFrames keyword */

short CSU_IMPORT_EXPORT csu_ConfLobes(NameNID conf);
short CSU_IMPORT_EXPORT csu_confCheck(const short n_lobes, const short n_orbitals,
	const short n_bonds, const short hi_btype, const short conf);
short CSU_IMPORT_EXPORT csu_bondOrbitals(short btype);

#ifdef _WINDOWS
CelErr CSU_IMPORT_EXPORT csu_FetchSequence( MolStruct	*msPtr,						// pointer to MolStruct
								  ObjectID* GroupIDSequence,			// array of group ObjectIDs 
								  ObjectID* GroupIndexSequence,	   // array of group Object Indexes 
							  	  ObjectID ArrayLen,						// array length
								  ObjectID* SeqLen						// the length of the output sequence
								);
#endif


/* Debugging functions */
#if defined (CS_DEBUG)
void csu_printColumnHeaders(const char *title, ObjclsH tablesH, ObjclsID tableNumber);
void csu_printTableAndColumnHeaders(MolStruct *tableStructure);
#endif

#ifdef __cplusplus	/* For type-safe linkage */
}
#endif


/* macros */
#define csu_SetBit(bitH, bit_no) \
	*(GetPtr(bitH) + ((unsigned)(bit_no) >> 3)) |= (1 << ((bit_no) & 7))
#define csu_ClearBit(bitH, bit_no) \
	*(GetPtr(bitH) + ((unsigned)(bit_no) >> 3)) &= ~(1 << ((bit_no) & 7))
#define csu_GetBit(bitH, bit_no) \
	((*(GetPtr(bitH) + ((unsigned)(bit_no) >> 3)) & (1 << ((bit_no) & 7))) != 0)

#define csu_ObjclsN(objclsID) (GetPtr(DataDict.objclsdictH) + objclsID)->objclsN

#define csu_EmptyObjcls(msPtr, i)  csu_ExistsObjclsID(msPtr, -1, i)
#define csu_EmptyProp(propsH, num_p, i)  csu_ExistsPropID(propsH, -1, num_p, i)

#endif /* _csu_ */
