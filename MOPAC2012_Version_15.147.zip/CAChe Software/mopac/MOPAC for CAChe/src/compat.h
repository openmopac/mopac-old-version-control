/*
**  compat.h -- compiler compatibility and configuration file
**
**  This file exists in more version than what is healty in CAChe
**  This version is the first attempt that tries to merge the PC,
**  Mac, and Standalone versions together.
**  Several compiler directives have been dropped, vide infra
**  12/Jun/2000, Ingvar Lagerstedt, Oxford Molecular
**
**  Authors:    Guido van Rossum, Scott Huddleston, Andy Spencer
**  Date:       14/Jun/2000
**  Revision:   2000.1
*/

#ifndef _COMPAT_
#define _COMPAT_

/*** D E F I N E   H O S T / C O M P I L E R ***/
 
/*
** This header file supports the following things.  All new code should
** use this and old code should be converted to use these when edited.
**
**	Platform / OS:
**		unix - Generic UNIX platforms.
**		WIN32 - 32-bit Windows code, no support for 16 bit code anymore
*/

/*** O/S SPECIFIC DEFINITIONS ***/

/*** I N C L U D E   F I L E S ***/

#include <stdio.h>
#include <stdlib.h>

#if defined (WIN32)
#if defined (_CACHE_DLL) || defined (_AFXDLL) || defined (_OGLDLL)
#include <windows.h>
#include <windowsx.h>
#endif
#include <malloc.h>
#include <string.h>
#include "OMFbool.h"
#elif defined (unix)
#include <sys/time.h>
#include <unistd.h>
#include <string.h>
#include "OMFbool.h"
#endif

/*** P L A T F O R M  /  O S  /  C O M P I L E R   S P E C I F I C ***/
#if defined(WIN32)
#	define SYS_STRING	"WIN"
#elif defined(cache_aix)
#	define SYS_STRING	"AIX"
#elif defined(cache_irix)
#	define SYS_STRING	"IRIX"
#elif defined(cache_bsd)
#	define SYS_STRING	"BSD"
#else
#	define SYS_STRING	"UNKNOWN"
#endif

#define Rename(new_name, old_name)	rename(old_name, new_name)

#define _HNDL_PTR_ /* To distinguish between handles on Mac and pointers elsewhere */

typedef unsigned char Boolean;

struct Rect {
	short top;
	short left;
	short bottom;
	short right;
};

typedef struct Rect Rect;
typedef Rect *RectPtr;
typedef int DialogPtr;

#define ARGS(arglist)   	()
#define NOARGS      		()
#define QD(name)			name

/*********************** 32 bit W I N D O W S ********************/

#if defined (WIN32)

/* JJS - Temporary porting things, survived for 6 years so maybe permanent */
#define INT2SHORT		short
#define INT2LONG		long
#define D2F				float
#define SHORT2CHAR		char

// JJS - 2/2/94 defined in typedef.h
#pragma warning(disable: 4237)

#if defined (_CACHE_DLL) || defined (_AFXDLL) || (_OGLDLL)
typedef HWND	GuiWin;
typedef HDC		GDHandle;
#endif

/* JJS - HUGE/FAR defined in windows?.h */
// JJS - Changed to pointers as opposed to just huge and far
// IL - FAR is obsolete in WIN32
#define FAR_PTR *
#define HUGE_PTR  *
#define __far
#define __huge

/* Mac stuff defined for the PC */

// JJS - 2/3/94
typedef short	OSErr;
typedef int		DialogPtr;
typedef unsigned char * CGrafPtr;
typedef unsigned char * ThreadHandle;

// DW 2/28/94
typedef unsigned long OSType;

#define SECTRECT(s1,s2,d) IntersectRect(d,s1,s2)

struct Point {
	short		v;
	short		h;
};

//DW - 2/28/94
typedef struct Point Point;

// These memory defines makes PCMemory obsolete
#define MLALLOC(s, m)		malloc(s)
#define RELALLOC(p, s, m)	realloc(p, s)
#define MLFREE(p, m)		free(p)

#define MSALLOC(s, m)		malloc(s)
#define RESALLOC(p, s, m)	realloc(p, s)
#define MSFREE(p, m)		free(p)

typedef char *					Handle;
#define HLock(h)
#define HUnlock(h)
#define HGetState(h)			(char)(1 << 7)
#define DisposHandle(h)			free((h))
#define SetHandleSize(h, size)	HSetSize(&(h), (long)(size))
#define noErr					0
#define freeHandle(h)			free((h)) // JJS - Garbage define for DLM

// It seems popular to use true/false even in c
#ifndef true
#define true 1
#endif
#ifndef false
#define false 0
#endif

/*** W I N D O W S   D L L ***/

#if defined (_WINDLL)

#define fcvt _fcvt
#define sprintf wsprintf

#endif /* _WINDLL */

#else /* WIN32 */

#define HUGE_PTR *

#endif  /* !WIN32 */



/*** U N I X  ***/

#if defined (unix)

#define Delete(filename_str)		remove(filename_str)

/* no handles available so use pointers instead */
typedef char* Handle;
#define HLock(h)
#define HUnlock(h)
#define HGetState(h)			(1 << 7)
#define HPurge   				free
#define DisposHandle   			free
#define SetHandleSize(h, size)	HSetSize(&(h), (long)(size))
#define noErr					0
struct Point {
	short		v;
	short		h;
};
typedef struct Point Point;
#endif

/*** P L A T F O R M   I N D E P E N D E N T   S T U F F ***/
/* de-reference a handle to a pointer */
#define GetPtr(handle) (_HNDL_PTR_(handle))
#define CastPtr(datatype,handle) ((datatype *) _HNDL_PTR_ handle)

#define PI  3.14159265358979323846264338327950

#define mlalloc     malloc
#define clalloc     calloc
#define relalloc    realloc

#ifndef		NULL
#define		NULL					0L
#endif		// NULL

#ifndef		FALSE
#define		FALSE					0
#endif		// FALSE

#ifndef		TRUE
#define		TRUE					1
#endif		// TRUE

#if !defined (unix)		/* most unix boxes define these in sys/param.h */

#ifndef		MAX
#define		MAX(a, b)				(((a) > (b)) ? (a) : (b))
#endif		// MAX

#ifndef		MIN
#define		MIN(a, b)				(((a) < (b)) ? (a) : (b))
#endif		// MIN

#endif

#ifndef		ABS
#define		ABS(a)					(((a) >= 0) ? (a) : -(a))
#endif		// ABS

#ifndef		ROUND
#define		ROUND(a)				(long) (((a) >= 0.0) ? ((a) + 0.5) : ((a) - 0.5))
#endif 		// ROUND

#endif
