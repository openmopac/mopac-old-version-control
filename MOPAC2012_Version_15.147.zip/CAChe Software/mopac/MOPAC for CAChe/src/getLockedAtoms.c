#include "compat.h"
#include "csu.h"

long getNumberLockedAtoms(molStruct, NAtom)
MolStruct	*molStruct;
int			NAtom;
{
	BitH	XYZLockH;
	long 	numLockedAtoms;
	long	i;
	
	csu_GetPropArrays(molStruct, AtomID, XYZID, &XYZLockH, NULL, NULL);
	for (i=0, numLockedAtoms=0; i<NAtom; i++) {
		if (csu_GetBit(XYZLockH, i)) 
			/* value of lockedAtoms is true if the atom has locked 
			   Cartesian coordinates */
			numLockedAtoms++;
	}
	return (numLockedAtoms);
}

void getLockedAtoms(molStruct, lockedAtoms, NAtom)
MolStruct	*molStruct;
long 		lockedAtoms[];
long			NAtom;
{
	BitH	XYZLockH;
	long	i;
	
	csu_GetPropArrays(molStruct, AtomID, XYZID, &XYZLockH, NULL, NULL);
	for (i=0; i<NAtom; i++) {
		if (csu_GetBit(XYZLockH, i)) {
			/* value of lockedAtoms is true if the atom has locked 
			   Cartesian coordinates */
			lockedAtoms[i] = true;
		} else
			lockedAtoms[i] = false;
	}
}

