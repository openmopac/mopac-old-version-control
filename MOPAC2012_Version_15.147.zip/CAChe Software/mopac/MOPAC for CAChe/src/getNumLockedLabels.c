#include <compat.h>
#include <cpu.h>
#include <csuServer.h>
#include <ZINDODriver.h>

int getNumberLockedLabels(MolStruct *molStruct)
{
	static ObjclsID objectClass[] = {Atom_distID, Bond_angID, DihedralID};
	long i,j;
	long	numLockedLabels, numberOfLabels;
	ObjectID objectID;
 	double	lowValue;
	double	highValue;
	long	numSteps;
	ObjectID	atomList[5];

	numLockedLabels = 0;
	numberOfLabels = 0;
	for (j=0; j<3; j++)
		numberOfLabels += csu_CountValidObjects(molStruct, (ObjclsID) objectClass[j]);

	for (j=0; j < 3; j++) {
		i=0;
		while (i < numberOfLabels) { /* number of atoms or labels */
			cpu_getLabelAtoms(molStruct, atomList,
							  objectClass[j], i);
			if (atomList[0] != 0) {
				if (cpu_LabelStatus(molStruct, atomList,objectClass[j], &objectID,
					&lowValue, &highValue, &numSteps) == 2) 
					/* returns 2 for a locked label */
					   numLockedLabels++;
			}
		i++;
		}
	}
	return (numLockedLabels);
}
