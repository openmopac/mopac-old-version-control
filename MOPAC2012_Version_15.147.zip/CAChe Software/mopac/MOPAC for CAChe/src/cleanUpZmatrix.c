#include <compat.h>
#include <math.h>
#include <cpu.h>
#include "MOPACDriver.h"

long cleanUpZmatrix(
	long NAtom,
	long numDummyAtoms,
	long numLockedAtoms,
	long *lockedAtoms,
	long numSearchLabels,
	SearchLabel *searchLabels,
	long numLockedLabels,
	LockedLabel *lockedLabels,
	Zmatrix *zMatrix,
	double (*coords)[3],
	long *atomLocation,
	long numberBonds,
	long (*bondList)[2]
)
{
	long i, j, k, m ,n, atom_after;
	char errs[256];
	Boolean colinear_1 = FALSE, colinear_2 = FALSE;
	Boolean colinear_3 = FALSE, colinear_4 = FALSE;

	/* put in Z matrix information for search labels */
	if (numSearchLabels > 0) {
		k = searchLabels[0].atomList[1];
		if (searchLabels[0].objclsID == Atom_distID) {
			zMatrix[k].varyDistance = -1;
		} 
		else if (searchLabels[0].objclsID == Bond_angID) {
			zMatrix[k].varyAngle = -1;
		} 
		else if (searchLabels[0].objclsID == DihedralID) {
			zMatrix[k].varyDihedral = -1;
		}
		/* 
		 * Change z-Matrix connectivity to account for the
		 * first search label. 
		 */
		zMatrix[k].atomA = searchLabels[0].atomList[2];
		/* 
		 * Replace the rest of the connectivity if it 
		 * is specified in the label.
		 */
		if (k > 1) 
			zMatrix[k].atomB = searchLabels[0].atomList[3];
		if (k > 2) 
			zMatrix[k].atomC = searchLabels[0].atomList[4];
	}
	
	if (numSearchLabels > 1) {
		k = searchLabels[1].atomList[1];
		if (searchLabels[1].objclsID == Atom_distID) {
			zMatrix[k].varyDistance = -1;
		} 
		else if (searchLabels[1].objclsID == Bond_angID) {
			zMatrix[k].varyAngle = -1;
		} 
		else if (searchLabels[1].objclsID == DihedralID) {
			zMatrix[k].varyDihedral = -1;
		}
		/* 
		 * Change z-Matrix connectivity to account for the
		 * second search label.
		 */
		zMatrix[k].atomA = searchLabels[1].atomList[2];
		/* 
		 * Replace the rest of the connectivity if it 
		 * is specified in the label.
		 */
		if (k > 1) 
			zMatrix[k].atomB = searchLabels[1].atomList[3];
		if (k > 2) 
			zMatrix[k].atomC = searchLabels[1].atomList[4];
	}
	cartesianToInternal(coords, NAtom + numDummyAtoms, zMatrix, 
		numberBonds, bondList, atomLocation, numDummyAtoms);
	
	/* 
	 * Go through list of atoms three times to try and remove all 
	 * colinearities from the Z Matrix; do not move atoms at the 
	 * begining of the Z-matrix that were placed there because they 
	 * are locked, part of a locked label, or part of a search label.
	 */
	
	for (n = 0; n < 3; n++) {
		for (m = MOPAC_MAX(3,numDummyAtoms), colinear_1 = FALSE; 
					m < NAtom + numDummyAtoms - 1; m++) {  
			/* 
			 * If the angle between the first three atoms of a 
			 * dihedral is nearly 0 or 180 degrees, look for another 
			 * atom to replace the first of the three.  Start with 
			 * the third atom, and go to the next-to-the-last atom.
			 */
			
			 if ((fabs(zMatrix[m].angle - 180.) < 5.) ||
				 (fabs(zMatrix[m].angle) < 5.)  && 
				 ((NAtom + numDummyAtoms) > m)) {
				colinear_1 = TRUE;
				for (i = m+1; i < NAtom + numDummyAtoms; i++) {
					if ((fabs(atomAngle(coords, zMatrix[m].atomA, 
						 zMatrix[m].atomB, i)*RadianToDegree - 180.) > 5.) &&
						(fabs(atomAngle(coords, zMatrix[m].atomA, 
						 zMatrix[m].atomB, i)*RadianToDegree) > 5.)) { 
						/*
						   Restore the atom numbers in the locked labels and 
						   search labels to the original
						   atom numbers.  The array atomLocation[i] contains the original
						   atom number for current atom numbered i.
						 */
						for (k = 0; k < numSearchLabels; k++) {
							for (j = searchLabels[k].atomList[0]; j > 0; j--) {
								 searchLabels[k].atomList[j] = 
								 atomLocation[searchLabels[k].atomList[j]];
							}  /* j loop */
						} /* k loop */
						for (k = 0; k < numLockedLabels; k++) {
							for (j = lockedLabels[k].atomList[0]; j > 0; j--) {
								 lockedLabels[k].atomList[j] =
									atomLocation[lockedLabels[k].atomList[j]];
							}  /* j loop */
						} /* k loop */
						swapAtoms(i, m, coords, atomLocation, numDummyAtoms);
						k = zMatrix[i].varyDistance;
						zMatrix[i].varyDistance = zMatrix[m].varyDistance;
						zMatrix[m].varyDistance = (short)k;
						k = zMatrix[i].varyAngle;
						zMatrix[i].varyAngle = zMatrix[m].varyAngle;
						zMatrix[m].varyAngle = (short)k;
						k = zMatrix[i].varyDihedral;
						zMatrix[i].varyDihedral = zMatrix[m].varyDihedral;
						zMatrix[m].varyDihedral = (short)k;
					
						if (numLockedLabels > 0) {
						/* 
						  Make sure that first atom is after other atoms in the label in the 
						  atomLocation list.  Do the check 3 times since for a dihedral angle, the
						  first atom could be ahead of the other 3 other atoms in the label. 
						*/
							for (k = 0; k < 3; k++)
								renumberForFirstAtom(i, lockedLabels, 
								numLockedLabels, NAtom + numDummyAtoms, 
								atomLocation, coords, numDummyAtoms);
						}
					
						if (numSearchLabels > 0) {
						/* 
						  Make sure that moving atom is after other atoms in the label in the 
						  atomLocation list.  Do the check 3 times since for a dihedral angle, the
						  moving atom could be ahead of the other 3 other atoms in the label. 
						*/
							for (k = 0; k < 3; k++)
								renumberForMovingAtom(i, searchLabels, 
								numSearchLabels, NAtom + numDummyAtoms, 
								atomLocation, coords, numDummyAtoms);
						}
						
						if (numLockedLabels > 0) {
						/* 
						  Make sure that first atom is after other atoms in the label in the 
						  atomLocation list.  Do the check 3 times since for a dihedral angle, the
						  first atom could be ahead of the other 3 other atoms in the label. 
						*/
							for (k = 0; k < 3; k++)
								renumberForFirstAtom(i, lockedLabels, 
								numLockedLabels, NAtom + numDummyAtoms, 
								atomLocation, coords, numDummyAtoms);
						}
					
						/* renumber the labels */
						renumberSearchLabels(searchLabels, numSearchLabels,
							   NAtom + numDummyAtoms, atomLocation);
						renumberLockedLabels(lockedLabels, numLockedLabels, 
								NAtom + numDummyAtoms, atomLocation);
						cartesianToInternal(coords, NAtom + numDummyAtoms, zMatrix, 
							numberBonds, bondList, atomLocation, 
							numDummyAtoms);
						break;
					} /* dihedral not colinear */
				}  /* i loop */
			 } /* nearly colinear angle */
		} /* m loop */
		if (!colinear_1) break; /* if no colinear atoms found, stop looking! */
	} /* n loop */
	
	/* Check that second three atoms of dihedral angles are not colinear */
	for (m = MOPAC_MAX(3,numDummyAtoms), colinear_2 = FALSE; 
						m < NAtom + numDummyAtoms; m++) {  
		if ((fabs(atomAngle(coords, zMatrix[m].atomA, 
			zMatrix[m].atomB, zMatrix[m].atomC)*RadianToDegree - 180.) < 5.) ||
			(fabs(atomAngle(coords, zMatrix[m].atomA, 
			zMatrix[m].atomB, zMatrix[m].atomC)*RadianToDegree) < 5.)) {
			colinear_2 = TRUE;
			break;
		}
	} /* m loop */
	
	
	if (numSearchLabels == 1) {
		if (searchLabels[0].objclsID == Atom_distID) {
			zMatrix[searchLabels[0].atomList[1]].distance = 
				searchLabels[0].lowValue;
			zMatrix[searchLabels[0].atomList[1]].varyDistance = -1;
		} 
		else if (searchLabels[0].objclsID == Bond_angID) {
			zMatrix[searchLabels[0].atomList[1]].angle = 
				searchLabels[0].lowValue;
			zMatrix[searchLabels[0].atomList[1]].varyAngle = -1;
		} 
		else if (searchLabels[0].objclsID == DihedralID) {
			zMatrix[searchLabels[0].atomList[1]].dihedral = 
				searchLabels[0].lowValue;
			zMatrix[searchLabels[0].atomList[1]].varyDihedral = -1;
		}
	} 
	else if (numSearchLabels == 2) {
		if (searchLabels[0].atomList[1] != 
			searchLabels[1].atomList[1]) { 
			/* Moving atom is different for both labels.
			 * Change z-Matrix connectivity to account for the
			 * first grid step 
			 */
			k = searchLabels[0].atomList[1]; /* moving atom */
			zMatrix[k].atomA = searchLabels[0].atomList[2];
			/* 
			 * Replace the rest of the connectivity if it is \
			 * specified in the label.
			 */
			if (k > 1) 
				zMatrix[k].atomB = searchLabels[0].atomList[3];
			if (k > 2) 
				zMatrix[k].atomC = searchLabels[0].atomList[4];
			
			/* 
			 * Change z-Matrix connectivity to account for the
			 * second grid step.
			 */
			k = searchLabels[1].atomList[1]; /* moving atom */
			zMatrix[k].atomA = searchLabels[1].atomList[2];
			/* 
			 * Replace the rest of the connectivity if it is 
			 * specified in the label.
			 */
			if (k > 1) 
				zMatrix[k].atomB = searchLabels[1].atomList[3];
			if (k > 2) 
				zMatrix[k].atomC = searchLabels[1].atomList[4];
			
		} 
		else {   
			/* moving atom for both labels is the same */
		
			/* perform a sanity check on the atoms in the search label */
			for (k = 2; k <= MOPAC_MIN(searchLabels[0].atomList[0],
					searchLabels[1].atomList[0]); k++) {
				if (searchLabels[0].atomList[k] !=
					searchLabels[1].atomList[k]) {
					sprintf(errs," Search label conflict.  Reorder search labels.");
					leaveBusyState();
					note_user(errs);
					enterBusyState();
					return (-1);
				}
			} /* k loop */
			/*
			 * Change z-Matrix connectivity to account for the 
			 * search label with the most atom numbers that are not -1. 
			 */
			for (k = 2, j = -1; k < 5; k++) {
				if (searchLabels[0].atomList[k] != -1) {
					j = 0;
				} else if (searchLabels[1].atomList[k] != -1) {
					j = 1;
				}
			}
			if (j == -1) {
				sprintf(errs,"cleanUpZmatrix: Error in connectivity for moving atoms being the same.");
				leaveBusyState();
				note_user(errs);
				enterBusyState();
				return (-1);
			}
			k = searchLabels[j].atomList[1]; /* moving atom */
			/* 
			* atomA will be the same for both labels if they have 
			* the same moving atom.
			*/
			zMatrix[k].atomA = searchLabels[j].atomList[2];
			if (k > 1) {
				/* 
				 * If either search label is an angle or a dihedral, 
				 * take atomB from its label.
				 */
				if (searchLabels[0].atomList[0] >= 3)
					zMatrix[k].atomB = searchLabels[0].atomList[3];
				else if (searchLabels[1].atomList[0] >= 3)
					zMatrix[k].atomB = searchLabels[1].atomList[3];
				else if (searchLabels[j].atomList[0] > 2)
					/* 
					 * Take atomB from the one with the label with 
					 * the most atom numbers that are not -1 
					 */
					zMatrix[k].atomB = searchLabels[j].atomList[3];
			}
			if (k > 2) {
				/* 
				 * If either search label is a dihedral, take atomC 
				 * from its label.
				 */
				if (searchLabels[0].atomList[0] >= 4)
					zMatrix[k].atomC = searchLabels[0].atomList[4];
				else if (searchLabels[1].atomList[0] >= 4)
					zMatrix[k].atomC = searchLabels[1].atomList[4];
				else if (searchLabels[j].atomList[0] > 3)
					/* 
					 * Take atomC from the one with the label with 
					 * the most atom numbers that are not -1 
					 */
					zMatrix[k].atomC = searchLabels[j].atomList[4];
			}
		}
		
		/*
		 * Set flag to use existing z-matrix connectivity when 
		 * converting from cartesian coordinates to internal coordinates.
		 */
		zMatrix[1].atomA = -1;
		cartesianToInternal(coords, NAtom + numDummyAtoms, zMatrix, 
			numberBonds, bondList, atomLocation, numDummyAtoms);
		
		/* 
		 * Go through list of atoms after the search labels three 
		 * times to try and remove all colinearities from the Z Matrix.
		 */
		atom_after = searchLabels[0].atomList[1] + 1;
		if (searchLabels[1].atomList[1] >  searchLabels[0].atomList[1])
				atom_after = searchLabels[1].atomList[1] + 1;
		
		for (n = 0; n < 3; n++) {
			for (m = atom_after, colinear_3 = FALSE; 
						m < (NAtom + numDummyAtoms - 1); m++) {  
				/* 
				 * If the angle between the first three atoms of a 
				 * dihedral is nearly  0 or 180 degrees, look for 
				 * another atom to replace the first of the three.
				 * Start with the third atom, and go to the 
				 * next-to-the-last atom.
				 */
				 if (((fabs(zMatrix[m].angle - 180.) < 5.) ||
					 (fabs(zMatrix[m].angle) < 5.))  && 
					 ((NAtom + numDummyAtoms) > m)) {
					colinear_3 = TRUE;
					for (i = m + 1; i < (NAtom + numDummyAtoms); i++) {
						if ((fabs(atomAngle(coords, zMatrix[m].atomA, 
							 zMatrix[m].atomB, i)*RadianToDegree - 180.) > 5.) &&
							(fabs(atomAngle(coords, zMatrix[m].atomA, 
							 zMatrix[m].atomB, i)*RadianToDegree) > 5.)) { 
							/*
							   Restore the atom numbers in the locked labels and
							   search labels to the original
							   atom numbers.  The array atomLocation[i] contains the original
							   atom number for current atom numbered i.
							 */
							for (k = 0; k < numSearchLabels; k++) {
								for (j = searchLabels[k].atomList[0]; j > 0; j--) {
									 searchLabels[k].atomList[j] = 
									 atomLocation[searchLabels[k].atomList[j]];
								} 
							}
							for (k = 0; k < numLockedLabels; k++) {
								for (j = lockedLabels[k].atomList[0]; j > 0; j--) {
									 lockedLabels[k].atomList[j] = 
										 atomLocation[lockedLabels[k].atomList[j]];
								} 
							}

							swapAtoms(i, m, coords, atomLocation, numDummyAtoms);
							k = zMatrix[i].varyDistance;
							zMatrix[i].varyDistance = zMatrix[m].varyDistance;
							zMatrix[m].varyDistance = (short)k;
							k = zMatrix[i].varyAngle;
							zMatrix[i].varyAngle = zMatrix[m].varyAngle;
							zMatrix[m].varyAngle = (short)k;
							k = zMatrix[i].varyDihedral;
							zMatrix[i].varyDihedral = zMatrix[m].varyDihedral;
							zMatrix[m].varyDihedral = (short)k;
							
							/* renumber the labels */
							renumberSearchLabels(searchLabels, numSearchLabels,
								   NAtom + numDummyAtoms, atomLocation);
							renumberLockedLabels(lockedLabels, numLockedLabels, 
									NAtom + numDummyAtoms, atomLocation);
							cartesianToInternal(coords, NAtom + numDummyAtoms, zMatrix, 
								numberBonds, bondList, atomLocation,
								numDummyAtoms);
							break;
						} /* angle not colinear */
					}  /* i loop */
				 } /* angle nearly colinear */
			} /* m loop */
			if (!colinear_3) break; /* if no colinear atoms found, stop looking! */
		} /* n loop */
		
		/* 
		 * Check that second three atoms of dihedral angles 
		 * are not colinear
		 */
		for (m = MOPAC_MAX(3,numDummyAtoms), colinear_4 = FALSE; 
							m < (NAtom + numDummyAtoms); m++) {  
			if ((fabs(atomAngle(coords, zMatrix[m].atomA, 
				zMatrix[m].atomB, zMatrix[m].atomC)*RadianToDegree - 180.) < 5.) ||
				(fabs(atomAngle(coords, zMatrix[m].atomA, 
				zMatrix[m].atomB, zMatrix[m].atomC)*RadianToDegree) < 5.)) {
				colinear_4 = TRUE;
				break;
			}
		} /* m loop */
		
		k = searchLabels[0].atomList[1];
		if (searchLabels[0].objclsID == Atom_distID) {
			zMatrix[k].distance = searchLabels[0].lowValue;				
			zMatrix[k].varyDistance = -1;
		} 
		else if (searchLabels[0].objclsID == Bond_angID) {
			zMatrix[k].angle = searchLabels[0].lowValue;				
			zMatrix[k].varyAngle = -1;
		} 
		else if (searchLabels[0].objclsID == DihedralID) {
			zMatrix[k].dihedral = searchLabels[0].lowValue;				
			zMatrix[k].varyDihedral = -1;
		}
		k = searchLabels[1].atomList[1];
		if (searchLabels[1].objclsID == Atom_distID) {
			zMatrix[k].distance = searchLabels[1].lowValue;				
			zMatrix[k].varyDistance = -1;
		} 
		else if (searchLabels[1].objclsID == Bond_angID) {
			zMatrix[k].angle = searchLabels[1].lowValue;			
			zMatrix[k].varyAngle = -1;
		} else if (searchLabels[1].objclsID == DihedralID) {
			zMatrix[k].dihedral = searchLabels[1].lowValue;				
			zMatrix[k].varyDihedral = -1;
		}
	} /* number of search labels 1 or 2 */
	
	if (colinear_1 || colinear_2 || colinear_3 || colinear_4) {
		sprintf(errs,"Unable to organize input such that all necessary dihedral angles"
				 " are properly defined.  Because of this, your calculation may not produce"
				 " the geometry you expect.  Changing the atom numbering or bonds"
				 " within the molecule may solve the problem.");
			
		leaveBusyState();
		note_user(errs);
		enterBusyState();
	}
	/* 
	 * Put in Z matrix elements for locked atoms if the number of
	 * locked atoms is greater than zero.  This "double check" is used
	 * by Mulliken, which doesn't use Z-matrix values to lock atoms.
	 */
	if (numLockedAtoms > 0) {
		for (m = 1; m < NAtom; m++) {
			if (lockedAtoms[atomLocation[m+numDummyAtoms]]) {
				/* 
				 * Set the geometry parameters of this atom to be 
				 * relative to the
				 * dummy atoms only.
				 */
				zMatrix[m+numDummyAtoms].atomA = 2;
				zMatrix[m+numDummyAtoms].atomB = 1;
				zMatrix[m+numDummyAtoms].atomC = 0;
				/* 
					modify connectivity if there are colinearities in the first
					three atoms.  The second, third and fourth are always chosen
					to be one at the origin, one on the X axis and the third in the
					positive X-Y plane quadrant.
				*/
				if ((fabs(atomAngle(coords, zMatrix[m+numDummyAtoms].atomA, 
					zMatrix[m+numDummyAtoms].atomB, 
					m+numDummyAtoms)*RadianToDegree - 180.) < 5.) ||
					(fabs(atomAngle(coords, zMatrix[m+numDummyAtoms].atomA, 
					zMatrix[m+numDummyAtoms].atomB, 
					m+numDummyAtoms)*RadianToDegree) < 5.)) {
					alert_user_watch("cleanUpZmatrix:  Colinearity found for locked atoms.");
				}
				/* and set the coordinates not to be optimized */
				zMatrix[m+numDummyAtoms].varyDistance = 0;
				zMatrix[m+numDummyAtoms].varyAngle = 0;
				zMatrix[m+numDummyAtoms].varyDihedral = 0;
			} /* locked atom */
		} /* m loop */
	} /* numLockedAtoms > 0 */
	
	/* put in Z matrix information for locked labels */	 
	for (m = 0; m < numLockedLabels; m++) {
		/* 
		 See if this atom is the first atom in a search label or in a
		 previous locked label.  If it is, and the other label is longer,
		 don't assign the connectivity that isn't contained in the locked
		 label being processed 
		*/
		Boolean in_previous;
		long search_label_number, locked_label_number, previous_length;
		
		k = lockedLabels[m].atomList[1];
		
		in_previous = false;
		search_label_number = -1;
		locked_label_number = -1;
		previous_length = -1;
		for (j = 0; j < numSearchLabels; j++) {
			if ((k == searchLabels[j].atomList[1]) 
				&& (searchLabels[j].atomList[0] > 
					lockedLabels[m].atomList[0])) {
						in_previous = true;
				search_label_number = j;
				break;
			}
		} /* j loop */
		
		for (j = 0; j < m; j++) {
			if ((k == lockedLabels[j].atomList[1]) 
				&& (lockedLabels[j].atomList[0] > 
					lockedLabels[m].atomList[0])) {
						in_previous = true;
				locked_label_number = j;
				break;
			}
		} /* j loop */
		if (in_previous) {
			if (search_label_number != -1 && locked_label_number != -1) {
				previous_length = 
					MOPAC_MAX(searchLabels[search_label_number].atomList[0],
						lockedLabels[locked_label_number].atomList[0]);
			} 
			else if (search_label_number != -1) {
				previous_length = 
					searchLabels[search_label_number].atomList[0];
			} 
			else if (locked_label_number != -1) {
				previous_length = lockedLabels[locked_label_number].atomList[0];
			}
		} /* in previous */
		if (lockedLabels[m].atomList[0] == 2) { /* a distance label */
			zMatrix[k].varyDistance = -1;
		} 
		else if (lockedLabels[m].atomList[0] == 3) { /* an angle label */
			zMatrix[k].varyAngle = -1;
		} 
		else if (lockedLabels[m].atomList[0] == 4) { /* a dihedral label */
			zMatrix[k].varyDihedral = -1;
		} 
		else {
			alert_user_watch("cleanUpZmatrix: error in locked label");
			return (-1);
		}
		zMatrix[k].atomA = lockedLabels[m].atomList[2];
		if ((k > 1) && 
			(!in_previous || 
			(previous_length <= lockedLabels[m].atomList[0])))
			zMatrix[k].atomB = lockedLabels[m].atomList[3];
		if ((k > 2) && 
			(!in_previous || 
			(previous_length <= lockedLabels[m].atomList[0])))
			zMatrix[k].atomC = lockedLabels[m].atomList[4];
	} /* m loop */
	
	/*
	 * Perform a sanity check on the atom ordering in the Z-matrix to 
	 * verify that for search labels that the moving atom in each 
	 * label is after all the other atoms in the label.
	*/
	if (numSearchLabels > 0) {
		Boolean order_wrong;
		for (i = 0; i < numSearchLabels; i++) {
			order_wrong = false;
			n = searchLabels[i].atomList[1];
			for (j = searchLabels[i].atomList[0]; j > 1; j--) {
				k = searchLabels[i].atomList[j];
				if (k > n) order_wrong = true;
			} /* j loop */
			if (order_wrong) {
				alert_user_watch("cleanUpZmatrix: Unable to organize input to handle all search labels"
							"  Deleting one or more of the locked labels may help.");
				return (-1);
			}
		} /* i loop */
	} /* numSearchLabels > 0 */
	
	/* 
	 * Perform a sanity check on the atom ordering in the Z-matrix 
	 * to verify that for locked labels that the first atom in each 
	 * label is after all the other atoms in the label.
	 */
	if (numLockedLabels > 0) {
		Boolean order_wrong;
		for (i = 0; i < numLockedLabels; i++) {
			order_wrong = false;
			n = lockedLabels[i].atomList[1];
			for (j = lockedLabels[i].atomList[0]; j > 1; j--) {
				k = lockedLabels[i].atomList[j];
				if (k > n) order_wrong = true;
			}
			if (order_wrong) {
				alert_user_watch("cleanUpZmatrix: Unable to organize input to handle all locked labels"
							"  Deleting one or more of the locked labels may help.");
				return (-1);
			}
		} /* i loop */
	} /* numLockedLabels > 0 */
	
	/* Rebuild internal coordinate matrix if there are locked labels or locked atoms */
	if ((numLockedAtoms > 0) || (numLockedLabels > 0)) {
		
		/*
		 * Set flag to use existing z-matrix connectivity 
		 * when converting from cartesian coordinates to internal 
		 * coordinates. 
		 */
		zMatrix[1].atomA = -1;
		cartesianToInternal(coords, NAtom + numDummyAtoms, zMatrix, 
			numberBonds, bondList, atomLocation, numDummyAtoms);
		/* then reset variation flags for locked labels */
		for (m = 0; m < numLockedLabels; m++) {
			k = lockedLabels[m].atomList[1];
			if (lockedLabels[m].atomList[0] == 2) { /* a distance label */
				zMatrix[k].distance = lockedLabels[m].value;
				zMatrix[k].varyDistance = 0;
			} 
			else if (lockedLabels[m].atomList[0] == 3) { /* an angle label */
				zMatrix[k].angle = lockedLabels[m].value; 
				zMatrix[k].varyAngle = 0;
			} 
			else if (lockedLabels[m].atomList[0] == 4) { /* a dihedral label */
				zMatrix[k].dihedral = lockedLabels[m].value; 
				zMatrix[k].varyDihedral = 0;
			} 
			else {
				alert_user_watch("cleanUpZmatrix: error in locked label");
				return (-1);
			}
		} /* m loop */
		/* and reset z-matrix information for search labels */
		for (i = 0; i < numSearchLabels; i++) {
			k = searchLabels[i].atomList[1];
			if (searchLabels[i].objclsID == Atom_distID) {
			   zMatrix[k].distance = searchLabels[i].lowValue;			
			   zMatrix[k].varyDistance = -1;
			} 
			else if (searchLabels[i].objclsID == Bond_angID) {
			   zMatrix[k].angle = searchLabels[i].lowValue;				
			   zMatrix[k].varyAngle = -1;
			} 
			else if (searchLabels[i].objclsID == DihedralID) {
			   zMatrix[k].dihedral = searchLabels[i].lowValue;			
			   zMatrix[k].varyDihedral = -1;
			}
		} /* loop */
	} /* have locked labels or atoms */
	return (0);
}
