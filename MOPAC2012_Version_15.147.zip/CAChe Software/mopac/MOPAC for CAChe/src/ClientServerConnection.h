/*
 * ClientServerConnection.h
 */

#ifndef	_CLIENT_SERVER_CONNECTION_H_
#define	_CLIENT_SERVER_CONNECTION_H_

/*
 * The first version of the client and server had no version number.
 * Fillers are used to distinguish ipAddr and rport in the first versions
 * of the client and server from later versions.
 */
#define UX_VERSION_FILLER	((unsigned long)~0)

/* The client and server must have the same version. */
#define UX_VERSION_NUMBER	3

/* Debug bits in command line arguments. */
#define UX_MAIN_DEBUG	(1 << 0)
#define UX_CHM_DEBUG	(1 << 1)
#define UX_UEM_DEBUG	(1 << 2)
#define UX_FTM_DEBUG	(1 << 3)

#if SRQ_VERS == UNIX_CLIENT || SRQ_VERS == UNIX_SERVER

#define UX_COMMON_NAME_LEN	256

typedef char ux_StartResult;

struct ux_ClientInfo {
	unsigned long	filler[1];	/* set to UX_VERSION_FILLER (size of ipAddr in old client) */
	unsigned long	version;	/* set to UX_VERSION_NUMBER */
	unsigned long	ipAddr;

	char			zoneName[UX_COMMON_NAME_LEN];		/* Mac's zone name */
	char			macName[UX_COMMON_NAME_LEN];		/* Mac's name */
	char			ownerName[UX_COMMON_NAME_LEN];		/* Mac's owner name */
	char			conName[UX_COMMON_NAME_LEN];		/* connection name */
};
typedef struct ux_ClientInfo ux_ClientInfo;

struct ux_ServerInfo {
	unsigned		filler[2];	/* set to UX_VERSION_FILLER (size of rport+sport in old server) */
	unsigned long	version;	/* set to UX_VERSION_NUMBER */
	unsigned long	rport;
	unsigned long	sport;
};
typedef struct ux_ServerInfo ux_ServerInfo;

/*
 * Function prototypes
 */

#if	defined(__cplusplus)
extern "C" {
#endif

ux_Err
ux_SendClientInfo(
chm_Channel					*channel,
const struct ux_ClientInfo	*clientInfo,
unsigned long				timeout
);

ux_Err
ux_RecvClientInfo(
chm_Channel				*channel,
struct ux_ClientInfo	*clientInfo
);

ux_Err
ux_SendServerInfo(
chm_Channel				*channel,
struct ux_ServerInfo	*serverInfo
);

ux_Err
ux_RecvServerInfo(
chm_Channel				*channel,
struct ux_ServerInfo	*serverInfo,
unsigned long			timeout
);

ux_Err
ux_SendStartResult(
chm_Channel				*channel,
ux_StartResult			*startResult
);

ux_Err
ux_SimulateRexec(
chm_Channel*	channel
);

#if	defined(__cplusplus)
}
#endif

#endif

#endif	/* _CLIENT_SERVER_CONNECTION_H_ */

