#include "compat.h"
#include "ZINDODriver.h"
#include <CACheFileLib.h>

short	getCalculationType()
{
	FILE *input = NULL;
	char aString[255];
	char *cp1, *cp2;
	short type = CALCTYPE_OPT;

	if (!(input = fopen("ZINDO Input", "r"))) {
		sprintf(aString,"getCalculationType: "
				"The ZINDO Input file cannot be opened.\n");
		alert_user(aString);
		return type;
	} else {

		for (;;) {
			if (cfl_fgets(aString, sizeof(aString), input) == 0) 
				break;
			if ((cp1 = strstr(aString, "RUNTYP")) != NULL) {
				if ((cp2 = strstr(cp1, "=")) != NULL)
					cp2++;
				else
					cp2 = cp1 + 6;
				
				if (strstr(cp2, "CI") != NULL)
					type = CALCTYPE_CI;
				else if (strstr(cp2, "GEOM") != NULL)
					type = CALCTYPE_OPT;
				else if (strstr(cp2, "ENERGY") != NULL)
					type = CALCTYPE_ENERGY;

				break;
			}
		}
		
		if (type == CALCTYPE_CI) { /* See if there is symmetry */

			fseek(input, 0, 0);
			for (;;) {
				if (cfl_fgets(aString, sizeof(aString), input) == 0) 
					break;
				if ((cp1 = strstr(aString, "ASYM")) != NULL) {

					if ((cp2 = strstr(cp1, "=")) != NULL)
						cp2++;
					else
						cp2 = cp1 + 4;
					
					/*
					 * If there is a symmetry keyword, only
					 * try to write the spectrum in the molecule
					 * if there is no symmetry.
					 */
					if (strstr(cp2, "C1") != NULL)
						type = CALCTYPE_CI;
					else
						type = CALCTYPE_ENERGY;
	
					break;
				}
			}
		}
		fclose(input);
	}
	return type;
}
