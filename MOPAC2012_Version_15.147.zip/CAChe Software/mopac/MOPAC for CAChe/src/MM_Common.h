/*
** MM_Common.h --	Common includes between MM/MD, the manager
**					process, and the UI
*/

#ifndef __MM_COMMON__
#define __MM_COMMON__

#include <cul.h>
#include <SSQFileTypes.h>
#include <CACheFileLib.h>

#if defined(powerc) || defined (__powerc)
#pragma options align=mac68k
#endif
struct ControlPanel { /* Keep the length of this on 8 byte multiples */
	double Buffer;
	double EConv;
	double ITemp;
	double FTemp;
	double SimTime;
	double Timestep;
	double EqlTime;
	double BathConst;
	double BathTemp;
	double vdWcutoff;
	double dielectric;
	short NMinim;
	short IterMax;
	short Refresh;
	short EmbedAtoms;
	short DebugD;
	short OmitvdWList;
	short energySurface;
	short Batch;
	short Eunits;
	short PBound;
	short Ensemb;
	short Constraint;
	short NDynamics;
	short SampFreq;
	short PrintControl;
	short RefreshLog;
	short MM_Log;
	short MM_Details;
	short ElecMethod;
	short vdWupdate;
	char FldNam;
	char AllAtm;
	char augmented;
	char bond_stretch;
	char bond_angle;
	char dihedral;
	char improper_torsion;
	char van_der_Waals;
	char electrostatics;
	char hydrogen_bond;
        char torsion_stretch;
        char bend_bend;
	char ConfSrch;
	char Movie;
	char characterizePt;
	char SameInitVel;
	char MSname[CFL_PATH_MAX]; /* the name of the molecule file */
	char startupVolume[32]; /* the name of the startup Volume */
	char SystemFolderPath[CFL_PATH_MAX];
	char CACheSystemPath[CFL_PATH_MAX];
    char version[32];	/* the date/time of compilation of this version		*/
    char datetime[32];	/* the date and time string for the calculation		*/
    char inpbuff[256];	/* holds contents of .inp file						*/
	char ParamFileName[CFL_PATH_MAX];	/* full pathname of user specified parameter file  */
	char dummy[4];	/*  this will pad this struct out to double alignment  SYL  11/16/91	*/
};
#if defined(powerc) || defined(__powerc)
#pragma options align=reset
#endif

typedef struct ControlPanel ControlPanel, *ControlPanelPtr;

/* enumerate energySurface types */
enum energySurfaceType {
	noSurfaceType,			/* 0 */
	rigidSurfaceType,		/* 1 */
	optimizeSurfaceType,	/* 2 */
	singleSeqSearchType,	/* 3 */
	multipleSeqSearchType,	/* 4 */
	numSurfaceTypes			/* 5 */
};

/* define NMinim identifiers for optimization methods */
enum optMethodNumber {
	noOptimizationMN,		/* 0 */
	steepestDescentMN,		/* 1 */
	conjugateGradientMN,	/* 2 */
	blockDiagonalMN = 8,	/* 8 */
	newtonRaphsonMN			/* 9 */
};

/* CAChe file type definitions */
enum MM_file_type {
	MM_PARAMETERS_FILE = ssq_file_custom,
	MM_DUMMY_FILE = ssq_file_dummy
};

/* Electrostatic interaction method */
enum Elec_Method_type {
    ELEC_UNDEFINED=0,
    MM2_DIPOLES,
    PARTIAL_CHARGES,
    GASTEOGER_CHARGES,
    DELRE_CHARGES,
    IDME_CHARGES,
    PDLD_CHARGES,
    POISSON_BOLTZMANN_CHARGES,
    WODAK_CHARGES,
    MM2_DIPOLES_IN_AUGMENTED,
    CACHE_39_DIPOLE
};

/* File name communication structures */

#define MM_MAX_NUM_INPUT_FILES 4
#define MM_MAX_NUM_OUTPUT_FILES 4

struct mm_InputFileSpec
{
	long entryIsValid;	/* Boolean: indicates whether this entry is valid */
	char name[CFL_PATH_MAX];
};

typedef struct mm_InputFileSpec mm_InputFileSpec, *mm_InputFileSpecPtr;

struct mm_InputFileList
{
	unsigned int maxNumEntries;
	mm_InputFileSpec inputFileSpec[MM_MAX_NUM_INPUT_FILES];
};

typedef struct mm_InputFileList mm_InputFileList, *mm_InputFileListPtr;

/* Defines of files in above list */

#define MM_IL_SETTINGS		0		/* settings (control panel) file */
#define MM_IL_PARAMETERS	1		/* calculation parameters file */
#define MM_IL_MOLSTRUCT		2		/* file on which to work */
#define MM_IL_DATADICT		3		/* path of data dictionary */

struct mm_OutputFileSpec
{
	long outputFileCode;
	long outputFolderCode;
	long fileFormat;
	long entryIsValid;	/* Boolean: indicates whether this entry is valid */
	char name[CFL_PATH_MAX];
};

typedef struct mm_OutputFileSpec mm_OutputFileSpec, *mm_OutputFileSpecPtr;

struct mm_OutputFileList
{
	unsigned int maxNumEntries;
	mm_OutputFileSpec outputFileSpec[MM_MAX_NUM_OUTPUT_FILES];
};

typedef struct mm_OutputFileList mm_OutputFileList, *mm_OutputFileListPtr;

/* Defines of files in above list */

#define MM_OL_MOLSTRUCT		0		/* file which was minimized */
#define MM_OL_LOG			1		/* calculation log */
#define MM_OL_DETAILS		2		/* calculation details */

/* Definition of the calculation history information structure */

#define ServerNameSize 32 /* should match ssq_ServerNameSize */
typedef struct {
	char serverName[ServerNameSize];
} CalcHistInfo, *CalcHistInfoPtr;

/* Definition of the 88K Env user structure. */

#if defined(powerc) || defined (__powerc)
#pragma options align=mac68k
#endif
struct IsaacDriver88kParam {
	cul_CPMsgChannel		*msgChannelP;
	long	pgmCode;		/* Mechanics or Dynamics */
	mm_InputFileListPtr		inputFileListP;
	mm_OutputFileListPtr	outputFileListP;
	CalcHistInfoPtr			calcHistInfoP;
	char 	*applicationVersionPtr;
	char	structureIsValid;		/* indicates this structure is initialized */
	char	runFlag;				/* run when non-zero, halt when zero */
};
#if defined(powerc) || defined(__powerc)
#pragma options align=reset
#endif

typedef struct IsaacDriver88kParam IsaacDriverParam88k;

#if defined(unix) || defined(_WIN32)

/*
** Simplified Env structure for unix version -- The Env structure
** for the coprocessor and Mac versions can be found in Env.h
*/

typedef struct Environ {
	long	user[16];	/* uncommitted - for use by applications to pass flags */
} Environ, *EnvPtr;

extern volatile Environ *Env;

#endif /* unix || _WIN32 */

/* prototypes */

#if	defined(__cplusplus)
extern "C" {
#endif

Boolean
getMMsettings(FILE *controlfile, ControlPanel *controlPanel);

#if	defined(__cplusplus)
}
#endif


#endif /* __MM_COMMON__ */
