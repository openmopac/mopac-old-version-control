#include "compat.h"
#include "MOPACDriver.h"

/*************************************************************************************
 *
 *  GetDefaultParams			programmer Sam Cole 3/13/92
 *
 *  This function sets the default values of the Control structure
 *
 *	parameters		:		Control		;pointer to MOPACControl data structure.
 *
 *	calls			:		fscanf, PrintControlOpts.
 *
 *	returns			:		Boolean  TRUE if no errors, else FALSE.
 *
 ***********************************************************************************/
 
void GetDefaultParams (MOPACControl *Control)

{
/*
 *  Set all parameters to default values.
 */
 
 /* Zero EVERYTHING */
 memset(Control,0,sizeof(MOPACControl));
 
 Control->accessoryInput = TRUE;	/* return MOPAC Input file */
 Control->accessoryOutput = TRUE;	/* return MOPAC Output file */
 Control->accessoryRestart = TRUE;	/* return MOPAC Restart file */
 Control->accessoryArchive = TRUE;	/* return MOPAC Archive file */
 Control->accessoryGraphics = TRUE;	/* return MOPAC Graphics file */
 Control->accessoryDensity = TRUE;	/* return MOPAC Density file */
 Control->accessoryIsotope = TRUE;	/* save force matrix to MOPAC Restart file */
 Control->accessoryLog = TRUE;	/* save scrolling status log file */
 Control->molecularCharge = 0;		/* assume molecule is neutral */
 Control->calculate = CALCTYPE_OPTGEOM;
 Control->parameters = PARAM_AM1;
 Control->CIlevel = CILVL_DEFAULT;

 Control->geometrySearch = GEOMETH_EF;
 Control->minimizeGradient = MINGRADMETH_EF; /* use EF as the default */
 Control->multiplicity = SPINMULT_DEFAULT;		//	Marek

//	Control->geometrySearch = 1;
//	Control->minimizeGradient = 1; /* use NLLSQ as the default */
//	Control->multiplicity = SPINMULT_SINGLET;

 Control->title[0] = 0;
 Control->rotationalSymmetry = ROTSYM_C1;
 Control->maxSCFiterations = 200;
 Control->extraKeyWords[0] = 0;
 Control->scfConverger = SCF_DEFAULT; /* use the Default converger */
 Control->temperature[0] = 0;
 Control->saveHOMO = 999;
 Control->saveLUMO = 3;
 
 Control->controlRestart = false;	/* do not restart by default */

 Control->detailsMMOK = false;
 Control->detailsEnergyPart = false;
 Control->detailsESR = false;
 Control->detailsLocalize = false;
 Control->detailsMulliken = false;
 Control->detailsPI = false;
 Control->detailsPolar = false;
 Control->detailsThermo = true;
 Control->detailsBondOrder = true;
 Control->detailsDensity = false;
 Control->detailsFock = false;
 Control->detailsGradients = false;
 Control->detailsInterADist = false;
 Control->detailsXYZCoord = true;
 Control->detailsSpin = false;
 Control->detailsVectors = false;
 Control->detailsPrecise = false;
 Control->detailsLarge = false;
 Control->detailsAnalytGrad = false;
 Control->detailsExternParam = false;
 Control->detailsUseXYZ = false;

 Control->detailsKeepOrient = true;		//	Marek

 Control->detailsGeoType = INTERNAL_COORD;
 
 Control->DRCdampKinetic = false;
 Control->DRChPrio = false;
 Control->DRCtPrio = false;
 Control->DRCxPrio = false;

 Control->searchType = SRCHTYPE_RXN;

 Control->ircMode = 1;
 Control->drcIrcMode = 1;
 Control->addKEforDRC = 0.0;
 Control->halfLifeForDRC = 0.0;
 Control->hPrioStep = 0.1F;
 Control->tPrioStep = 0.1F;
 Control->xPrioStep = 0.05F;
 Control->timeLimit = 1; /* set time limit to 1 hour */
 Control->timeLimitUnits = TIMELIM_HOUR;

 Control->controlUseCosmo = false;
 Control->cosmoDielectric = 78.4;
 Control->cosmoRadius = 1.0;
 Control->cosmoSolvent[0] = 0;
 strcpy(Control->cosmoSolvent, "Water");
 Control->MOZYME = false; /* plonkaw june2000*/
 Control->CItype = CITYPE_NONE; /*plonkaw june2000*/
 Control->CIroot = 1; /*plonkaw june2000*/
}
