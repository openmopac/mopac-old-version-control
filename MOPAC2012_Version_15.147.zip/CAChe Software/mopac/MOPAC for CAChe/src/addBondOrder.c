#include  <compat.h>
#include  <memory.h>
#include  <cpu.h>
#include  <ZINDODriver.h>

/***************************************************************************************
 *
 *  Add_BondOrder			George D. Purvis III			8/28/89
 *
 *  This routine adds the bond orders calculated in a ZINDO calculation to the
 *  MolStruct.
 *
 *  To do this, it gets a list of bonds using the cpu function getBondList
 *  then it fills a triangular array, (Natoms+1)(Natoms)/2, called bondOrderDefined 
 *  with true if the there is a bond between two atoms and false if there isn't.
 *  Then it checks each element of the bondorder array. If the bond order is
 *  greater than 0.3 and the corresponding bond does not exist (i.e. the 
 *  corresponding element in bondOrderDefined is false), a new bond is 
 *  added.  The bond type is based upon the magnitude of the bondorder.
 *
 **************************************************************************************/

int  AddBondOrder (MolStruct *msPtr, DoubleH bondOrders, long nAtoms,
				   long atomLocation[], short source)
{
 long	  Idx, atom1, atom2, nLinear, ij;
 long	  bond, numberBonds;
 ObjclsID bond_offset, conn_offset;
 PropID   bondpropi, connpropi, numconnprops, numbondprops;
 long	  i, j;
 short    bondType;
 ObjectID objectnum;
 PropH	  connpropsH, bondpropsH;
 char	  errs[256];
 CharH	  bondOrderDefined = NULL;
 short	  errorCode = 0;
 ObjectID (*bondList)[2] = NULL;
 CelErr   rtn_code;

  /*
   *  Get the properties for the connector object class to
   *  set up the search for bonds.
   */
   
  if (!csu_ExistsObjclsID (msPtr, BondID, &bond_offset)) {
     if ((rtn_code = csu_AddObjcls (msPtr, BondID, &bond_offset,
				 nAtoms)) < 0)	{
	   sprintf (errs,"addBondOrder: csu_AddObjcls BondID rtn_code %d\n", rtn_code);
	   alert_user(errs);
	   return (ZINDOerrors);
	 }
  }
    

  if (!csu_ExistsObjclsID (msPtr, ConnectorID, &conn_offset)) {
     if ((rtn_code = csu_AddObjcls (msPtr, ConnectorID, &conn_offset,
				 nAtoms)) < 0)	{
	   sprintf (errs,"addBondOrder: csu_AddObjcls ConnectorID rtn_code %d\n", rtn_code);
	   alert_user(errs);
	   return (ZINDOerrors);
	 }
  }
    
  connpropsH   = (GetPtr(msPtr->objclsH) + conn_offset)->propsH;
  bondpropsH   = (GetPtr(msPtr->objclsH) + bond_offset)->propsH;
  numconnprops = (GetPtr(msPtr->objclsH) + conn_offset)->num_props;
  numbondprops = (GetPtr(msPtr->objclsH) + bond_offset)->num_props;
  
  if (!csu_ExistsPropID(connpropsH, Objcls1ID, numconnprops, &connpropi)) {
	  if ((rtn_code = csu_InstProp(msPtr->objclsH, conn_offset, Objcls1ID,
								   1, source, CSU_NAME, NoUnit, 0, &connpropi)) < 0) {
		sprintf (errs,"addBondOrder: csu_InstProp Objcls1ID rtn_code %d\n", rtn_code);
		alert_user(errs);
		return (ZINDOerrors);
	  }
  }
  connpropsH   = (GetPtr(msPtr->objclsH) + conn_offset)->propsH;

  if (!csu_ExistsPropID(connpropsH, Obj1ID, numconnprops, &connpropi)) {
	  if ((rtn_code = csu_InstProp(msPtr->objclsH, conn_offset, Obj1ID,
								   1, source, CSU_INTEGER, NoUnit, 0, &connpropi)) < 0) {
		sprintf (errs,"addBondOrder: csu_InstProp Obj1ID rtn_code %d\n", rtn_code);
		alert_user(errs);
		return (ZINDOerrors);
	  }
  }
  connpropsH   = (GetPtr(msPtr->objclsH) + conn_offset)->propsH;

  if (!csu_ExistsPropID(connpropsH, Objcls2ID, numconnprops, &connpropi)) {
	  if ((rtn_code = csu_InstProp(msPtr->objclsH, conn_offset, Objcls2ID,
								   1, source, CSU_NAME, NoUnit, 0, &connpropi)) < 0) {
		sprintf (errs,"addBondOrder: csu_InstProp Objcls2ID rtn_code %d\n", rtn_code);
		alert_user(errs);
		return (ZINDOerrors);
	  }
  }
  connpropsH   = (GetPtr(msPtr->objclsH) + conn_offset)->propsH;

  if (!csu_ExistsPropID(connpropsH, Obj2ID, numconnprops, &connpropi)) {
	  if ((rtn_code = csu_InstProp(msPtr->objclsH, conn_offset, Obj2ID,
								   1, source, CSU_INTEGER, NoUnit, 0, &connpropi)) < 0) {
		sprintf (errs,"addBondOrder: csu_InstProp Obj2ID rtn_code %d\n", rtn_code);
		alert_user(errs);
		return (ZINDOerrors);
	  }
  }
  connpropsH   = (GetPtr(msPtr->objclsH) + conn_offset)->propsH;

  if (!csu_ExistsPropID(connpropsH, DflagID, numconnprops, &connpropi)) {
	  if ((rtn_code = csu_InstProp(msPtr->objclsH, conn_offset, DflagID,
								   1, source, CSU_HEX, NoUnit, 0, &connpropi)) < 0) {
		sprintf (errs,"addBondOrder: csu_InstProp DflagID rtn_code %d\n", rtn_code);
		alert_user(errs);
		return (ZINDOerrors);
	  }
  }
  connpropsH   = (GetPtr(msPtr->objclsH) + conn_offset)->propsH;
  numconnprops = (GetPtr(msPtr->objclsH) + conn_offset)->num_props;
  (GetPtr(connpropsH) + connpropi)->srcN = source;

  if (!csu_ExistsPropID(bondpropsH, ID_ID, numbondprops, &bondpropi)) {
	  if ((rtn_code = csu_InstProp(msPtr->objclsH, bond_offset, ID_ID,
								   1, source, CSU_NAME, NoUnit, 0, &bondpropi)) < 0) {
		sprintf (errs,"addBondOrder: csu_InstProp ID_ID rtn_code %d\n", rtn_code);
		alert_user(errs);
		return (ZINDOerrors);
	  }
  }

  bondpropsH   = (GetPtr(msPtr->objclsH) + bond_offset)->propsH;
  numbondprops = (GetPtr(msPtr->objclsH) + bond_offset)->num_props;
  nLinear = (nAtoms*(nAtoms+1))/2;

  if ((bondOrderDefined = (CharH) NewHandle(nLinear*sizeof(char))) == NULL) {
	sprintf (errs,"addBondOrder: bondOrderDefined memory request %ld too large\n",
			 nLinear*sizeof(char));
	alert_user(errs);
	return (ZINDOerrors);	 
  }
  HLock((Handle) bondOrderDefined);
  for (i = 0; i < nLinear; i++) (GetPtr(bondOrderDefined))[i] = false;

  /* build the list of bonds */
  if ((numberBonds = cpu_getBondList(msPtr, &bondList)) > 0) {
	ObjectID *bondListPointer;
	
    /* Add the bond order to each bond and mark the bondOrderDefined
	   array to indicate that the bond order has already been filled
	   in.
	*/
	for (bond=0; bond<numberBonds; bond++) {
	  bondListPointer = bondList[bond];
	  atom1 = bondListPointer[0];
	  if (atom1 >= 0) {
		 atom2 = bondListPointer[1];
    
		 Idx = (atom1>atom2) ? ((atom1*(atom1+1))/2 + atom2) : ((atom2*(atom2+1))/2 + atom1);
			
		 if((rtn_code = csu_AddObjVal (msPtr, BondID, Bond_OrderID,
						bond, source,
						CSU_FLOATING, 1, NoUnit, 4, (char*)&((GetPtr(bondOrders))[Idx]),
						0, BY_INDEX)) < 0) {
		   sprintf (errs,"AddBondOrder: csu_AddObjVal rtn_code %d\n", rtn_code);
		   alert_user(errs);
		 }
		 (GetPtr(bondOrderDefined))[Idx] = true; /* indicate that this bond order is already updated */
	  }
	}
    free(bondList);
  }

  /*
   *  For each bond order greater than 0.3, search the
   *  connector array for a bond between the pair of atoms
   *  defining the bond, if the bond exists, insert a value for the
   *  bond order, otherwise, create a bond and add the appropriate connectors.
   */
   

  for (i=1, ij=1; i<nAtoms; i++, ij++) 
  	for (j=0; j<i; j++, ij++) {
    
		if ((!(GetPtr(bondOrderDefined))[ij]) && ((GetPtr(bondOrders))[ij] > 0.3)) {
  		  getUniqueID (msPtr, BondID, &objectnum);
		  if((rtn_code = csu_AddObjVal (msPtr, BondID, Bond_OrderID,
						 objectnum, source,
						 CSU_FLOATING, 1, NoUnit, 4, (char*)&((GetPtr(bondOrders))[ij]),
						 0, BY_ID)) < 0) {
			sprintf (errs,"AddBondOrder: csu_AddObjVal Bond_OrderID rtn_code %d\n", rtn_code);
			alert_user(errs);
		  }
		  bondType = 0x7005;
		  if((rtn_code = csu_AddObjVal (msPtr, BondID, RflagID,
						 objectnum, source,
						 CSU_HEX, 1, NoUnit, 0, (char *) &bondType,
						 0, BY_ID)) < 0) {
			sprintf (errs,"AddBondOrder: csu_AddObjVal RflagID rtn_code %d\n", rtn_code);
			alert_user(errs);
		  }
		  if ((rtn_code = csu_AddConnectorVal (msPtr,
									  AtomID, 
									  atomLocation[i],
		  							  BondID,
		  							  csu_ObjectIDtoIndex(msPtr, BondID, objectnum),
									  (csu_Delete2if1 | csu_Delete2ifC | 1))) < 0) {
			  sprintf (errs,"addBondOrder: csu_AddConnectorVal BondID rtn_code %d\n",
				   rtn_code);
			  alert_user(errs);
			  errorCode = ZINDOerrors;
			  goto errorReturn2;
		  }

		  if ((rtn_code = csu_AddConnectorVal (msPtr, 
									  AtomID, 
									  atomLocation[j],
		  							  BondID,
		  							  csu_ObjectIDtoIndex(msPtr, BondID, objectnum),
									  (csu_Delete2if1 | csu_Delete2ifC | 1))) < 0) {
			  sprintf (errs,"addBondOrder: csu_AddConnectorVal BondID rtn_code %d\n",
				   rtn_code);
			  alert_user(errs);
			  errorCode = ZINDOerrors;
			  goto errorReturn2;
		  }

		  if ((GetPtr(bondOrders))[ij] > 2.6) bondType = TRIPLE_B;
		    else if ((GetPtr(bondOrders))[ij] > 1.6) bondType = DOUBLE_B;
		      else if ((GetPtr(bondOrders))[ij] > .6) bondType = SINGLE_B;
		        else bondType = WEAK_B;
		  
		  if((rtn_code = csu_AddObjVal (msPtr, BondID, TypeID,
						 objectnum, source,
						 CSU_NAME, 1, NoUnit, 0, (char *) &bondType,
						 0, BY_ID)) < 0) {
			sprintf (errs,"AddBondOrder: csu_AddObjVal TypeID rtn_code %d\n", rtn_code);
			alert_user(errs);
			errorCode = ZINDOerrors;
			goto errorReturn2;
		  }			
		}
	}


errorReturn2:
  if (bondOrderDefined != NULL) {
      HUnlock((Handle) bondOrderDefined);
      DisposHandle((Handle) bondOrderDefined);
  }
  return (errorCode);
}
