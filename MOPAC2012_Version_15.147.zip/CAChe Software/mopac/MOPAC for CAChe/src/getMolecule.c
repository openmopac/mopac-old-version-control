#include <compat.h>
#include <ZINDODriver.h>

long AtomLimit = 0;
long CiLimit = 0;

long getMolecule(MolStruct *molStruct, ZINDOControl *controlPanel)
{
	long NAtom;
	ObjclsID offset;
	short *tmp_element;
	int i, rtn_code;
	char errs[256];
	long numHeavyAtoms;

	enterBusyState();

   	if ((rtn_code = csu_GetMolstruct (controlPanel->molStructName,
        							  molStruct, 1, 1)) < 0) {
		/* clean up molstruct before returning */
		csu_DeleteMolstruct(molStruct, 1, 1);
     	controlPanel->molStructName[0] = 0;
		leaveBusyState();
	    if (rtn_code != CSUInvalidMolStruct && rtn_code != CSUAllocFail)
			rtn_code = ZINDO_MOLECULE_READMS;
		return (rtn_code);
   	} else {
		if (controlPanel->title[0] == 0)
			strcpy(controlPanel->title, controlPanel->molStructName);
		controlPanel->netCharge = moleculeNetCharge(molStruct);
	}
	leaveBusyState();

	/* Do not allow user to run on a trajectory file */
	if (csu_StartMovie > 0) { /* this is a movie file */
		/* clean up molstruct and return */
		alert_user("You have selected an assemblage file.  Please "
			"select a molecule file instead.");
		csu_DeleteMolstruct(molStruct, true, true);
		return (ZINDO_MOLECULE_ASSEMBL);
	}

   	if (csu_ExistsObjclsID (molStruct, AtomID, &offset))
     	NAtom = (long) ((GetPtr(molStruct->objclsH) + offset)->num_objs);
   	else {
		/* clean up molstruct before returning */
		csu_DeleteMolstruct(molStruct, true, true);
     	return (ZINDO_MOLECULE_NOATOMS);
   	}
      
  	csu_GrabVal(molStruct, AtomID, AnumID, (char **)&tmp_element);
	
	if ((AtomLimit == 0) || (CiLimit == 0)) {

		/* If they've not been set by mam_PreProcess or makeZINDOinput, get 
		 * atom and configuration limits for computational application */

		if (getAtomLimits(&AtomLimit, &CiLimit) != 0) {
			csu_ReleaseVal (molStruct, AtomID, AnumID);
			/* clean up molstruct before returning */
			csu_DeleteMolstruct(molStruct, true, true);
			return (ZINDO_MOLECULE_ATOMLIM); 
		}
	}

	for (numHeavyAtoms = 0, i=0; i<NAtom; i++)
		numHeavyAtoms += 1;
	
	if (numHeavyAtoms > AtomLimit) {
		sprintf(errs,"ZINDO is limited to %d atoms."
		             " '%s' contains %d atoms"
					 " and a ZINDO calculation cannot be performed.",
					 AtomLimit, controlPanel->molStructName,
					 numHeavyAtoms);
		alert_user(errs);
		/* clean up molstruct before returning */
		csu_DeleteMolstruct(molStruct, true, true);
		controlPanel->molStructName[0] = 0;
		return (ZINDO_MOLECULE_TOOMANY);
	}
	
    if ((rtn_code = csu_ReleaseVal (molStruct, AtomID, AnumID)) < 0) {
       sprintf (errs," getMolecule : csu_ReleaseVal AnumID, errno %d", rtn_code);
	   alert_user(errs);
    }
	return (0L);
}
