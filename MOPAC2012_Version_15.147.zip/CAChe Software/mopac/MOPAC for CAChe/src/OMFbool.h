#ifndef __OMFbool__
#define __OMFbool__
//
// File: OMFbool.h
//
// Created: John Woods  15/03/96
//
// Workaround for absence of the <bool.h> header file and the bool type on Windows.
// Include this file instead of bool.h.
//

#ifdef WIN32

// Visual C compiler
#ifdef _MSC_VER

// Need to explicitly define for C code
#ifndef __cplusplus

typedef unsigned char bool;

#ifndef true
#define true 1
#define false 0
#endif

// C++ code
#else
// MSVC after version 5.0 has bool built in for C++
#if (_MSC_VER < 1100)

#ifndef true
#define true 1
#define false 0
#endif

#ifndef bool
#define bool int
#endif

// Version 5.0 or above
#else
#endif

#endif

#ifndef TRUE
#define TRUE 1
#define FALSE 0
#endif

// Not MS Visual C
#else
#endif

#  elif defined (unix)

#    ifndef true
#      define true 1
#      define false 0
#    endif

#    if !defined(BOOL)
#      define BOOL Boolean
#    endif

#    ifndef bool
#      define bool int
#    endif

// Not Windows
#else
#include <bool.h>
#endif

#endif // __OMFbool__
