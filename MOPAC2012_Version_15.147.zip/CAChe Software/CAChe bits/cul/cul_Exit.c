/*
**	cul_Exit.c -- exit routine
*/

#if defined(_WIN32)
#include <process.h>
#endif

#include "cul.h"

void cul_Exit(int rc)
{
#if defined(_WIN32)
    _endthreadex(rc);
#else
    exit(rc);
#endif
}
