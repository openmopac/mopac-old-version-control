/*
** cul_seconds() -- Returns the current process seconds.
**  For fairness on all machines we try to sum computation and 
**  I/O time.
*/
#include <stdio.h>

#if defined(unix)
# include <time.h>
# include <sys/types.h>
# include <sys/times.h>
double
cul_seconds(void)
{
	struct tms ts;
	times(&ts);
	return((double)(ts.tms_utime+ts.tms_stime)/CLK_TCK);
}
#endif

#if defined(_WIN32)
#include <time.h>
double
cul_seconds(void)
{
	return(((double)clock())/ CLOCKS_PER_SEC);
}
#endif

/*
 * cul_elapsedtime: pretty prints the difference between startTime and endTime into the buffer.
 */
void cul_elapsedtime( double startTime, double endTime, char *buf)
{
 	int hours,minutes = 0;
	double elapsed = endTime - startTime;
	
	if (elapsed < 0.0) {
		sprintf(buf,"0000:00:00.00");
		return;
	}
	hours = (int) (elapsed / (60.0*60.0));
	elapsed -= (float)(hours)*60.0*60.0;
	minutes = (int) (elapsed / 60.0);
	elapsed -= (float)(minutes)*60.0;
	
	if (elapsed < 10.0)
		sprintf(buf,"%04d:%02d:0%3.2f",hours,minutes,elapsed);
	else
		sprintf(buf,"%04d:%02d:%4.2f",hours,minutes,elapsed);
	
 }
