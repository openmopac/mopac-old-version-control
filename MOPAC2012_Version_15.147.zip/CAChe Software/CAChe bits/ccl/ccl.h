/*
 * ccl.h
 *
 * Declarations for Compute and Communication Library
 * Merlin R. Miller
 * Copyright 1995 CAChe Scientic,
 */

#ifndef	CCL_H
#define	CCL_H


enum ccl_Boolean {
	ccl_Boolean_False = 0,
	ccl_Boolean_True
};

enum ccl_Err {
	ccl_Err_None = 0,
	ccl_Err_Unknown = -10000,

	ccl_Err_EventInvalid,
	ccl_Err_EventTypeInvalid,
	ccl_Err_EventInitFailed,

	ccl_Err_Msg_Connection_Create_Failed,
	ccl_Err_Msg_Channel_Create_Failed,
	ccl_Err_Msg_Pipe_Create_Failed,
	ccl_Err_Msg_Send_Ack_Failed,
	ccl_Err_Msg_Recv_Ack_Failed,
	ccl_Err_Msg_Read_Failed,
	ccl_Err_Msg_Write_Failed,
	ccl_Err_Msg_Alloc_Failed,
	ccl_Err_Msg_Create_Failed
};


#endif /* CCL_H */
