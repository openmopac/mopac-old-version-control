#include <windows.h>
#include <iostream.h>
#include <stdio.h>

#include <CACheFileTypes.h>
#include <cul.h>
#include "ComputeEngine.h"

static
LRESULT
CALLBACK
ce_WndProc(
    HWND hWnd,		// window handle
    UINT message,	// type of message
    WPARAM uParam,	// additional information
    LPARAM lParam	// additional information
) {
	LRESULT			result = 0;
	ComputeEngine*	ce = (ComputeEngine*) GetWindowLong(hWnd, 0);

    switch (message) {
	case WM_PAINT:
		result = ce->WmPaint(hWnd, message, uParam, lParam);
	    break;
	case WM_COPYDATA:
		result = ce->WmCopyData(hWnd, message, uParam, lParam);
	    break;
    case WM_DESTROY:
		PostQuitMessage(0);
        break;
	default:
		result = DefWindowProc(hWnd, message, uParam, lParam);
		break;
    }

    return(result);
}

BOOL
ce_InitApplication(
	HINSTANCE	hInstance,
	const char*	szAppName,
	int			iconId
) {
    WNDCLASS  wc;

    wc.style         = 3;// Class style(s).
    wc.lpfnWndProc   = (WNDPROC)ce_WndProc;    // Window Procedure
    wc.cbClsExtra    = 0;                      // No per-class extra data.
    wc.cbWndExtra    = sizeof(void*);          // One pointer of win data.
    wc.hInstance     = hInstance;              // Owner of this class
    wc.hIcon         = LoadIcon (hInstance, MAKEINTRESOURCE(iconId));
    wc.hCursor       = LoadCursor(hInstance, IDC_ARROW);// Cursor
    wc.hbrBackground = (HBRUSH)(COLOR_WINDOW+1);// Default color
    wc.lpszMenuName  = szAppName;
    wc.lpszClassName = szAppName;              // Name to register as

    return (RegisterClass(&wc));
}

BOOL 
ce_InitInstance(
    HINSTANCE		hInstance,
    int				nCmdShow,
	const char*		szAppName,
	const char*		szTitle,
	ComputeEngine*	ce,
    HWND*			hWnd
) {

    *hWnd = CreateWindow(
            szAppName,           // See RegisterClass() call.
            szTitle,             // Text for window title bar.
            WS_OVERLAPPEDWINDOW,	// Window style.
            CW_USEDEFAULT, 0, CW_USEDEFAULT, 0, // Use default positioning
            NULL,                // Overlapped windows have no parent.
            NULL,                // Use the window class menu.
            hInstance,           // This instance owns this window.
            NULL                 // We don't use any data in our WM_CREATE
    );

    if (*hWnd == NULL)
    	return (FALSE);

	SetLastError(0);
	LONG prevLong = SetWindowLong(*hWnd, 0, (LONG)ce);
	DWORD lastError = GetLastError();
	if (prevLong == 0 && lastError != 0)
		return(FALSE);

    ShowWindow(*hWnd, SW_SHOWMINNOACTIVE); // Show the window
    UpdateWindow(*hWnd);         // Sends WM_PAINT message
	
	return (TRUE);              // We succeeded...
}

int
ce_WinMain(
    HINSTANCE	hInstance,
    HINSTANCE	hPrevInstance,
    LPSTR		lpCmdLine,
    int			nCmdShow
) {
    MSG msg;

    /* Acquire and dispatch messages until a WM_QUIT message is received. */
    while (GetMessage(&msg, NULL, 0, 0)) {
		TranslateMessage(&msg);
    	DispatchMessage(&msg);
    }

    return(msg.wParam);
}

#if	defined(CE_TEST_FRAMEWORK)

const char* const CE_APP_NAME	= CUL_STRING(CACHE_MY_NAME);
const char* const CE_WIN_TITLE	= CUL_STRING(CACHE_MY_NAME);

static ComputeEngine my_TheCE;

int CALLBACK WinMain(
    HINSTANCE hInstance,
    HINSTANCE hPrevInstance,
    LPSTR lpCmdLine,
    int nCmdShow)
{
	int		argc;
	char** 	argv;
    HWND	hWnd;
	int		result;

	argv = cul_CommandLineToArgv(GetCommandLine(), &argc);
	if (argv == NULL)
		return (FALSE);

	if (!ce_InitApplication(hInstance, CE_APP_NAME, IDI_COMPUTE_ENGINE))
		return(FALSE);

	if (!ce_InitInstance(hInstance, nCmdShow, CE_APP_NAME, CE_WIN_TITLE, &hWnd))
		return(FALSE);

	if (!my_TheCE.Init(argc, argv, hWnd))
		return(FALSE);

	result = ce_WinMain(hInstance, hPrevInstance, lpCmdLine, nCmdShow);
 
 	result = my_TheCE.Term();

	return (result);
 
    lpCmdLine; // This will prevent 'unused formal parameter' warnings
}

#endif /* CE_TEST_FRAMEWORK */
