/*
 * LogMgr.cpp
 */

#include	<stdarg.h>
#include	<string.h>
#include	<time.h>
#include	<windows.h>

#include	<SimpleExceptions.h>

#include	"LogMgr.h"

// Initialization class 

class LogMgrInit {
public:
	LogMgrInit();
	~LogMgrInit();
};

LogMgrInit::LogMgrInit()
{
	LogMgr::g_tls = TlsAlloc();
	InitializeCriticalSection(&LogMgr::g_cs);
}

LogMgrInit::~LogMgrInit()
{
	TlsFree(LogMgr::g_tls);
	DeleteCriticalSection(&LogMgr::g_cs);
}

static LogMgrInit myLogMgrInit;

// Instantiation class

DWORD				LogMgr::g_tls;
CRITICAL_SECTION	LogMgr::g_cs;

// Public member functions

LogMgr::LogMgr()
{
	memset(this, 0, sizeof(*this));
	m_state = Disabled;
	m_shouldClose = FALSE;
	m_maxLogSize = k_MaxLogSizeDefault;
}

LogMgr::LogMgr(const char* name)
{
	memset(this, 0, sizeof(*this));

	m_fp = fopen(name, "w");
	if (m_fp != NULL) {
		m_state = Enabled;
		m_shouldClose = TRUE;
		int err = setvbuf(m_fp, NULL, _IOLBF, BUFSIZ);
	} else {
		m_state = Disabled;
		m_shouldClose = FALSE;
	}

	m_fileName = new char[strlen(name) + 1];
	if (m_fileName != NULL) strcpy(m_fileName, name);
	m_maxLogSize = k_MaxLogSizeDefault;
}

LogMgr::LogMgr(FILE* fp)
{
	memset(this, 0, sizeof(*this));

	m_fp = fp;
	if (m_fp != NULL) {
		m_state = Enabled;
	} else {
		m_state = Disabled;
	}

	m_shouldClose = FALSE;
	m_maxLogSize = k_MaxLogSizeDefault;
}

LogMgr::~LogMgr()
{
	delete[] m_fileName;
	if (m_shouldClose) fclose(m_fp);
}

LogMgr::State
LogMgr::GetState()
{
	CriticalBegin();
	State state = m_state;
	CriticalEnd();
	return(state);
}

void
LogMgr::SetState(State state)
{
	CriticalBegin();
	m_state = state;
	CriticalEnd();
}

char*
LogMgr::GetTag()
{
	CriticalBegin();
	char* tag = GetTag1();
	char* tag1 = new char[strlen(tag) + 1];
	if (tag != NULL && tag1 != NULL) strcpy(tag1, tag);
	CriticalEnd();

	return(tag1);
}

void
LogMgr::SetTag(const char* tag)
{
	CriticalBegin();
	char* tag1 = new char[strlen(tag) + 1];
	if (tag1 != NULL) strcpy(tag1, tag);
	SetTag1(tag1);
	CriticalEnd();
}

FILE*
LogMgr::GetFile()
{
	CriticalBegin();
	FILE* fp = m_fp;
	CriticalEnd();
	return(fp);
}

void
LogMgr::SetFile(FILE* fp)
{
	CriticalBegin();
	if (m_shouldClose) {
		fclose(m_fp);
		delete[] m_fileName;
		m_fileName = NULL;
	}
	m_shouldClose = FALSE;
	m_fp = fp;
	CriticalEnd();
}

char*
LogMgr::GetFileName()
{
	CriticalBegin();
	char* name = new char[strlen(m_fileName) + 1];
	if (name != NULL) strcpy(name, m_fileName);
	CriticalEnd();

	return(name);
}

long
LogMgr::GetMaxLogSize()
{
	CriticalBegin();
	long maxLogSize = m_maxLogSize;
	CriticalEnd();
	return(maxLogSize);
}

void
LogMgr::SetMaxLogSize(long maxLogSize)
{
	CriticalBegin();
	m_maxLogSize = maxLogSize;
	CriticalEnd();
}

void
LogMgr::Print(const char* fmt, ...)
{
	CriticalBegin();

	SPX_TRY {

		if (m_state == Disabled || m_fp == NULL) SPX_THROW(err_disabled);

		fprintf(m_fp, "%s: ", GetTag1());

		va_list	argp;
		va_start(argp, fmt);
		vfprintf(m_fp, fmt, argp);
		va_end(argp);

	}
	SPX_CATCH(err_disabled) {
	}

	CriticalEnd();
}

void
LogMgr::VPrint(const char* fmt, va_list argp)
{
	CriticalBegin();

	SPX_TRY {

		if (m_state == Disabled || m_fp == NULL) SPX_THROW(err_disabled);

		fprintf(m_fp, "%s: ", GetTag1());
		vfprintf(m_fp, fmt, argp);

	}
	SPX_CATCH(err_disabled) {
	}

	CriticalEnd();
}

void
LogMgr::Flush()
{
	CriticalBegin();

	SPX_TRY {

		if (m_state == Disabled || m_fp == NULL) SPX_THROW(err_disabled);
		fflush(m_fp);

	}
	SPX_CATCH(err_disabled) {
	}

	CriticalEnd();
}

void
LogMgr::Rewind(const char* fmt, ...)
{
	CriticalBegin();

	SPX_TRY {

		if (m_state == Disabled || m_fp == NULL) SPX_THROW(err_disabled);
	
		Flush();

		long fpos = ftell(m_fp);
		if (fpos > m_maxLogSize) {

			rewind(m_fp);
			m_numRewinds++;

			time_t start_time = time(NULL);
			if (start_time != -1) {
				Print("%s[%d]: %s\n", m_fileName, m_numRewinds, ctime(&start_time));
			}

			va_list	argp;
			va_start(argp, fmt);
			VPrint(fmt, argp);
			va_end(argp);
 	
			Flush();

		}

	}
	SPX_CATCH(err_disabled) {
	}

	CriticalEnd();
}

// Private member functions

inline
char*
LogMgr::GetTag1()
{
	return((char*)TlsGetValue(g_tls));
}

inline
void
LogMgr::SetTag1(const char* tag)
{
	TlsSetValue(g_tls, (char*)tag);
}

inline
void
LogMgr::CriticalBegin()
{
	EnterCriticalSection(&g_cs);
}

inline
void
LogMgr::CriticalEnd()
{
	LeaveCriticalSection(&g_cs);
}

