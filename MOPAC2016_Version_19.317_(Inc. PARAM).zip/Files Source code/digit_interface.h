interface
        !     FORTRAN FUNCTION TO CONVERT NUMERIC FIELD TO DOUBLE PRECISION
        !     NUMBER.  THE STRING IS ASSUMED TO BE CLEAN (NO INVALID DIGIT
        !     OR CHARACTER COMBINATIONS FROM ISTART TO THE FIRST NONSPACE,
        !     NONDIGIT, NONSIGN, AND NONDECIMAL POINT CHARACTER).
        !
  double precision function digit (string, istart)
          !
          !.. Current Callers:
          !     reada
          !
          !.. Formal Arguments ..
      character (len=*), intent (in) :: string
      integer, intent (in) :: istart
  end function digit
end interface
