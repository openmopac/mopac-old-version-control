interface
  subroutine empirn (formla, xscale, mode, nosort)
          !
          !.. Current Callers:
          !     files
      use common_molkst
      use common_keywrd
          !
          !.. Formal Arguments ..
      character (len=90), intent (inout) :: formla
      double precision, intent (out) :: xscale
      integer, intent (in) :: mode
      integer, dimension (107), intent (inout) :: nosort
  end subroutine empirn
end interface
