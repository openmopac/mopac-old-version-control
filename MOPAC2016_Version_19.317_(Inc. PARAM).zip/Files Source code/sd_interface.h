interface
  subroutine sd (hr, info, i, k)
          !
          !.. Current Callers:
          !     files
          !
          !.. Formal Arguments ..
      character, intent (inout) :: hr
      character (len=80), intent (in) :: info
      integer, intent (in) :: i
      integer, intent (inout) :: k
  end subroutine sd
end interface
