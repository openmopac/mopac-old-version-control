interface
  subroutine tidy (a)
          !
          !.. Current Callers:
          !     files
          !
          !.. Formal Arguments ..
      character (len=80), intent (inout) :: a
  end subroutine tidy
end interface
