interface
  subroutine sort (a, ia, n, asort, mark, mend, iasort)
          !
          !.. Current Callers:
          !     files
          !
          !.. Formal Arguments ..
      integer, intent (in) :: n
      integer, dimension (n), intent (inout) :: ia, iasort, mark, mend
      double precision, dimension (n), intent (inout) :: a, asort
  end subroutine sort
end interface
