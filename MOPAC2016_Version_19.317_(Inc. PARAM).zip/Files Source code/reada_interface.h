interface
        !     FORTRAN FUNCTION TO EXTRACT NUMBER FROM STRING
        !
  double precision function reada (string, istart)
          !
          !.. Current Callers:
          !     empirn, files
          !
          !.. Formal Arguments ..
      character (len=*), intent (in) :: string
      integer, intent (in) :: istart
  end function reada
end interface
